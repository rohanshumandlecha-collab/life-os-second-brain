import React, { createContext, useContext, useState, useEffect } from 'react';
import {
  MainNav,
  PlanSubNav,
  NotesSubNav,
  LifeSubNav,
  Task,
  Project,
  Goal,
  CalendarEvent,
  Habit,
  Note,
  EnergyLog,
  FinanceItem,
  FocusSession,
  WeeklyReview,
  AutomationRule,
  AIMemoryItem,
  AppSettings,
  UniversalCapturePayload,
  AppActionProposal,
  UndoActionItem,
  AIConversation,
  AIMessage,
  HomeWidgetId,
  HomeWidgetConfig,
  LifeObject,
  LifeObjectType,
  LifeObjectRelation,
  RelationType,
  BlockItem,
  ViewType,
  TemplateItem,
  TemplateCategory,
  TemplatesSubNav,
} from '../types';
import {
  initialTasks,
  initialProjects,
  initialGoals,
  initialCalendarEvents,
  initialHabits,
  initialNotes,
  initialEnergyLogs,
  initialFinanceItems,
  initialFocusSessions,
  initialAutomations,
  initialAIMemories,
  defaultSettings,
  initialHomeWidgets,
} from '../data/initialData';
import { initialTemplates } from '../data/initialTemplates';
import { getFullTemplateCatalog } from '../data/templateCatalog';
import {
  auth,
  firebaseSignOut,
  onAuthStateChanged,
  type User,
} from '../lib/firebase';

interface Toast {
  id: string;
  message: string;
  type: 'info' | 'success' | 'warning' | 'error';
}

interface LifeOSContextType {
  // Navigation
  activeNav: MainNav;
  setActiveNav: (nav: MainNav) => void;
  planSubNav: PlanSubNav;
  setPlanSubNav: (sub: PlanSubNav) => void;
  notesSubNav: NotesSubNav;
  setNotesSubNav: (sub: NotesSubNav) => void;
  lifeSubNav: LifeSubNav;
  setLifeSubNav: (sub: LifeSubNav) => void;

  // Firebase User & Auth
  currentUser: User | null;
  signOutUser: () => Promise<void>;

  // AI Backbone Headers & Testing
  getAIHeaders: () => Record<string, string>;
  testAIConnection: (
    provider: 'gemini' | 'openai',
    apiKey: string,
    model?: string
  ) => Promise<{ ok: boolean; message: string; latencyMs?: number; error?: string }>;

  // Modals & Panels
  isCaptureOpen: boolean;
  setIsCaptureOpen: (open: boolean) => void;
  isSearchOpen: boolean;
  setIsSearchOpen: (open: boolean) => void;
  isFocusOpen: boolean;
  setIsFocusOpen: (open: boolean) => void;
  isReviewOpen: boolean;
  setIsReviewOpen: (open: boolean) => void;
  isSettingsOpen: boolean;
  setIsSettingsOpen: (open: boolean) => void;
  isHelpOpen: boolean;
  setIsHelpOpen: (open: boolean) => void;
  openHelpWithContext: (query?: string, category?: string) => void;
  isOnboardingOpen: boolean;
  setIsOnboardingOpen: (open: boolean) => void;

  // Data
  tasks: Task[];
  projects: Project[];
  goals: Goal[];
  calendarEvents: CalendarEvent[];
  habits: Habit[];
  notes: Note[];
  energyLogs: EnergyLog[];
  financeItems: FinanceItem[];
  focusSessions: FocusSession[];
  weeklyReviews: WeeklyReview[];
  automations: AutomationRule[];
  aiMemories: AIMemoryItem[];
  settings: AppSettings;
  toasts: Toast[];
  homeWidgets: HomeWidgetConfig[];
  setHomeWidgets: React.Dispatch<React.SetStateAction<HomeWidgetConfig[]>>;
  addHomeWidget: (widgetId: HomeWidgetId) => void;
  removeHomeWidget: (widgetId: HomeWidgetId) => void;
  toggleHomeWidget: (widgetId: HomeWidgetId) => void;

  // Action Handlers
  addTask: (task: Omit<Task, 'id' | 'createdAt'>) => Task;
  updateTask: (id: string, updates: Partial<Task>) => void;
  deleteTask: (id: string) => void;
  toggleTaskComplete: (id: string) => void;
  toggleSubtask: (taskId: string, subtaskId: string) => void;

  addProject: (project: Omit<Project, 'id' | 'createdAt' | 'progress'>) => Project;
  updateProject: (id: string, updates: Partial<Project>) => void;
  deleteProject: (id: string) => void;

  addGoal: (goal: Omit<Goal, 'id' | 'createdAt' | 'lastActivityAt' | 'progress'>) => Goal;
  updateGoal: (id: string, updates: Partial<Goal>) => void;
  deleteGoal: (id: string) => void;
  toggleMilestone: (goalId: string, milestoneId: string) => void;

  addCalendarEvent: (event: Omit<CalendarEvent, 'id'>) => CalendarEvent;
  updateCalendarEvent: (id: string, updates: Partial<CalendarEvent>) => void;
  deleteCalendarEvent: (id: string) => void;

  addHabit: (habit: Omit<Habit, 'id' | 'createdAt' | 'streak' | 'completedDates'>) => Habit;
  updateHabit: (id: string, updates: Partial<Habit>) => void;
  deleteHabit: (id: string) => void;
  toggleHabitDate: (id: string, dateStr: string) => void;

  addNote: (note: Omit<Note, 'id' | 'createdAt' | 'updatedAt'>) => Note;
  updateNote: (id: string, updates: Partial<Note>) => void;
  deleteNote: (id: string) => void;

  addEnergyLog: (log: Omit<EnergyLog, 'id'>) => void;
  addFinanceItem: (item: Omit<FinanceItem, 'id'>) => void;
  deleteFinanceItem: (id: string) => void;

  logFocusSession: (session: Omit<FocusSession, 'id' | 'completedAt'>) => void;
  saveWeeklyReview: (review: Omit<WeeklyReview, 'id' | 'createdAt'>) => void;

  toggleAutomation: (id: string) => void;
  addAutomation: (rule: Omit<AutomationRule, 'id'>) => void;

  addAIMemory: (mem: Omit<AIMemoryItem, 'id' | 'createdAt'>) => void;
  deleteAIMemory: (id: string) => void;
  toggleAIMemory: (id: string) => void;
  resetAIMemories: () => void;

  updateSettings: (updates: Partial<AppSettings>) => void;
  completeOnboarding: (userName: string, additionalSettings?: Partial<AppSettings>) => void;
  restartOnboarding: () => void;
  processCapture: (payload: UniversalCapturePayload) => Promise<any>;
  dismissToast: (id: string) => void;
  showToast: (message: string, type?: Toast['type']) => void;

  exportDataAsJSON: () => string;
  importDataFromJSON: (jsonStr: string) => boolean;
  resetToDefaultData: () => void;
  clearAllData: () => void;

  // AI App Action Pipeline & Undo
  undoStack: UndoActionItem[];
  executeAppAction: (proposal: AppActionProposal) => Promise<{ ok: boolean; verified: boolean; message: string; undoId?: string }>;
  undoAction: (undoId?: string) => Promise<{ ok: boolean; message: string }>;

  // Persistent Searchable AI Conversations
  aiConversations: AIConversation[];
  activeConversationId: string;
  setActiveConversationId: (id: string) => void;
  createConversation: (title?: string) => string;
  deleteConversation: (id: string) => void;
  renameConversation: (id: string, newTitle: string) => void;
  addMessageToConversation: (convoId: string, message: AIMessage) => void;
  clearConversationMessages: (convoId: string) => void;

  // Universal Life Objects Layer
  lifeObjects: LifeObject[];
  linkObjects: (sourceId: string, sourceType: LifeObjectType, targetId: string, targetType: LifeObjectType, relationType?: RelationType) => void;
  unlinkObjects: (sourceId: string, targetId: string) => void;
  updateLifeObject: (id: string, type: LifeObjectType, updates: Partial<LifeObject>) => void;

  // Multi-View State
  activeViewType: ViewType;
  setActiveViewType: (view: ViewType) => void;

  // Block-Based Notes
  updateNoteBlocks: (noteId: string, blocks: BlockItem[]) => void;

  // Templates System
  templates: TemplateItem[];
  templatesSubNav: TemplatesSubNav;
  setTemplatesSubNav: (sub: TemplatesSubNav) => void;
  selectedTemplateForPreview: TemplateItem | null;
  setSelectedTemplateForPreview: (tpl: TemplateItem | null) => void;
  isTemplateModalOpen: boolean;
  setIsTemplateModalOpen: (open: boolean) => void;
  activeTemplateForLaunch: TemplateItem | null;
  setActiveTemplateForLaunch: (tpl: TemplateItem | null) => void;
  applyTemplate: (templateId: string, variableValues?: Record<string, string>) => Promise<{
    createdIds: {
      goalId?: string;
      projectIds: string[];
      taskIds: string[];
      eventIds: string[];
      habitIds: string[];
      noteIds: string[];
      automationIds: string[];
    };
  }>;
  saveAsTemplate: (params: {
    title: string;
    description: string;
    category: TemplateCategory;
    icon?: string;
    color?: string;
    projectId?: string;
    goalId?: string;
  }) => TemplateItem;
  addTemplate: (template: Omit<TemplateItem, 'id' | 'createdAt'>) => TemplateItem;
  updateTemplate: (id: string, updates: Partial<TemplateItem>) => void;
  deleteTemplate: (id: string) => void;
  toggleTemplateFavorite: (id: string) => void;
  duplicateTemplate: (templateId: string) => TemplateItem;
  publishTemplate: (templateId: string, isPublic: boolean) => void;
  reportTemplate: (templateId: string, reason?: string) => void;
  importTemplateFromJSON: (jsonString: string) => TemplateItem | null;
  exportTemplateToJSON: (templateId: string) => string;
  generateTemplateWithAI: (prompt: string, category?: string) => Promise<TemplateItem>;

  // Automations Engine
  triggerAutomation: (event: {
    trigger: 'task_completed' | 'task_created' | 'habit_completed' | 'habit_streak' | 'project_completed' | 'time_reached' | 'capture_created';
    payload: any;
  }) => void;
}

const LifeOSContext = createContext<LifeOSContextType | null>(null);

const STORAGE_KEY = 'life_os_data_v1';

export const LifeOSProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // Navigation State
  const [activeNav, setActiveNav] = useState<MainNav>('home');
  const [planSubNav, setPlanSubNav] = useState<PlanSubNav>('calendar');
  const [notesSubNav, setNotesSubNav] = useState<NotesSubNav>('notes');
  const [lifeSubNav, setLifeSubNav] = useState<LifeSubNav>('projects');

  // Modals
  const [isCaptureOpen, setIsCaptureOpen] = useState(false);
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [isFocusOpen, setIsFocusOpen] = useState(false);
  const [isReviewOpen, setIsReviewOpen] = useState(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [isHelpOpen, setIsHelpOpen] = useState(false);
  const [isOnboardingOpen, setIsOnboardingOpen] = useState(false);

  const openHelpWithContext = (_query?: string, _category?: string) => {
    setIsHelpOpen(true);
  };

  // Toasts
  const [toasts, setToasts] = useState<Toast[]>([]);

  // Entities state with localStorage recovery
  const [tasks, setTasks] = useState<Task[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) return JSON.parse(saved).tasks || initialTasks;
    } catch (e) {}
    return initialTasks;
  });

  const [projects, setProjects] = useState<Project[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) return JSON.parse(saved).projects || initialProjects;
    } catch (e) {}
    return initialProjects;
  });

  const [goals, setGoals] = useState<Goal[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) return JSON.parse(saved).goals || initialGoals;
    } catch (e) {}
    return initialGoals;
  });

  const [calendarEvents, setCalendarEvents] = useState<CalendarEvent[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) return JSON.parse(saved).calendarEvents || initialCalendarEvents;
    } catch (e) {}
    return initialCalendarEvents;
  });

  const [habits, setHabits] = useState<Habit[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) return JSON.parse(saved).habits || initialHabits;
    } catch (e) {}
    return initialHabits;
  });

  const [notes, setNotes] = useState<Note[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) return JSON.parse(saved).notes || initialNotes;
    } catch (e) {}
    return initialNotes;
  });

  const [energyLogs, setEnergyLogs] = useState<EnergyLog[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) return JSON.parse(saved).energyLogs || initialEnergyLogs;
    } catch (e) {}
    return initialEnergyLogs;
  });

  const [financeItems, setFinanceItems] = useState<FinanceItem[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) return JSON.parse(saved).financeItems || initialFinanceItems;
    } catch (e) {}
    return initialFinanceItems;
  });

  const [focusSessions, setFocusSessions] = useState<FocusSession[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) return JSON.parse(saved).focusSessions || initialFocusSessions;
    } catch (e) {}
    return initialFocusSessions;
  });

  const [weeklyReviews, setWeeklyReviews] = useState<WeeklyReview[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) return JSON.parse(saved).weeklyReviews || [];
    } catch (e) {}
    return [];
  });

  const [automations, setAutomations] = useState<AutomationRule[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) return JSON.parse(saved).automations || initialAutomations;
    } catch (e) {}
    return initialAutomations;
  });

  const [aiMemories, setAIMemories] = useState<AIMemoryItem[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) return JSON.parse(saved).aiMemories || initialAIMemories;
    } catch (e) {}
    return initialAIMemories;
  });

  // Home Screen Widgets Configuration (persisted)
  const [homeWidgets, setHomeWidgets] = useState<HomeWidgetConfig[]>(() => {
    try {
      const saved = localStorage.getItem('life_os_home_widgets');
      if (saved) return JSON.parse(saved);
    } catch (e) {}
    return initialHomeWidgets;
  });

  useEffect(() => {
    try {
      localStorage.setItem('life_os_home_widgets', JSON.stringify(homeWidgets));
    } catch (e) {}
  }, [homeWidgets]);

  const addHomeWidget = (widgetId: HomeWidgetId) => {
    setHomeWidgets((prev) => {
      const exists = prev.find((w) => w.id === widgetId);
      if (exists) {
        return prev.map((w) => (w.id === widgetId ? { ...w, enabled: true } : w));
      }
      return [...prev, { id: widgetId, enabled: true, order: prev.length, title: widgetId }];
    });
    showToast(`Added ${widgetId === 'clock' ? 'Live Clock' : widgetId} widget to Home`, 'success');
  };

  const removeHomeWidget = (widgetId: HomeWidgetId) => {
    setHomeWidgets((prev) =>
      prev.map((w) => (w.id === widgetId ? { ...w, enabled: false } : w))
    );
    showToast(`Removed ${widgetId} widget from Home`, 'info');
  };

  const toggleHomeWidget = (widgetId: HomeWidgetId) => {
    setHomeWidgets((prev) =>
      prev.map((w) => (w.id === widgetId ? { ...w, enabled: !w.enabled } : w))
    );
  };

  // Reversible AI Action Undo Stack (persisted)
  const [undoStack, setUndoStack] = useState<UndoActionItem[]>(() => {
    try {
      const saved = localStorage.getItem('life_os_undo_stack');
      if (saved) return JSON.parse(saved);
    } catch (e) {}
    return [];
  });

  // Persistent Searchable AI Conversations
  const [aiConversations, setAiConversations] = useState<AIConversation[]>(() => {
    try {
      const saved = localStorage.getItem('life_os_ai_conversations');
      if (saved) return JSON.parse(saved);
    } catch (e) {}
    return [
      {
        id: 'convo-1',
        title: 'Executive Partner',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
        messages: [
          {
            id: 'msg-init',
            sender: 'ai',
            text: 'Hello! I am your Life OS AI Executive Partner. I have live context of your tasks, schedule, projects, goals, and habits. How can I assist you today?',
            type: 'fact',
            timestamp: 'Just now',
          },
        ],
      },
    ];
  });

  const [activeConversationId, setActiveConversationId] = useState<string>(() => {
    try {
      const savedId = localStorage.getItem('life_os_active_convo_id');
      if (savedId) return savedId;
    } catch (e) {}
    return 'convo-1';
  });

  const [currentUser, setCurrentUser] = useState<User | null>(null);

  const [settings, setSettings] = useState<AppSettings>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      const hasCompletedFirstTime = localStorage.getItem('lifeos_first_time_onboarded') === 'true';
      const localGeminiKey = localStorage.getItem('life_os_gemini_api_key') || '';
      const localOpenaiKey = localStorage.getItem('life_os_openai_api_key') || '';
      const localProvider = (localStorage.getItem('life_os_ai_provider') as any) || 'gemini';
      const localGeminiModel = localStorage.getItem('life_os_gemini_model') || 'gemini-3.6-flash';
      const localOpenaiModel = localStorage.getItem('life_os_openai_model') || 'gpt-4o-mini';

      if (saved && JSON.parse(saved).settings) {
        const parsed = JSON.parse(saved).settings;
        return {
          ...defaultSettings,
          ...parsed,
          geminiApiKey: localGeminiKey || parsed.geminiApiKey || '',
          openaiApiKey: localOpenaiKey || parsed.openaiApiKey || '',
          preferredAIProvider: localProvider || parsed.preferredAIProvider || 'gemini',
          geminiModel: localGeminiModel || parsed.geminiModel || 'gemini-3.6-flash',
          openaiModel: localOpenaiModel || parsed.openaiModel || 'gpt-4o-mini',
          onboardingCompleted: hasCompletedFirstTime && Boolean(parsed.onboardingCompleted),
        };
      }
      return {
        ...defaultSettings,
        geminiApiKey: localGeminiKey,
        openaiApiKey: localOpenaiKey,
        preferredAIProvider: localProvider,
        geminiModel: localGeminiModel,
        openaiModel: localOpenaiModel,
      };
    } catch (e) {}
    return defaultSettings;
  });

  // Listen to Firebase Auth state
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (user) => {
      setCurrentUser(user);
      if (user) {
        setSettings((prev) => ({
          ...prev,
          userName: prev.userName || user.displayName || 'Google User',
          userEmail: user.email || prev.userEmail,
          userAvatar: user.photoURL || prev.userAvatar,
          authProvider: 'google',
        }));
      }
    });
    return () => unsubscribe();
  }, []);

  // Autosave
  useEffect(() => {
    try {
      const bundle = {
        tasks,
        projects,
        goals,
        calendarEvents,
        habits,
        notes,
        energyLogs,
        financeItems,
        focusSessions,
        weeklyReviews,
        automations,
        aiMemories,
        settings,
      };
      localStorage.setItem(STORAGE_KEY, JSON.stringify(bundle));
    } catch (e) {
      console.warn('LocalStorage autosave failed:', e);
    }
  }, [
    tasks,
    projects,
    goals,
    calendarEvents,
    habits,
    notes,
    energyLogs,
    financeItems,
    focusSessions,
    weeklyReviews,
    automations,
    aiMemories,
    settings,
  ]);

  // Persist undo stack and conversations
  useEffect(() => {
    try {
      localStorage.setItem('life_os_undo_stack', JSON.stringify(undoStack));
    } catch (e) {}
  }, [undoStack]);

  useEffect(() => {
    try {
      localStorage.setItem('life_os_ai_conversations', JSON.stringify(aiConversations));
      localStorage.setItem('life_os_active_convo_id', activeConversationId);
    } catch (e) {}
  }, [aiConversations, activeConversationId]);

  // Multi-View State ('list' | 'board' | 'calendar' | 'timeline' | 'table')
  const [activeViewType, setActiveViewType] = useState<ViewType>(() => {
    try {
      const saved = localStorage.getItem('life_os_view_type');
      if (saved && ['list', 'board', 'calendar', 'timeline', 'table'].includes(saved)) {
        return saved as ViewType;
      }
    } catch (e) {}
    return 'list';
  });

  useEffect(() => {
    try {
      localStorage.setItem('life_os_view_type', activeViewType);
    } catch (e) {}
  }, [activeViewType]);

  // Templates System State
  const [templates, setTemplates] = useState<TemplateItem[]>(() => {
    const catalog = getFullTemplateCatalog();
    try {
      const savedUserCustom = localStorage.getItem('life_os_user_custom_templates');
      if (savedUserCustom) {
        const parsed = JSON.parse(savedUserCustom);
        if (Array.isArray(parsed) && parsed.length > 0) {
          const userIds = new Set(parsed.map((p) => p.id));
          return [...parsed, ...catalog.filter((t) => !userIds.has(t.id))];
        }
      }
    } catch (e) {}
    return catalog;
  });

  const [templatesSubNav, setTemplatesSubNav] = useState<TemplatesSubNav>('featured');
  const [selectedTemplateForPreview, setSelectedTemplateForPreview] = useState<TemplateItem | null>(null);
  const [isTemplateModalOpen, setIsTemplateModalOpen] = useState(false);
  const [activeTemplateForLaunch, setActiveTemplateForLaunch] = useState<TemplateItem | null>(null);

  useEffect(() => {
    try {
      // Persist user-created, customized, or modified templates
      const userCustom = templates.filter((t) => !t.isBuiltIn || t.isFavorite || t.isReported || t.recentlyUsedAt);
      localStorage.setItem('life_os_user_custom_templates', JSON.stringify(userCustom));
    } catch (e) {}
  }, [templates]);

  // Central Theme Synchronization & System Preference Detection
  useEffect(() => {
    const applyTheme = () => {
      const mode = settings.theme || 'system';
      const systemDark =
        typeof window !== 'undefined' &&
        window.matchMedia &&
        window.matchMedia('(prefers-color-scheme: dark)').matches;
      const isDark = mode === 'dark' || (mode === 'system' && systemDark);

      if (isDark) {
        document.documentElement.classList.add('dark');
        document.documentElement.setAttribute('data-theme', 'dark');
        document.documentElement.style.colorScheme = 'dark';
      } else {
        document.documentElement.classList.remove('dark');
        document.documentElement.setAttribute('data-theme', 'light');
        document.documentElement.style.colorScheme = 'light';
      }

      try {
        localStorage.setItem('life_os_theme', mode);
      } catch (e) {}
    };

    applyTheme();

    if (typeof window !== 'undefined' && window.matchMedia) {
      const mediaQuery = window.matchMedia('(prefers-color-scheme: dark)');
      const handleSystemChange = () => {
        if (settings.theme === 'system') {
          applyTheme();
        }
      };

      if (mediaQuery.addEventListener) {
        mediaQuery.addEventListener('change', handleSystemChange);
        return () => mediaQuery.removeEventListener('change', handleSystemChange);
      } else if ((mediaQuery as any).addListener) {
        (mediaQuery as any).addListener(handleSystemChange);
        return () => (mediaQuery as any).removeListener(handleSystemChange);
      }
    }
  }, [settings.theme]);

  // Global hotkeys (Cmd+K / Ctrl+K for search, C for quick capture)
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Don't intercept when user is typing in form inputs
      const target = e.target as HTMLElement;
      if (target && ['INPUT', 'TEXTAREA', 'SELECT'].includes(target.tagName)) {
        return;
      }

      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault();
        setIsSearchOpen((prev) => !prev);
      } else if (e.key.toLowerCase() === 'c' && !e.metaKey && !e.ctrlKey) {
        e.preventDefault();
        setIsCaptureOpen(true);
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  const showToast = (message: string, type: Toast['type'] = 'info') => {
    const id = 'toast-' + Math.random().toString(36).substring(2, 9);
    setToasts((prev) => [...prev, { id, message, type }]);
    setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== id));
    }, 4000);
  };

  const dismissToast = (id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  };

  // Task Actions
  const addTask = (taskInput: Omit<Task, 'id' | 'createdAt'>): Task => {
    const newTask: Task = {
      ...taskInput,
      id: 'task-' + Date.now(),
      createdAt: new Date().toISOString(),
    };
    setTasks((prev) => [newTask, ...prev]);
    showToast(`Task added: "${newTask.title}"`, 'success');
    return newTask;
  };

  const updateTask = (id: string, updates: Partial<Task>) => {
    setTasks((prev) => prev.map((t) => (t.id === id ? { ...t, ...updates } : t)));
  };

  const deleteTask = (id: string) => {
    setTasks((prev) => prev.filter((t) => t.id !== id));
    showToast('Task removed', 'info');
  };

  const toggleTaskComplete = (id: string) => {
    setTasks((prev) =>
      prev.map((t) => {
        if (t.id !== id) return t;
        const isDone = t.status === 'completed';
        const newStatus = isDone ? 'today' : 'completed';
        const completedAt = isDone ? undefined : new Date().toISOString();

        // Check if automation triggers project progress recalculation
        if (!isDone && t.projectId) {
          setTimeout(() => recalculateProjectProgress(t.projectId!), 50);
        }

        return { ...t, status: newStatus, completedAt };
      })
    );
  };

  const toggleSubtask = (taskId: string, subtaskId: string) => {
    setTasks((prev) =>
      prev.map((t) => {
        if (t.id !== taskId) return t;
        const updatedSubs = t.subtasks.map((st) =>
          st.id === subtaskId ? { ...st, completed: !st.completed } : st
        );
        return { ...t, subtasks: updatedSubs };
      })
    );
  };

  // Project Actions
  const recalculateProjectProgress = (projectId: string) => {
    setProjects((prev) =>
      prev.map((p) => {
        if (p.id !== projectId) return p;
        const pTasks = tasks.filter((t) => t.projectId === projectId);
        if (pTasks.length === 0) return p;
        const done = pTasks.filter((t) => t.status === 'completed').length;
        const pct = Math.round((done / pTasks.length) * 100);
        return { ...p, progress: pct };
      })
    );
  };

  const addProject = (projectInput: Omit<Project, 'id' | 'createdAt' | 'progress'>): Project => {
    const newProj: Project = {
      ...projectInput,
      id: 'proj-' + Date.now(),
      progress: 0,
      createdAt: new Date().toISOString(),
    };
    setProjects((prev) => [newProj, ...prev]);
    showToast(`Project created: "${newProj.title}"`, 'success');
    return newProj;
  };

  const updateProject = (id: string, updates: Partial<Project>) => {
    setProjects((prev) => prev.map((p) => (p.id === id ? { ...p, ...updates } : p)));
  };

  const deleteProject = (id: string) => {
    setProjects((prev) => prev.filter((p) => p.id !== id));
    showToast('Project deleted', 'info');
  };

  // Goal Actions
  const addGoal = (goalInput: Omit<Goal, 'id' | 'createdAt' | 'lastActivityAt' | 'progress'>): Goal => {
    const newGoal: Goal = {
      ...goalInput,
      id: 'goal-' + Date.now(),
      progress: 0,
      lastActivityAt: new Date().toISOString(),
      createdAt: new Date().toISOString(),
    };
    setGoals((prev) => [newGoal, ...prev]);
    showToast(`Goal established: "${newGoal.title}"`, 'success');
    return newGoal;
  };

  const updateGoal = (id: string, updates: Partial<Goal>) => {
    setGoals((prev) =>
      prev.map((g) =>
        g.id === id ? { ...g, ...updates, lastActivityAt: new Date().toISOString() } : g
      )
    );
  };

  const deleteGoal = (id: string) => {
    setGoals((prev) => prev.filter((g) => g.id !== id));
    showToast('Goal removed', 'info');
  };

  const toggleMilestone = (goalId: string, milestoneId: string) => {
    setGoals((prev) =>
      prev.map((g) => {
        if (g.id !== goalId) return g;
        const milestones = g.milestones.map((m) =>
          m.id === milestoneId ? { ...m, completed: !m.completed } : m
        );
        const done = milestones.filter((m) => m.completed).length;
        const progress = milestones.length > 0 ? Math.round((done / milestones.length) * 100) : g.progress;
        return { ...g, milestones, progress, lastActivityAt: new Date().toISOString() };
      })
    );
  };

  // Calendar
  const addCalendarEvent = (eventInput: Omit<CalendarEvent, 'id'>): CalendarEvent => {
    const newEvent: CalendarEvent = {
      ...eventInput,
      id: 'cal-' + Date.now(),
    };
    setCalendarEvents((prev) => [...prev, newEvent]);
    showToast(`Scheduled: "${newEvent.title}"`, 'success');
    return newEvent;
  };

  const updateCalendarEvent = (id: string, updates: Partial<CalendarEvent>) => {
    setCalendarEvents((prev) => prev.map((e) => (e.id === id ? { ...e, ...updates } : e)));
  };

  const deleteCalendarEvent = (id: string) => {
    setCalendarEvents((prev) => prev.filter((e) => e.id !== id));
  };

  // Habits
  const addHabit = (habitInput: Omit<Habit, 'id' | 'createdAt' | 'streak' | 'completedDates'>): Habit => {
    const newHabit: Habit = {
      ...habitInput,
      id: 'habit-' + Date.now(),
      streak: 0,
      completedDates: [],
      createdAt: new Date().toISOString(),
    };
    setHabits((prev) => [...prev, newHabit]);
    showToast(`Habit created: "${newHabit.title}"`, 'success');
    return newHabit;
  };

  const updateHabit = (id: string, updates: Partial<Habit>) => {
    setHabits((prev) => prev.map((h) => (h.id === id ? { ...h, ...updates } : h)));
  };

  const deleteHabit = (id: string) => {
    setHabits((prev) => prev.filter((h) => h.id !== id));
  };

  const toggleHabitDate = (id: string, dateStr: string) => {
    setHabits((prev) =>
      prev.map((h) => {
        if (h.id !== id) return h;
        const exists = h.completedDates.includes(dateStr);
        const completedDates = exists
          ? h.completedDates.filter((d) => d !== dateStr)
          : [...h.completedDates, dateStr];

        // Recalculate streak
        const streak = exists ? Math.max(0, h.streak - 1) : h.streak + 1;
        return { ...h, completedDates, streak };
      })
    );
  };

  // Notes
  const addNote = (noteInput: Omit<Note, 'id' | 'createdAt' | 'updatedAt'>): Note => {
    const newNote: Note = {
      ...noteInput,
      id: 'note-' + Date.now(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    setNotes((prev) => [newNote, ...prev]);
    showToast(`Saved to Second Brain: "${newNote.title}"`, 'success');
    return newNote;
  };

  const updateNote = (id: string, updates: Partial<Note>) => {
    setNotes((prev) =>
      prev.map((n) =>
        n.id === id ? { ...n, ...updates, updatedAt: new Date().toISOString() } : n
      )
    );
  };

  const deleteNote = (id: string) => {
    setNotes((prev) => prev.filter((n) => n.id !== id));
    showToast('Note deleted', 'info');
  };

  // Energy & Finance
  const addEnergyLog = (log: Omit<EnergyLog, 'id'>) => {
    const newLog: EnergyLog = { ...log, id: 'energy-' + Date.now() };
    setEnergyLogs((prev) => [newLog, ...prev]);
    showToast('Energy check-in recorded', 'info');
  };

  const addFinanceItem = (item: Omit<FinanceItem, 'id'>) => {
    const newItem: FinanceItem = { ...item, id: 'fin-' + Date.now() };
    setFinanceItems((prev) => [newItem, ...prev]);
    showToast(`${newItem.type === 'income' ? 'Income' : 'Expense'} recorded`, 'success');
  };

  const deleteFinanceItem = (id: string) => {
    setFinanceItems((prev) => prev.filter((f) => f.id !== id));
  };

  // Focus
  const logFocusSession = (session: Omit<FocusSession, 'id' | 'completedAt'>) => {
    const newSession: FocusSession = {
      ...session,
      id: 'focus-' + Date.now(),
      completedAt: new Date().toISOString(),
    };
    setFocusSessions((prev) => [newSession, ...prev]);
    showToast(`Focus block completed: ${newSession.durationMinutes}m`, 'success');
  };

  // Reviews
  const saveWeeklyReview = (review: Omit<WeeklyReview, 'id' | 'createdAt'>) => {
    const newReview: WeeklyReview = {
      ...review,
      id: 'review-' + Date.now(),
      createdAt: new Date().toISOString(),
    };
    setWeeklyReviews((prev) => [newReview, ...prev]);
    showToast('Weekly review recorded', 'success');
  };

  // Automations
  const toggleAutomation = (id: string) => {
    setAutomations((prev) =>
      prev.map((a) => (a.id === id ? { ...a, enabled: !a.enabled } : a))
    );
  };

  const addAutomation = (rule: Omit<AutomationRule, 'id'>) => {
    const newRule: AutomationRule = { ...rule, id: 'auto-' + Date.now() };
    setAutomations((prev) => [...prev, newRule]);
    showToast(`Automation created: "${newRule.title}"`, 'success');
  };

  // AI Memory
  const addAIMemory = (mem: Omit<AIMemoryItem, 'id' | 'createdAt'>) => {
    const newMem: AIMemoryItem = {
      ...mem,
      id: 'mem-' + Date.now(),
      createdAt: new Date().toISOString(),
    };
    setAIMemories((prev) => [newMem, ...prev]);
    showToast('AI memory recorded', 'info');
  };

  const deleteAIMemory = (id: string) => {
    setAIMemories((prev) => prev.filter((m) => m.id !== id));
    showToast('AI memory deleted', 'info');
  };

  const toggleAIMemory = (id: string) => {
    setAIMemories((prev) =>
      prev.map((m) => (m.id === id ? { ...m, active: !m.active } : m))
    );
  };

  const resetAIMemories = () => {
    setAIMemories([]);
    showToast('All AI memories cleared', 'info');
  };

  // -------------------------------------------------------------
  // Universal Life Objects Layer
  // -------------------------------------------------------------
  const lifeObjects = React.useMemo<LifeObject[]>(() => {
    const list: LifeObject[] = [];

    tasks.forEach((t) => {
      const rels: LifeObjectRelation[] = [];
      if (t.projectId) {
        const p = projects.find((x) => x.id === t.projectId);
        rels.push({
          id: `rel-${t.id}-${t.projectId}`,
          targetId: t.projectId,
          targetType: 'project',
          relationType: 'project_of',
          targetTitle: p?.title,
        });
      }
      if (t.goalId) {
        const g = goals.find((x) => x.id === t.goalId);
        rels.push({
          id: `rel-${t.id}-${t.goalId}`,
          targetId: t.goalId,
          targetType: 'goal',
          relationType: 'child',
          targetTitle: g?.title,
        });
      }
      list.push({
        id: t.id,
        type: 'task',
        title: t.title,
        description: t.description,
        status: t.status,
        priority: t.priority,
        dueDate: t.dueDate,
        durationMinutes: t.durationMinutes,
        energyRequired: t.energyRequired,
        tags: t.tags || [],
        subtasks: t.subtasks,
        relations: rels,
        createdAt: t.createdAt,
        updatedAt: t.createdAt,
      });
    });

    notes.forEach((n) => {
      const rels: LifeObjectRelation[] = [...(n.relations || [])];
      (n.linkedProjectIds || []).forEach((pid) => {
        if (!rels.some((r) => r.targetId === pid)) {
          const p = projects.find((x) => x.id === pid);
          rels.push({
            id: `rel-${n.id}-${pid}`,
            targetId: pid,
            targetType: 'project',
            relationType: 'linked',
            targetTitle: p?.title,
          });
        }
      });
      (n.linkedTaskIds || []).forEach((tid) => {
        if (!rels.some((r) => r.targetId === tid)) {
          const t = tasks.find((x) => x.id === tid);
          rels.push({
            id: `rel-${n.id}-${tid}`,
            targetId: tid,
            targetType: 'task',
            relationType: 'linked',
            targetTitle: t?.title,
          });
        }
      });
      list.push({
        id: n.id,
        type: n.type === 'knowledge' ? 'knowledge' : 'note',
        title: n.title,
        description: n.content ? n.content.slice(0, 160) : undefined,
        tags: n.tags || [],
        blocks: n.blocks,
        relations: rels,
        isPinned: n.isPinned || n.pinned,
        createdAt: n.createdAt,
        updatedAt: n.updatedAt,
      });
    });

    goals.forEach((g) => {
      const rels: LifeObjectRelation[] = [];
      tasks
        .filter((t) => t.goalId === g.id)
        .forEach((t) => {
          rels.push({
            id: `rel-${g.id}-${t.id}`,
            targetId: t.id,
            targetType: 'task',
            relationType: 'parent',
            targetTitle: t.title,
          });
        });
      projects
        .filter((p) => p.goalId === g.id)
        .forEach((p) => {
          rels.push({
            id: `rel-${g.id}-${p.id}`,
            targetId: p.id,
            targetType: 'project',
            relationType: 'parent',
            targetTitle: p.title,
          });
        });
      list.push({
        id: g.id,
        type: 'goal',
        title: g.title,
        description: g.vision,
        status: g.status,
        targetDate: g.targetDate,
        progress: g.progress,
        tags: [g.area],
        relations: rels,
        createdAt: g.createdAt,
        updatedAt: g.lastActivityAt || g.createdAt,
      });
    });

    projects.forEach((p) => {
      const rels: LifeObjectRelation[] = [];
      if (p.goalId) {
        const g = goals.find((x) => x.id === p.goalId);
        rels.push({
          id: `rel-${p.id}-${p.goalId}`,
          targetId: p.goalId,
          targetType: 'goal',
          relationType: 'milestone_of',
          targetTitle: g?.title,
        });
      }
      tasks
        .filter((t) => t.projectId === p.id)
        .forEach((t) => {
          rels.push({
            id: `rel-${p.id}-${t.id}`,
            targetId: t.id,
            targetType: 'task',
            relationType: 'parent',
            targetTitle: t.title,
          });
        });
      list.push({
        id: p.id,
        type: 'project',
        title: p.title,
        description: p.description,
        status: p.status,
        dueDate: p.deadline,
        progress: p.progress,
        tags: p.tags || [],
        relations: rels,
        createdAt: p.createdAt,
        updatedAt: p.createdAt,
      });
    });

    habits.forEach((h) => {
      const rels: LifeObjectRelation[] = [];
      if (h.goalId) {
        const g = goals.find((x) => x.id === h.goalId);
        rels.push({
          id: `rel-${h.id}-${h.goalId}`,
          targetId: h.goalId,
          targetType: 'goal',
          relationType: 'habit_for',
          targetTitle: g?.title,
        });
      }
      list.push({
        id: h.id,
        type: 'habit',
        title: h.title,
        status: h.streak > 0 ? 'active' : 'pending',
        tags: [h.category],
        relations: rels,
        createdAt: h.createdAt,
        updatedAt: h.createdAt,
      });
    });

    calendarEvents.forEach((e) => {
      const rels: LifeObjectRelation[] = [];
      if (e.taskId) {
        const t = tasks.find((x) => x.id === e.taskId);
        rels.push({
          id: `rel-${e.id}-${e.taskId}`,
          targetId: e.taskId,
          targetType: 'task',
          relationType: 'linked',
          targetTitle: t?.title,
        });
      }
      list.push({
        id: e.id,
        type: 'event',
        title: e.title,
        description: e.notes,
        date: e.date,
        startTime: e.startTime,
        endTime: e.endTime,
        energyRequired: e.energyRequired,
        tags: [e.type],
        relations: rels,
        createdAt: e.date,
        updatedAt: e.date,
      });
    });

    return list;
  }, [tasks, notes, goals, projects, habits, calendarEvents]);

  const linkObjects = (
    sourceId: string,
    sourceType: LifeObjectType,
    targetId: string,
    targetType: LifeObjectType,
    relationType: RelationType = 'linked'
  ) => {
    if (sourceType === 'task' && targetType === 'project') {
      updateTask(sourceId, { projectId: targetId });
    } else if (sourceType === 'task' && targetType === 'goal') {
      updateTask(sourceId, { goalId: targetId });
    } else if (sourceType === 'project' && targetType === 'goal') {
      updateProject(sourceId, { goalId: targetId });
    } else if (sourceType === 'note') {
      const note = notes.find((n) => n.id === sourceId);
      if (note) {
        const existingRels = note.relations || [];
        if (!existingRels.some((r) => r.targetId === targetId)) {
          const targetObj = lifeObjects.find((o) => o.id === targetId);
          const newRel: LifeObjectRelation = {
            id: `rel-${Date.now()}`,
            targetId,
            targetType,
            relationType,
            targetTitle: targetObj?.title,
          };
          updateNote(sourceId, {
            relations: [...existingRels, newRel],
            linkedProjectIds:
              targetType === 'project'
                ? Array.from(new Set([...(note.linkedProjectIds || []), targetId]))
                : note.linkedProjectIds,
            linkedTaskIds:
              targetType === 'task'
                ? Array.from(new Set([...(note.linkedTaskIds || []), targetId]))
                : note.linkedTaskIds,
          });
        }
      }
    }
    showToast('Life objects connected', 'success');
  };

  const unlinkObjects = (sourceId: string, targetId: string) => {
    const task = tasks.find((t) => t.id === sourceId);
    if (task) {
      if (task.projectId === targetId) updateTask(sourceId, { projectId: undefined });
      if (task.goalId === targetId) updateTask(sourceId, { goalId: undefined });
    }
    const note = notes.find((n) => n.id === sourceId);
    if (note) {
      updateNote(sourceId, {
        relations: (note.relations || []).filter((r) => r.targetId !== targetId),
        linkedProjectIds: (note.linkedProjectIds || []).filter((id) => id !== targetId),
        linkedTaskIds: (note.linkedTaskIds || []).filter((id) => id !== targetId),
      });
    }
    const proj = projects.find((p) => p.id === sourceId);
    if (proj && proj.goalId === targetId) {
      updateProject(sourceId, { goalId: undefined });
    }
    showToast('Connection unlinked', 'info');
  };

  const updateLifeObject = (id: string, type: LifeObjectType, updates: Partial<LifeObject>) => {
    switch (type) {
      case 'task':
        updateTask(id, updates as Partial<Task>);
        break;
      case 'note':
      case 'knowledge':
        updateNote(id, updates as Partial<Note>);
        break;
      case 'goal':
        updateGoal(id, updates as Partial<Goal>);
        break;
      case 'project':
        updateProject(id, updates as Partial<Project>);
        break;
      case 'habit':
        updateHabit(id, updates as Partial<Habit>);
        break;
      case 'event':
        updateCalendarEvent(id, updates as Partial<CalendarEvent>);
        break;
      default:
        break;
    }
  };

  // Block-Based Notes Helper
  const updateNoteBlocks = (noteId: string, blocks: BlockItem[]) => {
    const mdLines = blocks.map((b) => {
      switch (b.type) {
        case 'heading1':
          return `# ${b.content}`;
        case 'heading2':
          return `## ${b.content}`;
        case 'heading3':
          return `### ${b.content}`;
        case 'todo':
          return `- [${b.checked ? 'x' : ' '}] ${b.content}`;
        case 'bullet':
          return `- ${b.content}`;
        case 'numbered':
          return `1. ${b.content}`;
        case 'quote':
          return `> ${b.content}`;
        case 'callout':
          return `> 💡 ${b.content}`;
        case 'code':
          return `\`\`\`${b.language || ''}\n${b.content}\n\`\`\``;
        case 'divider':
          return `---`;
        case 'relation_embed':
          return `[[embed:${b.relatedObjectId || ''}|${b.content}]]`;
        default:
          return b.content;
      }
    });

    const content = mdLines.join('\n\n');
    updateNote(noteId, { blocks, content });
  };

  // -------------------------------------------------------------
  // Real When -> If -> Then Automations Engine
  // -------------------------------------------------------------
  const triggerAutomation = (event: {
    trigger: 'task_completed' | 'task_created' | 'habit_completed' | 'habit_streak' | 'project_completed' | 'time_reached' | 'capture_created';
    payload: any;
  }) => {
    automations
      .filter((a) => a.enabled)
      .forEach((rule) => {
        const matchesTrigger =
          rule.whenTrigger === event.trigger ||
          (event.trigger === 'task_completed' && rule.trigger.toLowerCase().includes('task')) ||
          (event.trigger === 'habit_completed' && rule.trigger.toLowerCase().includes('habit'));

        if (!matchesTrigger) return;

        let conditionMet = true;
        if (rule.ifCondition) {
          const val = event.payload?.[rule.ifCondition.field];
          if (rule.ifCondition.operator === 'equals') {
            conditionMet = val === rule.ifCondition.value;
          } else if (rule.ifCondition.operator === 'contains') {
            conditionMet = String(val || '').toLowerCase().includes(String(rule.ifCondition.value).toLowerCase());
          } else if (rule.ifCondition.operator === 'greater_than') {
            conditionMet = Number(val) >= Number(rule.ifCondition.value);
          }
        }

        if (!conditionMet) return;

        if (rule.thenAction) {
          const { type, params } = rule.thenAction;
          if (type === 'show_toast') {
            showToast(params.message || `Automation triggered: ${rule.title}`, params.type || 'info');
          } else if (type === 'create_task') {
            addTask({
              title: params.title || `Follow up: ${rule.title}`,
              status: params.status || 'today',
              priority: params.priority || 'medium',
              subtasks: [],
              tags: ['automation'],
            });
          } else if (type === 'create_note') {
            addNote({
              title: params.title || `Log: ${rule.title}`,
              content: params.content || `Automated log recorded on ${new Date().toLocaleString()}`,
              type: 'note',
              tags: ['automated-log'],
              backlinks: [],
            });
          }
        } else {
          showToast(`⚡ Automation: "${rule.title}"`, 'info');
        }

        setAutomations((prev) =>
          prev.map((a) =>
            a.id === rule.id
              ? {
                  ...a,
                  lastTriggeredAt: new Date().toISOString(),
                  executionCount: (a.executionCount || 0) + 1,
                }
              : a
          )
        );
      });
  };

  // -------------------------------------------------------------
  // Template System Implementation
  // -------------------------------------------------------------
  const addTemplate = (template: Omit<TemplateItem, 'id' | 'createdAt'>): TemplateItem => {
    const newTpl: TemplateItem = {
      ...template,
      id: 'tpl-' + Date.now(),
      createdAt: new Date().toISOString(),
    };
    setTemplates((prev) => [newTpl, ...prev]);
    showToast(`Template saved: "${newTpl.title}"`, 'success');
    return newTpl;
  };

  const updateTemplate = (id: string, updates: Partial<TemplateItem>) => {
    setTemplates((prev) => prev.map((t) => (t.id === id ? { ...t, ...updates } : t)));
    showToast('Template updated', 'success');
  };

  const deleteTemplate = (id: string) => {
    setTemplates((prev) => prev.filter((t) => t.id !== id));
    showToast('Template deleted', 'info');
  };

  const toggleTemplateFavorite = (id: string) => {
    setTemplates((prev) =>
      prev.map((t) => (t.id === id ? { ...t, isFavorite: !t.isFavorite } : t))
    );
  };

  const applyTemplate = async (
    templateId: string,
    variableValues: Record<string, string> = {}
  ): Promise<{
    createdIds: {
      goalId?: string;
      projectIds: string[];
      taskIds: string[];
      eventIds: string[];
      habitIds: string[];
      noteIds: string[];
      automationIds: string[];
    };
  }> => {
    const template = templates.find((t) => t.id === templateId);
    if (!template) throw new Error(`Template not found: ${templateId}`);

    updateTemplate(templateId, { recentlyUsedAt: new Date().toISOString() });

    const replaceVars = (str?: string) => {
      if (!str) return str || '';
      let result = str;
      template.variables.forEach((v) => {
        const val = variableValues[v.key] ?? v.defaultValue;
        result = result.replaceAll(`{{${v.key}}}`, val);
      });
      return result;
    };

    const bp = template.blueprint;
    const createdIds = {
      goalId: undefined as string | undefined,
      projectIds: [] as string[],
      taskIds: [] as string[],
      eventIds: [] as string[],
      habitIds: [] as string[],
      noteIds: [] as string[],
      automationIds: [] as string[],
    };

    // 1. Create Goal
    let goalObj: Goal | undefined;
    if (bp.goal) {
      goalObj = addGoal({
        title: replaceVars(bp.goal.title) || `${template.title} Goal`,
        vision: replaceVars(bp.goal.vision) || '',
        area: (bp.goal.area as any) || 'Learning',
        targetDate:
          variableValues.targetDate ||
          bp.goal.targetDate ||
          new Date(Date.now() + 30 * 86400000).toISOString().split('T')[0],
        milestones: (bp.milestones || []).map((m, idx) => ({
          id: m.id || `m-${idx + 1}`,
          title: replaceVars(m.title) || 'Milestone',
          targetDate: m.targetDate,
          completed: Boolean(m.completed),
        })),
        status: 'active',
      });
      createdIds.goalId = goalObj.id;
    }

    // 2. Create Projects
    const createdProjects: Project[] = [];
    if (bp.projects && bp.projects.length > 0) {
      bp.projects.forEach((p) => {
        const proj = addProject({
          title: replaceVars(p.title) || 'Project Sprint',
          description: replaceVars(p.description) || '',
          deadline:
            variableValues.targetDate ||
            p.deadline ||
            new Date(Date.now() + 21 * 86400000).toISOString().split('T')[0],
          goalId: goalObj?.id,
          status: 'active',
        });
        createdProjects.push(proj);
        createdIds.projectIds.push(proj.id);
      });
    }

    // 3. Create Tasks
    if (bp.tasks && bp.tasks.length > 0) {
      bp.tasks.forEach((t, idx) => {
        const linkedProj = createdProjects[idx % Math.max(1, createdProjects.length)];
        const createdTask = addTask({
          title: replaceVars(t.title) || 'Template Task',
          description: replaceVars(t.description) || '',
          status: t.status || 'today',
          priority: t.priority || 'medium',
          dueDate: variableValues.targetDate || t.dueDate || new Date().toISOString().split('T')[0],
          durationMinutes: t.durationMinutes || 30,
          energyRequired: t.energyRequired || 'medium',
          projectId: linkedProj?.id,
          goalId: goalObj?.id,
          subtasks: (t.subtasks || []).map((st) => ({
            ...st,
            title: replaceVars(st.title),
          })),
          tags: t.tags || ['template'],
        });
        createdIds.taskIds.push(createdTask.id);
      });
    }

    // 4. Create Calendar Events
    if (bp.calendarEvents && bp.calendarEvents.length > 0) {
      bp.calendarEvents.forEach((ev) => {
        const createdEv = addCalendarEvent({
          title: replaceVars(ev.title) || 'Focus Block',
          date: new Date().toISOString().split('T')[0],
          startTime: ev.startTime || '09:00',
          endTime: ev.endTime || '10:30',
          type: ev.type || 'focus',
          energyRequired: ev.energyRequired || 'high',
          isFixedCommitment: Boolean(ev.isFixedCommitment),
          notes: replaceVars(ev.notes) || '',
          projectId: createdProjects[0]?.id,
        });
        createdIds.eventIds.push(createdEv.id);
      });
    }

    // 5. Create Habits
    if (bp.habits && bp.habits.length > 0) {
      bp.habits.forEach((h) => {
        const createdHabit = addHabit({
          title: replaceVars(h.title) || 'Daily Habit',
          frequency: h.frequency || 'daily',
          targetDaysPerWeek: h.targetDaysPerWeek || 6,
          category: h.category || 'Focus',
          goalId: goalObj?.id,
        });
        createdIds.habitIds.push(createdHabit.id);
      });
    }

    // 6. Create Notes
    if (bp.notes && bp.notes.length > 0) {
      bp.notes.forEach((n) => {
        const createdNote = addNote({
          title: replaceVars(n.title) || `${template.title} Notes`,
          content: replaceVars(n.content) || '',
          type: n.type || 'knowledge',
          tags: n.tags || ['template'],
          backlinks: [],
          linkedProjectIds: createdProjects.map((p) => p.id),
        });
        createdIds.noteIds.push(createdNote.id);
      });
    }

    // 7. Create Automations
    if (bp.automations && bp.automations.length > 0) {
      bp.automations.forEach((a) => {
        const auto = {
          title: replaceVars(a.title) || 'Smart Template Automation',
          trigger: replaceVars(a.trigger) || 'Habit completed',
          action: replaceVars(a.action) || 'Log progress',
          enabled: true,
          description: replaceVars(a.description) || '',
        };
        addAutomation(auto);
      });
    }

    // Add to Undo Stack
    const undoId = 'undo-template-' + Date.now();
    const undoItem: UndoActionItem = {
      id: undoId,
      actionId: templateId,
      actionType: 'apply_template',
      title: `Apply Template "${template.title}"`,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      snapshot: { createdIds },
    };
    setUndoStack((prev) => [undoItem, ...prev.slice(0, 29)]);

    // Update template usage stats and recently used date
    setTemplates((prev) =>
      prev.map((t) =>
        t.id === templateId
          ? {
              ...t,
              usageCount: (t.usageCount || 0) + 1,
              recentlyUsedAt: new Date().toISOString(),
            }
          : t
      )
    );

    showToast(`Template launched: "${template.title}" with connected objects!`, 'success');
    return { createdIds };
  };

  const saveAsTemplate = (params: {
    title: string;
    description: string;
    category: TemplateCategory;
    icon?: string;
    color?: string;
    projectId?: string;
    goalId?: string;
  }): TemplateItem => {
    const { title, description, category, icon = 'Sparkles', color = '#8b5cf6', projectId, goalId } = params;

    const linkedGoal = goalId ? goals.find((g) => g.id === goalId) : undefined;
    const linkedProjects = projectId
      ? projects.filter((p) => p.id === projectId)
      : goalId
      ? projects.filter((p) => p.goalId === goalId)
      : [];
    const linkedTasks = tasks.filter((t) =>
      (projectId && t.projectId === projectId) || (goalId && t.goalId === goalId)
    );
    const linkedHabits = habits.filter((h) => goalId && h.goalId === goalId);
    const linkedNotes = notes.filter((n) =>
      (projectId && n.linkedProjectIds?.includes(projectId)) || false
    );

    const newTemplate: TemplateItem = {
      id: 'tpl-custom-' + Date.now(),
      title,
      description,
      category,
      icon,
      color,
      isBuiltIn: false,
      variables: [
        {
          key: 'projectName',
          label: 'Project Name',
          placeholder: 'e.g. ' + title,
          defaultValue: title,
          type: 'text',
        },
      ],
      blueprint: {
        goal: linkedGoal
          ? { title: linkedGoal.title, vision: linkedGoal.vision, area: linkedGoal.area }
          : undefined,
        projects: linkedProjects.map((p) => ({ title: p.title, description: p.description })),
        milestones: linkedGoal?.milestones || [],
        tasks: linkedTasks.map((t) => ({
          title: t.title,
          description: t.description,
          priority: t.priority,
          status: t.status,
          durationMinutes: t.durationMinutes,
          energyRequired: t.energyRequired,
          subtasks: t.subtasks,
        })),
        habits: linkedHabits.map((h) => ({
          title: h.title,
          frequency: h.frequency,
          targetDaysPerWeek: h.targetDaysPerWeek,
          category: h.category,
        })),
        notes: linkedNotes.map((n) => ({
          title: n.title,
          content: n.content,
          type: n.type,
          tags: n.tags,
        })),
      },
      createdAt: new Date().toISOString(),
    };

    setTemplates((prev) => [newTemplate, ...prev]);
    showToast(`Saved workflow as template: "${title}"`, 'success');
    return newTemplate;
  };

  const duplicateTemplate = (templateId: string): TemplateItem => {
    const orig = templates.find((t) => t.id === templateId);
    const newTpl: TemplateItem = {
      ...(orig || {
        id: '',
        title: 'New Template',
        description: 'Custom workflow template',
        category: 'planning',
        icon: 'Sparkles',
        color: '#8b5cf6',
        variables: [],
        blueprint: { tasks: [] },
      }),
      id: 'tpl-remix-' + Date.now(),
      title: `${orig ? orig.title : 'Template'} (Remix)`,
      isBuiltIn: false,
      isPublic: false,
      status: 'draft',
      usageCount: 0,
      likesCount: 0,
      creator: { name: settings.userName || 'You', verified: false, role: 'Creator' },
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    setTemplates((prev) => [newTpl, ...prev]);
    showToast(`Template duplicated to My Templates`, 'success');
    return newTpl;
  };

  const publishTemplate = (templateId: string, isPublic: boolean) => {
    setTemplates((prev) =>
      prev.map((t) =>
        t.id === templateId
          ? {
              ...t,
              isPublic,
              status: isPublic ? 'published' : 'private',
              updatedAt: new Date().toISOString(),
            }
          : t
      )
    );
    showToast(isPublic ? 'Template published to community!' : 'Template marked private', 'success');
  };

  const reportTemplate = (templateId: string, reason?: string) => {
    setTemplates((prev) =>
      prev.map((t) =>
        t.id === templateId
          ? {
              ...t,
              isReported: true,
              reportCount: (t.reportCount || 0) + 1,
            }
          : t
      )
    );
    showToast('Report submitted for moderation review.', 'info');
  };

  const importTemplateFromJSON = (jsonString: string): TemplateItem | null => {
    try {
      const parsed = JSON.parse(jsonString);
      if (!parsed.title || !parsed.blueprint) {
        showToast('Invalid template: missing title or blueprint', 'error');
        return null;
      }
      const newTpl: TemplateItem = {
        ...parsed,
        id: 'tpl-imp-' + Date.now(),
        isBuiltIn: false,
        isPublic: false,
        status: 'private',
        usageCount: 0,
        likesCount: 0,
        creator: parsed.creator || { name: 'Imported', verified: false },
        createdAt: new Date().toISOString(),
      };
      setTemplates((prev) => [newTpl, ...prev]);
      showToast(`Template "${newTpl.title}" imported safely!`, 'success');
      return newTpl;
    } catch (e) {
      showToast('Invalid JSON file format', 'error');
      return null;
    }
  };

  const exportTemplateToJSON = (templateId: string): string => {
    const tpl = templates.find((t) => t.id === templateId);
    if (!tpl) return '';
    return JSON.stringify(tpl, null, 2);
  };

  const generateTemplateWithAI = async (
    prompt: string,
    category?: string
  ): Promise<TemplateItem> => {
    try {
      const res = await fetch('/api/ai/template-generate', {
        method: 'POST',
        headers: getAIHeaders(),
        body: JSON.stringify({ prompt, category }),
      });
      if (!res.ok) throw new Error('Failed to generate template from AI');
      const data = await res.json();
      const generated = data.template;
      const fullTpl: TemplateItem = {
        ...generated,
        id: 'tpl-ai-' + Date.now(),
        isBuiltIn: false,
        createdAt: new Date().toISOString(),
      };
      setTemplates((prev) => [fullTpl, ...prev]);
      showToast(`AI created template: "${fullTpl.title}"`, 'success');
      return fullTpl;
    } catch (e: any) {
      showToast('AI generation error, creating local template', 'info');
      return saveAsTemplate({
        title: prompt.slice(0, 40),
        description: `Custom workflow for ${prompt}`,
        category: (category as any) || 'projects',
      });
    }
  };

  // Settings & API Keys Persistence
  const updateSettings = (updates: Partial<AppSettings>) => {
    if (updates.theme) {
      try {
        localStorage.setItem('life_os_theme', updates.theme);
      } catch (e) {}
    }
    if (updates.geminiApiKey !== undefined) {
      try {
        localStorage.setItem('life_os_gemini_api_key', updates.geminiApiKey);
      } catch (e) {}
    }
    if (updates.openaiApiKey !== undefined) {
      try {
        localStorage.setItem('life_os_openai_api_key', updates.openaiApiKey);
      } catch (e) {}
    }
    if (updates.preferredAIProvider !== undefined) {
      try {
        localStorage.setItem('life_os_ai_provider', updates.preferredAIProvider);
      } catch (e) {}
    }
    if (updates.geminiModel !== undefined) {
      try {
        localStorage.setItem('life_os_gemini_model', updates.geminiModel);
      } catch (e) {}
    }
    if (updates.openaiModel !== undefined) {
      try {
        localStorage.setItem('life_os_openai_model', updates.openaiModel);
      } catch (e) {}
    }

    setSettings((prev) => ({ ...prev, ...updates }));
    if (!updates.theme || Object.keys(updates).length > 1) {
      showToast('Settings saved', 'success');
    }
  };

  const signOutUser = async () => {
    try {
      await firebaseSignOut(auth);
      setCurrentUser(null);
      setSettings((prev) => ({
        ...prev,
        authProvider: 'guest',
        userEmail: undefined,
        userAvatar: undefined,
      }));
      showToast('Signed out of Google account', 'info');
    } catch (err: any) {
      showToast('Sign out failed: ' + (err.message || 'Unknown error'), 'error');
    }
  };

  const getAIHeaders = (): Record<string, string> => {
    const headers: Record<string, string> = {
      'Content-Type': 'application/json',
      'x-ai-provider': settings.preferredAIProvider || 'gemini',
      'x-ai-fallback': settings.aiAutoFallback !== false ? 'true' : 'false',
    };
    if (settings.geminiApiKey) {
      headers['x-gemini-key'] = settings.geminiApiKey;
    }
    if (settings.openaiApiKey) {
      headers['x-openai-key'] = settings.openaiApiKey;
    }
    if (settings.preferredAIProvider === 'openai') {
      if (settings.openaiModel) headers['x-ai-model'] = settings.openaiModel;
    } else {
      if (settings.geminiModel) headers['x-ai-model'] = settings.geminiModel;
    }
    return headers;
  };

  const testAIConnection = async (
    provider: 'gemini' | 'openai',
    apiKey: string,
    model?: string
  ): Promise<{ ok: boolean; message: string; latencyMs?: number; error?: string }> => {
    try {
      const res = await fetch('/api/ai/test-key', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ provider, apiKey, model }),
      });
      const data = await res.json();
      if (!res.ok || !data.ok) {
        return {
          ok: false,
          message: data.error || 'Connection validation failed',
          error: data.error,
        };
      }
      return {
        ok: true,
        message: data.message || `Connected to ${provider} successfully!`,
        latencyMs: data.latencyMs,
      };
    } catch (err: any) {
      return {
        ok: false,
        message: err.message || 'Network error verifying key',
        error: err.message,
      };
    }
  };

  const completeOnboarding = (userName: string, additionalSettings?: Partial<AppSettings>) => {
    try {
      localStorage.setItem('lifeos_first_time_onboarded', 'true');
    } catch (e) {}
    setSettings((prev) => ({
      ...prev,
      ...additionalSettings,
      userName: userName.trim() || 'Rohan',
      onboardingCompleted: true,
    }));
    showToast(`Welcome to Life OS, ${userName.trim() || 'Rohan'}!`, 'success');
  };

  const restartOnboarding = () => {
    try {
      localStorage.removeItem('lifeos_first_time_onboarded');
    } catch (e) {}
    setSettings((prev) => ({
      ...prev,
      onboardingCompleted: false,
    }));
    showToast('Onboarding flow reset. Welcome!', 'info');
  };

  // Universal Capture AI Analysis & Auto-Routing
  const processCapture = async (payload: UniversalCapturePayload) => {
    try {
      const res = await fetch('/api/ai/capture', {
        method: 'POST',
        headers: getAIHeaders(),
        body: JSON.stringify({
          content: payload.rawContent,
          source: payload.source,
          existingContext: {
            projects: projects.map((p) => ({ id: p.id, title: p.title })),
            goals: goals.map((g) => ({ id: g.id, title: g.title })),
          },
        }),
      });

      let analysis: any;
      if (res.ok) {
        const data = await res.json();
        analysis = data.result;
      } else {
        throw new Error('Server response was not ok');
      }

      // Route according to classification
      const today = new Date().toISOString().split('T')[0];

      if (analysis.targetEntity === 'task') {
        const created = addTask({
          title: analysis.title || payload.rawContent.slice(0, 60),
          description: analysis.description || '',
          status: 'inbox',
          priority: analysis.priority || 'medium',
          dueDate: today,
          durationMinutes: analysis.estimatedMinutes || 30,
          energyRequired: analysis.energyRequired || 'medium',
          projectId: analysis.matchedProjectId || undefined,
          goalId: analysis.matchedGoalId || undefined,
          subtasks: [],
          tags: analysis.tags || ['capture'],
        });
        return { entityType: 'task', item: created, analysis };
      } else if (analysis.targetEntity === 'event') {
        const created = addCalendarEvent({
          title: analysis.title || payload.rawContent.slice(0, 60),
          date: today,
          startTime: '10:00',
          endTime: '11:00',
          type: 'event',
          isFixedCommitment: false,
          notes: analysis.description,
          energyRequired: analysis.energyRequired || 'medium',
          projectId: analysis.matchedProjectId || undefined,
        });
        return { entityType: 'event', item: created, analysis };
      } else if (analysis.targetEntity === 'habit') {
        const created = addHabit({
          title: analysis.title || payload.rawContent.slice(0, 60),
          frequency: 'daily',
          targetDaysPerWeek: 5,
          category: 'Personal',
          goalId: analysis.matchedGoalId || undefined,
        });
        return { entityType: 'habit', item: created, analysis };
      } else {
        // Note / Knowledge / Second Brain
        const created = addNote({
          title: analysis.title || 'Quick Note',
          content: analysis.description || payload.rawContent,
          type: analysis.targetEntity === 'knowledge' ? 'knowledge' : 'note',
          tags: analysis.tags || ['capture'],
          backlinks: [],
          linkedProjectIds: analysis.matchedProjectId ? [analysis.matchedProjectId] : [],
        });
        return { entityType: 'note', item: created, analysis };
      }
    } catch (err) {
      console.warn('Capture processing local fallback routing:', err);
      // Clean fallback
      const created = addTask({
        title: payload.rawContent.slice(0, 60),
        status: 'inbox',
        priority: 'medium',
        subtasks: [],
        tags: ['quick-capture'],
      });
      return {
        entityType: 'task',
        item: created,
        analysis: { confidence: 0.8, clarificationNeeded: null },
      };
    }
  };

  // Export / Import
  const exportDataAsJSON = () => {
    const data = {
      version: '1.0',
      exportedAt: new Date().toISOString(),
      tasks,
      projects,
      goals,
      calendarEvents,
      habits,
      notes,
      energyLogs,
      financeItems,
      focusSessions,
      weeklyReviews,
      automations,
      aiMemories,
      settings,
    };
    return JSON.stringify(data, null, 2);
  };

  const importDataFromJSON = (jsonStr: string): boolean => {
    try {
      const data = JSON.parse(jsonStr);
      if (data.tasks) setTasks(data.tasks);
      if (data.projects) setProjects(data.projects);
      if (data.goals) setGoals(data.goals);
      if (data.calendarEvents) setCalendarEvents(data.calendarEvents);
      if (data.habits) setHabits(data.habits);
      if (data.notes) setNotes(data.notes);
      if (data.energyLogs) setEnergyLogs(data.energyLogs);
      if (data.financeItems) setFinanceItems(data.financeItems);
      if (data.focusSessions) setFocusSessions(data.focusSessions);
      if (data.weeklyReviews) setWeeklyReviews(data.weeklyReviews);
      if (data.automations) setAutomations(data.automations);
      if (data.aiMemories) setAIMemories(data.aiMemories);
      if (data.settings) setSettings(data.settings);
      showToast('Life OS state restored successfully', 'success');
      return true;
    } catch (e) {
      showToast('Failed to import JSON file. Please check format.', 'error');
      return false;
    }
  };

  const resetToDefaultData = () => {
    setTasks(initialTasks);
    setProjects(initialProjects);
    setGoals(initialGoals);
    setCalendarEvents(initialCalendarEvents);
    setHabits(initialHabits);
    setNotes(initialNotes);
    setEnergyLogs(initialEnergyLogs);
    setFinanceItems(initialFinanceItems);
    setFocusSessions(initialFocusSessions);
    setAutomations(initialAutomations);
    setAIMemories(initialAIMemories);
    setSettings(defaultSettings);
    showToast('Life OS reset to default starter kit', 'info');
  };

  const clearAllData = () => {
    setTasks([]);
    setProjects([]);
    setGoals([]);
    setCalendarEvents([]);
    setHabits([]);
    setNotes([]);
    setEnergyLogs([]);
    setFinanceItems([]);
    setFocusSessions([]);
    setWeeklyReviews([]);
    showToast('Workspace cleared for clean start', 'info');
  };

  // AI App Action API with Verification & Undo Snapshot
  const executeAppAction = async (
    proposal: AppActionProposal
  ): Promise<{ ok: boolean; verified: boolean; message: string; undoId?: string }> => {
    const { actionType, payload, title } = proposal;
    const undoId = 'undo-' + Date.now();

    try {
      if (!actionType) throw new Error('Missing action type');

      let snapshot: any = null;
      let verificationNote = '';

      switch (actionType) {
        case 'add_home_widget': {
          const widgetId = (payload?.widgetId || payload?.id || 'clock') as HomeWidgetId;
          const existing = homeWidgets.find((w) => w.id === widgetId);
          snapshot = { widgetId, previousEnabled: existing ? existing.enabled : false };
          addHomeWidget(widgetId);
          verificationNote = `Home widget "${widgetId}" enabled`;
          break;
        }

        case 'remove_home_widget': {
          const widgetId = (payload?.widgetId || payload?.id || 'clock') as HomeWidgetId;
          const existing = homeWidgets.find((w) => w.id === widgetId);
          snapshot = { widgetId, previousEnabled: existing ? existing.enabled : true };
          removeHomeWidget(widgetId);
          verificationNote = `Home widget "${widgetId}" disabled`;
          break;
        }

        case 'toggle_home_widget': {
          const widgetId = (payload?.widgetId || payload?.id || 'clock') as HomeWidgetId;
          const existing = homeWidgets.find((w) => w.id === widgetId);
          snapshot = { widgetId, previousEnabled: existing ? existing.enabled : false };
          toggleHomeWidget(widgetId);
          verificationNote = `Home widget "${widgetId}" toggled`;
          break;
        }

        case 'create_task': {
          if (!payload?.title || typeof payload.title !== 'string') {
            throw new Error('Task title is required');
          }
          const created = addTask({
            title: payload.title.trim(),
            description: payload.description || '',
            status: payload.status || 'today',
            priority: payload.priority || 'medium',
            durationMinutes: payload.durationMinutes || 30,
            energyRequired: payload.energyRequired || 'medium',
            subtasks: payload.subtasks || [],
            tags: payload.tags || ['ai-action'],
            dueDate: payload.dueDate,
          });
          snapshot = { createdTaskId: created.id };
          verificationNote = `Task created with ID ${created.id}: "${created.title}"`;
          break;
        }

        case 'update_task': {
          let targetTask: Task | undefined;
          if (payload?.id) {
            targetTask = tasks.find((t) => t.id === payload.id);
          }
          if (!targetTask && (payload?.query || payload?.time || payload?.title)) {
            const q = (payload.query || payload.time || payload.title || '').toLowerCase();
            // Check direct title or description match
            targetTask = tasks.find(
              (t) =>
                t.title.toLowerCase().includes(q) ||
                (t.description && t.description.toLowerCase().includes(q))
            );
            // If user mentioned 5 PM / 5pm / 17:00 / 17:30, check linked events
            if (!targetTask && (q.includes('5') || q.includes('17'))) {
              const matchedEv = calendarEvents.find(
                (e) =>
                  e.startTime.includes('17') ||
                  e.startTime.includes('5:') ||
                  e.title.toLowerCase().includes('5')
              );
              if (matchedEv?.taskId) {
                targetTask = tasks.find((t) => t.id === matchedEv.taskId);
              }
              if (!targetTask) {
                targetTask = tasks.find(
                  (t) =>
                    t.title.toLowerCase().includes('run') ||
                    t.title.toLowerCase().includes('exercise') ||
                    t.title.toLowerCase().includes('5')
                );
              }
            }
          }
          if (!targetTask && tasks.length > 0) {
            targetTask = tasks.find((t) => t.status === 'today');
          }
          if (!targetTask) {
            throw new Error('Could not identify which task to update in your current tasks.');
          }

          snapshot = { id: targetTask.id, previous: { ...targetTask } };
          const updates = payload.updates || { ...payload };
          delete updates.id;
          delete updates.query;
          updateTask(targetTask.id, updates);

          // If date changed, also adjust linked calendar event
          if (updates.dueDate) {
            const linkedEv = calendarEvents.find((e) => e.taskId === targetTask!.id);
            if (linkedEv) {
              updateCalendarEvent(linkedEv.id, { date: updates.dueDate });
            }
          }

          verificationNote = `Task "${targetTask.title}" updated (${JSON.stringify(updates)})`;
          break;
        }

        case 'delete_task': {
          let targetId = payload?.id;
          if (!targetId && (payload?.query || payload?.title)) {
            const q = (payload.query || payload.title || '').toLowerCase();
            const found = tasks.find((t) => t.title.toLowerCase().includes(q));
            if (found) targetId = found.id;
          }
          if (!targetId) throw new Error('Task ID is required');
          const existing = tasks.find((t) => t.id === targetId);
          if (!existing) throw new Error(`Task not found: ${targetId}`);
          snapshot = { deletedTask: { ...existing } };
          deleteTask(targetId);
          verificationNote = `Task "${existing.title}" removed`;
          break;
        }

        case 'toggle_task': {
          let targetId = payload?.id;
          if (!targetId && (payload?.query || payload?.title)) {
            const q = (payload.query || payload.title || '').toLowerCase();
            const found = tasks.find((t) => t.title.toLowerCase().includes(q));
            if (found) targetId = found.id;
          }
          if (!targetId) throw new Error('Task ID is required');
          const existing = tasks.find((t) => t.id === targetId);
          if (!existing) throw new Error(`Task not found: ${targetId}`);
          snapshot = { id: targetId, previousStatus: existing.status };
          toggleTaskComplete(targetId);
          verificationNote = `Task "${existing.title}" completion toggled`;
          break;
        }

        case 'schedule_timeblock': {
          if (!payload?.title || !payload?.startTime || !payload?.endTime) {
            throw new Error('Timeblock requires title, startTime, and endTime');
          }
          const date = payload.date || new Date().toISOString().split('T')[0];
          const created = addCalendarEvent({
            title: payload.title.trim(),
            date,
            startTime: payload.startTime,
            endTime: payload.endTime,
            type: payload.type || 'focus',
            energyRequired: payload.energyRequired || 'high',
            isFixedCommitment: Boolean(payload.isFixedCommitment),
            notes: payload.notes || 'Scheduled via AI Control Layer',
          });
          snapshot = { createdEventId: created.id };
          verificationNote = `Time block scheduled: "${created.title}" at ${created.startTime}`;
          break;
        }

        case 'update_timeblock': {
          let targetId = payload?.id;
          if (!targetId && (payload?.query || payload?.time)) {
            const q = (payload.query || payload.time || '').toLowerCase();
            const matched = calendarEvents.find(
              (e) =>
                e.title.toLowerCase().includes(q) ||
                e.startTime.includes(q) ||
                ((q.includes('5') || q.includes('17')) &&
                  (e.startTime === '17:00' || e.startTime === '17:30'))
            );
            if (matched) targetId = matched.id;
          }
          if (!targetId) throw new Error('Target calendar event not found');
          const existing = calendarEvents.find((e) => e.id === targetId);
          if (!existing) throw new Error(`Event not found: ${targetId}`);
          snapshot = { id: targetId, previous: { ...existing } };
          updateCalendarEvent(targetId, payload.updates || payload);
          verificationNote = `Calendar event "${existing.title}" updated`;
          break;
        }

        case 'delete_timeblock': {
          if (!payload?.id) throw new Error('Timeblock ID is required');
          const existing = calendarEvents.find((e) => e.id === payload.id);
          if (!existing) throw new Error(`Event not found: ${payload.id}`);
          snapshot = { deletedEvent: { ...existing } };
          deleteCalendarEvent(payload.id);
          verificationNote = `Timeblock "${existing.title}" deleted`;
          break;
        }

        case 'create_habit': {
          if (!payload?.title) throw new Error('Habit title is required');
          const created = addHabit({
            title: payload.title.trim(),
            frequency: payload.frequency || 'daily',
            targetDaysPerWeek: payload.targetDaysPerWeek || 7,
            category: payload.category || 'Health',
          });
          snapshot = { createdHabitId: created.id };
          verificationNote = `Habit established: "${created.title}"`;
          break;
        }

        case 'toggle_habit': {
          if (!payload?.id || !payload?.dateStr) throw new Error('Habit ID and date required');
          snapshot = { id: payload.id, dateStr: payload.dateStr };
          toggleHabitDate(payload.id, payload.dateStr);
          verificationNote = `Habit toggled for ${payload.dateStr}`;
          break;
        }

        case 'create_goal': {
          if (!payload?.title || !payload?.vision) throw new Error('Goal requires title and vision');
          const created = addGoal({
            title: payload.title.trim(),
            vision: payload.vision.trim(),
            area: payload.area || 'Personal',
            targetDate:
              payload.targetDate ||
              new Date(Date.now() + 30 * 86400000).toISOString().split('T')[0],
            milestones: payload.milestones || [],
            status: 'active',
          });
          snapshot = { createdGoalId: created.id };
          verificationNote = `Goal created: "${created.title}"`;
          break;
        }

        case 'create_project': {
          if (!payload?.title) throw new Error('Project title is required');
          const created = addProject({
            title: payload.title.trim(),
            description: payload.description || '',
            deadline:
              payload.deadline ||
              new Date(Date.now() + 14 * 86400000).toISOString().split('T')[0],
            status: 'active',
          });
          snapshot = { createdProjectId: created.id };
          verificationNote = `Project created: "${created.title}"`;
          break;
        }

        case 'create_note': {
          if (!payload?.title) throw new Error('Note title is required');
          const created = addNote({
            title: payload.title.trim(),
            content: payload.content || '',
            type: payload.type || 'knowledge',
            tags: payload.tags || ['ai-note'],
            backlinks: [],
          });
          snapshot = { createdNoteId: created.id };
          verificationNote = `Note created: "${created.title}"`;
          break;
        }

        case 'navigate_app': {
          const nav = (payload?.nav || payload?.targetNav || 'home') as MainNav;
          snapshot = { previousNav: activeNav };
          setActiveNav(nav);
          if (payload?.subNav) {
            if (nav === 'plan') setPlanSubNav(payload.subNav as PlanSubNav);
            if (nav === 'life') setLifeSubNav(payload.subNav as LifeSubNav);
            if (nav === 'notes') setNotesSubNav(payload.subNav as NotesSubNav);
          }
          verificationNote = `Navigated to ${nav}${payload?.subNav ? ` / ${payload.subNav}` : ''}`;
          break;
        }

        case 'start_focus': {
          setIsFocusOpen(true);
          verificationNote = 'Focus Mode timer opened';
          break;
        }

        case 'change_theme': {
          const newTheme = payload?.theme || 'system';
          snapshot = { previousTheme: settings.theme };
          updateSettings({ theme: newTheme });
          verificationNote = `Theme switched to ${newTheme}`;
          break;
        }

        case 'apply_template': {
          const tplId = payload?.templateId || payload?.id;
          if (!tplId) throw new Error('Template ID is required');
          const res = await applyTemplate(tplId, payload?.variables || {});
          snapshot = { createdIds: res.createdIds };
          verificationNote = `Template applied and connected across tasks, projects, calendar, and notes`;
          break;
        }

        case 'create_life_object': {
          const objType = (payload?.type || 'task') as LifeObjectType;
          if (objType === 'task') {
            const created = addTask(payload);
            snapshot = { createdTaskId: created.id };
          } else if (objType === 'note' || objType === 'knowledge') {
            const created = addNote(payload);
            snapshot = { createdNoteId: created.id };
          } else if (objType === 'project') {
            const created = addProject(payload);
            snapshot = { createdProjectId: created.id };
          } else if (objType === 'goal') {
            const created = addGoal(payload);
            snapshot = { createdGoalId: created.id };
          } else if (objType === 'habit') {
            const created = addHabit(payload);
            snapshot = { createdHabitId: created.id };
          }
          verificationNote = `Created ${objType}: "${payload?.title}"`;
          break;
        }

        case 'update_life_object': {
          const objId = payload?.id;
          const objType = payload?.type as LifeObjectType;
          if (!objId) throw new Error('Object ID is required');
          updateLifeObject(objId, objType, payload.updates || payload);
          verificationNote = `Updated ${objType} ${objId}`;
          break;
        }

        case 'run_automation': {
          const autoId = payload?.automationId || payload?.id;
          const rule = automations.find((a) => a.id === autoId) || automations[0];
          if (!rule) throw new Error('Automation not found');
          triggerAutomation({ trigger: 'task_completed', payload: { title: 'Manual Run' } });
          verificationNote = `Executed automation: "${rule.title}"`;
          break;
        }

        default:
          throw new Error(`Unsupported action type: ${actionType}`);
      }

      // Add to Undo Stack
      if (proposal.undoable !== false && snapshot) {
        const undoItem: UndoActionItem = {
          id: undoId,
          actionId: proposal.id,
          actionType,
          title: title || `Action: ${actionType.replace(/_/g, ' ')}`,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          snapshot,
        };
        setUndoStack((prev) => [undoItem, ...prev.slice(0, 29)]);
      }

      showToast(`Verified: ${title || actionType.replace(/_/g, ' ')}`, 'success');
      return {
        ok: true,
        verified: true,
        message: verificationNote || `Action executed and verified: ${title}`,
        undoId,
      };
    } catch (err: any) {
      console.error('executeAppAction error:', err);
      showToast(`Action failed: ${err.message}`, 'error');
      return { ok: false, verified: false, message: err.message };
    }
  };

  // Undo Handlers
  const undoAction = async (undoId?: string): Promise<{ ok: boolean; message: string }> => {
    if (undoStack.length === 0) {
      showToast('No actions available to undo', 'info');
      return { ok: false, message: 'Nothing to undo' };
    }

    const item = undoId ? undoStack.find((u) => u.id === undoId) : undoStack[0];
    if (!item) {
      return { ok: false, message: 'Undo item not found' };
    }

    const { actionType, snapshot, title } = item;

    try {
      switch (actionType) {
        case 'add_home_widget':
          if (snapshot?.widgetId) {
            setHomeWidgets((prev) =>
              prev.map((w) =>
                w.id === snapshot.widgetId
                  ? { ...w, enabled: snapshot.previousEnabled ?? false }
                  : w
              )
            );
          }
          break;
        case 'remove_home_widget':
          if (snapshot?.widgetId) {
            setHomeWidgets((prev) =>
              prev.map((w) =>
                w.id === snapshot.widgetId
                  ? { ...w, enabled: snapshot.previousEnabled ?? true }
                  : w
              )
            );
          }
          break;
        case 'create_task':
          if (snapshot.createdTaskId) {
            deleteTask(snapshot.createdTaskId);
          }
          break;
        case 'update_task':
          if (snapshot.id && snapshot.previous) {
            updateTask(snapshot.id, snapshot.previous);
          }
          break;
        case 'delete_task':
          if (snapshot.deletedTask) {
            setTasks((prev) => [snapshot.deletedTask, ...prev]);
          }
          break;
        case 'toggle_task':
          if (snapshot.id) {
            toggleTaskComplete(snapshot.id);
          }
          break;
        case 'schedule_timeblock':
          if (snapshot.createdEventId) {
            deleteCalendarEvent(snapshot.createdEventId);
          }
          break;
        case 'update_timeblock':
          if (snapshot.id && snapshot.previous) {
            updateCalendarEvent(snapshot.id, snapshot.previous);
          }
          break;
        case 'delete_timeblock':
          if (snapshot.deletedEvent) {
            setCalendarEvents((prev) => [snapshot.deletedEvent, ...prev]);
          }
          break;
        case 'create_habit':
          if (snapshot.createdHabitId) {
            deleteHabit(snapshot.createdHabitId);
          }
          break;
        case 'toggle_habit':
          if (snapshot.id && snapshot.dateStr) {
            toggleHabitDate(snapshot.id, snapshot.dateStr);
          }
          break;
        case 'create_goal':
          if (snapshot.createdGoalId) {
            deleteGoal(snapshot.createdGoalId);
          }
          break;
        case 'create_project':
          if (snapshot.createdProjectId) {
            deleteProject(snapshot.createdProjectId);
          }
          break;
        case 'create_note':
          if (snapshot.createdNoteId) {
            deleteNote(snapshot.createdNoteId);
          }
          break;
        case 'navigate_app':
          if (snapshot.previousNav) {
            setActiveNav(snapshot.previousNav);
          }
          break;
        case 'apply_template':
          if (snapshot?.createdIds) {
            const { goalId, projectIds, taskIds, eventIds, habitIds, noteIds } = snapshot.createdIds;
            if (goalId) deleteGoal(goalId);
            (projectIds || []).forEach((pid: string) => deleteProject(pid));
            (taskIds || []).forEach((tid: string) => deleteTask(tid));
            (eventIds || []).forEach((eid: string) => deleteCalendarEvent(eid));
            (habitIds || []).forEach((hid: string) => deleteHabit(hid));
            (noteIds || []).forEach((nid: string) => deleteNote(nid));
          }
          break;
        case 'change_theme':
          if (snapshot.previousTheme) {
            updateSettings({ theme: snapshot.previousTheme });
          }
          break;
      }

      setUndoStack((prev) => prev.filter((u) => u.id !== item.id));
      showToast(`Undone: ${title}`, 'info');
      return { ok: true, message: `Successfully undone: ${title}` };
    } catch (err: any) {
      console.error('undoAction error:', err);
      showToast(`Failed to undo: ${err.message}`, 'error');
      return { ok: false, message: err.message };
    }
  };

  // Persistent Conversation Handlers
  const createConversation = (title?: string): string => {
    const newId = 'convo-' + Date.now();
    const newConvo: AIConversation = {
      id: newId,
      title: title || 'New Strategy Chat',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      messages: [
        {
          id: 'msg-' + Date.now(),
          sender: 'ai',
          text: `Hello ${settings.userName || 'there'}. I have active context of your tasks and projects. How can I help you plan or execute?`,
          type: 'fact',
          timestamp: 'Just now',
        },
      ],
    };
    setAiConversations((prev) => [newConvo, ...prev]);
    setActiveConversationId(newId);
    return newId;
  };

  const deleteConversation = (id: string) => {
    setAiConversations((prev) => {
      const remaining = prev.filter((c) => c.id !== id);
      if (remaining.length === 0) {
        const fresh: AIConversation = {
          id: 'convo-default',
          title: 'Executive Planning',
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString(),
          messages: [
            {
              id: 'msg-fresh',
              sender: 'ai',
              text: 'Conversation reset. How can I assist you?',
              timestamp: 'Just now',
            },
          ],
        };
        setActiveConversationId('convo-default');
        return [fresh];
      }
      if (activeConversationId === id) {
        setActiveConversationId(remaining[0].id);
      }
      return remaining;
    });
  };

  const renameConversation = (id: string, newTitle: string) => {
    if (!newTitle.trim()) return;
    setAiConversations((prev) =>
      prev.map((c) => (c.id === id ? { ...c, title: newTitle.trim(), updatedAt: new Date().toISOString() } : c))
    );
  };

  const addMessageToConversation = (convoId: string, message: AIMessage) => {
    setAiConversations((prev) =>
      prev.map((c) => {
        if (c.id === convoId) {
          // If first user message, optionally auto-rename title if default
          let title = c.title;
          if (c.messages.length <= 1 && message.sender === 'user') {
            title = message.text.slice(0, 32);
          }
          return {
            ...c,
            title,
            updatedAt: new Date().toISOString(),
            messages: [...c.messages, message],
          };
        }
        return c;
      })
    );
  };

  const clearConversationMessages = (convoId: string) => {
    setAiConversations((prev) =>
      prev.map((c) =>
        c.id === convoId
          ? {
              ...c,
              messages: [
                {
                  id: 'msg-cleared',
                  sender: 'ai',
                  text: 'Conversation cleared. What would you like to explore next?',
                  timestamp: 'Just now',
                },
              ],
              updatedAt: new Date().toISOString(),
            }
          : c
      )
    );
  };

  return (
    <LifeOSContext.Provider
      value={{
        activeNav,
        setActiveNav,
        planSubNav,
        setPlanSubNav,
        notesSubNav,
        setNotesSubNav,
        lifeSubNav,
        setLifeSubNav,
        currentUser,
        signOutUser,
        getAIHeaders,
        testAIConnection,
        isCaptureOpen,
        setIsCaptureOpen,
        isSearchOpen,
        setIsSearchOpen,
        isFocusOpen,
        setIsFocusOpen,
        isReviewOpen,
        setIsReviewOpen,
        isSettingsOpen,
        setIsSettingsOpen,
        isHelpOpen,
        setIsHelpOpen,
        openHelpWithContext,
        isOnboardingOpen,
        setIsOnboardingOpen,
        tasks,
        projects,
        goals,
        calendarEvents,
        habits,
        notes,
        energyLogs,
        financeItems,
        focusSessions,
        weeklyReviews,
        automations,
        aiMemories,
        settings,
        toasts,
        homeWidgets,
        setHomeWidgets,
        addHomeWidget,
        removeHomeWidget,
        toggleHomeWidget,
        addTask,
        updateTask,
        deleteTask,
        toggleTaskComplete,
        toggleSubtask,
        addProject,
        updateProject,
        deleteProject,
        addGoal,
        updateGoal,
        deleteGoal,
        toggleMilestone,
        addCalendarEvent,
        updateCalendarEvent,
        deleteCalendarEvent,
        addHabit,
        updateHabit,
        deleteHabit,
        toggleHabitDate,
        addNote,
        updateNote,
        deleteNote,
        addEnergyLog,
        addFinanceItem,
        deleteFinanceItem,
        logFocusSession,
        saveWeeklyReview,
        toggleAutomation,
        addAutomation,
        addAIMemory,
        deleteAIMemory,
        toggleAIMemory,
        resetAIMemories,
        updateSettings,
        completeOnboarding,
        restartOnboarding,
        processCapture,
        dismissToast,
        showToast,
        exportDataAsJSON,
        importDataFromJSON,
        resetToDefaultData,
        clearAllData,
        undoStack,
        executeAppAction,
        undoAction,
        aiConversations,
        activeConversationId,
        setActiveConversationId,
        createConversation,
        deleteConversation,
        renameConversation,
        addMessageToConversation,
        clearConversationMessages,
        lifeObjects,
        linkObjects,
        unlinkObjects,
        updateLifeObject,
        activeViewType,
        setActiveViewType,
        updateNoteBlocks,
        templates,
        templatesSubNav,
        setTemplatesSubNav,
        selectedTemplateForPreview,
        setSelectedTemplateForPreview,
        isTemplateModalOpen,
        setIsTemplateModalOpen,
        activeTemplateForLaunch,
        setActiveTemplateForLaunch,
        applyTemplate,
        saveAsTemplate,
        addTemplate,
        updateTemplate,
        deleteTemplate,
        toggleTemplateFavorite,
        duplicateTemplate,
        publishTemplate,
        reportTemplate,
        importTemplateFromJSON,
        exportTemplateToJSON,
        generateTemplateWithAI,
        triggerAutomation,
      }}
    >
      {children}
    </LifeOSContext.Provider>
  );
};

export const useLifeOS = () => {
  const context = useContext(LifeOSContext);
  if (!context) {
    throw new Error('useLifeOS must be used within a LifeOSProvider');
  }
  return context;
};
