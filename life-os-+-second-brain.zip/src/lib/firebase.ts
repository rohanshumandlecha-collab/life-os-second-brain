import { initializeApp, getApps, getApp } from 'firebase/app';
import {
  getAuth,
  GoogleAuthProvider,
  signInWithPopup,
  signOut as firebaseSignOut,
  onAuthStateChanged,
  type User,
} from 'firebase/auth';

export const firebaseConfig = {
  projectId: "yarling-mediator-7mn89",
  appId: "1:363829028084:web:c467e4c90013602efb2aa1",
  apiKey: "AIzaSyASn4mLWcCljxUxcjYJC4GtHjfrtMqW6PI",
  authDomain: "yarling-mediator-7mn89.firebaseapp.com",
  firestoreDatabaseId: "ai-studio-lifeossecondbrai-c06228a1-61bd-4a93-a455-1b2392f744f1",
  storageBucket: "yarling-mediator-7mn89.firebasestorage.app",
  messagingSenderId: "363829028084",
  measurementId: "",
  oAuthClientId: "363829028084-ta0npcrp7lt95vc9j60rhtqdgk5od2at.apps.googleusercontent.com",
  recaptchaSiteKey: "",
};

export const app = getApps().length > 0 ? getApp() : initializeApp(firebaseConfig);
export const auth = getAuth(app);

export const googleProvider = new GoogleAuthProvider();
googleProvider.setCustomParameters({
  prompt: 'select_account',
});

export const signInWithGoogle = async (): Promise<User> => {
  const result = await signInWithPopup(auth, googleProvider);
  return result.user;
};

export { signInWithPopup, firebaseSignOut, onAuthStateChanged };
export type { User };
