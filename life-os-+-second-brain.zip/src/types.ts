/**
 * Life OS + Second Brain Types
 */

export type MainNav = 'home' | 'tasks' | 'plan' | 'notes' | 'life' | 'ai' | 'templates';
export type PlanSubNav = 'calendar' | 'timeblocking' | 'goals';
export type NotesSubNav = 'notes' | 'secondbrain';
export type LifeSubNav = 'projects' | 'habits' | 'money' | 'energy' | 'automations';
export type TemplatesSubNav = 'featured' | 'popular' | 'new' | 'recommended' | 'categories' | 'my-templates' | 'create';

export type Priority = 'low' | 'medium' | 'high' | 'urgent';
export type EnergyLevel = 'low' | 'medium' | 'high' | 'peak';
export type TaskStatus = 'inbox' | 'today' | 'upcoming' | 'completed' | 'someday';

export interface SubTask {
  id: string;
  title: string;
  completed: boolean;
}

export interface Task {
  id: string;
  title: string;
  description?: string;
  status: TaskStatus;
  priority: Priority;
  dueDate?: string; // YYYY-MM-DD
  durationMinutes?: number;
  energyRequired?: EnergyLevel;
  projectId?: string;
  goalId?: string;
  subtasks: SubTask[];
  recurring?: 'none' | 'daily' | 'weekly' | 'monthly';
  dependencies?: string[]; // Task IDs
  timeBlockId?: string;
  tags: string[];
  createdAt: string;
  completedAt?: string;
}

export interface Milestone {
  id: string;
  title: string;
  targetDate?: string;
  completed: boolean;
}

export interface Goal {
  id: string;
  title: string;
  vision: string;
  area: 'Career' | 'Health' | 'Personal' | 'Finance' | 'Learning' | 'Creative';
  targetDate: string;
  progress: number; // 0 to 100
  milestones: Milestone[];
  status: 'active' | 'achieved' | 'paused';
  lastActivityAt: string;
  createdAt: string;
}

export interface Project {
  id: string;
  title: string;
  description: string;
  objectives?: string[];
  status: 'active' | 'on-hold' | 'completed';
  goalId?: string;
  area?: string;
  deadline: string;
  progress: number; // 0 to 100
  tags?: string[];
  timeBlockIds?: string[];
  createdAt: string;
}

export interface CalendarEvent {
  id: string;
  title: string;
  date: string; // YYYY-MM-DD
  startTime: string; // HH:mm
  endTime: string; // HH:mm
  type: 'event' | 'timeblock' | 'focus' | 'buffer';
  taskId?: string;
  projectId?: string;
  energyRequired?: EnergyLevel;
  isFixedCommitment: boolean;
  notes?: string;
}

export interface Habit {
  id: string;
  title: string;
  frequency: 'daily' | 'weekly' | 'flexible';
  targetDaysPerWeek: number;
  streak: number;
  completedDates: string[]; // ['YYYY-MM-DD']
  goalId?: string;
  reminderTime?: string;
  category: string;
  createdAt: string;
}

export type NoteType = 'note' | 'knowledge' | 'idea' | 'book_summary' | 'research' | 'learning' | 'document' | 'meeting' | 'review';

export type BlockType =
  | 'paragraph'
  | 'heading1'
  | 'heading2'
  | 'heading3'
  | 'todo'
  | 'bullet'
  | 'numbered'
  | 'quote'
  | 'callout'
  | 'toggle'
  | 'code'
  | 'divider'
  | 'relation_embed';

export interface BlockItem {
  id: string;
  type: BlockType;
  content: string;
  checked?: boolean;
  collapsed?: boolean;
  language?: string;
  relatedObjectId?: string;
  children?: BlockItem[];
}

export type LifeObjectType =
  | 'task'
  | 'note'
  | 'goal'
  | 'project'
  | 'habit'
  | 'event'
  | 'knowledge'
  | 'meeting'
  | 'review'
  | 'budget'
  | 'file'
  | 'custom';

export type RelationType =
  | 'parent'
  | 'child'
  | 'linked'
  | 'blocks'
  | 'blocked_by'
  | 'milestone_of'
  | 'habit_for'
  | 'note_for'
  | 'project_of'
  | 'task_of';

export interface LifeObjectRelation {
  id: string;
  targetId: string;
  targetType: LifeObjectType;
  relationType: RelationType;
  title?: string;
  targetTitle?: string;
}

export interface LifeObjectProperty {
  id: string;
  key: string;
  name: string;
  type: 'text' | 'number' | 'select' | 'multi_select' | 'status' | 'date' | 'checkbox' | 'url' | 'relation';
  value: any;
  options?: string[];
}

export interface Note {
  id: string;
  title: string;
  content: string;
  type: NoteType;
  tags: string[];
  backlinks: string[]; // Note IDs
  linkedTaskIds?: string[];
  linkedProjectIds?: string[];
  pinned?: boolean;
  isPinned?: boolean;
  blocks?: BlockItem[];
  properties?: Record<string, any>;
  relations?: LifeObjectRelation[];
  createdAt: string;
  updatedAt: string;
}

export type ViewType = 'list' | 'board' | 'calendar' | 'timeline' | 'table';

export interface LifeObject {
  id: string;
  type: LifeObjectType;
  title: string;
  description?: string;
  status?: string;
  priority?: Priority;
  dueDate?: string;
  targetDate?: string;
  date?: string;
  startTime?: string;
  endTime?: string;
  progress?: number; // 0 to 100
  durationMinutes?: number;
  energyRequired?: EnergyLevel;
  tags: string[];
  blocks?: BlockItem[];
  properties?: Record<string, any>;
  customProperties?: LifeObjectProperty[];
  relations: LifeObjectRelation[];
  subtasks?: SubTask[];
  isPinned?: boolean;
  isFavorite?: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface EnergyLog {
  id: string;
  date: string;
  timeOfDay: 'morning' | 'afternoon' | 'evening' | 'night';
  level: EnergyLevel;
  mood?: string;
  note?: string;
  tags?: string[];
}

export interface FinanceItem {
  id: string;
  title?: string;
  type: 'income' | 'expense';
  amount: number;
  category: string;
  date: string;
  isRecurring?: boolean;
  note?: string;
  goalId?: string;
}

export interface FocusSession {
  id: string;
  durationMinutes: number;
  completedAt: string;
  taskId?: string;
  projectId?: string;
  reflection?: string;
  rating?: number;
  distractionsCount?: number;
}

export interface WeeklyReview {
  id: string;
  weekStartDate: string;
  completedTaskCount?: number;
  unfinishedTaskCount?: number;
  highlights?: string[];
  whatMatters?: string;
  whatNeedsAttention?: string[];
  proposedActions?: {
    id: string;
    action: string;
    targetArea: string;
    approved?: boolean;
  }[];
  wins?: string[];
  misses?: string[];
  insights?: string;
  nextWeekFocus?: string[];
  focusHoursTotal?: number;
  status?: 'draft' | 'completed';
  createdAt: string;
}

export interface AutomationRule {
  id: string;
  title: string;
  trigger: string;
  action: string;
  enabled: boolean;
  description: string;
  whenTrigger?: 'task_completed' | 'task_created' | 'habit_completed' | 'habit_streak' | 'project_completed' | 'time_reached' | 'capture_created';
  ifCondition?: {
    field: string;
    operator: 'equals' | 'contains' | 'greater_than' | 'less_than' | 'in';
    value: any;
  };
  thenAction?: {
    type: 'create_task' | 'show_toast' | 'create_note' | 'schedule_block' | 'update_object' | 'run_ai_prompt';
    params: Record<string, any>;
  };
  lastTriggeredAt?: string;
  executionCount?: number;
}

export type TemplateCategory =
  | 'tasks'
  | 'calendar'
  | 'timeblocking'
  | 'goals'
  | 'habits'
  | 'money'
  | 'notes'
  | 'secondbrain'
  | 'focus'
  | 'energy'
  | 'reviews'
  | 'projects'
  | 'study'
  | 'planning'
  | 'content'
  | 'business'
  | 'lifeplanning'
  | 'universal'
  | 'meetings'
  | 'budgeting'
  | 'reading'
  | 'custom';

export interface TemplateVariable {
  key: string;
  label: string;
  placeholder: string;
  defaultValue: string;
  type: 'text' | 'date' | 'number' | 'select';
  options?: string[];
}

export interface TemplateBlueprint {
  goal?: Partial<Goal>;
  projects?: Partial<Project>[];
  milestones?: Partial<Milestone>[];
  tasks: Partial<Task>[];
  calendarEvents?: Partial<CalendarEvent>[];
  habits?: Partial<Habit>[];
  notes?: Partial<Note>[];
  automations?: Partial<AutomationRule>[];
}

export interface TemplateCreator {
  id?: string;
  name: string;
  avatar?: string;
  verified?: boolean;
  role?: string;
  bio?: string;
}

export interface TemplateItem {
  id: string;
  title: string;
  description: string;
  category: TemplateCategory;
  icon: string;
  color: string;
  isFavorite?: boolean;
  isBuiltIn?: boolean;
  isPublic?: boolean;
  status?: 'draft' | 'published' | 'private';
  version?: string;
  creator?: TemplateCreator;
  usageCount?: number;
  likesCount?: number;
  reportCount?: number;
  isReported?: boolean;
  featuresUsed?: string[];
  tags?: string[];
  variables: TemplateVariable[];
  blueprint: TemplateBlueprint;
  recentlyUsedAt?: string;
  createdAt?: string;
  updatedAt?: string;
}

export interface AIMemoryItem {
  id: string;
  category?: 'working_hours' | 'focus_times' | 'tone' | 'personal_rule' | 'project_rule';
  type?: 'preference' | 'behavior_pattern' | 'context' | 'fact';
  content?: string;
  fact?: string;
  confidence: number;
  active: boolean;
  createdAt: string;
}

export interface UniversalCapturePayload {
  rawContent: string;
  source: 'text' | 'voice' | 'link' | 'image' | 'file';
  audioBlobUrl?: string;
}

export interface AppSettings {
  theme: 'system' | 'light' | 'dark';
  aiRouting: 'hybrid' | 'cloud' | 'local';
  aiRoutingMode?: 'hybrid' | 'cloud_only' | 'local_only';
  aiMemoryEnabled: boolean;
  ambientSound: 'none' | 'rain' | 'whitenoise' | 'cafe' | 'waves';
  notificationsEnabled: boolean;
  onboardingCompleted: boolean;
  userName: string;
  userEmail?: string;
  userAvatar?: string;
  authProvider?: 'google' | 'guest';
  primaryAreas: string[];
  // AI Backbone Configuration
  preferredAIProvider: 'gemini' | 'openai';
  geminiApiKey?: string;
  openaiApiKey?: string;
  geminiModel?: string;
  openaiModel?: string;
  aiAutoFallback?: boolean;
}

export type HomeWidgetId =
  | 'clock'
  | 'priorities'
  | 'schedule'
  | 'habits'
  | 'goals'
  | 'projects'
  | 'energy'
  | 'templates'
  | 'automations'
  | 'quick_capture';

export interface HomeWidgetConfig {
  id: HomeWidgetId;
  enabled: boolean;
  order: number;
  title?: string;
}

// -------------------------------------------------------------
// AI Intelligent Control Architecture & App Action Types
// Pipeline: Understand → Context → Plan → Validate → Confirm → Execute → Verify → Save
// -------------------------------------------------------------

export type AppActionType =
  | 'create_task'
  | 'update_task'
  | 'delete_task'
  | 'toggle_task'
  | 'schedule_timeblock'
  | 'update_timeblock'
  | 'delete_timeblock'
  | 'create_habit'
  | 'toggle_habit'
  | 'create_goal'
  | 'create_project'
  | 'create_note'
  | 'apply_template'
  | 'create_life_object'
  | 'update_life_object'
  | 'delete_life_object'
  | 'run_automation'
  | 'add_home_widget'
  | 'remove_home_widget'
  | 'toggle_home_widget'
  | 'navigate_app'
  | 'start_focus'
  | 'update_settings'
  | 'change_theme';

export type PipelineStage =
  | 'understand'
  | 'context'
  | 'plan'
  | 'validate'
  | 'confirm'
  | 'execute'
  | 'verify'
  | 'save';

export interface AppActionProposal {
  id: string;
  actionType: AppActionType;
  title: string;
  description: string;
  requiresConfirmation: boolean;
  autoExecute?: boolean;
  isDestructive?: boolean;
  payload: any;
  status: 'planned' | 'validating' | 'confirmed' | 'executing' | 'verified' | 'failed' | 'undone';
  verificationMessage?: string;
  undoable: boolean;
  previousSnapshot?: any;
  executedAt?: string;
  verifiedAt?: string;
}

export interface UndoActionItem {
  id: string;
  actionId: string;
  actionType: AppActionType;
  title: string;
  timestamp: string;
  description?: string;
  snapshot: any;
}

export interface AIMessage {
  id: string;
  sender: 'user' | 'ai' | 'system';
  text: string;
  timestamp: string;
  type?: 'fact' | 'inference' | 'suggestion' | 'action_plan';
  pipelineStage?: PipelineStage;
  proposedActions?: AppActionProposal[];
}

export interface AIConversation {
  id: string;
  title: string;
  createdAt: string;
  updatedAt: string;
  messages: AIMessage[];
  pinned?: boolean;
}

// -------------------------------------------------------------
// Feature Registry Types for AI Help Center / Tutor
// -------------------------------------------------------------

export interface FeatureRegistryItem {
  id: string;
  name: string;
  category: 'core' | 'tasks' | 'plan' | 'notes' | 'life' | 'ai' | 'settings' | 'pwa';
  summary: string;
  detailedSteps: string[];
  tips: string[];
  targetNav?: MainNav;
  targetSubNav?: string;
  sampleAction?: {
    label: string;
    actionType: AppActionType;
    payload: any;
  };
}

export type HelpCategory =
  | 'getting-started'
  | 'tasks'
  | 'plan'
  | 'notes'
  | 'life'
  | 'focus'
  | 'ai'
  | 'settings'
  | 'privacy'
  | 'shortcuts'
  | 'tasks-gtd'
  | 'plan-calendar'
  | 'notes-secondbrain'
  | 'life-habits-projects'
  | 'ai-intelligence'
  | 'privacy-sync-backup'
  | 'settings-personalization'
  | 'mobile-gestures-pwa'
  | 'troubleshooting'
  | string;

export interface HelpArticle {
  id: string;
  title: string;
  category: HelpCategory;
  categoryLabel: string;
  keywords: string[];
  summary: string;
  whereToFind?: string;
  steps: string[];
  advancedTips?: string[];
  troubleshooting?: string[];
  action?: {
    label: string;
    actionType?: string;
    targetNav?: MainNav;
    subNav?: string;
    modal?: 'capture' | 'search' | 'focus' | 'settings' | 'review' | string;
    payload?: any;
    run?: () => void;
    [key: string]: any;
  };
  relatedAction?: {
    label: string;
    nav?: MainNav;
    subNav?: string;
    modal?: 'capture' | 'search' | 'focus' | 'settings' | 'review' | string;
  };
}


