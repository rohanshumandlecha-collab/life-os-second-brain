import { HelpArticle, HelpCategory } from '../types';

export const LIFE_OS_KNOWLEDGE_BASE: HelpArticle[] = [
  // ==========================================
  // 1. GETTING STARTED & OVERVIEW
  // ==========================================
  {
    id: 'getting-started-overview',
    title: 'Getting Started: The 9-Step Life Operating System',
    category: 'getting-started',
    categoryLabel: 'Getting Started',
    keywords: ['start', 'beginner', 'overview', 'philosophy', 'how to use', 'first time', 'teach me', 'guide'],
    summary:
      'Life OS is a unified, privacy-first personal operating system designed to turn raw daily inputs into clear, focused action without clutter.',
    whereToFind: 'Home screen & global navigation',
    steps: [
      '1. Capture: Quickly record every thought, task, or idea using Universal Quick Capture (Press C or tap the + button).',
      '2. Understand & Organize: Review incoming items in Tasks > Inbox or Notes > Second Brain.',
      '3. Prioritize: Move high-impact items to your "Today" view in Tasks.',
      '4. Plan: Use Plan > Time Blocking or Calendar to carve out dedicated focus slots.',
      '5. Act: Launch Focus Mode (Clock icon in Header) to eliminate distractions with built-in ambient soundscapes.',
      '6. Track & Learn: Check off daily habits, log energy levels, and track financial burn rate in the Life tab.',
      '7. Review: Conduct a structured Weekly Review every Sunday or Friday to celebrate wins and reset for next week.',
    ],
    advancedTips: [
      'Use keyboard shortcuts: Press ⌘K / Ctrl+K for search and C for instant capture anywhere in the app.',
      'Swipe left or right on mobile to navigate between primary tabs smoothly.',
    ],
    troubleshooting: [
      'If you ever feel overwhelmed, focus only on the top 3 items in your Today view on the Home screen.',
    ],
    action: {
      id: 'act-go-home',
      label: 'Go to Home Screen',
      actionType: 'navigate',
      payload: { nav: 'home' },
      icon: 'Home',
    },
  },
  {
    id: 'interactive-curriculum',
    title: 'Progressive Life OS Mastery: Beginner to Advanced',
    category: 'getting-started',
    categoryLabel: 'Getting Started',
    keywords: ['curriculum', 'tutorial', 'learn everything', 'beginner to advanced', 'walkthrough'],
    summary:
      'A structured 4-level pathway to master Life OS step-by-step from zero to executive productivity.',
    whereToFind: 'Help Center > Interactive Guide',
    steps: [
      'Level 1: The Daily Essentials (Day 1-3) — Use Universal Quick Capture (C key), manage your Today task list on Home, and complete 1 focus block.',
      'Level 2: Time Architecture (Day 4-7) — Build 2-3 daily time blocks in Plan > Time Blocking, match them to your morning peak energy, and track 2 habits in Life > Habits.',
      'Level 3: The Second Brain (Week 2) — Store project notes in Notes > PARA system, link related ideas, and explore the interactive 3D Knowledge Graph.',
      'Level 4: Autonomous Life System (Week 3+) — Configure custom AI Memory rules, set up smart Automations, and run AI-generated Weekly Reviews.',
    ],
    advancedTips: [
      'Do not try to set up all 4 levels on day one. Master capturing and today’s tasks first.',
    ],
    action: {
      id: 'act-start-curriculum',
      label: 'Open Quick Capture (Level 1)',
      actionType: 'open_capture',
      icon: 'Plus',
    },
  },

  // ==========================================
  // 2. HOME SCREEN & COMMAND CENTER
  // ==========================================
  {
    id: 'home-command-center',
    title: 'Home: The 5-Second Command Center',
    category: 'getting-started',
    categoryLabel: 'Home Screen',
    keywords: ['home', 'dashboard', 'command center', 'overview', 'today priorities', 'daily briefing'],
    summary:
      'The Home screen is engineered for a 5-second check-in: see today’s top priorities, upcoming schedule, active habits, and AI intelligence.',
    whereToFind: 'Navigation > Home tab (first icon)',
    steps: [
      '1. Review Daily Intelligence Briefing: The top banner highlights your next upcoming block and daily capacity.',
      '2. Fast Capture Input: Type any thought or task in the input bar ("Quick capture a task...") and press Enter.',
      '3. Today’s Priorities: Tap the circle checkbox to complete a task, or tap any task to expand details.',
      '4. Today’s Schedule: View time-blocked events scheduled for today with start times and duration.',
      '5. Habits & Goals Snapshot: Check off daily habits right on the right sidebar and view active goal progress.',
    ],
    advancedTips: [
      'Tap "Focus Mode" in the top right to start a distraction-free Pomodoro session right from Home.',
    ],
    action: {
      id: 'act-nav-home',
      label: 'Go to Home',
      actionType: 'navigate',
      payload: { nav: 'home' },
      icon: 'Home',
    },
  },
  {
    id: 'home-show-only-today',
    title: 'How to make Home show only today’s tasks',
    category: 'tasks',
    categoryLabel: 'Tasks',
    keywords: ['home show today', 'filter today', 'clean home', 'today only', 'hide backlog'],
    summary:
      'Home is specifically designed to only display tasks with status "Today". Learn how to manage statuses so your Home stays laser-focused.',
    whereToFind: 'Tasks tab > Status selector or Home > Today’s Priorities',
    steps: [
      '1. Go to the "Tasks" view via the top bar or bottom navigation.',
      '2. Inspect your tasks: tasks marked as "Inbox", "Upcoming", or "Someday" will NEVER clutter your Home view.',
      '3. To add a task to Today, click the task row to expand it, tap "Status", and select "Today".',
      '4. To remove a task from Home without deleting it, change its status to "Upcoming" or "Someday".',
      '5. Only tasks explicitly intended for today will appear in the Home "Today’s Priorities" list.',
    ],
    advancedTips: [
      'Keep your Today queue under 5 items for maximum psychological momentum.',
    ],
    action: {
      id: 'act-go-tasks-today',
      label: 'Manage Today’s Tasks',
      actionType: 'navigate',
      payload: { nav: 'tasks' },
      icon: 'CheckSquare',
    },
  },

  // ==========================================
  // 3. TASKS & CHECKLISTS
  // ==========================================
  {
    id: 'tasks-management',
    title: 'Tasks: Organization, Priorities & Subtasks',
    category: 'tasks',
    categoryLabel: 'Tasks',
    keywords: ['task', 'tasks', 'todo', 'checklist', 'subtask', 'priority', 'due date', 'recurring', 'inbox'],
    summary:
      'A powerful GTD-compliant task manager with Inbox, Today, Upcoming, and Completed views, subtask checklists, and project linking.',
    whereToFind: 'Navigation > Tasks tab',
    steps: [
      '1. Status Tabs: Switch between "Today", "Inbox", "Upcoming", "Completed", and "All" using the segmented control.',
      '2. Rapid Inline Add: Type a task into the "+ Add a new task..." row at the top of the list and press Enter.',
      '3. Full Task Modal: Tap "+ New Task" in the top right to configure due dates, priority (Urgent/High/Med/Low), duration in minutes, and energy level.',
      '4. Subtask Checklists: Tap any task to expand details, type into the "Add item..." checklist field, and press Enter.',
      '5. Filter by Priority or Project: Use the filter dropdowns above the task list to narrow down your view.',
    ],
    advancedTips: [
      'Marking a task Urgent highlights it in vivid red and prioritizes it at the top of your Home screen.',
    ],
    action: {
      id: 'act-nav-tasks',
      label: 'Open Tasks View',
      actionType: 'navigate',
      payload: { nav: 'tasks' },
      icon: 'CheckSquare',
    },
  },

  // ==========================================
  // 4. CALENDAR & TIME BLOCKING
  // ==========================================
  {
    id: 'calendar-and-timeblocking',
    title: 'How to create and use Time Blocks',
    category: 'plan',
    categoryLabel: 'Plan & Calendar',
    keywords: ['time block', 'time blocking', 'calendar', 'schedule', 'create time block', 'ai smart schedule', 'plan'],
    summary:
      'Transform intentions into calendar commitments. Block out deep work sessions, align with energy rhythms, and prevent scheduling overlaps.',
    whereToFind: 'Navigation > Plan > Time Blocking (or Calendar)',
    steps: [
      '1. Navigate to "Plan" in the top menu or bottom tab bar.',
      '2. Choose the "Time Blocking" or "Calendar" sub-tab.',
      '3. Tap "+ Add Block" in the upper right corner.',
      '4. Set the Block Title (e.g. "Deep Work: Project Architecture").',
      '5. Select Start Time and End Time (e.g., 09:00 to 10:30).',
      '6. Choose the block Type: "timeblock", "focus", "event", or "buffer".',
      '7. (Optional) Select a linked task from your active queue.',
      '8. Tap "Schedule Block" to place it onto your 24-hour visual day timeline.',
    ],
    advancedTips: [
      'Tap "AI Smart Schedule" in the Plan header to have the AI automatically place today’s highest-priority tasks into optimal morning energy slots.',
      'Red indicator lines flag any overlapping events so you never double-book.',
    ],
    troubleshooting: [
      'If a time block does not appear on today’s schedule, verify that the date picker at the top matches today’s date.',
    ],
    action: {
      id: 'act-nav-timeblocking',
      label: 'Go to Time Blocking',
      actionType: 'navigate',
      payload: { nav: 'plan', subNav: 'timeblocking' },
      icon: 'Clock',
    },
  },

  // ==========================================
  // 5. GOALS & MILESTONES
  // ==========================================
  {
    id: 'goals-and-milestones',
    title: 'Goals: Milestones & Progress Tracking',
    category: 'plan',
    categoryLabel: 'Plan & Goals',
    keywords: ['goals', 'milestone', 'okr', 'vision', 'progress', 'target date', 'achieved'],
    summary:
      'Set long-range visions categorized by life domain (Career, Health, Personal, Finance, Learning, Creative) with automated progress bars.',
    whereToFind: 'Navigation > Plan > Goals sub-tab',
    steps: [
      '1. Open "Plan" and select the "Goals" sub-tab.',
      '2. Tap "+ New Goal" in the top right.',
      '3. Enter your Goal Title, primary Life Area, Target Date, and Vision statement.',
      '4. Add individual milestones on separate lines in the milestones box.',
      '5. Save your goal. As you check off milestone checkboxes, your goal’s progress percentage automatically updates.',
    ],
    action: {
      id: 'act-nav-goals',
      label: 'View Goals',
      actionType: 'navigate',
      payload: { nav: 'plan', subNav: 'goals' },
      icon: 'Target',
    },
  },

  // ==========================================
  // 6. HABITS & STREAKS
  // ==========================================
  {
    id: 'habits-tracking',
    title: 'Habits: Streaks & Daily Check-Ins',
    category: 'life',
    categoryLabel: 'Life & Habits',
    keywords: ['habit', 'habits', 'streak', 'daily check-in', 'consistency', 'routine'],
    summary:
      'Build non-negotiable daily and weekly rituals. Track streaks with real-time feedback and flame indicators.',
    whereToFind: 'Navigation > Life > Habits sub-tab',
    steps: [
      '1. Go to "Life" and select "Habits".',
      '2. Tap "+ New Habit" to create a new routine (e.g., "Morning Hydration & Sunlight", "Read 20 pages").',
      '3. Choose frequency (Daily, Weekly, or Flexible) and target days per week.',
      '4. To check in for today: simply tap the circle checkbox next to the habit on either Home or the Habits view.',
      '5. The flame icon displays your current consecutive day streak.',
    ],
    action: {
      id: 'act-nav-habits',
      label: 'Go to Habits',
      actionType: 'navigate',
      payload: { nav: 'life', subNav: 'habits' },
      icon: 'Repeat',
    },
  },

  // ==========================================
  // 7. NOTES & SECOND BRAIN GRAPH
  // ==========================================
  {
    id: 'notes-para-and-second-brain',
    title: 'Notes & Second Brain: PARA Method & Knowledge Graph',
    category: 'notes',
    categoryLabel: 'Notes & Knowledge',
    keywords: ['notes', 'second brain', 'graph', 'para', 'knowledge', 'backlinks', 'markdown', 'ideas'],
    summary:
      'A Tiago Forte PARA-inspired knowledge vault. Organize notes into Projects, Areas, Resources, and Archives, and explore connected concepts via an interactive 2D/3D knowledge graph.',
    whereToFind: 'Navigation > Notes > Notes or Second Brain sub-tab',
    steps: [
      '1. View Notes: Open "Notes" to view your markdown document library with search and tag filters.',
      '2. Create a Note: Tap "+ New Note", write in markdown, select note type (Note, Knowledge, Idea, Research), and add tags.',
      '3. Pin Notes: Tap the star or pin icon to keep important reference cards at the top of your library.',
      '4. Explore Second Brain Graph: Click the "Second Brain" sub-tab to launch the interactive knowledge node graph.',
      '5. Graph Interaction: Drag nodes, click any node to read its linked contents, and discover emergent connections across your ideas.',
    ],
    advancedTips: [
      'Notes captured through Universal Quick Capture are automatically categorized as "knowledge" or "note" and linked to relevant projects.',
    ],
    action: {
      id: 'act-nav-notes',
      label: 'Explore Second Brain',
      actionType: 'navigate',
      payload: { nav: 'notes', subNav: 'secondbrain' },
      icon: 'Brain',
    },
  },

  // ==========================================
  // 8. FOCUS MODE & AMBIENT SOUNDSCAPES
  // ==========================================
  {
    id: 'focus-mode-and-sound',
    title: 'Focus Mode: Pomodoro Timer & Synthesized Soundscapes',
    category: 'focus',
    categoryLabel: 'Focus & Sound',
    keywords: ['focus', 'pomodoro', 'timer', 'sound', 'ambient', 'rain', 'white noise', 'synthesizer', 'distraction'],
    summary:
      'A dedicated full-screen focus chamber with customizable Pomodoro intervals (25m / 50m / custom) and synthesized ambient soundscapes generated in real-time via the Web Audio API.',
    whereToFind: 'Header > Clock icon, or Home > "Focus Mode" button',
    steps: [
      '1. Tap the Clock icon in the top header or the "Focus Mode" button on the Home screen.',
      '2. Select your timer duration: 25 minutes, 50 minutes, or a custom duration.',
      '3. Select an Ambient Soundscape: Choose between Rain, Ocean Waves, White Noise, or Binaural Drone.',
      '4. Link an optional Task: Choose what you are working on during this session.',
      '5. Tap "Start Focus": The distraction shield activates, and full-screen timer commences.',
      '6. When complete, your session is automatically logged to your productivity history.',
    ],
    advancedTips: [
      'Ambient sounds are procedurally generated directly in your browser using audio synthesizers — zero streaming bandwidth or buffering.',
      'You can also toggle background rain sound instantly from the speaker icon in the top header without opening Focus Mode.',
    ],
    action: {
      id: 'act-open-focus',
      label: 'Open Focus Mode',
      actionType: 'open_focus',
      icon: 'Clock',
    },
  },

  // ==========================================
  // 9. ENERGY & RHYTHMS
  // ==========================================
  {
    id: 'energy-and-chronotypes',
    title: 'Energy & Rhythms: Chronotype & Capacity Tracking',
    category: 'life',
    categoryLabel: 'Life & Energy',
    keywords: ['energy', 'chronotype', 'circadian', 'rhythm', 'capacity', 'peak focus', 'fatigue'],
    summary:
      'Align demanding cognitive tasks with your biological peak hours. Log daily energy levels (1-5) and discover your personal productivity curve.',
    whereToFind: 'Navigation > Life > Energy & Rhythms sub-tab',
    steps: [
      '1. Go to "Life" and select "Energy & Rhythms".',
      '2. Check in: Select your current energy level (Low, Medium, High, or Peak) and add an optional note.',
      '3. Review Circadian Curve: Check your visual rhythm chart to identify your optimal morning and afternoon deep work windows.',
      '4. Plan accordingly: Schedule heavy creative and strategic tasks during Peak hours, and administrative tasks during Low energy troughs.',
    ],
    action: {
      id: 'act-nav-energy',
      label: 'Go to Energy Tracking',
      actionType: 'navigate',
      payload: { nav: 'life', subNav: 'energy' },
      icon: 'Zap',
    },
  },

  // ==========================================
  // 10. MONEY & FINANCIAL CLARITY
  // ==========================================
  {
    id: 'money-and-finances',
    title: 'Money: Financial Runway & Burn Rate Clarity',
    category: 'life',
    categoryLabel: 'Life & Money',
    keywords: ['money', 'finance', 'burn rate', 'expenses', 'income', 'budget', 'runway', 'subscriptions'],
    summary:
      'Keep financial anxiety low with clear monthly metrics: track fixed burn rate, recurring subscriptions, and runway calculations.',
    whereToFind: 'Navigation > Life > Money sub-tab',
    steps: [
      '1. Go to "Life" and select "Money".',
      '2. View your high-level financial overview: Monthly Inflow, Monthly Burn Rate, Net Savings, and Runway estimate.',
      '3. Tap "+ Log Transaction" to record an income or expense with category and recurring toggle.',
      '4. Review the category breakdown chart to pinpoint areas for optimization.',
    ],
    action: {
      id: 'act-nav-money',
      label: 'View Money & Finances',
      actionType: 'navigate',
      payload: { nav: 'life', subNav: 'money' },
      icon: 'DollarSign',
    },
  },

  // ==========================================
  // 11. WEEKLY REVIEW RITUAL
  // ==========================================
  {
    id: 'weekly-review-ritual',
    title: 'Weekly Review: Sunday Reflection Ritual & AI Synthesis',
    category: 'getting-started',
    categoryLabel: 'Reviews',
    keywords: ['weekly review', 'review', 'reflection', 'sunday ritual', 'ai review', 'audit'],
    summary:
      'A structured 4-part weekly reflection framework (What happened, What matters, What needs attention, Next actions) powered by automated AI synthesis.',
    whereToFind: 'Universal Search > "Weekly Review" or AI Assistant view',
    steps: [
      '1. Launch the Weekly Review: Open Universal Search (⌘K) and type "Review", or click "Start Review" in the AI Assistant.',
      '2. Part 1: What Happened — Audit completed vs open tasks, habit consistency, and total focus hours.',
      '3. Part 2: What Matters — Reconnect with your primary quarterly goals and vision.',
      '4. Part 3: What Needs Attention — Identify stalled projects, overdue tasks, or dropped habits.',
      '5. Part 4: Proposed Actions — Approve actionable recommendations to schedule for the coming week.',
      '6. Tap "Save Weekly Review" to store your reflection in your review history.',
    ],
    action: {
      id: 'act-open-review',
      label: 'Start Weekly Review',
      actionType: 'open_review',
      icon: 'Sparkles',
    },
  },

  // ==========================================
  // 12. UNIVERSAL SEARCH (⌘K)
  // ==========================================
  {
    id: 'universal-search-guide',
    title: 'Universal Search: Instant Access Across Everything',
    category: 'shortcuts',
    categoryLabel: 'Search & Shortcuts',
    keywords: ['search', 'cmd k', 'universal search', 'find', 'filter', 'keyboard shortcut'],
    summary:
      'A lightning-fast spotlight search modal that queries all tasks, projects, goals, notes, and calendar events simultaneously.',
    whereToFind: 'Header > "Search" button, or press ⌘K (Cmd+K) / Ctrl+K',
    steps: [
      '1. Press ⌘K on macOS, Ctrl+K on Windows/Linux, or tap the Search button in the top header.',
      '2. Start typing any keyword (e.g. project name, task title, note concept).',
      '3. Results appear grouped by category: Tasks, Projects, Notes, Goals, and Events.',
      '4. Click any result to immediately navigate directly to that item in the app.',
      '5. Press Escape (Esc) to dismiss search at any time.',
    ],
    action: {
      id: 'act-open-search',
      label: 'Open Universal Search',
      actionType: 'open_search',
      icon: 'Search',
    },
  },

  // ==========================================
  // 13. UNIVERSAL QUICK CAPTURE (C KEY)
  // ==========================================
  {
    id: 'universal-quick-capture',
    title: 'Universal Quick Capture: Zero-Friction Thought Ingestion',
    category: 'getting-started',
    categoryLabel: 'Capture & Input',
    keywords: ['quick capture', 'capture', 'press c', 'floating button', 'voice input', 'auto-routing', 'multimodal'],
    summary:
      'Never lose an idea. Hit "C" anywhere in the app to capture thoughts via text, voice, link, or image. AI automatically categorizes and routes it to the right module.',
    whereToFind: 'Floating "+" button in bottom-right corner, or press "C"',
    steps: [
      '1. Press "C" on your keyboard or tap the floating blue "+" button in the lower right corner.',
      '2. Choose your input modality: Text, Voice Recording, Web Link, or Image attachment.',
      '3. Enter your raw thought (e.g., "Schedule dentist next Tuesday at 2pm", or "Book note: The Psychology of Money").',
      '4. (Optional) Choose Manual Override or let AI Auto-Route handle classification.',
      '5. Tap "Capture Thought": The system automatically parses due dates, priority, and assigns it to Tasks, Events, Habits, or Notes.',
    ],
    action: {
      id: 'act-open-capture',
      label: 'Open Quick Capture (C)',
      actionType: 'open_capture',
      icon: 'Plus',
    },
  },

  // ==========================================
  // 14. AI ASSISTANT, MEMORY & PERSONALIZATION
  // ==========================================
  {
    id: 'ai-assistant-overview',
    title: 'AI Assistant: Executive Coach & Strategic Advisor',
    category: 'ai',
    categoryLabel: 'AI Intelligence',
    keywords: ['ai', 'assistant', 'gemini', 'openai', 'coach', 'chat', 'intelligence', 'ask ai'],
    summary:
      'An intelligent executive coach with full context of your tasks, projects, goals, energy logs, and calendar. Provides honest, actionable coaching.',
    whereToFind: 'Navigation > AI tab (Sparkles icon)',
    steps: [
      '1. Navigate to the "AI" tab.',
      '2. Choose from quick prompt suggestions (e.g. "What should I focus on right now?", "Audit my stalled goals", "Plan my day around high energy") or type a custom question.',
      '3. The AI analyzes your real context and responds with structured advice and one-tap action buttons.',
      '4. When the AI proposes an action (e.g. create a focus block or add a task), tap the button to execute it instantly in your app.',
    ],
    action: {
      id: 'act-nav-ai',
      label: 'Open AI Assistant',
      actionType: 'navigate',
      payload: { nav: 'ai' },
      icon: 'Sparkles',
    },
  },
  {
    id: 'ai-memory-and-rules',
    title: 'How AI Memory works: Storage, Privacy & Controls',
    category: 'ai',
    categoryLabel: 'AI Intelligence',
    keywords: ['ai memory', 'memory', 'personal rules', 'privacy', 'how does memory work', 'reset memory', 'what does it store'],
    summary:
      'Understand exactly what the AI remembers about you, how that knowledge is applied, and how you retain total sovereignty over your memory vault.',
    whereToFind: 'AI tab > "Personal Rules & Memory" tab, or Settings modal',
    steps: [
      '1. What AI Memory Stores: Working hour boundaries, preferred tone (direct/concise), chronotype/energy preferences, and explicit rules you specify (e.g. "Never schedule deep work after 6pm").',
      '2. What It Never Stores: Passwords, credentials, payment details, or unapproved chat logs.',
      '3. How Memory is Used: Active memories are injected as system instructions into AI calls so coaching is tailored to your real life without repetitive prompting.',
      '4. Managing Memories: Go to the AI view, switch to the "Personal Rules & Memory" tab.',
      '5. Toggle On/Off: Use the toggle switch on each memory item to temporarily enable or disable it.',
      '6. Delete or Reset: Click the trash icon to remove an individual memory, or tap "Clear All Memory" to wipe the memory vault clean.',
    ],
    advancedTips: [
      'You can also disable AI memory entirely in Settings > AI Backbone if you prefer zero persistent memory.',
    ],
    action: {
      id: 'act-nav-ai-memory',
      label: 'Manage AI Memories',
      actionType: 'navigate',
      payload: { nav: 'ai' },
      icon: 'Brain',
    },
  },
  {
    id: 'ai-actions-explain-guide-do',
    title: 'AI Actions: Explain → Guide → Do it for me',
    category: 'ai',
    categoryLabel: 'AI Intelligence',
    keywords: ['ai actions', 'do it for me', 'automate', 'execute action', 'app action api'],
    summary:
      'Life OS AI is not just a chat window — it can execute real changes in your app with a single confirmation tap.',
    whereToFind: 'AI Assistant view and Help Center',
    steps: [
      '1. Explain: Ask the AI how to do something or ask it for a recommendation.',
      '2. Guide: The AI returns exact step-by-step instructions so you learn how the feature works.',
      '3. Do it for me: Where supported, the AI provides an interactive Action Button at the bottom of its response.',
      '4. Tap the button (e.g. "Switch to Dark Mode", "Open Focus Mode", "Add Task: Buy Groceries"): The action executes immediately and safely in your current session.',
    ],
  },
  {
    id: 'automations-engine',
    title: 'Automations: Rules-Based Productivity Workflows',
    category: 'ai',
    categoryLabel: 'AI Intelligence',
    keywords: ['automation', 'automations', 'triggers', 'rules', 'if this then that'],
    summary:
      'Set up event-driven automation rules to eliminate manual busywork between tasks, goals, and reviews.',
    whereToFind: 'AI tab > "Automations" sub-tab',
    steps: [
      '1. Open the "AI" tab and select "Automations".',
      '2. Browse pre-configured rules (e.g., "When task is marked urgent, automatically add to today", "When goal milestone reached, update progress %").',
      '3. Toggle rules on or off with the toggle switches.',
      '4. Tap "+ New Rule" to configure custom Trigger & Action combinations.',
    ],
    action: {
      id: 'act-nav-automations',
      label: 'View Automations',
      actionType: 'navigate',
      payload: { nav: 'ai' },
      icon: 'Zap',
    },
  },

  // ==========================================
  // 15. AI BACKBONE: GEMINI, OPENAI & LOCAL AI
  // ==========================================
  {
    id: 'ai-providers-keys-and-local-fallback',
    title: 'Gemini, OpenAI & Local AI: Keys and Offline Resilience',
    category: 'settings',
    categoryLabel: 'Settings & AI Models',
    keywords: ['gemini', 'openai', 'api key', 'models', 'local ai', 'cloud ai', 'offline', 'gpt-4o', 'fallback'],
    summary:
      'Connect your own Google Gemini or OpenAI API keys, choose custom models, and enjoy automatic local offline fallback if disconnected.',
    whereToFind: 'Header > Settings icon > "AI Engine & Backbone"',
    steps: [
      '1. Open Settings by clicking the Gear icon in the top header.',
      '2. Locate the "AI Engine & Backbone" section.',
      '3. Select your Preferred AI Provider: Google Gemini or OpenAI.',
      '4. Enter your custom API Key (Gemini API Key or OpenAI API Key).',
      '5. Tap "Validate Key" to verify network latency and credentials.',
      '6. Model Selection: Choose your model (e.g. gemini-3.6-flash, gemini-flash-latest, gpt-4o-mini, gpt-4o).',
      '7. Auto Fallback: Keep "Automatic Fallback" enabled so if a model is unavailable or you are offline, local heuristic intelligence steps in seamlessly.',
    ],
    advancedTips: [
      'API keys are stored exclusively in your browser localStorage and transmitted via secure Bearer proxy headers — never stored on external third-party servers.',
    ],
    troubleshooting: [
      'If key validation fails, ensure your API key has active billing or quota on Google AI Studio or platform.openai.com.',
      'The app works completely offline without API keys using built-in local heuristic planners.',
    ],
    action: {
      id: 'act-open-settings-keys',
      label: 'Open AI Key Settings',
      actionType: 'open_settings',
      icon: 'Settings',
    },
  },

  // ==========================================
  // 16. PRIVACY, SECURITY & DATA OWNERSHIP
  // ==========================================
  {
    id: 'privacy-security-data-ownership',
    title: 'Privacy, Security & Data Sovereignty',
    category: 'privacy',
    categoryLabel: 'Privacy & Security',
    keywords: ['privacy', 'security', 'data', 'cloud', 'offline', 'encryption', 'gdpr', 'telemetry'],
    summary:
      'Life OS is built on the principle of personal sovereignty. Your data belongs to you, runs locally in your browser, and features zero advertising or tracking.',
    whereToFind: 'Settings modal > Privacy & Data section',
    steps: [
      '1. Local-First Architecture: All tasks, notes, habits, and financial logs are stored in your device’s browser storage.',
      '2. Zero Telemetry: No third-party behavioral trackers or ad networks are integrated.',
      '3. Optional Cloud Sync: If you sign in with Google Firebase, your data is synced securely to your private Firebase Firestore instance with strict per-user security rules.',
      '4. Immediate Data Export: You can export your entire database as a single portable JSON file at any moment.',
    ],
    action: {
      id: 'act-export-data',
      label: 'Export My Data (JSON)',
      actionType: 'export_data',
      icon: 'ShieldCheck',
    },
  },

  // ==========================================
  // 17. GOOGLE LOGIN & CLOUD SYNC
  // ==========================================
  {
    id: 'google-login-and-sync',
    title: 'Google Login & Multi-Device Cloud Sync',
    category: 'settings',
    categoryLabel: 'Accounts & Sync',
    keywords: ['google login', 'firebase', 'sync', 'account', 'sign in', 'multi device', 'cloud backup'],
    summary:
      'Sign in with your Google account to enable instantaneous cross-device cloud synchronization powered by Firebase Firestore.',
    whereToFind: 'Header > Avatar or Settings > Account section',
    steps: [
      '1. Tap your Avatar or Gear icon in the top header to open Settings.',
      '2. In the "Account & Sync" section, tap "Sign in with Google".',
      '3. Complete the Google authentication popup.',
      '4. Once authenticated, your profile avatar and email appear in the header.',
      '5. All changes made on your phone, tablet, or desktop synchronize in real-time.',
      '6. To sign out, open Settings and tap "Sign Out". You can continue using Life OS in local guest mode anytime.',
    ],
    action: {
      id: 'act-open-settings-account',
      label: 'Open Account Settings',
      actionType: 'open_settings',
      icon: 'Settings',
    },
  },

  // ==========================================
  // 18. BACKUP, DATA EXPORT & IMPORT
  // ==========================================
  {
    id: 'backup-export-import',
    title: 'Backup, Export & Import: Full Data Portability',
    category: 'settings',
    categoryLabel: 'Data & Backup',
    keywords: ['backup', 'export', 'import', 'json', 'restore', 'reset data', 'transfer'],
    summary:
      'Download a complete JSON snapshot of your entire Life OS at any time, or restore from a previous backup file.',
    whereToFind: 'Settings modal > "Data Management & Backup"',
    steps: [
      '1. Open Settings (Gear icon in top header).',
      '2. Scroll down to the "Data Management & Backup" section.',
      '3. To Export: Click "Export All Data (JSON)". A timestamped .json file containing all tasks, notes, goals, habits, and settings downloads immediately.',
      '4. To Import: Click "Import Backup (JSON)" and select your previously saved JSON file.',
      '5. To Reset to Defaults: Click "Reset to Sample Data" if you ever want a fresh clean slate.',
    ],
    action: {
      id: 'act-export-json',
      label: 'Download Backup Now',
      actionType: 'export_data',
      icon: 'Save',
    },
  },

  // ==========================================
  // 19. SETTINGS, THEMES & AUDIO
  // ==========================================
  {
    id: 'settings-themes-and-audio',
    title: 'Themes (Light, Dark OLED & System) and Audio Settings',
    category: 'settings',
    categoryLabel: 'Settings & Appearance',
    keywords: ['theme', 'dark mode', 'light mode', 'oled', 'system theme', 'appearance', 'audio', 'sound'],
    summary:
      'Switch between iOS System Light, True OLED Black Dark Mode, and automatic system detection, with customizable ambient sound presets.',
    whereToFind: 'Header > Theme icon (Sun/Moon/Laptop) or Settings modal',
    steps: [
      '1. Fast Theme Toggle: Tap the Sun/Moon/Laptop icon in the top header to cycle instantly between Light, Dark, and System mode.',
      '2. In Settings: Open Settings and choose your preferred Theme and Accent color palette.',
      '3. Ambient Soundscapes: Toggle background soundscapes in the header (Volume icon) or configure your default ambient sound preset in Settings.',
    ],
    action: {
      id: 'act-toggle-theme',
      label: 'Cycle Theme Mode',
      actionType: 'switch_theme',
      icon: 'Sun',
    },
  },

  // ==========================================
  // 20. KEYBOARD SHORTCUTS & MOBILE GESTURES
  // ==========================================
  {
    id: 'keyboard-shortcuts-and-gestures',
    title: 'Keyboard Shortcuts & Native Mobile Gestures',
    category: 'shortcuts',
    categoryLabel: 'Shortcuts & Gestures',
    keywords: ['keyboard shortcuts', 'shortcuts', 'gestures', 'swipe', 'hotkeys', 'hotkey', 'navigation'],
    summary:
      'Supercharge your daily workflow with rapid keyboard hotkeys on desktop and fluid touch gestures on mobile devices.',
    whereToFind: 'Available everywhere in the application',
    steps: [
      'Desktop Keyboard Shortcuts:',
      '• ⌘K or Ctrl+K: Open Universal Search spotlight.',
      '• C: Open Universal Quick Capture modal from any view.',
      '• Esc: Close any active modal, drawer, or search window.',
      '• Enter: Submit inline task additions and quick captures.',
      'Mobile Gestures & Ergonomics:',
      '• Swipe Left / Right: Horizontally swipe the screen canvas to fluidly switch between tabs.',
      '• Fixed Bottom Tab Bar: Easy one-handed thumb navigation across Home, Tasks, Plan, Notes, Life, and AI.',
      '• Pull / Tap Outside: Dismiss bottom sheets smoothly.',
    ],
    action: {
      id: 'act-open-search-shortcuts',
      label: 'Try Universal Search (⌘K)',
      actionType: 'open_search',
      icon: 'Command',
    },
  },

  // ==========================================
  // 21. TROUBLESHOOTING & FAQS
  // ==========================================
  {
    id: 'troubleshooting-calendar-sync',
    title: 'Troubleshooting: Why isn’t my calendar syncing or updating?',
    category: 'troubleshooting',
    categoryLabel: 'Troubleshooting',
    keywords: ['calendar sync', 'sync issue', 'event not showing', 'troubleshoot', 'calendar bug', 'help sync'],
    summary:
      'Step-by-step diagnostic guide for calendar events, time blocks, and Google sync resolution.',
    whereToFind: 'Plan > Calendar or Settings > Account',
    steps: [
      '1. Verify Date Filter: Check the date picker at the top of Plan > Calendar. Ensure you are viewing the actual date of your event.',
      '2. Check Cloud Connection: If using Google Sign-In, check your network connection in Settings > Account. If token has expired, click "Sign Out" and re-authenticate.',
      '3. Refresh Browser: Hard refresh the page (Cmd+Shift+R or Ctrl+F5) to clear temporary in-memory state.',
      '4. Offline Mode: If offline, events are safely queued in localStorage and will sync once internet connectivity returns.',
    ],
    troubleshooting: [
      'If conflicts occur, look for the red Schedule Overlap banner in the Calendar header for resolution guidance.',
    ],
    action: {
      id: 'act-go-calendar-troubleshoot',
      label: 'Open Calendar View',
      actionType: 'navigate',
      payload: { nav: 'plan', subNav: 'calendar' },
      icon: 'Calendar',
    },
  },
  {
    id: 'troubleshooting-ai-key-errors',
    title: 'Troubleshooting: AI Assistant errors or invalid API key',
    category: 'troubleshooting',
    categoryLabel: 'Troubleshooting',
    keywords: ['ai error', 'api key error', 'gemini error', 'openai error', 'quota', '503', '429'],
    summary:
      'Resolve AI connectivity errors, rate limits, and model busy responses.',
    whereToFind: 'Header > Settings > "AI Engine & Backbone"',
    steps: [
      '1. Check API Key in Settings: Open Settings and ensure there are no trailing whitespace characters or quotes around your key.',
      '2. Tap "Validate Key": Click the button to inspect the real-time server test response and ping latency.',
      '3. Rate Limits (429/503): If Google Gemini or OpenAI is experiencing high global demand, the app automatically switches to fallback models or local intelligence.',
      '4. Local Mode: If you do not have an API key, the app functions with built-in heuristic local intelligence for quick captures and schedule planning.',
    ],
    action: {
      id: 'act-fix-ai-keys',
      label: 'Check AI Settings',
      actionType: 'open_settings',
      icon: 'Settings',
    },
  },
  {
    id: 'troubleshooting-audio-sound',
    title: 'Troubleshooting: Ambient sounds not playing or silent',
    category: 'troubleshooting',
    categoryLabel: 'Troubleshooting',
    keywords: ['sound not playing', 'audio silent', 'rain sound issue', 'ambient muted', 'web audio'],
    summary:
      'Fix browser audio permissions for synthesized ambient soundscapes.',
    whereToFind: 'Header > Volume icon or Focus Mode modal',
    steps: [
      '1. Browser Autoplay Policies: Modern browsers require at least one user click or gesture on the page before web audio can emit sound.',
      '2. Unmute Audio: Click the Volume icon in the top header once to toggle sound from Muted to Rain.',
      '3. Device Volume & Silent Switch: Check your physical device volume and ensure your phone is not on silent/vibrate mode.',
      '4. Tab Muting: Ensure the browser tab itself has not been muted in Chrome/Safari.',
    ],
    action: {
      id: 'act-play-rain',
      label: 'Test Ambient Rain Sound',
      actionType: 'play_sound',
      payload: { sound: 'rain' },
      icon: 'Volume2',
    },
  },
];

// Helper: Fast Client-Side Search Engine over Knowledge Base
export function searchKnowledgeBase(query: string, categoryFilter?: string): HelpArticle[] {
  const cleanQ = query.trim().toLowerCase();
  if (!cleanQ && !categoryFilter) return LIFE_OS_KNOWLEDGE_BASE;

  return LIFE_OS_KNOWLEDGE_BASE.filter((article) => {
    if (categoryFilter && categoryFilter !== 'all' && article.category !== categoryFilter) {
      return false;
    }
    if (!cleanQ) return true;

    // Title match (high weight)
    if (article.title.toLowerCase().includes(cleanQ)) return true;

    // Keywords match
    if (article.keywords.some((k: string) => k.toLowerCase().includes(cleanQ))) return true;

    // Summary match
    if (article.summary.toLowerCase().includes(cleanQ)) return true;

    // Steps match
    if (article.steps.some((s: string) => s.toLowerCase().includes(cleanQ))) return true;

    // Troubleshooting match
    if (article.troubleshooting?.some((t: string) => t.toLowerCase().includes(cleanQ))) return true;

    return false;
  });
}

// Helper: Contextual screen-to-category mapping
export function mapScreenContextToCategory(
  activeNav: string,
  planSubNav?: string,
  notesSubNav?: string,
  lifeSubNav?: string
): { category: HelpCategory; label: string; primaryArticleId?: string } {
  if (activeNav === 'home') {
    return { category: 'getting-started', label: 'Home Screen', primaryArticleId: 'home-command-center' };
  }
  if (activeNav === 'tasks') {
    return { category: 'tasks', label: 'Tasks & Priorities', primaryArticleId: 'tasks-management' };
  }
  if (activeNav === 'plan') {
    if (planSubNav === 'goals') {
      return { category: 'plan', label: 'Goals & Milestones', primaryArticleId: 'goals-and-milestones' };
    }
    return { category: 'plan', label: 'Calendar & Time Blocking', primaryArticleId: 'calendar-and-timeblocking' };
  }
  if (activeNav === 'notes') {
    return { category: 'notes', label: 'Notes & Second Brain', primaryArticleId: 'notes-para-and-second-brain' };
  }
  if (activeNav === 'life') {
    if (lifeSubNav === 'habits') {
      return { category: 'life', label: 'Habits & Streaks', primaryArticleId: 'habits-tracking' };
    }
    if (lifeSubNav === 'money') {
      return { category: 'life', label: 'Money & Finances', primaryArticleId: 'money-and-finances' };
    }
    if (lifeSubNav === 'energy') {
      return { category: 'life', label: 'Energy & Rhythms', primaryArticleId: 'energy-and-chronotypes' };
    }
    return { category: 'life', label: 'Life Modules', primaryArticleId: 'habits-tracking' };
  }
  if (activeNav === 'ai') {
    return { category: 'ai', label: 'AI Assistant & Memory', primaryArticleId: 'ai-assistant-overview' };
  }
  return { category: 'getting-started', label: 'Life OS Overview', primaryArticleId: 'getting-started-overview' };
}
