import { TemplateItem, TemplateCategory, TemplateVariable, TemplateBlueprint } from '../types';
import { initialTemplates } from './initialTemplates';

export interface CategoryMeta {
  id: TemplateCategory;
  label: string;
  description: string;
  iconName: string;
  color: string;
  tags: string[];
}

export const CATEGORY_DEFINITIONS: CategoryMeta[] = [
  {
    id: 'tasks',
    label: 'Tasks & GTD',
    description: 'Task management, daily priorities, inbox zero, sprint backlogs, and checklist systems.',
    iconName: 'CheckSquare',
    color: '#3b82f6',
    tags: ['gtd', 'inbox', 'priorities', 'eisenhower', 'checklists'],
  },
  {
    id: 'calendar',
    label: 'Calendar & Schedules',
    description: 'Weekly time grids, recurring schedules, event routines, and appointment blueprints.',
    iconName: 'Calendar',
    color: '#06b6d4',
    tags: ['calendar', 'events', 'schedule', 'weekly', 'agenda'],
  },
  {
    id: 'timeblocking',
    label: 'Time Blocking',
    description: 'Maker/manager schedules, deep work reservations, pomodoro blocks, and theme days.',
    iconName: 'Clock',
    color: '#6366f1',
    tags: ['timeblocking', 'deepwork', 'maker', 'pomodoro', 'flow'],
  },
  {
    id: 'goals',
    label: 'Goals & OKRs',
    description: 'Quarterly OKRs, 12-week year sprints, milestone trackers, and ambitious life milestones.',
    iconName: 'Target',
    color: '#ec4899',
    tags: ['okr', 'vision', 'milestones', 'sprint', 'ambition'],
  },
  {
    id: 'habits',
    label: 'Habits & Routines',
    description: 'Atomic morning/evening habits, fitness protocols, streak building, and micro-routines.',
    iconName: 'Flame',
    color: '#f97316',
    tags: ['habits', 'streaks', 'atomic', 'morning', 'evening'],
  },
  {
    id: 'money',
    label: 'Money & Wealth',
    description: '50/30/20 budgeting, cash flow tracking, expense optimization, and debt payoff systems.',
    iconName: 'DollarSign',
    color: '#10b981',
    tags: ['budget', 'expenses', 'finance', 'cashflow', 'savings'],
  },
  {
    id: 'notes',
    label: 'Notes & Scratchpads',
    description: 'Structured scratchpads, meeting minutes, decision logs, and book synthesis notes.',
    iconName: 'FileText',
    color: '#14b8a6',
    tags: ['notes', 'scratchpad', 'meetings', 'decisions', 'logs'],
  },
  {
    id: 'secondbrain',
    label: 'Second Brain & Knowledge',
    description: 'PARA method systems, Zettelkasten slip-boxes, mental models, and atomic knowledge wikis.',
    iconName: 'Brain',
    color: '#8b5cf6',
    tags: ['secondbrain', 'para', 'zettelkasten', 'atomic', 'knowledge'],
  },
  {
    id: 'focus',
    label: 'Focus & Deep Work',
    description: 'Distraction-free protocols, flow catalyst timers, concentration bunkers, and focus blocks.',
    iconName: 'Zap',
    color: '#eab308',
    tags: ['focus', 'flow', 'deepwork', 'distractionfree', 'monkmode'],
  },
  {
    id: 'energy',
    label: 'Energy & Circadian',
    description: 'Circadian rhythm planning, chronotype optimization, post-lunch slump recovery, and rest.',
    iconName: 'BatteryCharging',
    color: '#f59e0b',
    tags: ['energy', 'circadian', 'recovery', 'sleep', 'rhythm'],
  },
  {
    id: 'reviews',
    label: 'Weekly Reviews',
    description: 'Sunday resets, quarterly retrospectives, team post-mortems, and alignment check-ins.',
    iconName: 'RotateCcw',
    color: '#a855f7',
    tags: ['review', 'reflection', 'sundayreset', 'audit', 'alignment'],
  },
  {
    id: 'projects',
    label: 'Projects & Workflows',
    description: 'Agile sprints, roadmap management, product launches, client delivery, and Gantt tracking.',
    iconName: 'FolderGit2',
    color: '#3b82f6',
    tags: ['projects', 'sprint', 'scrum', 'roadmap', 'workflow'],
  },
  {
    id: 'study',
    label: 'Study & Education',
    description: 'Exam preparation, syllabus mastery, thesis timelines, spaced repetition, and certifications.',
    iconName: 'GraduationCap',
    color: '#8b5cf6',
    tags: ['study', 'exams', 'university', 'spacedrepetition', 'learning'],
  },
  {
    id: 'planning',
    label: 'Personal Planning',
    description: 'Annual vision boards, Ikigai roadmaps, quarterly retreats, and life transition plans.',
    iconName: 'Compass',
    color: '#06b6d4',
    tags: ['planning', 'vision', 'ikigai', 'retreat', 'lifebalance'],
  },
  {
    id: 'content',
    label: 'Content Creation',
    description: 'YouTube publishing pipelines, weekly newsletters, social media batching, and podcasts.',
    iconName: 'Video',
    color: '#ef4444',
    tags: ['content', 'youtube', 'newsletter', 'writing', 'podcast'],
  },
  {
    id: 'business',
    label: 'Business & Work',
    description: 'Solo founder OS, B2B sales pipelines, investor updates, hiring funnels, and client retainers.',
    iconName: 'Briefcase',
    color: '#2563eb',
    tags: ['business', 'founder', 'sales', 'clients', 'startup'],
  },
  {
    id: 'lifeplanning',
    label: 'Life Planning & Legacy',
    description: '10-year life visions, relocation blueprints, family estate planning, and longevity tracks.',
    iconName: 'HeartHandshake',
    color: '#d946ef',
    tags: ['life', 'legacy', 'family', 'relocation', 'decade'],
  },
  {
    id: 'universal',
    label: 'Universal Life OS',
    description: 'All-in-one unified systems combining all Life OS modules into cohesive operational hubs.',
    iconName: 'Layers',
    color: '#7c3aed',
    tags: ['universal', 'allinone', 'complete', 'hub', 'ecosystem'],
  },
];

// -------------------------------------------------------------
// Realistic Template Catalog Definitions (100 per Category)
// -------------------------------------------------------------

// Rich topic seed blueprints per module
const MODULE_SEEDS: Partial<Record<TemplateCategory, { title: string; desc: string; focus: string; habit: string; task1: string; task2: string }[]>> = {
  tasks: [
    { title: 'GTD Weekly Inbox Zero Protocol', desc: 'Capture, clarify, organize, reflect, and engage with absolute zero friction.', focus: 'Inbox Processing', habit: 'Daily 10-Min Inbox Zero Sweep', task1: 'Empty mental inbox into triage', task2: 'Assign next actions and 2-min rule' },
    { title: 'Eisenhower Matrix Priority Engine', desc: 'Quadrant segregation: Urgent vs Important for ruthless delegation and focus.', focus: 'Prioritization', habit: 'Morning Quadrant Sort', task1: 'Filter all Q1 urgent crises', task2: 'Protect Q2 strategic deep work' },
    { title: 'Daily Rule of 3 Impact System', desc: 'Select 3 non-negotiable needle-movers every single morning before checking feeds.', focus: 'Daily Focus', habit: 'Define 3 Most Important Tasks', task1: 'Complete Primary Needle-Mover', task2: 'Review secondary outputs' },
    { title: 'Product Sprint Backlog Tracker', desc: 'Continuous task grooming from user story to QA, testing, and production deploy.', focus: 'Engineering', habit: 'Daily Standup Sync', task1: 'Groom user story acceptance criteria', task2: 'Resolve blocking pull requests' },
    { title: 'Freelance Deliverable Milestones', desc: 'Client scoped project tasks, asset reviews, invoicing checks, and revisions.', focus: 'Client Work', habit: 'Client Progress Check', task1: 'Deliver draft design asset package', task2: 'Send milestone signoff invoice' },
    { title: 'Moving House Master Checklist', desc: 'Chronological relocation tasks from lease termination to utility connections.', focus: 'Life Operations', habit: 'Pack 2 Boxes Daily', task1: 'Transfer broadband & power utilities', task2: 'Label color-coded room boxes' },
    { title: 'Event Logistics Masterplan', desc: 'End-to-end event planning: vendor contracts, invitations, ticketing, and AV prep.', focus: 'Events', habit: 'Vendor Followup Call', task1: 'Finalize catering headcount', task2: 'Test projector and audio livestream' },
    { title: 'Daily Admin Batching System', desc: 'Group small administrative tasks into a single afternoon power hour.', focus: 'Efficiency', habit: 'Batch Admin at 4 PM', task1: 'Clear pending invoice approvals', task2: 'File receipts and digital documents' },
    { title: 'Quarterly Audit Readiness Queue', desc: 'Systematic compliance documentation, security access reviews, and evidence logs.', focus: 'Compliance', habit: 'Log weekly audit evidence', task1: 'Verify SOC2 access permission log', task2: 'Archive vendor agreements' },
    { title: 'Travel Packing & Departure Checklist', desc: 'International travel logistics: passport validity, packing cubes, and offline maps.', focus: 'Travel', habit: 'Check travel documents', task1: 'Download offline Google Maps & boarding pass', task2: 'Pack chargers and foreign currency' },
  ],
  calendar: [
    { title: 'Executive Time-Grid Layout', desc: 'Protected strategic thinking mornings with batched afternoon synchronous meetings.', focus: 'Calendar Architecture', habit: 'Calendar Audit at 5 PM', task1: 'Audit weekly meeting invitations', task2: 'Decline non-agenda appointments' },
    { title: 'Shift Worker Optimized Sleep & Work', desc: 'Adaptive schedule accounting for rotating shifts, blackout rest, and recovery.', focus: 'Shift Schedule', habit: 'Log Shift Recovery Sleep', task1: 'Block blackout sleep window', task2: 'Prep meals for night shift' },
    { title: 'Async Maker Schedule Grid', desc: 'Zero meetings Monday, Wednesday, Friday; all collaboration batched Tuesday & Thursday.', focus: 'Async Work', habit: 'Decline unscheduled calls', task1: 'Reserve uninterrupted 4-hour build block', task2: 'Consolidate 1-on-1s into office hours' },
    { title: 'Academic Semester Schedule Grid', desc: 'Course lecture blocks, lab sessions, study halls, and office hours alignment.', focus: 'Academics', habit: 'Daily lecture prep review', task1: 'Attend advanced seminar lecture', task2: 'Complete lab practical experiment' },
    { title: 'Athlete High-Performance Training Calendar', desc: 'Periodized training blocks: strength, zone 2 cardio, mobility, and deloading.', focus: 'Athletics', habit: 'Log workout & resting HR', task1: 'Zone 2 aerobic base ride (90 min)', task2: 'Post-workout mobility protocol' },
    { title: 'Client Consultation Weekly Grid', desc: 'Pre-set client booking buffers, preparation intervals, and debriefing slots.', focus: 'Consulting', habit: 'Review client intake notes', task1: 'Conduct strategy discovery session', task2: 'Dispatch post-call action summary' },
    { title: 'Working Parent Dual-Cadence Calendar', desc: 'Harmonized school dropoff/pickup windows, core focus hours, and family dinners.', focus: 'Family Balance', habit: 'Evening family dinner block', task1: 'Core work sprint (9:00 - 14:30)', task2: 'School activity & dinner window' },
    { title: 'Conference & Networking Schedule Grid', desc: 'Keynote attendance, speaker networking, exhibit floor meetings, and recharge breaks.', focus: 'Conferences', habit: 'Connect on LinkedIn daily', task1: 'Attend morning keynote session', task2: 'Host industry roundtable lunch' },
    { title: 'Doctor & Clinical Appointment Cadence', desc: 'Preventative care, dental checkups, biometric bloodwork, and health followups.', focus: 'Healthcare', habit: 'Log preventative health check', task1: 'Schedule annual comprehensive labs', task2: 'Review biomarker panel report' },
    { title: 'Sabbatical Exploration Rhythm', desc: 'Structured open space: creative reading, physical exploration, and zero meetings.', focus: 'Restoration', habit: 'Morning nature walk', task1: 'Explore local historical archive', task2: 'Reflective journaling session' },
  ],
  timeblocking: [
    { title: 'Maker vs Manager Split Block', desc: 'Mornings reserved purely for creation; afternoons opened for communication.', focus: 'Deep Flow', habit: 'No communication before 12 PM', task1: 'Write core application algorithm', task2: 'Respond to team Slack and emails' },
    { title: 'Pomodoro 50/10 Ultradian Rhythm', desc: '50-minute laser-focused intervals followed by 10-minute true physiological resets.', focus: 'Ultradian Flow', habit: 'Complete 4 Pomodoros Daily', task1: 'Pomodoro 1: Hardest problem of the day', task2: 'Pomodoro 2: Architecture draft' },
    { title: 'The 4-Hour Deep Work Bunker', desc: 'Continuous 4-hour monastic deep work session with airplane mode and zero alerts.', focus: 'Deep Focus', habit: 'Activate Do-Not-Disturb', task1: 'Produce chapter draft or module code', task2: 'Conduct self-review before shutdown' },
    { title: 'Theme Day Operational Blocking', desc: 'Monday Strategy, Tuesday Build, Wednesday Sync, Thursday Marketing, Friday Review.', focus: 'Themed Days', habit: 'Align tasks to today\'s theme', task1: 'Execute dedicated theme deliverables', task2: 'Log weekly theme progress' },
    { title: 'Golden Hour Dawn Writing Block', desc: '6:00 AM - 7:30 AM uninterrupted creative writing before the world wakes up.', focus: 'Writing', habit: 'Write 500 words at dawn', task1: 'Complete newsletter essay draft', task2: 'Edit previous day\'s chapter' },
    { title: 'Afternoon Creative Sprint Block', desc: 'Post-coffee afternoon burst dedicated to visual prototyping and UI exploration.', focus: 'Design Sprint', habit: 'Design review at 3 PM', task1: 'Figma interface component variant set', task2: 'Interactive prototype animation check' },
    { title: 'Meeting-Free Deep Wednesday', desc: 'Zero meetings allowed company-wide; pure uninterrupted execution day.', focus: 'Zero Meetings', habit: 'Honor Meeting-Free Day', task1: 'Solve complex architectural bottleneck', task2: 'Document API specifications' },
    { title: 'Sundown Shutdown Routine Block', desc: 'Daily 30-minute transition block at 5:30 PM to close tabs, log wins, and disconnect.', focus: 'Shutdown', habit: 'Complete shutdown ritual', task1: 'Archive inbox and close workspace', task2: 'Review tomorrow\'s top 3 objectives' },
    { title: 'Sprint Review & Demo Timeblock', desc: 'Dedicated Friday afternoon block for sprint retrospective and stakeholder demo.', focus: 'Agile Demo', habit: 'Prepare demo walkthrough', task1: 'Record video demo of new features', task2: 'Post sprint changelog update' },
    { title: 'Weekend Digital Detox Timeblock', desc: 'Dedicated Saturday 8-hour window without screens, notifications, or work apps.', focus: 'Recovery', habit: 'Turn off screens by 9 AM', task1: 'Engage in outdoor physical activity', task2: 'Read physical book for 2 hours' },
  ],
  goals: [
    { title: '12-Week Year Sprint Master', desc: 'Treat 12 weeks as a full year to drive relentless execution and eliminate procrastination.', focus: '12-Week Sprint', habit: 'Score weekly execution percentage', task1: 'Audit Week 4 milestone deliverables', task2: 'Recalibrate tactics for Week 5' },
    { title: 'Quarterly OKR Execution Framework', desc: '3 Ambitious Objectives with 4 Measurable Key Results each with weekly scoring.', focus: 'OKRs', habit: 'Update Key Results metrics', task1: 'Review KR1 progress metrics with team', task2: 'Unblock dependencies for KR2' },
    { title: 'Financial Independence / FIRE Goal', desc: 'Target net worth milestone with savings rate target, index allocation, and expense tracking.', focus: 'Financial Freedom', habit: 'Log monthly savings rate', task1: 'Automate index fund investment', task2: 'Review passive dividend yield' },
    { title: 'First $100K ARR SaaS Goal', desc: 'From MVP validation to initial 100 paying customers and predictable acquisition funnel.', focus: 'Revenue Growth', habit: 'Reach out to 5 prospects daily', task1: 'Publish case study testimonial', task2: 'Optimize checkout conversion rate' },
    { title: 'Marathon Under 4 Hours', desc: '16-week endurance progression: weekly mileage, nutrition fueling, and taper week.', focus: 'Endurance Goal', habit: 'Weekly long run on Sunday', task1: 'Execute 18-mile progressive pacing run', task2: 'Practice race-day carbohydrate fueling' },
    { title: 'Master Conversational Spanish (B2)', desc: '90-day language acquisition: daily vocabulary, audio immersion, and 1-on-1 tutoring.', focus: 'Language Mastery', habit: '30 mins Spanish listening daily', task1: 'Complete 45-minute speaking lesson', task2: 'Write 200-word daily journal in Spanish' },
    { title: 'Publish Non-Fiction Book', desc: 'Manuscript outline to final proof: chapter pacing, developmental editing, and launch.', focus: 'Author Goal', habit: 'Write 1,000 words daily', task1: 'Submit Chapters 1-4 for beta feedback', task2: 'Finalize cover art typography' },
    { title: 'Buy First Investment Property', desc: 'Real estate acquisition: market analysis, loan pre-approval, property inspection, closing.', focus: 'Real Estate', habit: 'Analyze 3 deals weekly', task1: 'Secure mortgage pre-approval letter', task2: 'Schedule property home inspection' },
    { title: 'Eliminate $50,000 Debt Payoff', desc: 'Debt snowball / avalanche method with automated accelerated monthly principal payments.', focus: 'Debt Elimination', habit: 'Review zero-spend days', task1: 'Send extra $500 principal payment', task2: 'Negotiate lower interest APR' },
    { title: 'Master Data Structures & Algorithms', desc: 'Ace technical interviews: 150 LeetCode patterns, time complexity, and mock interviews.', focus: 'Tech Career', habit: 'Solve 1 algorithmic problem daily', task1: 'Master Dynamic Programming memoization', task2: 'Conduct 60-min peer mock interview' },
  ],
  habits: [
    { title: 'Atomic Morning Routine Protocol', desc: 'Hydrate, sunlight exposure, movement, mindfulness, and zero phone before deep work.', focus: 'Morning Power', habit: 'Morning Routine Completion', task1: 'Drink 500ml water with electrolytes', task2: '15 mins outdoor sunlight exposure' },
    { title: '75 Hard Mental Toughness System', desc: 'Two 45-min workouts, 1 gallon water, 10 pages reading, clean diet, daily progress photo.', focus: 'Discipline', habit: '75 Hard Daily Checklist', task1: 'Complete outdoor 45-min workout', task2: 'Read 10 pages non-fiction book' },
    { title: 'Digital Sunset & Sleep Hygiene', desc: '10-3-2-1-0 framework: zero screens 1 hr before bed, cold bedroom, and dark rest.', focus: 'Sleep Mastery', habit: 'Screens off 60 mins before sleep', task1: 'Turn on blue-light blocking filters', task2: '10 mins stretching and journaling' },
    { title: 'Daily Gratitude & Stoic Journaling', desc: 'Morning intention setting and evening reflection on control, virtues, and gratitude.', focus: 'Mindset', habit: '5-Minute Stoic Journaling', task1: 'Write 3 specific things grateful for', task2: 'Evening review of personal conduct' },
    { title: '10,000 Steps Daily Movement Tracker', desc: 'Consistent non-exercise activity thermogenesis (NEAT) for metabolic longevity.', focus: 'Daily Movement', habit: 'Reach 10,000 steps daily', task1: 'Morning 20-minute walking meeting', task2: 'Post-dinner brisk walk' },
    { title: 'Zero Sugar 30-Day Metabolic Sprint', desc: 'Eliminate refined sugars, ultra-processed snacks, and artificial sweeteners.', focus: 'Nutrition', habit: 'Zero Added Sugar Log', task1: 'Meal prep whole-food lunches', task2: 'Stock pantry with healthy whole nuts' },
    { title: 'Daily Code Commit & Continuous Learning', desc: 'Ship at least one clean git commit every day to build compound engineering muscle.', focus: 'Skill Compound', habit: 'Daily Git Commit', task1: 'Push clean commits with unit tests', task2: 'Review pull request feedback' },
    { title: 'Cold Shower & Breathwork Activation', desc: 'Wim Hof breathing followed by 2 minutes of cold shower exposure for dopamine reset.', focus: 'Physiology', habit: 'Cold Shower & Breathwork', task1: 'Complete 3 rounds of breathing', task2: '2-minute cold water finish' },
    { title: 'Mindful Eating & Intermittent Fasting', desc: '16:8 fasting window with mindful, slow chewing and zero mindless desk snacking.', focus: 'Fasting', habit: '16-Hour Fast Window', task1: 'Break fast with high-protein meal', task2: 'Begin evening fast by 7:30 PM' },
    { title: 'Daily Relationship Outreach Habit', desc: 'Send one heartfelt message or appreciation note to a friend, mentor, or family member.', focus: 'Relationships', habit: 'Send 1 thoughtful message daily', task1: 'Message long-distance friend', task2: 'Write mentor thank-you note' },
  ],
  money: [
    { title: '50/30/20 Budgeting Operating System', desc: '50% Needs, 30% Wants, 20% Savings & Debt reduction with automated category transfers.', focus: 'Budgeting', habit: 'Log weekly expense categories', task1: 'Allocate paycheck across accounts', task2: 'Review discretionary spend budget' },
    { title: 'Zero-Based Monthly Cash Flow Engine', desc: 'Every single dollar is assigned a job before the month starts; income minus expenses = 0.', focus: 'Cash Flow', habit: 'Track daily transactions', task1: 'Set next month income allocations', task2: 'Reconcile credit card balances' },
    { title: 'Freelance Tax & Expense System', desc: 'Auto-reserve 30% for tax withholdings, track deductible expenses, and invoice on time.', focus: 'Freelance Tax', habit: 'Archive business receipts', task1: 'Transfer 30% into tax reserve account', task2: 'Generate quarterly estimated tax report' },
    { title: 'Emergency Fund 6-Month Sprint', desc: 'Build a fully funded 6-month liquid cushion in high-yield savings for total peace of mind.', focus: 'Emergency Fund', habit: 'Automate weekly savings transfer', task1: 'Calculate exact 6-month baseline expenses', task2: 'Verify High-Yield Savings Account APY' },
    { title: 'High-Yield DCA & Index Fund Engine', desc: 'Automate dollar-cost averaging into broad-market index funds (VTI, VOO) every Monday.', focus: 'Investing', habit: 'Check automated investment execution', task1: 'Review asset allocation percentages', task2: 'Reinvest quarterly dividends' },
    { title: 'SaaS Subscription Audit & Cut', desc: 'Audit recurring subscriptions, cancel zombie software, and negotiate lower tiers.', focus: 'Expense Reduction', habit: 'Monthly recurring bill check', task1: 'List all active recurring subscriptions', task2: 'Cancel underutilized software licenses' },
    { title: 'Real Estate Rental Cash Flow Tracker', desc: 'Monitor gross rental receipts, operating expenses, vacancy reserves, and net cap rates.', focus: 'Real Estate Cashflow', habit: 'Log monthly rent receipts', task1: 'Verify tenant rent deposits', task2: 'Schedule property maintenance repair' },
    { title: 'Wedding Budget & Vendor Master', desc: 'Track venue, photography, catering, florals, and attire with deposit deadline tracking.', focus: 'Wedding Finance', habit: 'Review vendor payment dates', task1: 'Confirm catering deposit milestone', task2: 'Update master guest count spreadsheet' },
    { title: 'Student Loan Accelerated Payoff', desc: 'Target highest interest student loans with avalanche bi-weekly extra principal payments.', focus: 'Debt Freedom', habit: 'Log accelerated loan balance', task1: 'Submit bi-weekly extra loan payment', task2: 'Verify payment applied to principal' },
    { title: 'Annual Net Worth & Asset Ledger', desc: 'Quarterly balance sheet: assets, liabilities, retirement accounts, and trajectory.', focus: 'Net Worth', habit: 'Quarterly Net Worth Audit', task1: 'Update retirement account balances', task2: 'Calculate year-over-year net worth delta' },
  ],
  notes: [
    { title: 'Daily Structured Scratchpad', desc: 'Morning intentions, raw thoughts, meeting takeaways, and evening closure all in one note.', focus: 'Daily Notes', habit: 'Open fresh scratchpad at 8 AM', task1: 'Jot down top 3 focus priorities', task2: 'Archive scratchpad at day end' },
    { title: 'Executive Meeting Minutes & Actions', desc: 'Meeting agenda, attendee list, key discussion points, and assigned next action items.', focus: 'Meeting Records', habit: 'Publish minutes within 2 hours', task1: 'Document key stakeholder decisions', task2: 'Assign follow-up tasks with owners' },
    { title: 'Book Synthesis & Key Quotes Note', desc: 'Core thesis, 3 most impactful insights, memorable quotes, and practical life applications.', focus: 'Reading Notes', habit: 'Highlight & summarize key ideas', task1: 'Synthesize chapter 1-3 core thesis', task2: 'Write 3 personal action takeaways' },
    { title: 'One-on-One Collaborative Agendas', desc: 'Bi-directional agenda for manager/report meetings: wins, blockers, and growth goals.', focus: '1-on-1s', habit: 'Update 1-on-1 agenda before call', task1: 'Review career growth milestones', task2: 'Resolve cross-functional blocker' },
    { title: 'Client Call Briefing & Summary', desc: 'Client background, call objectives, questions asked, and immediate follow-up deliverables.', focus: 'Client Notes', habit: 'Send post-call recap email', task1: 'Review client project history', task2: 'Log client feature requests' },
    { title: 'Idea Incubation & Spark Lab', desc: 'Capture raw creative sparks, flesh out hypotheses, test assumptions, and link to projects.', focus: 'Creative Sparks', habit: 'Jot down 2 new ideas daily', task1: 'Flesh out product feature hypothesis', task2: 'Conduct quick market viability check' },
    { title: 'Architecture Decision Record (ADR)', desc: 'Context, decision taken, considered alternatives, and engineering consequences.', focus: 'Tech Decisions', habit: 'Review ADR before major refactor', task1: 'Document schema migration rationale', task2: 'Review architectural trade-offs' },
    { title: 'Cornell Lecture Notes System', desc: 'Cues column on left, lecture notes on right, and 2-sentence summary at bottom.', focus: 'Academic Notes', habit: 'Summarize lecture within 24h', task1: 'Write lecture keyword cues', task2: 'Synthesize bottom summary block' },
    { title: 'Podcast Synthesis & Action Log', desc: 'Episode title, guest credentials, counter-intuitive insights, and tools mentioned.', focus: 'Podcast Notes', habit: 'Extract 1 actionable insight', task1: 'Log key quotes and timestamps', task2: 'Implement recommended tool test' },
    { title: 'Weekly Recipe & Meal Prep Log', desc: 'Weekly menu, grocery list, prep steps, and cooking times for clean nutrition.', focus: 'Meal Planning', habit: 'Sunday meal prep session', task1: 'Compile grocery ingredient list', task2: 'Prep 4 days of protein lunches' },
  ],
  secondbrain: [
    { title: 'Tiago Forte PARA Second Brain Hub', desc: 'Projects, Areas, Resources, and Archives system for total digital knowledge mastery.', focus: 'PARA Method', habit: 'Weekly PARA folder cleanup', task1: 'Move finished project to Archive', task2: 'Update active Area standard operating procedure' },
    { title: 'Zettelkasten Atomic Slip-Box System', desc: 'Permanent atomic notes with bidirectional links and index tags for insight generation.', focus: 'Zettelkasten', habit: 'Create 1 permanent atomic note', task1: 'Convert fleeting thought into atomic note', task2: 'Create bidirectional links to existing slips' },
    { title: 'Mental Models Compendium', desc: 'First principles, inversion, Occam’s razor, second-order thinking, and leverage frameworks.', focus: 'Mental Models', habit: 'Apply 1 mental model to daily decision', task1: 'Document case study of Inversion', task2: 'Analyze project risk using second-order thinking' },
    { title: 'Software Architecture Playbook', desc: 'System design patterns, microservices vs monoliths, caching, and database indexing.', focus: 'System Design', habit: 'Read 1 engineering whitepaper weekly', task1: 'Document distributed tracing pattern', task2: 'Benchmark database indexing strategy' },
    { title: 'Scientific Paper Deep-Read System', desc: 'Abstract, methodology critique, data visualization review, and reproducible claims.', focus: 'Research', habit: 'Review 1 peer-reviewed paper weekly', task1: 'Analyze paper sample size and p-values', task2: 'Synthesize clinical implications' },
    { title: 'Product Management Playbook', desc: 'User personas, discovery interviews, prioritization matrices (RICE), and launch roadmaps.', focus: 'Product Knowledge', habit: 'Review user feedback weekly', task1: 'Score feature candidates with RICE matrix', task2: 'Map end-to-end customer journey' },
    { title: 'Design System & UI Component Wiki', desc: 'Design tokens, typography scales, accessibility standards (WCAG), and component states.', focus: 'Design Systems', habit: 'Audit accessibility contrast', task1: 'Document primary button state variants', task2: 'Verify color tokens match design spec' },
    { title: 'Health & Longevity Research Hub', desc: 'Biomarkers, supplement protocols, VO2 max research, and metabolic science notes.', focus: 'Longevity Science', habit: 'Track health metrics daily', task1: 'Log latest clinical trial on zone 2', task2: 'Update daily longevity supplement protocol' },
    { title: 'Philosophy & Stoicism Knowledgebase', desc: 'Marcus Aurelius, Seneca, Epictetus, cognitive reframing, and resilience practices.', focus: 'Stoic Wisdom', habit: 'Morning philosophy reading', task1: 'Reflect on dichotomy of control', task2: 'Practice voluntary discomfort exercise' },
    { title: 'Personal Standard Operating Procedures', desc: 'Step-by-step checklists for recurring personal, financial, and digital workflows.', focus: 'Personal SOPs', habit: 'Update SOP during weekly review', task1: 'Document computer backup workflow', task2: 'Document quarterly tax filing procedure' },
  ],
  focus: [
    { title: 'Deep Work Monastic Bunker', desc: 'Isolate from notifications, noise, and distractions for 3 hours of hardcore intellectual output.', focus: 'Monastic Focus', habit: 'Turn off phone during focus block', task1: 'Lock into priority task without interruption', task2: 'Log focus duration and output achieved' },
    { title: 'Flow State Neuro-Chemical Catalyst', desc: 'Binaural beats, clear goal, tight feedback loop, and high challenge/skill balance.', focus: 'Flow State', habit: 'Play focus audio synth', task1: 'Set concrete 45-min output target', task2: 'Eliminate all tab notifications' },
    { title: '90-Minute High-Stakes Focus Sprint', desc: 'Aligned with natural ultradian cycles: 90 mins max effort, 20 mins total recovery.', focus: 'Sprint Focus', habit: '90-Min Focus Sprint Daily', task1: 'Solve hardest engineering bug', task2: 'Take 20-minute walk with zero devices' },
    { title: 'Distraction-Free Writing Session', desc: 'Full screen minimalist editor, ambient rain sounds, and zero internet browsing.', focus: 'Writing Focus', habit: 'Write without backspacing', task1: 'Draft 1,500 words in one sitting', task2: 'Export draft to review folder' },
    { title: 'Complex Code Refactoring Intensive', desc: 'High-focus code overhaul: extract services, write unit tests, and improve performance.', focus: 'Code Quality', habit: 'Write tests before refactoring', task1: 'Refactor monolithic controller class', task2: 'Verify test coverage above 90%' },
    { title: 'Exam Cramming Laser Block', desc: 'Intensive active recall session: flashcards, formula derivations, and mock test questions.', focus: 'Active Recall', habit: 'Test self without looking at notes', task1: 'Derive 10 core formulas from memory', task2: 'Complete timed past paper section' },
    { title: 'Creative Brainstorming Capsule', desc: 'Mind mapping, divergent thinking, and idea quantity over quality for 60 minutes.', focus: 'Brainstorming', habit: 'Generate 20 ideas before judging', task1: 'Brainstorm 25 marketing angles', task2: 'Select top 3 concepts for prototyping' },
    { title: 'Zero-Distraction Inbox Cleansing', desc: 'Process 100+ emails and notifications in 45 rapid minutes using keyboard shortcuts.', focus: 'Inbox Sprint', habit: 'Batch emails into single session', task1: 'Archive all newsletters and promotions', task2: 'Reply to 10 high-priority emails' },
    { title: 'Strategic Planning Solitude Session', desc: 'Step back from the weeds: review quarter trajectory, market positioning, and strategy.', focus: 'Strategy', habit: 'Schedule monthly solitude day', task1: 'Draft 12-month company strategy', task2: 'Identify top 3 business risks' },
    { title: 'Evening Decompression Focus', desc: 'Gentle mindful wind-down: light reading, classical music, and ambient dim lighting.', focus: 'Relaxation', habit: 'Dim lights by 8:30 PM', task1: 'Read non-fiction for 30 minutes', task2: 'Practice 10-minute deep breathing' },
  ],
  energy: [
    { title: 'Circadian Rhythm Alignment Engine', desc: 'Synchronize wake time, light exposure, meals, and sleep with natural solar cycles.', focus: 'Circadian Biology', habit: 'Morning sunlight within 30 mins', task1: 'Get 15 mins direct morning sunlight', task2: 'Turn off overhead lights after sunset' },
    { title: 'Peak Cortisol Work Optimization', desc: 'Schedule your highest-friction, most demanding work during peak morning cortisol.', focus: 'Hormonal Alignment', habit: 'Tackle hardest task by 10 AM', task1: 'Execute analytical problem solving', task2: 'Avoid low-value meetings before noon' },
    { title: 'Post-Lunch Slump Countermeasure', desc: 'Combat the 2 PM dip: light walk, hydration, no high-GI carbs, and NSDR protocol.', focus: 'Midday Energy', habit: '10-Min Walk After Lunch', task1: 'Take 15-minute non-sleep deep rest (NSDR)', task2: 'Drink 400ml cold water with electrolytes' },
    { title: 'Sleep Score & Biomarker Optimization', desc: 'Track deep sleep, REM, HRV, and resting heart rate to continuously optimize vitality.', focus: 'Sleep Recovery', habit: 'Log Oura/Apple sleep metrics', task1: 'Review HRV baseline trends', task2: 'Adjust room temperature to 66°F (19°C)' },
    { title: 'Caffeine Half-Life Timing Protocol', desc: 'Delay first coffee 90 mins after waking; cut off caffeine 10 hours before bed.', focus: 'Adenosine Balance', habit: 'Wait 90 mins for first coffee', task1: 'Drink morning water before caffeine', task2: 'Cut off caffeine strictly by 1:30 PM' },
    { title: 'High-Stakes Presentation Energy Prep', desc: 'Breath control, power posture, vocal warmups, and adrenaline management before speaking.', focus: 'Peak Performance', habit: 'Pre-presentation box breathing', task1: 'Do 5-minute vocal warmup exercises', task2: 'Visualize successful keynote delivery' },
    { title: 'Chronic Fatigue Recovery Protocol', desc: 'Pacing system, gentle zone 1 movement, vagus nerve stimulation, and anti-inflammatory rest.', focus: 'Gentle Recovery', habit: 'Check energy level every 3 hours', task1: 'Rest without phone or screen for 20 mins', task2: 'Drink warm herbal tea and magnesium' },
    { title: 'Neuroplasticity & Rest Windows', desc: 'Pair intense learning intervals with 10-minute eyes-closed rest for memory consolidation.', focus: 'Learning Rest', habit: '10-Min Quiet Rest After Study', task1: 'Complete 40-minute study session', task2: 'Sit in silence for 10 mins (memory lock)' },
    { title: 'Travel Jet Lag Reset System', desc: 'Meal timing, melatonin protocol, and local timezone fasting to eliminate jet lag in 24 hours.', focus: 'Jet Lag Protocol', habit: 'Eat on destination meal schedule', task1: 'Fast during overnight flight', task2: 'Get immediate morning light at destination' },
    { title: 'Post-Illness Gradual Re-entry Protocol', desc: 'Graduated ramp-up: 25% capacity on Day 1, 50% on Day 2, prioritizing deep recovery.', focus: 'Convalescence', habit: 'Honor 50% capacity rule', task1: 'Limit work to 2 critical tasks only', task2: 'Prioritize 9 hours of restorative sleep' },
  ],
  reviews: [
    { title: 'Sunday Life Alignment Master Review', desc: 'Reflect on wins, audit open loops, calibrate goals, and plan the upcoming week.', focus: 'Weekly Reset', habit: 'Sunday Review at 6 PM', task1: 'Clear physical and digital inboxes', task2: 'Schedule top 3 weekly priorities in calendar' },
    { title: 'Friday Work Shutdown & Handoff', desc: 'Close open tickets, write team status update, clear desktop, and sign off with clarity.', focus: 'Friday Wrap', habit: 'Friday 4:30 PM Shutdown', task1: 'Post weekly asynchronous status summary', task2: 'Clean desktop and organize download folder' },
    { title: 'Quarterly OKR Retrospective', desc: 'Grade key results, celebrate major wins, analyze failed initiatives, and set next OKRs.', focus: 'Quarterly Audit', habit: 'Quarterly Strategy Offsite', task1: 'Calculate final Key Results scores', task2: 'Document lessons learned and anti-patterns' },
    { title: 'Post-Mortem Incident Blameless Review', desc: 'Timeline of production outage, root cause analysis (5 Whys), and preventive action items.', focus: 'Post-Mortem', habit: 'Publish post-mortem within 48h', task1: 'Map out incident timeline minute-by-minute', task2: 'Assign preventive engineering remediation tickets' },
    { title: 'Financial Sunday Spending Review', desc: 'Categorize week’s credit card transactions, audit impulse purchases, and update budget.', focus: 'Weekly Finance', habit: 'Sunday Financial Check', task1: 'Categorize all card transactions', task2: 'Update remaining monthly budget balances' },
    { title: 'Health & Biomarker Weekly Audit', desc: 'Review weekly workout volume, average sleep hours, macro compliance, and HRV trends.', focus: 'Health Audit', habit: 'Log weekly health averages', task1: 'Calculate weekly running and lifting volume', task2: 'Review weekly average sleep duration' },
    { title: 'Creative Output & Portfolio Review', desc: 'Audit published articles, videos, designs, and track audience feedback and metrics.', focus: 'Creative Audit', habit: 'Weekly creative metric check', task1: 'Review newsletter open and click rates', task2: 'Catalogue newly created design assets' },
    { title: 'Team Leadership & 1-on-1 Pulse Check', desc: 'Review team morale, unblock team bottlenecks, and prepare constructive coaching notes.', focus: 'Leadership Review', habit: 'Prepare weekly 1-on-1 agendas', task1: 'Identify team member recognition moments', task2: 'Address resource bottleneck with management' },
    { title: 'Academic Progress & Assignment Audit', desc: 'Review upcoming due dates, syllabus milestones, and schedule study time blocks.', focus: 'Academic Review', habit: 'Weekly assignment audit', task1: 'Review grade book and pending submissions', task2: 'Map out study schedule for upcoming midterm' },
    { title: 'Relationship & Social Check-In', desc: 'Audit quality time with partner, family, and friends; plan upcoming social dates.', focus: 'Social Health', habit: 'Schedule 1 meaningful date weekly', task1: 'Plan weekend dinner with partner or friend', task2: 'Call parents or close family member' },
  ],
  projects: [
    { title: 'Agile Scrum 2-Week Sprint Master', desc: 'Sprint planning, user story backlog, daily standups, review, and retro all connected.', focus: 'Scrum Sprint', habit: 'Daily Standup Update', task1: 'Conduct Sprint Planning & story point estimation', task2: 'Ship release build to staging' },
    { title: 'Website Redesign & Launch Roadmap', desc: 'Information architecture, wireframes, copywriting, Figma design, and Webflow build.', focus: 'Web Design', habit: 'Weekly design critique', task1: 'Finalize interactive Figma prototypes', task2: 'Perform cross-browser QA testing' },
    { title: 'Mobile App MVP 60-Day Sprint', desc: 'Wireframing, React Native build, authentication, database schema, and App Store submission.', focus: 'App Launch', habit: 'Daily build deployment to TestFlight', task1: 'Implement OAuth and user database', task2: 'Submit iOS App Store binary' },
    { title: 'ISO 27001 / SOC 2 Security Audit', desc: 'Policy drafting, access controls, vendor risk reviews, penetration testing, and evidence.', focus: 'Security Audit', habit: 'Log compliance access check', task1: 'Conduct third-party penetration test', task2: 'Compile evidence for auditor review' },
    { title: 'Brand Identity & Guidelines Sprint', desc: 'Brand positioning, logo typography, color palette, voice guidelines, and brand kit.', focus: 'Branding', habit: 'Daily visual moodboard exploration', task1: 'Present 3 brand identity concept directions', task2: 'Export final vector assets and brand guide PDF' },
    { title: 'End-to-End Video Production Pipeline', desc: 'Scriptwriting, storyboard, shooting day checklist, rough cut, color grade, and thumbnail.', focus: 'Video Production', habit: 'Daily editing sprint', task1: 'Shoot A-roll talking head and B-roll footage', task2: 'Complete rough edit assembly cut' },
    { title: 'Podcast Season Production System', desc: 'Guest outreach, prep research, audio recording, editing, show notes, and distribution.', focus: 'Podcast Season', habit: 'Record on Thursdays', task1: 'Send guest prep sheet and calendar link', task2: 'Master audio track to -16 LUFS' },
    { title: 'Open-Source Library Release Workflow', desc: 'Typescript architecture, documentation site, semantic versioning, and npm publish.', focus: 'Open Source', habit: 'Triage GitHub issues daily', task1: 'Write comprehensive README with examples', task2: 'Publish v1.0.0 to npm registry' },
    { title: 'Office Relocation & Buildout Tracker', desc: 'Commercial lease, space planning, IT infrastructure, furniture, and employee comms.', focus: 'Office Buildout', habit: 'Weekly contractor site walk', task1: 'Install high-speed network fiber lines', task2: 'Coordinate moving weekend logistics' },
    { title: 'Product Hunt Launch Day War Room', desc: 'Maker comment, hunter outreach, teaser assets, live community engagement, and updates.', focus: 'Launch Day', habit: 'Monitor launch thread comments', task1: 'Publish Product Hunt listing at 12:01 AM PST', task2: 'Engage with every single community comment' },
  ],
  study: [
    { title: 'Exam Preparation Masterplan', desc: 'Complete academic sprint: Goal → Subjects & Milestones → Daily Revision Tasks → Calendar Blocks → Habits → Notes.', focus: 'Exam Sprint', habit: 'Daily 2-Hour Spaced Revision', task1: 'Review flashcard deck on Subject A', task2: 'Complete past exam practice question set' },
    { title: 'MCAT / Medical Licensing Prep System', desc: 'Content review, UWorld practice questions, full-length practice exams, and score audit.', focus: 'Medical Exam', habit: '50 UWorld Questions Daily', task1: 'Review biochemistry reaction pathways', task2: 'Conduct 7-hour full-length practice test' },
    { title: 'Bar Exam Intensive Preparation', desc: 'MBE practice, essay outlines, MPT performance tests, and doctrinal law memory drills.', focus: 'Law Exam', habit: 'Write 1 essay outline daily', task1: 'Complete 30 multiple choice questions', task2: 'Draft full-length torts essay' },
    { title: 'Master’s Thesis / Dissertation Roadmap', desc: 'Literature review, methodology, data collection, chapter drafts, and defense prep.', focus: 'Academic Research', habit: 'Write 500 words of thesis daily', task1: 'Synthesize 5 literature review papers', task2: 'Draft methodology chapter section' },
    { title: 'Spaced Repetition & Anki Mastery', desc: 'Create high-yield flashcards, maintain daily review streak, and eliminate card leeches.', focus: 'Memory Science', habit: 'Zero Anki Reviews Remaining', task1: 'Create 20 new atomic flashcards', task2: 'Clear daily Anki review queue' },
    { title: 'Computer Science Core Fast-Track', desc: 'Algorithms, operating systems, networking, databases, and distributed systems curriculum.', focus: 'Computer Science', habit: 'Implement 1 core data structure', task1: 'Implement balanced binary search tree in code', task2: 'Study TCP/IP three-way handshake' },
    { title: 'CFA Level 1 Study Sprint', desc: 'Ethics, Financial Reporting, Equity Investments, Fixed Income, and mock exams.', focus: 'Finance Exam', habit: 'Daily CFA question bank drill', task1: 'Review Financial Statement Analysis ratios', task2: 'Complete 120-question morning mock session' },
    { title: 'Language Immersion 90-Day Challenge', desc: 'Daily podcast listening, vocabulary flashcards, speaking practice, and grammar drills.', focus: 'Language Learning', habit: 'Speak target language for 15 mins', task1: 'Listen to native language podcast', task2: 'Memorize 25 new vocabulary words' },
    { title: 'High School Finals All-Subject Sprint', desc: 'Color-coded subject schedules, summary cheat sheets, and active recall drills.', focus: 'High School', habit: 'Review today’s hardest subject', task1: 'Solve calculus practice problem set', task2: 'Make history timeline flashcards' },
    { title: 'PhD Qualifying Exam Defense Blueprint', desc: 'Comprehensive reading list, theoretical frameworks, mock oral exams, and defense notes.', focus: 'PhD Defense', habit: 'Daily research defense practice', task1: 'Present thesis outline to peer group', task2: 'Review anticipated committee questions' },
  ],
  planning: [
    { title: 'Annual Life & Vision Architecture', desc: 'Holistic 10-dimension life audit, 1-year goals, habit systems, and identity shift.', focus: 'Annual Vision', habit: 'Monthly vision calibration', task1: 'Complete Wheel of Life self-assessment', task2: 'Select top 3 transformational annual goals' },
    { title: 'Ikigai Purpose & Career Alignment', desc: 'What you love, what you are good at, what the world needs, and what you can be paid for.', focus: 'Ikigai Alignment', habit: 'Daily reflection on meaningful work', task1: 'Map personal skills and passions in Venn diagram', task2: 'Identify high-overlap career opportunities' },
    { title: 'Quarterly Personal Solitude Retreat', desc: 'Off-grid weekend: disconnection, deep reading, trajectory review, and life redesign.', focus: 'Personal Retreat', habit: 'Block quarterly retreat dates', task1: 'Book cabin or quiet solitude space', task2: 'Complete quarterly reflection questionnaire' },
    { title: 'Retirement Transition & Life Redesign', desc: 'Post-career identity, passion projects, community involvement, and longevity routine.', focus: 'Life Transition', habit: 'Engage in volunteer or craft activity', task1: 'Define weekly purposeful activity schedule', task2: 'Plan mentoring or community involvement' },
    { title: 'Digital Declutter & Minimalist Reset', desc: 'Clean desktop, inbox zero, archive old files, unsubscribe from junk, and backup photos.', focus: 'Digital Minimalism', habit: 'Daily zero-desktop policy', task1: 'Unsubscribe from 20 promotional email lists', task2: 'Organize cloud storage into clean folders' },
    { title: 'Minimalist Wardrobe & Life Declutter', desc: 'Capsule wardrobe, purge unused possessions, donate excess, and live with clarity.', focus: 'Minimalism', habit: '1-in-1-out possession rule', task1: 'Donate 2 bags of unworn clothing', task2: 'Organize capsule wardrobe by color' },
    { title: 'Family Coordination & Calendar Sync', desc: 'Shared grocery lists, chore allocations, kids’ activities, and weekend family dates.', focus: 'Family Harmony', habit: 'Sunday family sync meeting', task1: 'Coordinate school schedules and carpools', task2: 'Plan weekend family outdoor excursion' },
    { title: 'Home Maintenance & Seasonal Care', desc: 'Spring cleaning, HVAC filters, gutter clearing, smoke detector tests, and deep cleaning.', focus: 'Home Care', habit: 'Monthly home inspection check', task1: 'Replace HVAC air filters', task2: 'Test smoke and carbon monoxide detectors' },
    { title: 'Mindful Reading List & Backlog Triage', desc: 'Curate to-read list, prioritize top 5 books, eliminate guilt of unread books.', focus: 'Reading Plan', habit: 'Read 20 mins before bed', task1: 'Select next 3 high-impact books to read', task2: 'Donate physical books that will not be read' },
    { title: 'Personal Brand & Online Presence Plan', desc: 'LinkedIn profile optimization, personal domain, bio update, and portfolio site.', focus: 'Personal Brand', habit: 'Post 1 professional insight weekly', task1: 'Update LinkedIn experience & headline', task2: 'Refresh portfolio project case studies' },
  ],
  content: [
    { title: 'YouTube 100K Channel Content Engine', desc: 'Ideation, title/thumbnail A/B testing, script outline, filming, editing, and analytics.', focus: 'YouTube Engine', habit: 'Draft 1 video concept daily', task1: 'Design 3 thumbnail concepts before filming', task2: 'Record high-energy video intro hook' },
    { title: 'Weekly Newsletter Publishing Pipeline', desc: 'Curate links, draft core essay, review sponsor placements, send test email, and broadcast.', focus: 'Newsletter', habit: 'Send weekly newsletter on Thursday', task1: 'Draft 800-word lead essay', task2: 'Send test email and verify all links' },
    { title: 'Twitter/X Thread & Content Multiplier', desc: 'Hook writing, storytelling thread, call to action, and repurposing into LinkedIn post.', focus: 'Social Media', habit: 'Post 1 value thread weekly', task1: 'Write compelling 3-second hook tweet', task2: 'Repurpose thread into LinkedIn carousel' },
    { title: 'Technical Blog Post & SEO Master', desc: 'Keyword research, code snippets, architectural diagram, and dev.to / Hashnode cross-post.', focus: 'Technical Writing', habit: 'Write 1 technical article bi-weekly', task1: 'Create clean architecture diagram in Mermaid', task2: 'Publish to personal blog and dev.to' },
    { title: 'Short-Form Video Batching Engine (Reels/TikTok)', desc: 'Batch script 10 short hooks, record in 1 hour, edit with dynamic captions, and schedule.', focus: 'Short-Form Video', habit: 'Batch record 5 clips on Tuesday', task1: 'Record 5 short-form vertical videos', task2: 'Add animated captions and sound effects' },
    { title: 'Online Course Curriculum & Launch', desc: 'Module learning objectives, video lessons, downloadable worksheets, and sales page.', focus: 'Course Creation', habit: 'Record 2 course lessons weekly', task1: 'Record Module 2 video walkthroughs', task2: 'Create downloadable action PDF cheat sheet' },
    { title: 'E-Book Self-Publishing Sprint', desc: 'Book outline, 30-day writing sprint, developmental edit, formatting, and Gumroad launch.', focus: 'E-Book Author', habit: 'Write 750 words daily', task1: 'Format e-book EPUB and PDF versions', task2: 'Set up Gumroad checkout and email sequence' },
    { title: 'Podcast Host Production Cadence', desc: 'Guest booking, research brief, riverside.fm recording, editor handoff, and clip promotion.', focus: 'Podcasting', habit: 'Record weekly episode', task1: 'Compile 1-page deep research brief on guest', task2: 'Create 3 promotional audiograms for Instagram' },
    { title: 'SEO Topic Cluster & Pillar Page Strategy', desc: 'Target primary keyword pillar with 8 supporting subtopic articles linking to hub.', focus: 'SEO Growth', habit: 'Publish 1 cluster article weekly', task1: 'Publish 3,000-word comprehensive pillar page', task2: 'Build internal linking mesh between cluster posts' },
    { title: 'Product Launch Email Sequence (7-Day)', desc: 'Anticipation, launch announcement, social proof, FAQ, objection handling, and last chance.', focus: 'Email Copywriting', habit: 'Review email open & click rates', task1: 'Write Day 1 Launch Announcement email', task2: 'Write Day 7 Final Call urgency email' },
  ],
  business: [
    { title: 'Solo Founder Operating System', desc: 'Product roadmap, customer support, revenue tracking, marketing, and legal all in one.', focus: 'Solo Founder', habit: 'Daily revenue & metric check', task1: 'Resolve all open customer support tickets', task2: 'Ship weekly product feature update' },
    { title: 'B2B Sales Pipeline & CRM Master', desc: 'Prospecting, discovery call, demo, proposal, negotiation, and closed-won onboarding.', focus: 'B2B Sales', habit: 'Reach out to 10 qualified leads daily', task1: 'Conduct 30-min product demonstration call', task2: 'Send custom enterprise proposal' },
    { title: 'Investor Pitch Deck & Fundraising Sprint', desc: 'Problem, solution, market size, business model, traction, team, and financial ask.', focus: 'Fundraising', habit: 'Update investor pipeline sheet', task1: 'Refine 12-slide investor pitch deck', task2: 'Schedule pitch meetings with 5 angel investors' },
    { title: 'Client Onboarding & Kickoff System', desc: 'Welcome email, questionnaire, shared workspace, kickoff call, and deliverable timeline.', focus: 'Client Success', habit: 'Send onboarding packet within 24h', task1: 'Provision shared client Notion portal', task2: 'Conduct 45-minute project kickoff meeting' },
    { title: 'Quarterly Board & Stakeholder Update', desc: 'KPI scorecard, revenue growth, cash runway, customer churn, and strategic priorities.', focus: 'Board Reporting', habit: 'Send monthly investor update', task1: 'Compile monthly financial and growth metrics', task2: 'Draft CEO narrative on highlights & lowlights' },
    { title: 'Hiring & Candidate Interview Pipeline', desc: 'Job description, resume screening, take-home challenge, cultural fit, and offer letter.', focus: 'Recruiting', habit: 'Review applicant resumes daily', task1: 'Conduct technical screening interview', task2: 'Send formal employment offer letter' },
    { title: 'Employee Performance Review Cycle', desc: 'Self-assessment, peer feedback, manager review, career leveling, and compensation review.', focus: 'People & HR', habit: 'Quarterly review completion', task1: 'Complete direct report performance appraisal', task2: 'Conduct 1-on-1 career trajectory review' },
    { title: 'Agency Monthly Retainer Management', desc: 'Scope tracking, hours logging, deliverable deadlines, and monthly client reporting.', focus: 'Agency Work', habit: 'Log billable hours daily', task1: 'Compile monthly client ROI deliverable report', task2: 'Schedule monthly strategy review call' },
    { title: 'E-Commerce Product Launch Checklist', desc: 'Supplier inventory, photography, product page copy, ads setup, and shipping logistics.', focus: 'E-Commerce', habit: 'Check inventory stock levels', task1: 'Launch Meta and Google advertising campaigns', task2: 'Verify warehouse fulfillment integration' },
    { title: 'Vendor Contract & Procurement Pipeline', desc: 'Vendor evaluation, NDA, contract negotiation, security review, and payment terms.', focus: 'Procurement', habit: 'Review active vendor agreements', task1: 'Negotiate annual enterprise contract discount', task2: 'Execute vendor mutual non-disclosure agreement' },
  ],
  lifeplanning: [
    { title: '10-Year Life Vision & Milestones', desc: 'Where will you be in 10 years? Career, health, family, wealth, and community.', focus: 'Decade Vision', habit: 'Annual 10-year vision calibration', task1: 'Draft narrative vision of life 10 years out', task2: 'Reverse engineer 3-year milestone markers' },
    { title: 'Family Estate & Emergency Blueprint', desc: 'Will, beneficiaries, passwords, insurance policies, and critical document locations.', focus: 'Estate Planning', habit: 'Annual estate document check', task1: 'Update digital password emergency access', task2: 'Review life insurance policy beneficiaries' },
    { title: 'Healthspan & Longevity Protocol', desc: 'Biomarkers, exercise regimen, nutritional protocol, and cognitive resilience habits.', focus: 'Longevity', habit: 'Daily zone 2 cardio & clean diet', task1: 'Schedule annual comprehensive biomarker panel', task2: 'Audit sleep and resting heart rate trends' },
    { title: 'International Relocation & Nomad Blueprint', desc: 'Visas, taxation, international health insurance, housing lease, and luggage packing.', focus: 'Relocation', habit: 'Check visa requirement status', task1: 'Apply for digital nomad residence visa', task2: 'Secure global expat health insurance' },
    { title: 'Mid-Career Sabbatical Exploration', desc: 'Budgeting, leave agreement, travel itinerary, learning projects, and mind recharge.', focus: 'Sabbatical', habit: 'Journal daily thoughts without pressure', task1: 'Secure 6-month leave agreement with employer', task2: 'Plan 3-month international travel route' },
    { title: 'Parenting & Child Development Milestones', desc: 'Growth milestones, school activities, medical visits, reading lists, and family traditions.', focus: 'Parenting', habit: 'Daily bedtime story reading', task1: 'Schedule pediatric well-child checkup', task2: 'Plan monthly special one-on-one child date' },
    { title: 'Relationship Mastery & Date Night Planner', desc: 'Weekly intentional date nights, love languages, annual retreat, and shared life goals.', focus: 'Relationship Health', habit: 'Weekly intentional date night', task1: 'Plan creative surprise date for partner', task2: 'Have quarterly shared dreams & goals talk' },
    { title: 'Personal Core Values & Ethics Compass', desc: 'Define your non-negotiable core values, moral boundaries, and decision framework.', focus: 'Core Values', habit: 'Review core values in tough decisions', task1: 'List top 5 personal non-negotiable values', task2: 'Write personal code of ethics statement' },
    { title: 'Community Service & Mentorship Tracker', desc: 'Give back: volunteer hours, mentoring junior professionals, and charitable giving.', focus: 'Contribution', habit: 'Volunteer 2 hours monthly', task1: 'Conduct monthly mentorship session', task2: 'Allocate annual charitable donations' },
    { title: 'Bucket List & Adventure Master System', desc: '100 life adventures: countries to visit, skills to learn, adrenaline feats, and dreams.', focus: 'Adventures', habit: 'Complete 1 bucket list item quarterly', task1: 'Book tickets for international adventure feat', task2: 'Document completed adventure with photos' },
  ],
  universal: [
    { title: 'All-In-One Unified Second Brain OS', desc: 'Tasks + Calendar + Habits + Projects + Knowledge + Goals unified into a single command center.', focus: 'Unified Life OS', habit: 'Daily Command Center Sweep', task1: 'Process raw capture into connected objects', task2: 'Review day’s priorities and timeblocks' },
    { title: 'Minimalist Executive Life OS', desc: 'Stripped down to absolute essentials: 3 priorities, calendar timeblocks, and 1 daily note.', focus: 'Minimalist OS', habit: 'Review 3 Priorities Daily', task1: 'Clear calendar of non-essential meetings', task2: 'Focus on singular high-leverage objective' },
    { title: 'Student All-In-One Academic OS', desc: 'Classes, assignments, exams, GPA goals, study habits, lecture notes, and revision sprints.', focus: 'Student OS', habit: 'Daily study block & notes review', task1: 'Log assignment due dates from syllabus', task2: 'Revise lecture notes before next class' },
    { title: 'Freelancer Business & Life OS', desc: 'Client pipeline, project milestones, hourly tracking, invoicing, taxes, and personal life.', focus: 'Freelancer OS', habit: 'Log billable work and client comms', task1: 'Send bi-weekly project milestone updates', task2: 'Reconcile business expenses for month' },
    { title: 'Creator Unified Production Studio OS', desc: 'Content calendar, YouTube scripting, newsletter drafts, sponsor CRM, and analytics.', focus: 'Creator OS', habit: 'Publish on schedule weekly', task1: 'Move drafted video script to production queue', task2: 'Follow up with potential brand sponsors' },
    { title: 'High-Performance Athlete Life OS', desc: 'Training blocks, nutrition logs, sleep recovery scores, race calendar, and physiotherapy.', focus: 'Athlete OS', habit: 'Log daily workout metrics & recovery', task1: 'Complete prescribed training session', task2: 'Perform 15 mins mobility and foam rolling' },
    { title: 'Remote Worker Work-Life Harmony OS', desc: 'Clear boundaries between focus time and personal life, daily shutdown, and social connection.', focus: 'Remote Work OS', habit: 'Perform daily 5:30 PM shutdown', task1: 'Establish hard boundary between work & home', task2: 'Take lunch break away from work desk' },
    { title: 'Digital Nomad Travel & Business OS', desc: 'Co-working spaces, flight bookings, multi-currency expenses, client deadlines, and timezone sync.', focus: 'Nomad OS', habit: 'Check local timezone overlap hours', task1: 'Confirm co-working space high-speed Wi-Fi', task2: 'Organize multi-currency travel expenses' },
    { title: 'Startup Founder Company & Life OS', desc: 'Product, hiring, runway, fundraising, team 1-on-1s, plus personal physical health and sleep.', focus: 'Founder OS', habit: 'Protect 7 hours sleep & daily workout', task1: 'Review company burn rate and cash runway', task2: 'Conduct weekly all-hands sprint alignment' },
    { title: 'Holistic Wellbeing & Mental Health OS', desc: 'Mindfulness, therapy reflections, mood check-ins, sleep tracking, and gentle goal setting.', focus: 'Mental Wellbeing OS', habit: 'Daily mindful breathing & gratitude', task1: 'Log daily mood and energy check-in', task2: 'Engage in restful screen-free hobby' },
  ],
};

// Procedural generator to expand each category to at least 100 high-quality, distinct templates!
// 18 categories * 100 templates = 1,800 templates!
export function generateFullTemplateCatalog(): TemplateItem[] {
  const allTemplates: TemplateItem[] = [];

  // 1. Include the hand-crafted featured initial templates first
  initialTemplates.forEach((t) => {
    allTemplates.push({
      ...t,
      isPublic: true,
      status: 'published',
      version: '1.0.0',
      creator: { name: 'Life OS Master Lab', verified: true, role: 'Official Core Blueprint' },
      usageCount: Math.floor(Math.random() * 5000) + 3000,
      likesCount: Math.floor(Math.random() * 1200) + 400,
    });
  });

  const creators = [
    { name: 'Alex Vance', role: 'Executive Coach', verified: true },
    { name: 'Dr. Elena Rostova', role: 'Neuroscience Researcher', verified: true },
    { name: 'Productivity Guild', role: 'Community Curators', verified: true },
    { name: 'Marcus Sterling', role: 'Solo SaaS Founder', verified: false },
    { name: 'Sarah Lin', role: 'Creative Director', verified: true },
    { name: 'Deep Work Lab', role: 'Cognitive Science Studio', verified: true },
    { name: 'Kenji Sato', role: 'Minimalist Designer', verified: false },
    { name: 'Maya Patel', role: 'Medical Resident & Tutor', verified: true },
  ];

  const subModifiers = [
    'Master Framework',
    'Essential Sprint',
    'Advanced Protocol',
    'Minimalist Edition',
    'Power User System',
    'Rapid Execution Blueprint',
    'Complete Operating Engine',
    'Daily Alignment Cadence',
    'High-Leverage Hub',
    'Full-Lifecycle Architecture',
  ];

  CATEGORY_DEFINITIONS.forEach((catMeta) => {
    const seeds = MODULE_SEEDS[catMeta.id] || MODULE_SEEDS['tasks'] || [];
    if (!seeds.length) return;
    let countForCategory = allTemplates.filter((t) => t.category === catMeta.id).length;

    // Generate up to 100 distinct templates for this category
    let index = 1;
    while (countForCategory < 100) {
      const seedIndex = (index - 1) % seeds.length;
      const modIndex = Math.floor((index - 1) / seeds.length) % subModifiers.length;
      const seed = seeds[seedIndex];
      const modifier = subModifiers[modIndex];
      const creator = creators[(index + catMeta.id.length) % creators.length];

      const templateId = `tpl-${catMeta.id}-${index.toString().padStart(3, '0')}`;

      // Create distinct title and description
      const title = index <= seeds.length ? seed.title : `${seed.title} (${modifier})`;
      const desc = `${seed.desc} Designed specifically for ${catMeta.label} practitioners with connected tasks, goals, calendar timeblocks, and habits.`;

      const variables: TemplateVariable[] = [
        {
          key: 'primaryFocus',
          label: 'Primary Focus / Scope',
          placeholder: 'e.g. Q4 Objective',
          defaultValue: seed.focus,
          type: 'text',
        },
        {
          key: 'targetDate',
          label: 'Target Completion Date',
          placeholder: 'YYYY-MM-DD',
          defaultValue: new Date(Date.now() + 30 * 86400000).toISOString().split('T')[0],
          type: 'date',
        },
        {
          key: 'dailyCommitment',
          label: 'Daily Target Duration (Mins)',
          placeholder: '45',
          defaultValue: '45',
          type: 'number',
        },
      ];

      const blueprint: TemplateBlueprint = {
        goal: {
          title: `Achieve ${seed.focus} Mastery`,
          vision: `Successfully execute ${title} with high consistency, clear metrics, and zero wasted motion.`,
          area: catMeta.id === 'money' ? 'Finance' : catMeta.id === 'study' ? 'Learning' : catMeta.id === 'business' ? 'Career' : 'Personal',
          status: 'active',
          progress: 0,
        },
        projects: [
          {
            title: `{{primaryFocus}} Execution Project`,
            description: `Active deliverables and milestones for ${title}.`,
            status: 'active',
            progress: 0,
            deadline: `{{targetDate}}`,
          },
        ],
        tasks: [
          {
            title: seed.task1,
            status: 'today',
            priority: 'urgent',
            durationMinutes: 45,
            energyRequired: 'high',
            subtasks: [
              { id: 'st-1', title: 'Prepare reference material & environment', completed: false },
              { id: 'st-2', title: 'Complete first 30-minute block', completed: false },
            ],
            tags: [catMeta.id, 'priority'],
          },
          {
            title: seed.task2,
            status: 'upcoming',
            priority: 'high',
            durationMinutes: 30,
            energyRequired: 'medium',
            subtasks: [],
            tags: [catMeta.id],
          },
          {
            title: `Review & verify {{primaryFocus}} milestones`,
            status: 'upcoming',
            priority: 'medium',
            durationMinutes: 20,
            energyRequired: 'low',
            subtasks: [],
            tags: [catMeta.id, 'review'],
          },
        ],
        habits: [
          {
            title: seed.habit,
            frequency: 'daily',
            targetDaysPerWeek: 6,
            category: catMeta.label,
          },
        ],
        calendarEvents: [
          {
            title: `${seed.focus} Dedicated Block`,
            date: new Date().toISOString().split('T')[0],
            startTime: '09:30',
            endTime: '11:00',
            type: 'focus',
            energyRequired: 'high',
            isFixedCommitment: true,
            notes: `Reserved for ${title}`,
          },
        ],
        notes: [
          {
            title: `${title} Standard Operating Note`,
            type: catMeta.id === 'secondbrain' ? 'knowledge' : 'note',
            content: `# ${title}\n\n## Overview\nThis template establishes a repeatable operating cadence for **{{primaryFocus}}**.\n\n### Key Principles\n1. **Consistency**: Execute the daily habit without breaking the chain.\n2. **Clarity**: Keep next action items concrete and small.\n3. **Continuous Review**: Audit progress at the end of each sprint.\n\n### Connected Life Objects\n- **Goal**: Achieve {{primaryFocus}} Mastery\n- **Project**: {{primaryFocus}} Execution\n- **Daily Habit**: ${seed.habit}`,
            tags: [catMeta.id, 'template-note'],
            backlinks: [],
          },
        ],
        automations: [
          {
            id: `auto-${catMeta.id}-${index}`,
            title: `Sync ${seed.focus} Progress`,
            trigger: `When habit "${seed.habit}" is completed`,
            action: `Recalculate project progress and log celebration toast`,
            enabled: true,
            description: `Automates accountability between habit execution and goal progress.`,
            whenTrigger: 'habit_completed',
          },
        ],
      };

      allTemplates.push({
        id: templateId,
        title,
        description: desc,
        category: catMeta.id,
        icon: catMeta.iconName,
        color: catMeta.color,
        isFavorite: index <= 3,
        isBuiltIn: true,
        isPublic: true,
        status: 'published',
        version: '1.0.0',
        creator,
        usageCount: Math.floor(Math.random() * 4500) + 120,
        likesCount: Math.floor(Math.random() * 950) + 25,
        featuresUsed: ['tasks', 'goals', 'habits', 'calendar', 'notes', 'automations'],
        tags: [catMeta.id, ...catMeta.tags, seed.focus.toLowerCase().replace(/\s+/g, '-')],
        variables,
        blueprint,
        createdAt: new Date(Date.now() - (index * 86400000)).toISOString(),
      });

      countForCategory++;
      index++;
    }
  });

  return allTemplates;
}

// Global memoized catalog instance
let cachedCatalog: TemplateItem[] | null = null;

export function getFullTemplateCatalog(): TemplateItem[] {
  if (!cachedCatalog) {
    cachedCatalog = generateFullTemplateCatalog();
  }
  return cachedCatalog;
}

export function searchTemplateCatalog(
  templates: TemplateItem[],
  query: string,
  category: string = 'all',
  sortBy: 'popular' | 'new' | 'rating' | 'title' = 'popular'
): TemplateItem[] {
  let list = templates;

  if (category !== 'all') {
    list = list.filter((t) => t.category === category);
  }

  if (query.trim()) {
    const q = query.toLowerCase().trim();
    list = list.filter((t) => {
      const titleMatch = t.title.toLowerCase().includes(q);
      const descMatch = t.description.toLowerCase().includes(q);
      const tagMatch = t.tags?.some((tg) => tg.toLowerCase().includes(q));
      const creatorMatch = t.creator?.name.toLowerCase().includes(q);
      return titleMatch || descMatch || tagMatch || creatorMatch;
    });
  }

  // Sort
  return list.sort((a, b) => {
    if (sortBy === 'popular') {
      return (b.usageCount || 0) - (a.usageCount || 0);
    }
    if (sortBy === 'new') {
      return new Date(b.createdAt || 0).getTime() - new Date(a.createdAt || 0).getTime();
    }
    if (sortBy === 'rating') {
      return (b.likesCount || 0) - (a.likesCount || 0);
    }
    return a.title.localeCompare(b.title);
  });
}
