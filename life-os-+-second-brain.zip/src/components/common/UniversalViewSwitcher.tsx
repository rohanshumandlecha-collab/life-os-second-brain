import React from 'react';
import { List, LayoutGrid, Calendar, AlignLeft, Table } from 'lucide-react';
import { ViewType } from '../../types';

interface UniversalViewSwitcherProps {
  activeView: ViewType;
  onViewChange: (view: ViewType) => void;
  availableViews?: ViewType[];
  className?: string;
}

export const UniversalViewSwitcher: React.FC<UniversalViewSwitcherProps> = ({
  activeView,
  onViewChange,
  availableViews = ['list', 'board', 'calendar', 'timeline', 'table'],
  className = '',
}) => {
  const views: { id: ViewType; label: string; icon: React.FC<{ className?: string }> }[] = [
    { id: 'list', label: 'List', icon: List },
    { id: 'board', label: 'Board', icon: LayoutGrid },
    { id: 'calendar', label: 'Calendar', icon: Calendar },
    { id: 'timeline', label: 'Timeline', icon: AlignLeft },
    { id: 'table', label: 'Table', icon: Table },
  ];

  const visibleViews = views.filter((v) => availableViews.includes(v.id));

  return (
    <div
      className={`inline-flex items-center p-1 rounded-xl bg-[var(--bg-surface-subtle)] border border-[var(--border-default)] shadow-xs ${className}`}
    >
      {visibleViews.map((v) => {
        const Icon = v.icon;
        const isActive = activeView === v.id;
        return (
          <button
            key={v.id}
            onClick={() => onViewChange(v.id)}
            className={`active-press flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs font-medium transition-all cursor-pointer ${
              isActive
                ? 'bg-[var(--bg-surface-elevated)] text-[var(--accent)] shadow-xs font-semibold'
                : 'text-[var(--text-secondary)] hover:text-[var(--text-primary)]'
            }`}
            title={`${v.label} View`}
            aria-label={`${v.label} View`}
          >
            <Icon className={`w-3.5 h-3.5 ${isActive ? 'text-[var(--accent)]' : ''}`} />
            <span className="hidden sm:inline">{v.label}</span>
          </button>
        );
      })}
    </div>
  );
};
