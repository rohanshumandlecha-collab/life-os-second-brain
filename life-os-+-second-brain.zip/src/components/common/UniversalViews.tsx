import React, { useState } from 'react';
import {
  CheckCircle2,
  Circle,
  Clock,
  Calendar as CalendarIcon,
  Tag,
  Link2,
  ChevronRight,
  ChevronLeft,
  ArrowUpDown,
  Filter,
  Plus,
  MoreHorizontal,
  Flame,
  Target,
  FolderGit2,
  FileText,
  AlertCircle,
  Check,
} from 'lucide-react';
import { LifeObject, LifeObjectType, ViewType, Priority } from '../../types';
import { useLifeOS } from '../../context/LifeOSContext';

interface UniversalViewsProps {
  items: LifeObject[];
  activeView: ViewType;
  onItemClick?: (item: LifeObject) => void;
  onToggleComplete?: (id: string, type: LifeObjectType) => void;
  onStatusChange?: (id: string, newStatus: string, type: LifeObjectType) => void;
  emptyMessage?: string;
  allowQuickAdd?: boolean;
  defaultType?: LifeObjectType;
}

export const UniversalViews: React.FC<UniversalViewsProps> = ({
  items,
  activeView,
  onItemClick,
  onToggleComplete,
  onStatusChange,
  emptyMessage = 'No items found in this view.',
  allowQuickAdd = true,
  defaultType = 'task',
}) => {
  const { addTask, addNote, projects, goals, showToast } = useLifeOS();
  const [filterType, setFilterType] = useState<string>('all');
  const [searchFilter, setSearchFilter] = useState('');
  const [sortField, setSortField] = useState<'title' | 'date' | 'priority'>('date');
  const [sortAsc, setSortAsc] = useState(false);
  const [quickTitle, setQuickTitle] = useState('');

  // Calendar view state
  const [calendarMonth, setCalendarMonth] = useState(new Date().getMonth());
  const [calendarYear, setCalendarYear] = useState(new Date().getFullYear());
  const [selectedCalendarDate, setSelectedCalendarDate] = useState<string>(
    new Date().toISOString().split('T')[0]
  );

  // Filter and sort items
  const filtered = items
    .filter((item) => {
      if (filterType !== 'all' && item.type !== filterType) return false;
      if (searchFilter.trim()) {
        const q = searchFilter.toLowerCase();
        const matchTitle = item.title.toLowerCase().includes(q);
        const matchDesc = item.description?.toLowerCase().includes(q);
        const matchTags = item.tags.some((t) => t.toLowerCase().includes(q));
        if (!matchTitle && !matchDesc && !matchTags) return false;
      }
      return true;
    })
    .sort((a, b) => {
      if (sortField === 'title') {
        return sortAsc ? a.title.localeCompare(b.title) : b.title.localeCompare(a.title);
      }
      if (sortField === 'priority') {
        const weights: Record<string, number> = { urgent: 4, high: 3, medium: 2, low: 1 };
        const wA = weights[a.priority || 'medium'] || 0;
        const wB = weights[b.priority || 'medium'] || 0;
        return sortAsc ? wA - wB : wB - wA;
      }
      // date
      const dateA = a.dueDate || a.date || a.targetDate || a.createdAt;
      const dateB = b.dueDate || b.date || b.targetDate || b.createdAt;
      return sortAsc ? dateA.localeCompare(dateB) : dateB.localeCompare(dateA);
    });

  const handleQuickAdd = (e: React.FormEvent) => {
    e.preventDefault();
    if (!quickTitle.trim()) return;

    if (defaultType === 'task') {
      addTask({
        title: quickTitle.trim(),
        status: 'today',
        priority: 'medium',
        dueDate: new Date().toISOString().split('T')[0],
        subtasks: [],
        tags: ['quick-add'],
      });
      showToast(`Task added: "${quickTitle.trim()}"`, 'success');
    } else {
      addNote({
        title: quickTitle.trim(),
        content: '',
        type: 'note',
        tags: ['quick-note'],
        backlinks: [],
      });
      showToast(`Note added: "${quickTitle.trim()}"`, 'success');
    }
    setQuickTitle('');
  };

  const getPriorityBadge = (p?: Priority) => {
    switch (p) {
      case 'urgent':
        return <span className="text-[10px] px-2 py-0.5 rounded-full font-bold bg-rose-500/15 text-rose-600 dark:text-rose-400">Urgent</span>;
      case 'high':
        return <span className="text-[10px] px-2 py-0.5 rounded-full font-bold bg-amber-500/15 text-amber-600 dark:text-amber-400">High</span>;
      case 'medium':
        return <span className="text-[10px] px-2 py-0.5 rounded-full font-medium bg-blue-500/10 text-blue-600 dark:text-blue-400">Medium</span>;
      default:
        return <span className="text-[10px] px-2 py-0.5 rounded-full font-medium bg-[var(--bg-surface-input)] text-[var(--text-tertiary)]">Low</span>;
    }
  };

  const getTypeIcon = (type: LifeObjectType) => {
    switch (type) {
      case 'task':
        return <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500" />;
      case 'note':
      case 'knowledge':
        return <FileText className="w-3.5 h-3.5 text-indigo-500" />;
      case 'goal':
        return <Target className="w-3.5 h-3.5 text-blue-500" />;
      case 'project':
        return <FolderGit2 className="w-3.5 h-3.5 text-purple-500" />;
      case 'habit':
        return <Flame className="w-3.5 h-3.5 text-amber-500" />;
      case 'event':
        return <CalendarIcon className="w-3.5 h-3.5 text-cyan-500" />;
      default:
        return <Tag className="w-3.5 h-3.5 text-[var(--text-tertiary)]" />;
    }
  };

  // -------------------------------------------------------------
  // 1. LIST VIEW
  // -------------------------------------------------------------
  const renderListView = () => {
    if (filtered.length === 0) {
      return (
        <div className="p-8 rounded-2xl bg-[var(--bg-surface-elevated)] border border-[var(--border-default)] text-center text-xs text-[var(--text-tertiary)]">
          {emptyMessage}
        </div>
      );
    }

    return (
      <div className="ios-grouped-list">
        {filtered.map((item) => {
          const isDone = item.status === 'completed' || item.status === 'achieved';
          return (
            <div
              key={item.id}
              className="ios-list-row gap-3 cursor-pointer group"
              onClick={() => onItemClick && onItemClick(item)}
            >
              <div className="flex items-center gap-2.5 min-w-0 flex-1">
                {onToggleComplete && item.type === 'task' ? (
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      onToggleComplete(item.id, item.type);
                    }}
                    className="text-[var(--text-tertiary)] hover:text-[var(--accent)] transition-colors cursor-pointer shrink-0"
                    aria-label="Toggle completion"
                  >
                    {isDone ? (
                      <CheckCircle2 className="w-5 h-5 text-emerald-500" />
                    ) : (
                      <Circle className="w-5 h-5" />
                    )}
                  </button>
                ) : (
                  <span className="shrink-0">{getTypeIcon(item.type)}</span>
                )}

                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-2">
                    <span
                      className={`text-xs sm:text-sm font-medium truncate ${
                        isDone ? 'line-through text-[var(--text-tertiary)]' : 'text-[var(--text-primary)]'
                      }`}
                    >
                      {item.title}
                    </span>
                  </div>

                  <div className="flex items-center gap-2 mt-0.5 text-[11px] text-[var(--text-tertiary)] flex-wrap">
                    <span className="capitalize font-mono text-[10px] uppercase font-bold text-[var(--text-secondary)]">
                      {item.type}
                    </span>
                    {(item.dueDate || item.date || item.targetDate) && (
                      <span className="flex items-center gap-1">
                        <CalendarIcon className="w-3 h-3" />
                        {item.dueDate || item.date || item.targetDate}
                      </span>
                    )}
                    {item.durationMinutes && (
                      <span className="flex items-center gap-1">
                        <Clock className="w-3 h-3" />
                        {item.durationMinutes}m
                      </span>
                    )}
                    {item.relations && item.relations.length > 0 && (
                      <span className="flex items-center gap-1 px-1.5 py-0.2 rounded-md bg-[var(--bg-surface-subtle)] text-[10px] text-[var(--accent)] font-medium">
                        <Link2 className="w-3 h-3" />
                        {item.relations.length} linked
                      </span>
                    )}
                    {item.tags.slice(0, 2).map((t) => (
                      <span key={t} className="text-[10px]">
                        #{t}
                      </span>
                    ))}
                  </div>
                </div>
              </div>

              <div className="flex items-center gap-2 shrink-0">
                {item.priority && getPriorityBadge(item.priority)}
                <ChevronRight className="w-4 h-4 text-[var(--text-tertiary)] group-hover:text-[var(--text-secondary)] transition-colors" />
              </div>
            </div>
          );
        })}
      </div>
    );
  };

  // -------------------------------------------------------------
  // 2. BOARD (KANBAN) VIEW
  // -------------------------------------------------------------
  const renderBoardView = () => {
    const columns: { id: string; title: string; filterFn: (item: LifeObject) => boolean }[] = [
      {
        id: 'inbox',
        title: 'Inbox / Backlog',
        filterFn: (i) => i.status === 'inbox' || (!i.status && i.type === 'note'),
      },
      {
        id: 'today',
        title: 'Today / In Progress',
        filterFn: (i) => i.status === 'today' || i.status === 'active',
      },
      {
        id: 'upcoming',
        title: 'Upcoming / Scheduled',
        filterFn: (i) => i.status === 'upcoming' || Boolean(i.dueDate && i.status !== 'completed'),
      },
      {
        id: 'completed',
        title: 'Completed',
        filterFn: (i) => i.status === 'completed' || i.status === 'achieved',
      },
    ];

    return (
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 overflow-x-auto pb-4">
        {columns.map((col) => {
          const colItems = filtered.filter(col.filterFn);
          return (
            <div
              key={col.id}
              className="p-3.5 rounded-2xl bg-[var(--bg-surface-elevated)] border border-[var(--border-default)] flex flex-col min-h-[400px] shadow-xs"
            >
              <div className="flex items-center justify-between pb-3 border-b border-[var(--border-subtle)] mb-3">
                <span className="text-xs font-bold uppercase tracking-wider text-[var(--text-secondary)]">
                  {col.title}
                </span>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-[var(--bg-surface-input)] text-[var(--text-secondary)]">
                  {colItems.length}
                </span>
              </div>

              <div className="flex-1 space-y-2 overflow-y-auto max-h-[550px] pr-1">
                {colItems.length === 0 ? (
                  <p className="text-[11px] text-[var(--text-tertiary)] text-center py-8">
                    No items in this column
                  </p>
                ) : (
                  colItems.map((item) => (
                    <div
                      key={item.id}
                      onClick={() => onItemClick && onItemClick(item)}
                      className="active-press p-3 rounded-xl bg-[var(--bg-surface-subtle)] border border-[var(--border-default)] hover:border-[var(--border-focus)] transition-all cursor-pointer space-y-2 shadow-2xs"
                    >
                      <div className="flex items-start justify-between gap-2">
                        <div className="flex items-center gap-1.5">
                          {getTypeIcon(item.type)}
                          <h4 className="text-xs font-semibold text-[var(--text-primary)] line-clamp-2">
                            {item.title}
                          </h4>
                        </div>
                        {item.priority && (
                          <span className="shrink-0">{getPriorityBadge(item.priority)}</span>
                        )}
                      </div>

                      {item.description && (
                        <p className="text-[11px] text-[var(--text-secondary)] line-clamp-2">
                          {item.description}
                        </p>
                      )}

                      <div className="flex items-center justify-between text-[10px] text-[var(--text-tertiary)] pt-1 border-t border-[var(--border-subtle)]">
                        <span>{item.dueDate || item.date || item.targetDate || 'No date'}</span>
                        {onStatusChange && (
                          <select
                            value={col.id}
                            onChange={(e) => {
                              e.stopPropagation();
                              onStatusChange(item.id, e.target.value, item.type);
                            }}
                            className="bg-transparent border border-[var(--border-subtle)] rounded px-1 py-0.5 text-[10px] text-[var(--text-secondary)] focus:outline-hidden"
                            onClick={(e) => e.stopPropagation()}
                          >
                            <option value="inbox">Inbox</option>
                            <option value="today">Today</option>
                            <option value="upcoming">Upcoming</option>
                            <option value="completed">Done</option>
                          </select>
                        )}
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>
          );
        })}
      </div>
    );
  };

  // -------------------------------------------------------------
  // 3. CALENDAR VIEW
  // -------------------------------------------------------------
  const renderCalendarView = () => {
    const daysInMonth = new Date(calendarYear, calendarMonth + 1, 0).getDate();
    const firstDayIndex = new Date(calendarYear, calendarMonth, 1).getDay();
    const monthNames = [
      'January', 'February', 'March', 'April', 'May', 'June',
      'July', 'August', 'September', 'October', 'November', 'December'
    ];

    const prevMonth = () => {
      if (calendarMonth === 0) {
        setCalendarMonth(11);
        setCalendarYear(calendarYear - 1);
      } else {
        setCalendarMonth(calendarMonth - 1);
      }
    };

    const nextMonth = () => {
      if (calendarMonth === 11) {
        setCalendarMonth(0);
        setCalendarYear(calendarYear + 1);
      } else {
        setCalendarMonth(calendarMonth + 1);
      }
    };

    const itemsOnSelectedDate = filtered.filter((i) => {
      const d = i.dueDate || i.date || i.targetDate;
      return d === selectedCalendarDate;
    });

    return (
      <div className="space-y-4">
        {/* Calendar Nav */}
        <div className="flex items-center justify-between p-4 rounded-2xl bg-[var(--bg-surface-elevated)] border border-[var(--border-default)]">
          <div className="flex items-center gap-2">
            <CalendarIcon className="w-5 h-5 text-[var(--accent)]" />
            <h3 className="text-sm font-bold text-[var(--text-primary)]">
              {monthNames[calendarMonth]} {calendarYear}
            </h3>
          </div>
          <div className="flex items-center gap-1.5">
            <button
              onClick={prevMonth}
              className="active-press p-1.5 rounded-lg border border-[var(--border-default)] text-[var(--text-secondary)] hover:text-[var(--text-primary)]"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
            <button
              onClick={nextMonth}
              className="active-press p-1.5 rounded-lg border border-[var(--border-default)] text-[var(--text-secondary)] hover:text-[var(--text-primary)]"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* 7-Day Grid */}
        <div className="p-4 rounded-2xl bg-[var(--bg-surface-elevated)] border border-[var(--border-default)]">
          <div className="grid grid-cols-7 gap-1 text-center pb-2 text-[11px] font-bold text-[var(--text-tertiary)]">
            <span>Sun</span>
            <span>Mon</span>
            <span>Tue</span>
            <span>Wed</span>
            <span>Thu</span>
            <span>Fri</span>
            <span>Sat</span>
          </div>

          <div className="grid grid-cols-7 gap-1">
            {Array.from({ length: firstDayIndex }).map((_, idx) => (
              <div key={`empty-${idx}`} className="h-14 sm:h-18 p-1 opacity-20" />
            ))}

            {Array.from({ length: daysInMonth }).map((_, idx) => {
              const day = idx + 1;
              const dateStr = `${calendarYear}-${String(calendarMonth + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
              const dayItems = filtered.filter((i) => (i.dueDate || i.date || i.targetDate) === dateStr);
              const isSelected = selectedCalendarDate === dateStr;
              const isToday = dateStr === new Date().toISOString().split('T')[0];

              return (
                <button
                  key={day}
                  onClick={() => setSelectedCalendarDate(dateStr)}
                  className={`active-press h-14 sm:h-18 p-1 sm:p-1.5 rounded-xl border text-left flex flex-col justify-between transition-all cursor-pointer ${
                    isSelected
                      ? 'border-[var(--border-focus)] bg-[var(--ui-selected)] font-bold'
                      : isToday
                      ? 'border-[var(--accent)] bg-[var(--bg-surface-subtle)]'
                      : 'border-[var(--border-subtle)] hover:bg-[var(--ui-hover)]'
                  }`}
                >
                  <span
                    className={`text-[11px] ${
                      isToday
                        ? 'w-5 h-5 rounded-full bg-[var(--accent)] text-[var(--accent-text)] flex items-center justify-center font-bold'
                        : isSelected
                        ? 'text-[var(--accent)] font-bold'
                        : 'text-[var(--text-secondary)]'
                    }`}
                  >
                    {day}
                  </span>

                  <div className="flex items-center gap-1 flex-wrap overflow-hidden">
                    {dayItems.slice(0, 3).map((item) => (
                      <span
                        key={item.id}
                        className="w-1.5 h-1.5 rounded-full bg-[var(--accent)]"
                        title={item.title}
                      />
                    ))}
                    {dayItems.length > 3 && (
                      <span className="text-[9px] text-[var(--text-tertiary)]">
                        +{dayItems.length - 3}
                      </span>
                    )}
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Selected Date Drawer */}
        <div className="p-4 rounded-2xl bg-[var(--bg-surface-elevated)] border border-[var(--border-default)] space-y-3">
          <div className="flex items-center justify-between pb-2 border-b border-[var(--border-subtle)]">
            <h4 className="text-xs font-bold text-[var(--text-primary)]">
              Scheduled on {selectedCalendarDate} ({itemsOnSelectedDate.length})
            </h4>
          </div>

          {itemsOnSelectedDate.length === 0 ? (
            <p className="text-xs text-[var(--text-tertiary)] text-center py-4">
              No items scheduled for this day.
            </p>
          ) : (
            <div className="space-y-1.5">
              {itemsOnSelectedDate.map((item) => (
                <div
                  key={item.id}
                  onClick={() => onItemClick && onItemClick(item)}
                  className="active-press p-2.5 rounded-xl bg-[var(--bg-surface-subtle)] border border-[var(--border-default)] flex items-center justify-between text-xs cursor-pointer hover:border-[var(--border-focus)]"
                >
                  <div className="flex items-center gap-2">
                    {getTypeIcon(item.type)}
                    <span className="font-medium text-[var(--text-primary)]">{item.title}</span>
                  </div>
                  {item.priority && getPriorityBadge(item.priority)}
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    );
  };

  // -------------------------------------------------------------
  // 4. TIMELINE (GANTT) VIEW
  // -------------------------------------------------------------
  const renderTimelineView = () => {
    return (
      <div className="p-4 rounded-2xl bg-[var(--bg-surface-elevated)] border border-[var(--border-default)] space-y-4">
        <div className="flex items-center justify-between pb-2 border-b border-[var(--border-subtle)]">
          <span className="text-xs font-bold uppercase tracking-wider text-[var(--text-secondary)]">
            Visual Horizontal Lifecycle & Progress
          </span>
          <span className="text-xs text-[var(--text-tertiary)]">{filtered.length} active streams</span>
        </div>

        <div className="space-y-3">
          {filtered.length === 0 ? (
            <p className="text-xs text-[var(--text-tertiary)] text-center py-8">{emptyMessage}</p>
          ) : (
            filtered.map((item) => {
              const progressVal = item.progress ?? (item.status === 'completed' ? 100 : 35);
              return (
                <div
                  key={item.id}
                  onClick={() => onItemClick && onItemClick(item)}
                  className="active-press p-3 rounded-xl bg-[var(--bg-surface-subtle)] border border-[var(--border-default)] hover:border-[var(--border-focus)] transition-all cursor-pointer space-y-2"
                >
                  <div className="flex items-center justify-between text-xs">
                    <div className="flex items-center gap-2">
                      {getTypeIcon(item.type)}
                      <span className="font-semibold text-[var(--text-primary)]">{item.title}</span>
                      <span className="text-[10px] uppercase font-mono text-[var(--text-tertiary)]">
                        {item.type}
                      </span>
                    </div>
                    <div className="flex items-center gap-2 text-[11px] text-[var(--text-tertiary)]">
                      <span>{item.dueDate || item.date || item.targetDate || 'Continuous'}</span>
                      <span className="font-mono font-bold text-[var(--accent)]">
                        {progressVal}%
                      </span>
                    </div>
                  </div>

                  <div className="w-full h-2 rounded-full bg-[var(--bg-surface-input)] overflow-hidden">
                    <div
                      className="h-full rounded-full bg-[var(--accent)] transition-all duration-300"
                      style={{ width: `${progressVal}%` }}
                    />
                  </div>
                </div>
              );
            })
          )}
        </div>
      </div>
    );
  };

  // -------------------------------------------------------------
  // 5. TABLE (DATABASE) VIEW
  // -------------------------------------------------------------
  const renderTableView = () => {
    return (
      <div className="rounded-2xl bg-[var(--bg-surface-elevated)] border border-[var(--border-default)] overflow-x-auto shadow-xs">
        <table className="w-full text-left text-xs">
          <thead className="bg-[var(--bg-surface-subtle)] text-[var(--text-tertiary)] uppercase text-[10px] font-bold border-b border-[var(--border-default)]">
            <tr>
              <th className="py-3 px-4">Title</th>
              <th className="py-3 px-3">Type</th>
              <th className="py-3 px-3">Status</th>
              <th className="py-3 px-3">Priority</th>
              <th className="py-3 px-3">Target Date</th>
              <th className="py-3 px-3">Connections</th>
              <th className="py-3 px-3">Tags</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-[var(--border-subtle)]">
            {filtered.length === 0 ? (
              <tr>
                <td colSpan={7} className="py-8 text-center text-xs text-[var(--text-tertiary)]">
                  {emptyMessage}
                </td>
              </tr>
            ) : (
              filtered.map((item) => (
                <tr
                  key={item.id}
                  onClick={() => onItemClick && onItemClick(item)}
                  className="hover:bg-[var(--ui-hover)] transition-colors cursor-pointer"
                >
                  <td className="py-3 px-4 font-medium text-[var(--text-primary)] max-w-xs truncate">
                    <div className="flex items-center gap-2">
                      {getTypeIcon(item.type)}
                      <span className="truncate">{item.title}</span>
                    </div>
                  </td>
                  <td className="py-3 px-3">
                    <span className="text-[10px] font-mono uppercase px-2 py-0.5 rounded bg-[var(--bg-surface-subtle)] text-[var(--text-secondary)]">
                      {item.type}
                    </span>
                  </td>
                  <td className="py-3 px-3">
                    <span className="text-[11px] capitalize text-[var(--text-secondary)]">
                      {item.status || 'Active'}
                    </span>
                  </td>
                  <td className="py-3 px-3">
                    {item.priority ? getPriorityBadge(item.priority) : '—'}
                  </td>
                  <td className="py-3 px-3 font-mono text-[11px] text-[var(--text-tertiary)]">
                    {item.dueDate || item.date || item.targetDate || '—'}
                  </td>
                  <td className="py-3 px-3">
                    {item.relations && item.relations.length > 0 ? (
                      <span className="inline-flex items-center gap-1 text-[10px] px-2 py-0.5 rounded-full bg-[var(--accent)]/10 text-[var(--accent)] font-medium">
                        <Link2 className="w-3 h-3" />
                        {item.relations.length}
                      </span>
                    ) : (
                      '—'
                    )}
                  </td>
                  <td className="py-3 px-3">
                    <div className="flex items-center gap-1 max-w-[150px] truncate">
                      {item.tags.map((t) => (
                        <span key={t} className="text-[10px] text-[var(--text-tertiary)]">
                          #{t}
                        </span>
                      ))}
                    </div>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    );
  };

  return (
    <div className="space-y-4">
      {/* Filtering & Quick Inline Controls */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2.5">
        <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar pb-1">
          {['all', 'task', 'note', 'project', 'goal', 'habit'].map((t) => (
            <button
              key={t}
              onClick={() => setFilterType(t)}
              className={`active-press text-xs px-2.5 py-1 rounded-xl capitalize font-medium transition-colors cursor-pointer ${
                filterType === t
                  ? 'bg-[var(--accent)] text-[var(--accent-text)] shadow-xs'
                  : 'bg-[var(--bg-surface-elevated)] text-[var(--text-secondary)] border border-[var(--border-default)]'
              }`}
            >
              {t}
            </button>
          ))}
        </div>

        <div className="flex items-center gap-2">
          <input
            type="text"
            placeholder="Search items..."
            value={searchFilter}
            onChange={(e) => setSearchFilter(e.target.value)}
            className="px-3 py-1.5 text-xs rounded-xl bg-[var(--bg-surface-elevated)] border border-[var(--border-default)] text-[var(--text-primary)] placeholder-[var(--text-tertiary)] focus:outline-hidden"
          />

          <button
            onClick={() => setSortAsc(!sortAsc)}
            className="active-press p-1.5 rounded-xl bg-[var(--bg-surface-elevated)] border border-[var(--border-default)] text-[var(--text-secondary)] hover:text-[var(--text-primary)] cursor-pointer"
            title="Toggle sort direction"
          >
            <ArrowUpDown className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Quick Add Row */}
      {allowQuickAdd && (
        <form onSubmit={handleQuickAdd} className="flex items-center gap-2">
          <input
            type="text"
            value={quickTitle}
            onChange={(e) => setQuickTitle(e.target.value)}
            placeholder={`+ Rapidly add a new ${defaultType}... (Press Enter)`}
            className="flex-1 px-4 py-2.5 rounded-xl bg-[var(--bg-surface-elevated)] border border-[var(--border-default)] text-xs text-[var(--text-primary)] placeholder-[var(--text-tertiary)] focus:outline-hidden focus:border-[var(--accent)] shadow-xs"
          />
        </form>
      )}

      {/* Render Dynamic View */}
      {activeView === 'list' && renderListView()}
      {activeView === 'board' && renderBoardView()}
      {activeView === 'calendar' && renderCalendarView()}
      {activeView === 'timeline' && renderTimelineView()}
      {activeView === 'table' && renderTableView()}
    </div>
  );
};
