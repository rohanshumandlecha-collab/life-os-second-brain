import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { useLifeOS } from '../../context/LifeOSContext';
import { CheckCircle2, AlertCircle, Info, X } from 'lucide-react';

export const ToastContainer: React.FC = () => {
  const { toasts, dismissToast } = useLifeOS();

  return (
    <div className="fixed top-3 inset-x-0 z-50 flex flex-col items-center gap-2 pointer-events-none px-4 pt-safe">
      <AnimatePresence>
        {toasts.map((toast) => (
          <motion.div
            key={toast.id}
            initial={{ opacity: 0, y: -24, scale: 0.92 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -16, scale: 0.94 }}
            transition={{ type: 'spring', stiffness: 450, damping: 30 }}
            className="pointer-events-auto flex items-center gap-2.5 px-4 py-2 rounded-full ios-glass border border-[var(--border-default)] shadow-xl text-xs text-[var(--text-primary)] select-none cursor-pointer max-w-md w-auto"
            onClick={() => dismissToast(toast.id)}
          >
            {toast.type === 'success' && (
              <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0" />
            )}
            {toast.type === 'error' && (
              <AlertCircle className="w-4 h-4 text-rose-500 shrink-0" />
            )}
            {toast.type === 'info' && (
              <Info className="w-4 h-4 text-[var(--accent)] shrink-0" />
            )}
            <span className="font-medium tracking-tight text-[12px]">{toast.message}</span>
            <button
              onClick={(e) => {
                e.stopPropagation();
                dismissToast(toast.id);
              }}
              className="text-[var(--text-tertiary)] hover:text-[var(--text-primary)] p-0.5 ml-1 transition-colors"
              aria-label="Dismiss notification"
            >
              <X className="w-3 h-3" />
            </button>
          </motion.div>
        ))}
      </AnimatePresence>
    </div>
  );
};
