import React, { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Layers,
  Search,
  Sparkles,
  Star,
  Play,
  Copy,
  Plus,
  Share2,
  Download,
  Upload,
  Eye,
  CheckCircle2,
  Clock,
  Target,
  Flame,
  FileText,
  Calendar,
  Zap,
  FolderGit2,
  ArrowRight,
  TrendingUp,
  Award,
  Filter,
  SlidersHorizontal,
  X,
  AlertTriangle,
  Globe,
  Lock,
  Edit3,
  Trash2,
  Check,
  Tag,
  BookOpen,
  DollarSign,
  HeartHandshake,
  Briefcase,
  Video,
  Compass,
  RotateCcw,
  BatteryCharging,
  GraduationCap,
  ShieldCheck,
  ChevronRight,
  Send,
  HelpCircle,
  CheckSquare,
  Brain,
} from 'lucide-react';
import { useLifeOS } from '../../context/LifeOSContext';
import {
  TemplateItem,
  TemplateCategory,
  TemplateBlueprint,
  TemplateVariable,
  TemplatesSubNav,
} from '../../types';
import { CATEGORY_DEFINITIONS, searchTemplateCatalog } from '../../data/templateCatalog';

export const TemplatesView: React.FC = () => {
  const {
    templates,
    templatesSubNav,
    setTemplatesSubNav,
    selectedTemplateForPreview,
    setSelectedTemplateForPreview,
    activeTemplateForLaunch,
    setActiveTemplateForLaunch,
    applyTemplate,
    saveAsTemplate,
    deleteTemplate,
    toggleTemplateFavorite,
    duplicateTemplate,
    publishTemplate,
    reportTemplate,
    importTemplateFromJSON,
    exportTemplateToJSON,
    generateTemplateWithAI,
    projects,
    goals,
    settings,
    showToast,
  } = useLifeOS();

  // Search & Filter State
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [sortBy, setSortBy] = useState<'popular' | 'new' | 'rating' | 'title'>('popular');
  const [onlyFavorites, setOnlyFavorites] = useState(false);
  const [pageSize, setPageSize] = useState(24);

  // AI Recommendation State
  const [aiPrompt, setAiPrompt] = useState('');
  const [isAIGenerating, setIsAIGenerating] = useState(false);
  const [aiRecommendationMatches, setAiRecommendationMatches] = useState<TemplateItem[] | null>(null);

  // Create Template State
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [newTitle, setNewTitle] = useState('');
  const [newDesc, setNewDesc] = useState('');
  const [newCategory, setNewCategory] = useState<TemplateCategory>('planning');
  const [newStatus, setNewStatus] = useState<'published' | 'private' | 'draft'>('published');
  const [convertFromProjectId, setConvertFromProjectId] = useState<string>('');
  const [convertFromGoalId, setConvertFromGoalId] = useState<string>('');

  // Import Modal State
  const [isImportModalOpen, setIsImportModalOpen] = useState(false);
  const [importJsonText, setImportJsonText] = useState('');

  // Launch Variable Form State
  const [variableValues, setVariableValues] = useState<Record<string, string>>({});
  const [isApplying, setIsApplying] = useState(false);

  // Share Code Modal State
  const [shareTemplate, setShareTemplate] = useState<TemplateItem | null>(null);

  // Compute filtered templates based on current subnav and search query
  const filteredTemplates = useMemo(() => {
    let list = templates;

    // SubNav filtering
    if (templatesSubNav === 'featured') {
      list = list.filter((t) => t.isBuiltIn || t.isFavorite || (t.likesCount || 0) > 400);
    } else if (templatesSubNav === 'popular') {
      list = [...list].sort((a, b) => (b.usageCount || 0) - (a.usageCount || 0));
    } else if (templatesSubNav === 'new') {
      list = [...list].sort((a, b) => new Date(b.createdAt || 0).getTime() - new Date(a.createdAt || 0).getTime());
    } else if (templatesSubNav === 'recommended') {
      // Prioritize active goals/projects areas
      const activeGoalAreas = new Set(goals.map((g) => g.area.toLowerCase()));
      list = list.filter((t) => activeGoalAreas.has(t.category) || t.isFavorite || (t.usageCount || 0) > 800);
    } else if (templatesSubNav === 'my-templates') {
      list = list.filter((t) => !t.isBuiltIn || t.creator?.name === (settings.userName || 'You'));
    }

    if (onlyFavorites) {
      list = list.filter((t) => t.isFavorite);
    }

    return searchTemplateCatalog(list, searchQuery, selectedCategory, sortBy);
  }, [
    templates,
    templatesSubNav,
    searchQuery,
    selectedCategory,
    sortBy,
    onlyFavorites,
    goals,
    settings.userName,
  ]);

  const displayedTemplates = useMemo(() => {
    return filteredTemplates.slice(0, pageSize);
  }, [filteredTemplates, pageSize]);

  // Handle launch of template
  const handleStartLaunch = (tpl: TemplateItem) => {
    const initialVars: Record<string, string> = {};
    (tpl.variables || []).forEach((v) => {
      initialVars[v.key] = v.defaultValue || '';
    });
    setVariableValues(initialVars);
    setActiveTemplateForLaunch(tpl);
  };

  const handleConfirmLaunch = async () => {
    if (!activeTemplateForLaunch) return;
    setIsApplying(true);
    try {
      await applyTemplate(activeTemplateForLaunch.id, variableValues);
      setActiveTemplateForLaunch(null);
      setSelectedTemplateForPreview(null);
    } catch (e) {
      showToast('Error launching template', 'error');
    } finally {
      setIsApplying(false);
    }
  };

  // AI Recommendation Handler
  const handleRunAIRecommendation = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!aiPrompt.trim()) return;

    setIsAIGenerating(true);
    const query = aiPrompt.toLowerCase();

    // 1. First search real registry for semantic matches
    const matches = templates.filter((t) => {
      const matchTitle = t.title.toLowerCase().includes(query);
      const matchDesc = t.description.toLowerCase().includes(query);
      const matchTags = t.tags?.some((tg) => tg.toLowerCase().includes(query));
      return matchTitle || matchDesc || matchTags;
    });

    if (matches.length > 0) {
      setAiRecommendationMatches(matches.slice(0, 6));
      showToast(`Found ${matches.length} matching templates in library`, 'success');
      setIsAIGenerating(false);
      return;
    }

    // 2. If no exact match found, invoke server AI template generator to build a custom system
    try {
      const generated = await generateTemplateWithAI(aiPrompt);
      if (generated) {
        setAiRecommendationMatches([generated]);
        showToast(`AI created custom template: "${generated.title}"`, 'success');
      }
    } catch (err) {
      showToast('No exact templates found. Try keywords like "exam", "budget", or "sprint".', 'info');
    } finally {
      setIsAIGenerating(false);
    }
  };

  const handleCreateTemplateSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim()) return;

    if (convertFromProjectId || convertFromGoalId) {
      saveAsTemplate({
        title: newTitle.trim(),
        description: newDesc.trim() || 'Custom workflow template',
        category: newCategory,
        projectId: convertFromProjectId || undefined,
        goalId: convertFromGoalId || undefined,
      });
    } else {
      saveAsTemplate({
        title: newTitle.trim(),
        description: newDesc.trim() || 'Custom workflow blueprint',
        category: newCategory,
      });
    }

    setNewTitle('');
    setNewDesc('');
    setConvertFromProjectId('');
    setConvertFromGoalId('');
    setIsCreateModalOpen(false);
    setTemplatesSubNav('my-templates');
  };

  const handleImportSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!importJsonText.trim()) return;
    const res = importTemplateFromJSON(importJsonText);
    if (res) {
      setImportJsonText('');
      setIsImportModalOpen(false);
      setTemplatesSubNav('my-templates');
      setSelectedTemplateForPreview(res);
    }
  };

  const getCategoryIcon = (iconName: string) => {
    switch (iconName) {
      case 'CheckSquare': return <CheckSquare className="w-4 h-4" />;
      case 'Calendar': return <Calendar className="w-4 h-4" />;
      case 'Clock': return <Clock className="w-4 h-4" />;
      case 'Target': return <Target className="w-4 h-4" />;
      case 'Flame': return <Flame className="w-4 h-4" />;
      case 'DollarSign': return <DollarSign className="w-4 h-4" />;
      case 'FileText': return <FileText className="w-4 h-4" />;
      case 'Brain': return <Brain className="w-4 h-4" />;
      case 'Zap': return <Zap className="w-4 h-4" />;
      case 'BatteryCharging': return <BatteryCharging className="w-4 h-4" />;
      case 'RotateCcw': return <RotateCcw className="w-4 h-4" />;
      case 'FolderGit2': return <FolderGit2 className="w-4 h-4" />;
      case 'GraduationCap': return <GraduationCap className="w-4 h-4" />;
      case 'Compass': return <Compass className="w-4 h-4" />;
      case 'Video': return <Video className="w-4 h-4" />;
      case 'Briefcase': return <Briefcase className="w-4 h-4" />;
      case 'HeartHandshake': return <HeartHandshake className="w-4 h-4" />;
      default: return <Layers className="w-4 h-4" />;
    }
  };

  return (
    <div className="max-w-6xl mx-auto px-3.5 sm:px-6 py-5 sm:py-6 space-y-6 text-[var(--text-primary)]">
      {/* ============================================================ */}
      {/* 1. HEADER & HERO BANNER                                      */}
      {/* ============================================================ */}
      <div className="relative overflow-hidden p-6 sm:p-8 rounded-3xl bg-[var(--bg-surface-elevated)] border border-[var(--border-default)] shadow-xs space-y-4">
        <div className="absolute -right-12 -top-12 w-64 h-64 bg-purple-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute -left-12 -bottom-12 w-64 h-64 bg-indigo-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="relative flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="space-y-1.5 max-w-xl">
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider bg-purple-500/15 text-purple-600 dark:text-purple-400">
              <Sparkles className="w-3.5 h-3.5" />
              <span>Public Workflow Ecosystem • 1,800+ Templates</span>
            </div>
            <h1 className="text-2xl sm:text-3xl md:text-4xl font-black tracking-tight text-[var(--text-primary)]">
              Workflow & System Templates
            </h1>
            <p className="text-xs sm:text-sm text-[var(--text-secondary)] leading-relaxed">
              Discover, remix, and launch battle-tested productivity systems. Every template creates fully connected
              Tasks, Goals, Calendar blocks, Habits, Notes, and Automations.
            </p>
          </div>

          <div className="flex items-center gap-2 flex-wrap">
            <button
              onClick={() => setIsImportModalOpen(true)}
              className="active-press flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-semibold bg-[var(--bg-surface-subtle)] border border-[var(--border-default)] hover:bg-[var(--ui-hover)] text-[var(--text-primary)] transition-all cursor-pointer shadow-xs"
            >
              <Upload className="w-3.5 h-3.5 text-[var(--text-secondary)]" />
              <span>Import JSON</span>
            </button>
            <button
              onClick={() => setIsCreateModalOpen(true)}
              className="active-press flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-semibold bg-[var(--accent)] text-[var(--accent-text)] shadow-md transition-all cursor-pointer hover:opacity-90"
            >
              <Plus className="w-4 h-4 stroke-[2.5]" />
              <span>Create Template</span>
            </button>
          </div>
        </div>

        {/* AI Intent Recommendation Bar */}
        <form onSubmit={handleRunAIRecommendation} className="relative pt-2">
          <div className="flex items-center gap-2 p-1.5 rounded-2xl bg-[var(--bg-surface-input)] border border-[var(--border-default)] focus-within:border-[var(--accent)] shadow-xs">
            <Sparkles className="w-4 h-4 text-purple-500 ml-2.5 shrink-0" />
            <input
              type="text"
              value={aiPrompt}
              onChange={(e) => setAiPrompt(e.target.value)}
              placeholder="Ask AI what you are trying to accomplish (e.g., 'Prep for exams', 'Launch SaaS product', 'Sunday reset')..."
              className="w-full px-2 py-1.5 bg-transparent text-xs sm:text-sm text-[var(--text-primary)] placeholder-[var(--text-tertiary)] focus:outline-hidden"
            />
            <button
              type="submit"
              disabled={!aiPrompt.trim() || isAIGenerating}
              className="active-press px-4 py-2 rounded-xl bg-purple-600 text-white text-xs font-semibold hover:bg-purple-700 disabled:opacity-50 transition-all flex items-center gap-1 shrink-0 cursor-pointer"
            >
              <span>{isAIGenerating ? 'Searching...' : 'Find / Generate'}</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </form>

        {/* AI Match Results Panel */}
        {aiRecommendationMatches && (
          <div className="p-4 rounded-2xl bg-purple-500/10 border border-purple-500/25 space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-purple-700 dark:text-purple-300 flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5" />
                AI Recommended Matches for "{aiPrompt}"
              </span>
              <button
                onClick={() => setAiRecommendationMatches(null)}
                className="text-xs text-[var(--text-tertiary)] hover:text-[var(--text-primary)]"
              >
                Dismiss
              </button>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-2.5">
              {aiRecommendationMatches.map((tpl) => (
                <div
                  key={tpl.id}
                  onClick={() => setSelectedTemplateForPreview(tpl)}
                  className="active-press p-3 rounded-xl bg-[var(--bg-surface-elevated)] border border-[var(--border-default)] hover:border-purple-500/50 transition-all cursor-pointer space-y-1 shadow-xs"
                >
                  <h4 className="text-xs font-bold text-[var(--text-primary)] truncate">{tpl.title}</h4>
                  <p className="text-[11px] text-[var(--text-secondary)] line-clamp-1">{tpl.description}</p>
                  <div className="flex items-center justify-between text-[10px] text-purple-600 dark:text-purple-400 font-semibold pt-1">
                    <span>{tpl.category}</span>
                    <span>Preview →</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* ============================================================ */}
      {/* 2. SUB-NAVIGATION TABS (Featured, Popular, Categories...)    */}
      {/* ============================================================ */}
      <div className="flex items-center gap-1.5 p-1 rounded-2xl bg-[var(--bg-surface-subtle)] border border-[var(--border-default)] overflow-x-auto no-scrollbar">
        {[
          { id: 'featured', label: 'Featured', icon: Award },
          { id: 'popular', label: 'Popular', icon: TrendingUp },
          { id: 'new', label: 'New & Trending', icon: Clock },
          { id: 'recommended', label: 'Recommended', icon: Sparkles },
          { id: 'categories', label: 'All 18 Categories', icon: Filter },
          { id: 'my-templates', label: 'My Templates', icon: UserCircleIcon },
        ].map((tab) => {
          const Icon = tab.icon;
          const isActive = templatesSubNav === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => {
                setTemplatesSubNav(tab.id as TemplatesSubNav);
                if (tab.id !== 'categories') setSelectedCategory('all');
              }}
              className={`active-press relative flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-colors cursor-pointer ${
                isActive
                  ? 'text-[var(--accent)] font-bold'
                  : 'text-[var(--text-secondary)] hover:text-[var(--text-primary)]'
              }`}
            >
              {isActive && (
                <motion.div
                  layoutId="templatesSubNavIndicator"
                  transition={{ type: 'spring', stiffness: 450, damping: 32 }}
                  className="absolute inset-0 bg-[var(--bg-surface-elevated)] rounded-xl border border-[var(--border-default)] shadow-xs"
                />
              )}
              <span className="relative z-10 flex items-center gap-1.5">
                <Icon className="w-3.5 h-3.5" />
                <span>{tab.label}</span>
              </span>
            </button>
          );
        })}
      </div>

      {/* ============================================================ */}
      {/* 3. CATEGORY BROWSER GRID (When 'Categories' tab is selected) */}
      {/* ============================================================ */}
      {templatesSubNav === 'categories' && (
        <div className="space-y-3">
          <div className="flex items-center justify-between px-1">
            <h3 className="text-xs font-bold uppercase tracking-wider text-[var(--text-secondary)]">
              Browse 18 Feature Categories (100 Templates Each)
            </h3>
            {selectedCategory !== 'all' && (
              <button
                onClick={() => setSelectedCategory('all')}
                className="text-xs text-[var(--accent)] font-semibold hover:underline"
              >
                Clear Category Filter
              </button>
            )}
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2.5">
            {CATEGORY_DEFINITIONS.map((cat) => {
              const count = templates.filter((t) => t.category === cat.id).length;
              const isSelected = selectedCategory === cat.id;
              return (
                <button
                  key={cat.id}
                  onClick={() => setSelectedCategory(isSelected ? 'all' : cat.id)}
                  className={`active-press p-3 rounded-2xl border text-left transition-all cursor-pointer space-y-1.5 ${
                    isSelected
                      ? 'bg-purple-500/10 border-purple-500/40 shadow-xs'
                      : 'bg-[var(--bg-surface-elevated)] border-[var(--border-default)] hover:border-[var(--border-focus)]'
                  }`}
                >
                  <div
                    className="w-8 h-8 rounded-xl flex items-center justify-center text-white"
                    style={{ backgroundColor: cat.color }}
                  >
                    {getCategoryIcon(cat.iconName)}
                  </div>
                  <div>
                    <h4 className="text-xs font-bold text-[var(--text-primary)] truncate">{cat.label}</h4>
                    <span className="text-[10px] font-mono font-semibold text-[var(--text-tertiary)]">
                      {count} templates
                    </span>
                  </div>
                </button>
              );
            })}
          </div>
        </div>
      )}

      {/* ============================================================ */}
      {/* 4. SEARCH & FILTER CONTROLS                                  */}
      {/* ============================================================ */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
        <div className="flex items-center gap-2 flex-1">
          <div className="relative flex-1 max-w-md">
            <Search className="w-3.5 h-3.5 absolute left-3 top-2.5 text-[var(--text-tertiary)]" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search 1,800+ templates by keyword, role, goal, or tags..."
              className="w-full pl-8 pr-3 py-1.5 rounded-xl bg-[var(--bg-surface-input)] border border-[var(--border-default)] text-xs text-[var(--text-primary)] focus:outline-hidden focus:border-[var(--accent)]"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-2.5 top-2 text-[var(--text-tertiary)] hover:text-[var(--text-primary)]"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>

          {/* Category Quick Filter */}
          <div className="hidden md:flex items-center gap-1 bg-[var(--bg-surface-elevated)] border border-[var(--border-default)] rounded-xl px-2.5 py-1 text-xs">
            <Filter className="w-3 h-3 text-[var(--text-tertiary)]" />
            <select
              value={selectedCategory}
              onChange={(e) => setSelectedCategory(e.target.value)}
              className="bg-transparent text-[var(--text-secondary)] focus:outline-hidden cursor-pointer max-w-[130px] truncate"
            >
              <option value="all">All Categories</option>
              {CATEGORY_DEFINITIONS.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.label}
                </option>
              ))}
            </select>
          </div>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          <button
            onClick={() => setOnlyFavorites(!onlyFavorites)}
            className={`active-press px-2.5 py-1 rounded-xl border text-xs font-semibold flex items-center gap-1 transition-colors cursor-pointer ${
              onlyFavorites
                ? 'bg-amber-500/10 border-amber-500/30 text-amber-600 dark:text-amber-400'
                : 'bg-[var(--bg-surface-elevated)] border-[var(--border-default)] text-[var(--text-secondary)] hover:text-[var(--text-primary)]'
            }`}
          >
            <Star className={`w-3.5 h-3.5 ${onlyFavorites ? 'fill-current' : ''}`} />
            <span>Favorites</span>
          </button>

          {/* Sort Dropdown */}
          <div className="flex items-center gap-1 bg-[var(--bg-surface-elevated)] border border-[var(--border-default)] rounded-xl px-2.5 py-1 text-xs">
            <SlidersHorizontal className="w-3 h-3 text-[var(--text-tertiary)]" />
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value as any)}
              className="bg-transparent text-[var(--text-secondary)] focus:outline-hidden cursor-pointer"
            >
              <option value="popular">Most Popular</option>
              <option value="new">Newest</option>
              <option value="rating">Top Rated</option>
              <option value="title">Alphabetical</option>
            </select>
          </div>

          <span className="text-[11px] font-mono text-[var(--text-tertiary)] pl-1">
            {filteredTemplates.length} matches
          </span>
        </div>
      </div>

      {/* ============================================================ */}
      {/* 5. TEMPLATES CARDS GRID                                      */}
      {/* ============================================================ */}
      {filteredTemplates.length === 0 ? (
        <div className="p-12 text-center rounded-3xl border border-dashed border-[var(--border-default)] bg-[var(--bg-surface-elevated)] space-y-3">
          <Layers className="w-8 h-8 mx-auto text-[var(--text-tertiary)] opacity-40" />
          <h3 className="text-sm font-bold text-[var(--text-primary)]">No templates matched your query</h3>
          <p className="text-xs text-[var(--text-secondary)] max-w-sm mx-auto">
            Try searching broader keywords like "study", "sprint", "meeting", or generate a customized workflow with AI.
          </p>
          <button
            onClick={() => {
              setSearchQuery('');
              setSelectedCategory('all');
              setOnlyFavorites(false);
            }}
            className="active-press px-4 py-1.5 rounded-xl bg-[var(--accent)] text-[var(--accent-text)] text-xs font-semibold"
          >
            Reset Filters
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {displayedTemplates.map((tpl) => {
            const taskCount = tpl.blueprint.tasks?.length || 0;
            const habitCount = tpl.blueprint.habits?.length || 0;
            const eventCount = tpl.blueprint.calendarEvents?.length || 0;
            const isFav = tpl.isFavorite;

            return (
              <div
                key={tpl.id}
                className="group relative p-4 rounded-2xl bg-[var(--bg-surface-elevated)] border border-[var(--border-default)] hover:border-[var(--border-focus)] transition-all flex flex-col justify-between space-y-3 shadow-xs hover:shadow-md"
              >
                <div className="space-y-2.5">
                  {/* Card Header: Icon, Category & Actions */}
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex items-center gap-2 min-w-0">
                      <div
                        className="w-8 h-8 rounded-xl flex items-center justify-center text-white shrink-0 shadow-xs"
                        style={{ backgroundColor: tpl.color || '#8b5cf6' }}
                      >
                        {getCategoryIcon(tpl.icon)}
                      </div>
                      <div className="min-w-0">
                        <span className="text-[10px] uppercase font-bold tracking-wider text-[var(--text-tertiary)] block truncate">
                          {tpl.category}
                        </span>
                        <div className="flex items-center gap-1">
                          <span className="text-[11px] text-[var(--text-secondary)] truncate">
                            {tpl.creator?.name || 'Community'}
                          </span>
                          {tpl.creator?.verified && (
                            <ShieldCheck className="w-3 h-3 text-purple-600 dark:text-purple-400 shrink-0" />
                          )}
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center gap-1 shrink-0">
                      <button
                        onClick={() => toggleTemplateFavorite(tpl.id)}
                        className={`active-press p-1.5 rounded-lg hover:bg-[var(--ui-hover)] transition-colors cursor-pointer ${
                          isFav ? 'text-amber-500' : 'text-[var(--text-tertiary)] hover:text-amber-500'
                        }`}
                        title="Favorite"
                      >
                        <Star className={`w-3.5 h-3.5 ${isFav ? 'fill-current' : ''}`} />
                      </button>
                      <button
                        onClick={() => setShareTemplate(tpl)}
                        className="active-press p-1.5 text-[var(--text-tertiary)] hover:text-[var(--text-primary)] rounded-lg hover:bg-[var(--ui-hover)] transition-colors cursor-pointer"
                        title="Share / Export"
                      >
                        <Share2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>

                  {/* Title & Description */}
                  <div>
                    <h3 className="text-sm font-bold text-[var(--text-primary)] group-hover:text-[var(--accent)] transition-colors line-clamp-1">
                      {tpl.title}
                    </h3>
                    <p className="text-xs text-[var(--text-secondary)] line-clamp-2 mt-1 leading-relaxed">
                      {tpl.description}
                    </p>
                  </div>

                  {/* Connected Life Objects Tags */}
                  <div className="flex items-center gap-1.5 flex-wrap pt-1">
                    {tpl.blueprint.goal && (
                      <span className="px-2 py-0.5 rounded-md text-[10px] font-semibold bg-pink-500/10 text-pink-600 dark:text-pink-400 border border-pink-500/20 flex items-center gap-1">
                        <Target className="w-2.5 h-2.5" /> Goal
                      </span>
                    )}
                    {taskCount > 0 && (
                      <span className="px-2 py-0.5 rounded-md text-[10px] font-semibold bg-blue-500/10 text-blue-600 dark:text-blue-400 border border-blue-500/20 flex items-center gap-1">
                        <CheckCircle2 className="w-2.5 h-2.5" /> {taskCount} Tasks
                      </span>
                    )}
                    {habitCount > 0 && (
                      <span className="px-2 py-0.5 rounded-md text-[10px] font-semibold bg-amber-500/10 text-amber-600 dark:text-amber-400 border border-amber-500/20 flex items-center gap-1">
                        <Flame className="w-2.5 h-2.5" /> Habit
                      </span>
                    )}
                    {eventCount > 0 && (
                      <span className="px-2 py-0.5 rounded-md text-[10px] font-semibold bg-indigo-500/10 text-indigo-600 dark:text-indigo-400 border border-indigo-500/20 flex items-center gap-1">
                        <Clock className="w-2.5 h-2.5" /> Timeblock
                      </span>
                    )}
                  </div>
                </div>

                {/* Card Footer: Metrics & Action Buttons */}
                <div className="pt-3 border-t border-[var(--border-subtle)] flex items-center justify-between gap-2">
                  <div className="flex items-center gap-2 text-[11px] text-[var(--text-tertiary)] font-mono">
                    <span title="Community Usage Count">{tpl.usageCount?.toLocaleString() || 120} uses</span>
                    <span>•</span>
                    <span className="text-emerald-600 dark:text-emerald-400 font-semibold">v{tpl.version || '1.0'}</span>
                  </div>

                  <div className="flex items-center gap-1.5">
                    <button
                      onClick={() => setSelectedTemplateForPreview(tpl)}
                      className="active-press px-2.5 py-1 rounded-xl text-xs font-semibold bg-[var(--bg-surface-subtle)] hover:bg-[var(--ui-hover)] border border-[var(--border-default)] text-[var(--text-primary)] transition-all flex items-center gap-1 cursor-pointer"
                    >
                      <Eye className="w-3 h-3 text-[var(--text-secondary)]" />
                      <span>Preview</span>
                    </button>
                    <button
                      onClick={() => handleStartLaunch(tpl)}
                      className="active-press px-3 py-1 rounded-xl text-xs font-semibold bg-[var(--accent)] text-[var(--accent-text)] hover:opacity-90 shadow-xs transition-all flex items-center gap-1 cursor-pointer"
                    >
                      <Play className="w-3 h-3 fill-current" />
                      <span>Use</span>
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Pagination / Load More */}
      {filteredTemplates.length > pageSize && (
        <div className="text-center pt-4">
          <button
            onClick={() => setPageSize((prev) => prev + 24)}
            className="active-press px-6 py-2.5 rounded-2xl bg-[var(--bg-surface-elevated)] border border-[var(--border-default)] text-xs font-bold text-[var(--text-primary)] hover:border-[var(--accent)] shadow-xs transition-all cursor-pointer"
          >
            Load 24 More Templates ({filteredTemplates.length - pageSize} remaining)
          </button>
        </div>
      )}

      {/* ============================================================ */}
      {/* 6. TEMPLATE PREVIEW MODAL                                    */}
      {/* ============================================================ */}
      {selectedTemplateForPreview && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-md flex items-center justify-center p-3 sm:p-5 overflow-y-auto">
          <div className="w-full max-w-2xl rounded-3xl bg-[var(--bg-surface-elevated)] border border-[var(--border-default)] shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
            {/* Modal Header */}
            <div className="p-5 border-b border-[var(--border-default)] flex items-start justify-between gap-3 bg-[var(--bg-surface)]">
              <div className="flex items-center gap-3">
                <div
                  className="w-10 h-10 rounded-2xl flex items-center justify-center text-white shrink-0 shadow-sm"
                  style={{ backgroundColor: selectedTemplateForPreview.color || '#8b5cf6' }}
                >
                  {getCategoryIcon(selectedTemplateForPreview.icon)}
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <h2 className="text-base sm:text-lg font-bold text-[var(--text-primary)]">
                      {selectedTemplateForPreview.title}
                    </h2>
                    <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-purple-500/10 text-purple-600 dark:text-purple-400 font-bold uppercase">
                      {selectedTemplateForPreview.category}
                    </span>
                  </div>
                  <p className="text-xs text-[var(--text-secondary)]">
                    Created by {selectedTemplateForPreview.creator?.name || 'Community'} • {selectedTemplateForPreview.usageCount || 100} people used this
                  </p>
                </div>
              </div>
              <button
                onClick={() => setSelectedTemplateForPreview(null)}
                className="p-1.5 rounded-xl text-[var(--text-tertiary)] hover:text-[var(--text-primary)] hover:bg-[var(--ui-hover)]"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Modal Scrollable Body */}
            <div className="p-5 space-y-5 overflow-y-auto flex-1 text-xs">
              <div>
                <h4 className="font-semibold text-[var(--text-tertiary)] uppercase tracking-wider text-[10px] mb-1">
                  Description & Methodology
                </h4>
                <p className="text-xs sm:text-sm text-[var(--text-primary)] leading-relaxed">
                  {selectedTemplateForPreview.description}
                </p>
              </div>

              {/* Connected Life Objects Inspector */}
              <div className="space-y-3">
                <h4 className="font-semibold text-[var(--text-tertiary)] uppercase tracking-wider text-[10px]">
                  Connected Life OS Objects Generated
                </h4>

                <div className="space-y-2">
                  {/* Goal */}
                  {selectedTemplateForPreview.blueprint.goal && (
                    <div className="p-3 rounded-xl bg-pink-500/10 border border-pink-500/20 space-y-1">
                      <div className="flex items-center gap-1.5 text-pink-600 dark:text-pink-400 font-bold text-xs">
                        <Target className="w-3.5 h-3.5" />
                        <span>Goal: {selectedTemplateForPreview.blueprint.goal.title}</span>
                      </div>
                      <p className="text-[11px] text-[var(--text-secondary)]">
                        {selectedTemplateForPreview.blueprint.goal.vision}
                      </p>
                    </div>
                  )}

                  {/* Tasks */}
                  {(selectedTemplateForPreview.blueprint.tasks || []).length > 0 && (
                    <div className="p-3 rounded-xl bg-[var(--bg-surface-subtle)] border border-[var(--border-default)] space-y-2">
                      <div className="flex items-center justify-between text-xs font-bold text-[var(--text-primary)]">
                        <span className="flex items-center gap-1.5">
                          <CheckCircle2 className="w-3.5 h-3.5 text-blue-500" />
                          <span>Actionable Tasks ({selectedTemplateForPreview.blueprint.tasks?.length})</span>
                        </span>
                      </div>
                      <ul className="space-y-1.5 pl-2">
                        {selectedTemplateForPreview.blueprint.tasks?.map((t, idx) => (
                          <li key={idx} className="flex items-center justify-between text-[11px] text-[var(--text-secondary)]">
                            <span className="truncate">• {t.title}</span>
                            <span className="text-[10px] font-mono text-[var(--text-tertiary)] shrink-0">{t.durationMinutes}m</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}

                  {/* Habit */}
                  {(selectedTemplateForPreview.blueprint.habits || []).length > 0 && (
                    <div className="p-3 rounded-xl bg-amber-500/10 border border-amber-500/20 space-y-1">
                      <div className="flex items-center gap-1.5 text-amber-600 dark:text-amber-400 font-bold text-xs">
                        <Flame className="w-3.5 h-3.5" />
                        <span>Daily Habits ({selectedTemplateForPreview.blueprint.habits?.length})</span>
                      </div>
                      {selectedTemplateForPreview.blueprint.habits?.map((h, idx) => (
                        <p key={idx} className="text-[11px] text-[var(--text-secondary)]">
                          • {h.title} ({h.targetDaysPerWeek || 7} days/week)
                        </p>
                      ))}
                    </div>
                  )}

                  {/* Calendar Block */}
                  {(selectedTemplateForPreview.blueprint.calendarEvents || []).length > 0 && (
                    <div className="p-3 rounded-xl bg-indigo-500/10 border border-indigo-500/20 space-y-1">
                      <div className="flex items-center gap-1.5 text-indigo-600 dark:text-indigo-400 font-bold text-xs">
                        <Clock className="w-3.5 h-3.5" />
                        <span>Calendar Focus Blocks</span>
                      </div>
                      {selectedTemplateForPreview.blueprint.calendarEvents?.map((ev, idx) => (
                        <p key={idx} className="text-[11px] text-[var(--text-secondary)]">
                          • {ev.title} ({ev.startTime} - {ev.endTime})
                        </p>
                      ))}
                    </div>
                  )}

                  {/* Automations */}
                  {(selectedTemplateForPreview.blueprint.automations || []).length > 0 && (
                    <div className="p-3 rounded-xl bg-purple-500/10 border border-purple-500/20 space-y-1">
                      <div className="flex items-center gap-1.5 text-purple-600 dark:text-purple-400 font-bold text-xs">
                        <Zap className="w-3.5 h-3.5" />
                        <span>When → If → Then Automations</span>
                      </div>
                      {selectedTemplateForPreview.blueprint.automations?.map((a, idx) => (
                        <p key={idx} className="text-[11px] text-[var(--text-secondary)]">
                          • {a.title}: {a.trigger} → {a.action}
                        </p>
                      ))}
                    </div>
                  )}
                </div>
              </div>

              {/* Template Controls & Actions */}
              <div className="pt-2 border-t border-[var(--border-subtle)] flex items-center justify-between gap-2 flex-wrap">
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => duplicateTemplate(selectedTemplateForPreview.id)}
                    className="active-press px-3 py-1.5 rounded-xl border border-[var(--border-default)] hover:bg-[var(--ui-hover)] text-xs font-semibold flex items-center gap-1"
                  >
                    <Copy className="w-3 h-3 text-[var(--text-secondary)]" />
                    <span>Remix / Duplicate</span>
                  </button>
                  <button
                    onClick={() => setShareTemplate(selectedTemplateForPreview)}
                    className="active-press px-3 py-1.5 rounded-xl border border-[var(--border-default)] hover:bg-[var(--ui-hover)] text-xs font-semibold flex items-center gap-1"
                  >
                    <Share2 className="w-3 h-3 text-[var(--text-secondary)]" />
                    <span>Share</span>
                  </button>
                  <button
                    onClick={() => reportTemplate(selectedTemplateForPreview.id)}
                    className="active-press p-1.5 text-[var(--text-tertiary)] hover:text-rose-500 rounded-lg"
                    title="Report Broken/Inappropriate"
                  >
                    <AlertTriangle className="w-3.5 h-3.5" />
                  </button>
                </div>

                <button
                  onClick={() => {
                    handleStartLaunch(selectedTemplateForPreview);
                  }}
                  className="active-press px-4 py-2 rounded-xl bg-[var(--accent)] text-[var(--accent-text)] font-semibold text-xs flex items-center gap-1.5 shadow-md"
                >
                  <Play className="w-3.5 h-3.5 fill-current" />
                  <span>Configure & Launch Template</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ============================================================ */}
      {/* 7. LAUNCH / VARIABLE SUBSTITUTION MODAL                     */}
      {/* ============================================================ */}
      {activeTemplateForLaunch && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-md flex items-center justify-center p-3 sm:p-5">
          <div className="w-full max-w-lg rounded-3xl bg-[var(--bg-surface-elevated)] border border-[var(--border-default)] shadow-2xl p-5 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-[var(--border-default)]">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-xl bg-purple-500 text-white flex items-center justify-center">
                  <Play className="w-4 h-4 fill-current" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-[var(--text-primary)]">
                    Launch "{activeTemplateForLaunch.title}"
                  </h3>
                  <p className="text-[11px] text-[var(--text-secondary)]">
                    Customize your parameters. Life OS will generate all connected objects.
                  </p>
                </div>
              </div>
              <button
                onClick={() => setActiveTemplateForLaunch(null)}
                className="text-[var(--text-tertiary)] hover:text-[var(--text-primary)]"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-3 max-h-[350px] overflow-y-auto pr-1">
              {(activeTemplateForLaunch.variables || []).map((v) => (
                <div key={v.key} className="space-y-1">
                  <label className="block text-xs font-semibold text-[var(--text-secondary)]">
                    {v.label}
                  </label>
                  <input
                    type={v.type === 'number' ? 'number' : v.type === 'date' ? 'date' : 'text'}
                    value={variableValues[v.key] ?? v.defaultValue}
                    onChange={(e) =>
                      setVariableValues((prev) => ({ ...prev, [v.key]: e.target.value }))
                    }
                    placeholder={v.placeholder}
                    className="w-full px-3 py-2 rounded-xl bg-[var(--bg-surface-input)] border border-[var(--border-default)] text-xs text-[var(--text-primary)] focus:outline-hidden focus:border-[var(--accent)]"
                  />
                </div>
              ))}
            </div>

            <div className="pt-3 border-t border-[var(--border-subtle)] flex items-center justify-end gap-2">
              <button
                type="button"
                onClick={() => setActiveTemplateForLaunch(null)}
                className="active-press px-3.5 py-1.5 rounded-xl text-xs font-semibold text-[var(--text-secondary)] hover:bg-[var(--ui-hover)]"
              >
                Cancel
              </button>
              <button
                type="button"
                disabled={isApplying}
                onClick={handleConfirmLaunch}
                className="active-press px-4 py-2 rounded-xl text-xs font-semibold bg-[var(--accent)] text-[var(--accent-text)] shadow-md flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
              >
                <Play className="w-3.5 h-3.5 fill-current" />
                <span>{isApplying ? 'Creating Objects...' : 'Generate & Connect Now'}</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ============================================================ */}
      {/* 8. CREATE TEMPLATE MODAL                                     */}
      {/* ============================================================ */}
      {isCreateModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-md flex items-center justify-center p-3 sm:p-5">
          <form
            onSubmit={handleCreateTemplateSubmit}
            className="w-full max-w-lg rounded-3xl bg-[var(--bg-surface-elevated)] border border-[var(--border-default)] shadow-2xl p-5 space-y-4"
          >
            <div className="flex items-center justify-between pb-3 border-b border-[var(--border-default)]">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-xl bg-[var(--accent)] text-[var(--accent-text)] flex items-center justify-center">
                  <Plus className="w-4 h-4 stroke-[2.5]" />
                </div>
                <h3 className="text-sm font-bold text-[var(--text-primary)]">
                  Create Reusable Template
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setIsCreateModalOpen(false)}
                className="text-[var(--text-tertiary)] hover:text-[var(--text-primary)]"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-3">
              <div>
                <label className="block text-xs font-semibold text-[var(--text-secondary)] mb-1">
                  Template Title
                </label>
                <input
                  type="text"
                  required
                  value={newTitle}
                  onChange={(e) => setNewTitle(e.target.value)}
                  placeholder="e.g., Weekly Content Machine, Triathlon Base Block..."
                  className="w-full px-3 py-2 rounded-xl bg-[var(--bg-surface-input)] border border-[var(--border-default)] text-xs text-[var(--text-primary)] focus:outline-hidden focus:border-[var(--accent)] font-medium"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-[var(--text-secondary)] mb-1">
                  Description & Method
                </label>
                <textarea
                  value={newDesc}
                  onChange={(e) => setNewDesc(e.target.value)}
                  placeholder="Explain how this system works and how other users should apply it..."
                  rows={3}
                  className="w-full px-3 py-2 rounded-xl bg-[var(--bg-surface-input)] border border-[var(--border-default)] text-xs text-[var(--text-primary)] focus:outline-hidden focus:border-[var(--accent)]"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-[var(--text-secondary)] mb-1">
                    Category
                  </label>
                  <select
                    value={newCategory}
                    onChange={(e) => setNewCategory(e.target.value as TemplateCategory)}
                    className="w-full px-3 py-2 rounded-xl bg-[var(--bg-surface-input)] border border-[var(--border-default)] text-xs text-[var(--text-primary)] focus:outline-hidden cursor-pointer"
                  >
                    {CATEGORY_DEFINITIONS.map((c) => (
                      <option key={c.id} value={c.id}>
                        {c.label}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-[var(--text-secondary)] mb-1">
                    Visibility
                  </label>
                  <select
                    value={newStatus}
                    onChange={(e) => setNewStatus(e.target.value as any)}
                    className="w-full px-3 py-2 rounded-xl bg-[var(--bg-surface-input)] border border-[var(--border-default)] text-xs text-[var(--text-primary)] focus:outline-hidden cursor-pointer"
                  >
                    <option value="published">Public (Community Ecosystem)</option>
                    <option value="private">Private (Only You)</option>
                    <option value="draft">Draft</option>
                  </select>
                </div>
              </div>

              {/* Optional: Convert existing Life OS setup */}
              <div className="p-3 rounded-xl bg-[var(--bg-surface-subtle)] border border-[var(--border-subtle)] space-y-2">
                <span className="text-[11px] font-semibold text-[var(--text-tertiary)] uppercase tracking-wider block">
                  Optional: Convert Existing Life OS Setup
                </span>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  <select
                    value={convertFromProjectId}
                    onChange={(e) => setConvertFromProjectId(e.target.value)}
                    className="w-full px-2.5 py-1.5 rounded-lg bg-[var(--bg-surface-elevated)] border border-[var(--border-default)] text-xs text-[var(--text-primary)] focus:outline-hidden"
                  >
                    <option value="">Include Project: None</option>
                    {projects.map((p) => (
                      <option key={p.id} value={p.id}>
                        {p.title}
                      </option>
                    ))}
                  </select>

                  <select
                    value={convertFromGoalId}
                    onChange={(e) => setConvertFromGoalId(e.target.value)}
                    className="w-full px-2.5 py-1.5 rounded-lg bg-[var(--bg-surface-elevated)] border border-[var(--border-default)] text-xs text-[var(--text-primary)] focus:outline-hidden"
                  >
                    <option value="">Include Goal: None</option>
                    {goals.map((g) => (
                      <option key={g.id} value={g.id}>
                        {g.title}
                      </option>
                    ))}
                  </select>
                </div>
              </div>
            </div>

            <div className="pt-3 border-t border-[var(--border-subtle)] flex items-center justify-end gap-2">
              <button
                type="button"
                onClick={() => setIsCreateModalOpen(false)}
                className="active-press px-3.5 py-1.5 rounded-xl text-xs font-semibold text-[var(--text-secondary)] hover:bg-[var(--ui-hover)]"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="active-press px-4 py-2 rounded-xl text-xs font-semibold bg-[var(--accent)] text-[var(--accent-text)] shadow-md"
              >
                Save Template
              </button>
            </div>
          </form>
        </div>
      )}

      {/* ============================================================ */}
      {/* 9. IMPORT TEMPLATE MODAL                                     */}
      {/* ============================================================ */}
      {isImportModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-md flex items-center justify-center p-3 sm:p-5">
          <form
            onSubmit={handleImportSubmit}
            className="w-full max-w-lg rounded-3xl bg-[var(--bg-surface-elevated)] border border-[var(--border-default)] shadow-2xl p-5 space-y-4"
          >
            <div className="flex items-center justify-between pb-3 border-b border-[var(--border-default)]">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-xl bg-purple-500 text-white flex items-center justify-center">
                  <Upload className="w-4 h-4" />
                </div>
                <h3 className="text-sm font-bold text-[var(--text-primary)]">
                  Safe Template Import
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setIsImportModalOpen(false)}
                className="text-[var(--text-tertiary)] hover:text-[var(--text-primary)]"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-2">
              <p className="text-xs text-[var(--text-secondary)] leading-relaxed">
                Paste raw template JSON code below. Templates only create template blueprints and never access your private data.
              </p>
              <textarea
                value={importJsonText}
                onChange={(e) => setImportJsonText(e.target.value)}
                placeholder='{ "title": "My Template", "category": "planning", "blueprint": { ... } }'
                rows={8}
                required
                className="w-full p-3 rounded-xl bg-[var(--bg-surface-input)] border border-[var(--border-default)] text-xs text-[var(--text-primary)] font-mono focus:outline-hidden focus:border-[var(--accent)] resize-none"
              />
            </div>

            <div className="pt-3 border-t border-[var(--border-subtle)] flex items-center justify-end gap-2">
              <button
                type="button"
                onClick={() => setIsImportModalOpen(false)}
                className="active-press px-3.5 py-1.5 rounded-xl text-xs font-semibold text-[var(--text-secondary)] hover:bg-[var(--ui-hover)]"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="active-press px-4 py-2 rounded-xl text-xs font-semibold bg-[var(--accent)] text-[var(--accent-text)] shadow-md"
              >
                Import to My Templates
              </button>
            </div>
          </form>
        </div>
      )}

      {/* ============================================================ */}
      {/* 10. SHARE TEMPLATE MODAL                                     */}
      {/* ============================================================ */}
      {shareTemplate && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-md flex items-center justify-center p-3 sm:p-5">
          <div className="w-full max-w-md rounded-3xl bg-[var(--bg-surface-elevated)] border border-[var(--border-default)] shadow-2xl p-5 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-[var(--border-default)]">
              <div className="flex items-center gap-2">
                <Share2 className="w-4 h-4 text-purple-500" />
                <h3 className="text-sm font-bold text-[var(--text-primary)]">
                  Share Template
                </h3>
              </div>
              <button
                onClick={() => setShareTemplate(null)}
                className="text-[var(--text-tertiary)] hover:text-[var(--text-primary)]"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-3">
              <div className="p-3 rounded-xl bg-[var(--bg-surface-subtle)] border border-[var(--border-subtle)] space-y-1">
                <h4 className="text-xs font-bold text-[var(--text-primary)]">{shareTemplate.title}</h4>
                <p className="text-[11px] text-[var(--text-secondary)] line-clamp-2">{shareTemplate.description}</p>
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-[var(--text-secondary)] mb-1">
                  Shareable Link
                </label>
                <div className="flex items-center gap-2">
                  <input
                    type="text"
                    readOnly
                    value={`${window.location.origin}?template=${shareTemplate.id}`}
                    className="w-full px-3 py-1.5 rounded-xl bg-[var(--bg-surface-input)] border border-[var(--border-default)] text-xs text-[var(--text-primary)] font-mono"
                  />
                  <button
                    onClick={() => {
                      navigator.clipboard.writeText(`${window.location.origin}?template=${shareTemplate.id}`);
                      showToast('Share link copied to clipboard!', 'success');
                    }}
                    className="active-press px-3 py-1.5 rounded-xl bg-[var(--accent)] text-[var(--accent-text)] text-xs font-semibold shrink-0"
                  >
                    Copy
                  </button>
                </div>
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-[var(--text-secondary)] mb-1">
                  Export Full JSON Blueprint
                </label>
                <button
                  onClick={() => {
                    const json = exportTemplateToJSON(shareTemplate.id);
                    navigator.clipboard.writeText(json);
                    showToast('Template JSON blueprint copied to clipboard!', 'success');
                  }}
                  className="active-press w-full py-2 rounded-xl border border-[var(--border-default)] bg-[var(--bg-surface-subtle)] hover:bg-[var(--ui-hover)] text-xs font-semibold flex items-center justify-center gap-1.5"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Copy JSON to Clipboard</span>
                </button>
              </div>
            </div>

            <div className="pt-2 border-t border-[var(--border-subtle)] text-right">
              <button
                onClick={() => setShareTemplate(null)}
                className="active-press px-4 py-1.5 rounded-xl text-xs font-semibold bg-[var(--bg-surface-subtle)]"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

// Simple User icon helper
const UserCircleIcon: React.FC<{ className?: string }> = ({ className }) => (
  <svg className={className || "w-3.5 h-3.5"} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2" />
    <circle cx="12" cy="7" r="4" />
  </svg>
);
