import React, { useState } from 'react';
import {
  Calendar as CalendarIcon,
  Clock,
  Target,
  Sparkles,
  Plus,
  AlertCircle,
  CheckCircle2,
  Circle,
  Trash2,
  ArrowRight,
  ShieldAlert,
  ChevronLeft,
  ChevronRight,
  X,
  HelpCircle,
} from 'lucide-react';
import { useLifeOS } from '../../context/LifeOSContext';
import { CalendarEvent, Goal, Milestone, Task } from '../../types';

export const PlanView: React.FC = () => {
  const {
    planSubNav,
    setPlanSubNav,
    calendarEvents,
    tasks,
    projects,
    goals,
    addCalendarEvent,
    deleteCalendarEvent,
    addGoal,
    updateGoal,
    deleteGoal,
    toggleMilestone,
    showToast,
    getAIHeaders,
    openHelpWithContext,
  } = useLifeOS();

  const todayStr = new Date().toISOString().split('T')[0];
  const [selectedDate, setSelectedDate] = useState(todayStr);

  // AI Scheduling state
  const [isScheduling, setIsScheduling] = useState(false);
  const [proposedSchedule, setProposedSchedule] = useState<any[] | null>(null);
  const [scheduleExplanation, setScheduleExplanation] = useState<string>('');

  // New Event Form Modal
  const [isAddingEvent, setIsAddingEvent] = useState(false);
  const [newEvTitle, setNewEvTitle] = useState('');
  const [newEvStart, setNewEvStart] = useState('10:00');
  const [newEvEnd, setNewEvEnd] = useState('11:00');
  const [newEvType, setNewEvType] = useState<'event' | 'timeblock' | 'focus' | 'buffer'>('timeblock');
  const [newEvTaskId, setNewEvTaskId] = useState('');
  const [newEvFixed, setNewEvFixed] = useState(false);

  // New Goal Form Modal
  const [isAddingGoal, setIsAddingGoal] = useState(false);
  const [newGoalTitle, setNewGoalTitle] = useState('');
  const [newGoalVision, setNewGoalVision] = useState('');
  const [newGoalArea, setNewGoalArea] = useState<Goal['area']>('Career');
  const [newGoalTargetDate, setNewGoalTargetDate] = useState('2026-12-31');
  const [newMilestoneText, setNewMilestoneText] = useState('');

  // Detect conflicts on selected date
  const eventsOnDate = calendarEvents
    .filter((e) => e.date === selectedDate)
    .sort((a, b) => a.startTime.localeCompare(b.startTime));

  const conflicts: { eventA: CalendarEvent; eventB: CalendarEvent }[] = [];
  for (let i = 0; i < eventsOnDate.length - 1; i++) {
    const a = eventsOnDate[i];
    const b = eventsOnDate[i + 1];
    if (a.endTime > b.startTime) {
      conflicts.push({ eventA: a, eventB: b });
    }
  }

  // Handle AI Auto-Schedule request
  const handleAISmartSchedule = async () => {
    setIsScheduling(true);
    try {
      const unscheduledTasks = tasks.filter((t) => t.status === 'today' || t.status === 'inbox');
      const res = await fetch('/api/ai/schedule', {
        method: 'POST',
        headers: getAIHeaders(),
        body: JSON.stringify({
          tasks: unscheduledTasks,
          existingEvents: eventsOnDate,
          userEnergy: 'peak_morning',
        }),
      });

      if (res.ok) {
        const data = await res.json();
        setProposedSchedule(data.result.proposedSchedule || []);
        setScheduleExplanation(data.result.explanation || '');
      } else {
        throw new Error('Failed to fetch schedule');
      }
    } catch (err) {
      showToast('Using local schedule optimizer', 'info');
      const proposed = tasks
        .filter((t) => t.status === 'today')
        .slice(0, 2)
        .map((t, idx) => ({
          taskId: t.id,
          title: t.title,
          startHour: 10 + idx * 2,
          startMinute: 0,
          durationMinutes: 45,
          reasoning: 'Protected focus slot aligned with morning energy',
        }));
      setProposedSchedule(proposed);
      setScheduleExplanation('Optimized for energy balance with 45m protected recovery buffer.');
    } finally {
      setIsScheduling(false);
    }
  };

  // Confirm and apply AI Schedule
  const applyProposedSchedule = () => {
    if (!proposedSchedule) return;
    proposedSchedule.forEach((item) => {
      const startH = String(item.startHour).padStart(2, '0');
      const startM = String(item.startMinute).padStart(2, '0');
      const endTotalM = item.startHour * 60 + item.startMinute + (item.durationMinutes || 45);
      const endH = String(Math.floor(endTotalM / 60)).padStart(2, '0');
      const endM = String(endTotalM % 60).padStart(2, '0');

      addCalendarEvent({
        title: item.title,
        date: selectedDate,
        startTime: `${startH}:${startM}`,
        endTime: `${endH}:${endM}`,
        type: 'timeblock',
        taskId: item.taskId,
        isFixedCommitment: false,
        notes: item.reasoning,
        energyRequired: 'high',
      });
    });

    setProposedSchedule(null);
    showToast('AI schedule applied to your calendar', 'success');
  };

  const handleCreateEvent = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newEvTitle.trim()) return;

    addCalendarEvent({
      title: newEvTitle.trim(),
      date: selectedDate,
      startTime: newEvStart,
      endTime: newEvEnd,
      type: newEvType,
      taskId: newEvTaskId || undefined,
      isFixedCommitment: newEvFixed,
    });

    setNewEvTitle('');
    setIsAddingEvent(false);
    showToast('Time block scheduled', 'success');
  };

  const handleCreateGoal = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newGoalTitle.trim()) return;

    addGoal({
      title: newGoalTitle.trim(),
      vision: newGoalVision.trim(),
      area: newGoalArea,
      targetDate: newGoalTargetDate,
      milestones: newMilestoneText
        ? newMilestoneText
            .split('\n')
            .filter((m) => m.trim())
            .map((m) => ({
              id: 'm-' + Math.random().toString(36).substring(2, 7),
              title: m.trim(),
              completed: false,
            }))
        : [],
      status: 'active',
    });

    setNewGoalTitle('');
    setNewGoalVision('');
    setNewMilestoneText('');
    setIsAddingGoal(false);
    showToast('Goal established', 'success');
  };

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 py-6 space-y-6 text-[var(--text-primary)]">
      {/* Sub-view: CALENDAR & TIME BLOCKING */}
      {(planSubNav === 'calendar' || planSubNav === 'timeblocking') && (
        <div className="space-y-6">
          {/* Header & Controls */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-[var(--border-default)]">
            <div>
              <h1 className="text-xl sm:text-2xl font-bold tracking-tight text-[var(--text-primary)]">
                {planSubNav === 'calendar' ? 'Calendar & Schedule' : 'Time Blocking Canvas'}
              </h1>
              <p className="text-xs sm:text-sm text-[var(--text-secondary)] mt-0.5">
                Unified planning: events, commitments, time blocks, and protected buffers.
              </p>
            </div>

            <div className="flex items-center gap-2 flex-wrap">
              <button
                onClick={() => openHelpWithContext('plan')}
                className="active-press p-1.5 rounded-xl border border-[var(--border-default)] text-[var(--text-secondary)] hover:text-[var(--accent)] hover:bg-[var(--ui-hover)] transition-colors cursor-pointer"
                title="Calendar & Time Blocking Guide"
                aria-label="Planning Help"
              >
                <HelpCircle className="w-4 h-4" />
              </button>

              <button
                onClick={handleAISmartSchedule}
                disabled={isScheduling}
                className="active-press flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-medium bg-[var(--bg-surface-subtle)] text-[var(--text-primary)] border border-[var(--border-default)] hover:bg-[var(--ui-hover)] transition-colors cursor-pointer disabled:opacity-50"
              >
                <Sparkles className="w-3.5 h-3.5 text-indigo-500" />
                <span>{isScheduling ? 'Analyzing...' : 'AI Smart Schedule'}</span>
              </button>

              <button
                onClick={() => setIsAddingEvent(true)}
                className="active-press flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl text-xs font-semibold bg-[var(--accent)] text-[var(--accent-text)] hover:opacity-90 transition-all shadow-xs cursor-pointer"
              >
                <Plus className="w-4 h-4" />
                <span>Add Block</span>
              </button>
            </div>
          </div>

          {/* Conflict detection alert if any */}
          {conflicts.length > 0 && (
            <div className="flex items-center gap-3 p-3.5 rounded-2xl bg-amber-500/10 border border-amber-500/20 text-xs text-amber-600 dark:text-amber-400">
              <ShieldAlert className="w-4 h-4 text-amber-500 shrink-0" />
              <span>
                Schedule overlap detected between "{conflicts[0].eventA.title}" and "
                {conflicts[0].eventB.title}". Consider adjusting times.
              </span>
            </div>
          )}

          {/* Date Selector bar */}
          <div className="flex items-center justify-between p-3.5 rounded-2xl bg-[var(--bg-surface-elevated)] border border-[var(--border-default)] shadow-xs">
            <div className="flex items-center gap-3">
              <input
                type="date"
                value={selectedDate}
                onChange={(e) => setSelectedDate(e.target.value)}
                className="text-xs sm:text-sm font-semibold text-[var(--text-primary)] bg-transparent border-none focus:outline-hidden cursor-pointer"
              />
              {selectedDate === todayStr && (
                <span className="text-[10px] uppercase font-bold px-2 py-0.5 rounded-lg bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border border-emerald-500/20">
                  Today
                </span>
              )}
            </div>

            <div className="flex items-center gap-1">
              <button
                onClick={() => {
                  const d = new Date(selectedDate);
                  d.setDate(d.getDate() - 1);
                  setSelectedDate(d.toISOString().split('T')[0]);
                }}
                className="active-press p-1.5 rounded-lg text-[var(--text-tertiary)] hover:text-[var(--text-primary)] hover:bg-[var(--ui-hover)] transition-colors cursor-pointer"
                aria-label="Previous day"
              >
                <ChevronLeft className="w-4 h-4" />
              </button>
              <button
                onClick={() => setSelectedDate(todayStr)}
                className="active-press px-2.5 py-1 text-xs text-[var(--text-secondary)] hover:text-[var(--text-primary)] rounded-lg hover:bg-[var(--ui-hover)] font-medium cursor-pointer"
              >
                Today
              </button>
              <button
                onClick={() => {
                  const d = new Date(selectedDate);
                  d.setDate(d.getDate() + 1);
                  setSelectedDate(d.toISOString().split('T')[0]);
                }}
                className="active-press p-1.5 rounded-lg text-[var(--text-tertiary)] hover:text-[var(--text-primary)] hover:bg-[var(--ui-hover)] transition-colors cursor-pointer"
                aria-label="Next day"
              >
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* AI Schedule Proposal Banner */}
          {proposedSchedule && (
            <div className="p-4 rounded-2xl bg-indigo-500/10 border border-indigo-500/20 space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Sparkles className="w-4 h-4 text-indigo-500" />
                  <h3 className="text-xs font-semibold uppercase tracking-wider text-indigo-600 dark:text-indigo-300">
                    Proposed AI Schedule
                  </h3>
                </div>
                <button
                  onClick={() => setProposedSchedule(null)}
                  className="active-press text-xs text-[var(--text-tertiary)] hover:text-[var(--text-primary)] cursor-pointer"
                >
                  Dismiss
                </button>
              </div>

              <p className="text-xs text-[var(--text-secondary)] leading-relaxed">
                {scheduleExplanation}
              </p>

              <div className="space-y-1.5">
                {proposedSchedule.map((s, idx) => (
                  <div
                    key={idx}
                    className="flex items-center justify-between p-2.5 rounded-xl bg-[var(--bg-surface-elevated)] border border-[var(--border-default)] text-xs shadow-xs"
                  >
                    <span className="font-medium text-[var(--text-primary)]">
                      {String(s.startHour).padStart(2, '0')}:{String(s.startMinute).padStart(2, '0')} • {s.title} ({s.durationMinutes}m)
                    </span>
                    <span className="text-[11px] text-[var(--text-tertiary)]">{s.reasoning}</span>
                  </div>
                ))}
              </div>

              <div className="flex items-center justify-end gap-2 pt-1">
                <button
                  onClick={() => setProposedSchedule(null)}
                  className="active-press px-3 py-1.5 rounded-lg text-xs font-medium text-[var(--text-secondary)] hover:text-[var(--text-primary)] cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  onClick={applyProposedSchedule}
                  className="active-press px-4 py-1.5 rounded-xl text-xs font-semibold bg-indigo-600 text-white hover:bg-indigo-700 shadow-xs cursor-pointer"
                >
                  Confirm & Apply Schedule
                </button>
              </div>
            </div>
          )}

          {/* Schedule Timeline Slots */}
          <div className="space-y-2.5">
            {eventsOnDate.length === 0 ? (
              <div className="p-12 text-center rounded-2xl border border-dashed border-[var(--border-default)] bg-[var(--bg-surface-subtle)] space-y-2">
                <CalendarIcon className="w-6 h-6 mx-auto text-[var(--text-tertiary)] mb-2" />
                <p className="text-sm font-medium text-[var(--text-secondary)]">
                  No time blocks scheduled for this date.
                </p>
                <button
                  onClick={() => setIsAddingEvent(true)}
                  className="active-press text-xs text-[var(--text-primary)] underline font-semibold cursor-pointer"
                >
                  Add your first commitment or time block
                </button>
              </div>
            ) : (
              eventsOnDate.map((ev) => (
                <div
                  key={ev.id}
                  className="flex items-center justify-between p-3.5 sm:p-4 rounded-2xl bg-[var(--bg-surface-elevated)] border border-[var(--border-default)] hover:border-[var(--border-focus)] transition-colors shadow-xs"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-24 font-mono text-xs font-medium text-[var(--text-secondary)]">
                      {ev.startTime} – {ev.endTime}
                    </div>

                    <div className="space-y-0.5">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="text-xs sm:text-sm font-semibold text-[var(--text-primary)]">
                          {ev.title}
                        </span>
                        {ev.isFixedCommitment && (
                          <span className="text-[10px] px-2 py-0.5 rounded-lg bg-[var(--bg-surface-subtle)] text-[var(--text-secondary)] border border-[var(--border-default)] font-medium">
                            Fixed Commitment
                          </span>
                        )}
                      </div>
                      {ev.notes && (
                        <p className="text-[11px] text-[var(--text-secondary)] truncate max-w-md">
                          {ev.notes}
                        </p>
                      )}
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    <span className="text-[11px] text-[var(--text-tertiary)] uppercase font-mono">
                      {ev.type}
                    </span>
                    <button
                      onClick={() => deleteCalendarEvent(ev.id)}
                      className="active-press p-1.5 text-[var(--text-tertiary)] hover:text-rose-500 rounded-lg transition-colors cursor-pointer"
                      aria-label="Delete block"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      )}

      {/* Sub-view: GOALS */}
      {planSubNav === 'goals' && (
        <div className="space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-[var(--border-default)]">
            <div>
              <h1 className="text-xl sm:text-2xl font-bold tracking-tight text-[var(--text-primary)]">
                Goals & Milestones
              </h1>
              <p className="text-xs sm:text-sm text-[var(--text-secondary)] mt-0.5">
                Vision → Goals → Milestones → Projects → Tasks hierarchy.
              </p>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={() => openHelpWithContext('goals')}
                className="active-press p-1.5 rounded-xl border border-[var(--border-default)] text-[var(--text-secondary)] hover:text-[var(--accent)] hover:bg-[var(--ui-hover)] transition-colors cursor-pointer"
                title="Goals & Milestones Guide"
                aria-label="Goals Help"
              >
                <HelpCircle className="w-4 h-4" />
              </button>
              <button
                onClick={() => setIsAddingGoal(true)}
                className="active-press flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl text-xs font-semibold bg-[var(--accent)] text-[var(--accent-text)] hover:opacity-90 transition-all shadow-xs cursor-pointer"
              >
                <Plus className="w-4 h-4" />
                <span>New Goal</span>
              </button>
            </div>
          </div>

          <div className="space-y-4">
            {goals.map((goal) => {
              const daysSinceActivity = Math.floor(
                (Date.now() - new Date(goal.lastActivityAt || goal.createdAt).getTime()) /
                  (1000 * 60 * 60 * 24)
              );
              const isStagnant = daysSinceActivity > 10;
              const linkedProjects = projects.filter((p) => p.goalId === goal.id);

              return (
                <div
                  key={goal.id}
                  className="p-4 sm:p-5 rounded-2xl bg-[var(--bg-surface-elevated)] border border-[var(--border-default)] space-y-4 shadow-xs"
                >
                  <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-2">
                    <div>
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="text-sm sm:text-base font-semibold text-[var(--text-primary)]">
                          {goal.title}
                        </span>
                        <span className="text-[10px] uppercase tracking-wider font-semibold px-2 py-0.5 rounded-lg bg-[var(--bg-surface-subtle)] text-[var(--text-secondary)] border border-[var(--border-default)]">
                          {goal.area}
                        </span>
                        {isStagnant && (
                          <span className="text-[10px] uppercase font-bold px-2 py-0.5 rounded-lg bg-rose-500/10 border border-rose-500/20 text-rose-600 dark:text-rose-400 flex items-center gap-1">
                            <AlertCircle className="w-3 h-3" />
                            Stagnant ({daysSinceActivity}d inactive)
                          </span>
                        )}
                      </div>
                      <p className="text-xs text-[var(--text-secondary)] mt-1 italic leading-relaxed">
                        Vision: “{goal.vision}”
                      </p>
                    </div>

                    <div className="flex items-center gap-3">
                      <span className="text-xs font-mono font-semibold text-[var(--text-secondary)]">
                        {goal.progress}%
                      </span>
                      <button
                        onClick={() => deleteGoal(goal.id)}
                        className="active-press text-[var(--text-tertiary)] hover:text-rose-500 transition-colors p-1.5 rounded-lg cursor-pointer"
                        aria-label="Delete goal"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>

                  {/* Progress Bar */}
                  <div className="w-full h-1.5 rounded-full bg-[var(--bg-surface-subtle)] overflow-hidden border border-[var(--border-default)]">
                    <div
                      className="h-full rounded-full bg-[var(--accent)] transition-all duration-500"
                      style={{ width: `${goal.progress}%` }}
                    />
                  </div>

                  {/* Milestones Checklist */}
                  <div className="space-y-2 pt-2 border-t border-[var(--border-default)]">
                    <p className="text-[10px] font-semibold text-[var(--text-tertiary)] uppercase tracking-wider">
                      Milestones
                    </p>
                    <div className="space-y-1.5">
                      {goal.milestones.map((m) => (
                        <div
                          key={m.id}
                          onClick={() => toggleMilestone(goal.id, m.id)}
                          className="flex items-center gap-2 text-xs text-[var(--text-primary)] cursor-pointer hover:opacity-80 transition-opacity"
                        >
                          <button className="text-[var(--text-tertiary)] hover:text-[var(--text-primary)]">
                            {m.completed ? (
                              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500" />
                            ) : (
                              <Circle className="w-3.5 h-3.5" />
                            )}
                          </button>
                          <span className={m.completed ? 'line-through text-[var(--text-tertiary)]' : ''}>
                            {m.title}
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Connected Projects */}
                  {linkedProjects.length > 0 && (
                    <div className="flex items-center gap-2 text-xs text-[var(--text-secondary)] pt-1">
                      <span className="text-[10px] uppercase tracking-wider font-semibold text-[var(--text-tertiary)]">
                        Connected Projects:
                      </span>
                      {linkedProjects.map((p) => (
                        <span
                          key={p.id}
                          className="px-2 py-0.5 rounded-lg bg-[var(--bg-surface-subtle)] text-[var(--text-secondary)] border border-[var(--border-default)] font-medium"
                        >
                          {p.title}
                        </span>
                      ))}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Add Event Modal */}
      {isAddingEvent && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto">
          <form
            onSubmit={handleCreateEvent}
            className="w-full max-w-md p-5 rounded-2xl bg-[var(--bg-surface-elevated)] border border-[var(--border-default)] shadow-2xl space-y-4 text-[var(--text-primary)]"
          >
            <div className="flex items-center justify-between border-b border-[var(--border-default)] pb-2.5">
              <h3 className="text-sm font-semibold text-[var(--text-primary)]">
                Add Time Block or Event
              </h3>
              <button
                type="button"
                onClick={() => setIsAddingEvent(false)}
                className="active-press p-1 rounded-lg text-[var(--text-tertiary)] hover:text-[var(--text-primary)] cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <div>
                <label className="block text-[var(--text-secondary)] font-medium mb-1">Title</label>
                <input
                  type="text"
                  placeholder="Block title..."
                  value={newEvTitle}
                  onChange={(e) => setNewEvTitle(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-[var(--bg-surface-input)] border border-[var(--border-default)] text-[var(--text-primary)] placeholder-[var(--text-tertiary)] focus:outline-hidden font-medium"
                  autoFocus
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[var(--text-secondary)] font-medium mb-1">Start Time</label>
                  <input
                    type="time"
                    value={newEvStart}
                    onChange={(e) => setNewEvStart(e.target.value)}
                    className="w-full px-3 py-1.5 rounded-xl bg-[var(--bg-surface-input)] border border-[var(--border-default)] text-[var(--text-primary)] focus:outline-hidden"
                  />
                </div>
                <div>
                  <label className="block text-[var(--text-secondary)] font-medium mb-1">End Time</label>
                  <input
                    type="time"
                    value={newEvEnd}
                    onChange={(e) => setNewEvEnd(e.target.value)}
                    className="w-full px-3 py-1.5 rounded-xl bg-[var(--bg-surface-input)] border border-[var(--border-default)] text-[var(--text-primary)] focus:outline-hidden"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[var(--text-secondary)] font-medium mb-1">Block Type</label>
                  <select
                    value={newEvType}
                    onChange={(e) => setNewEvType(e.target.value as any)}
                    className="w-full px-2.5 py-1.5 rounded-xl bg-[var(--bg-surface-input)] border border-[var(--border-default)] text-[var(--text-primary)] focus:outline-hidden"
                  >
                    <option value="timeblock">Time Block</option>
                    <option value="focus">Focus Session</option>
                    <option value="event">Meeting / Event</option>
                    <option value="buffer">Protected Buffer</option>
                  </select>
                </div>

                <div>
                  <label className="block text-[var(--text-secondary)] font-medium mb-1">Link to Task</label>
                  <select
                    value={newEvTaskId}
                    onChange={(e) => setNewEvTaskId(e.target.value)}
                    className="w-full px-2.5 py-1.5 rounded-xl bg-[var(--bg-surface-input)] border border-[var(--border-default)] text-[var(--text-primary)] focus:outline-hidden truncate"
                  >
                    <option value="">None</option>
                    {tasks.map((t) => (
                      <option key={t.id} value={t.id}>
                        {t.title}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="flex items-center gap-2 pt-1">
                <input
                  type="checkbox"
                  id="chk-fixed"
                  checked={newEvFixed}
                  onChange={(e) => setNewEvFixed(e.target.checked)}
                  className="rounded border-[var(--border-default)] cursor-pointer"
                />
                <label htmlFor="chk-fixed" className="text-[var(--text-secondary)] cursor-pointer select-none">
                  Fixed commitment (Do not auto-reschedule)
                </label>
              </div>
            </div>

            <div className="flex items-center justify-end gap-2 pt-3 border-t border-[var(--border-default)]">
              <button
                type="button"
                onClick={() => setIsAddingEvent(false)}
                className="active-press px-3 py-1.5 rounded-xl text-xs font-medium text-[var(--text-secondary)] hover:text-[var(--text-primary)] cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="active-press px-4 py-1.5 rounded-xl text-xs font-semibold bg-[var(--accent)] text-[var(--accent-text)] hover:opacity-90 shadow-xs cursor-pointer"
              >
                Schedule Block
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Add Goal Modal */}
      {isAddingGoal && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto">
          <form
            onSubmit={handleCreateGoal}
            className="w-full max-w-md p-5 rounded-2xl bg-[var(--bg-surface-elevated)] border border-[var(--border-default)] shadow-2xl space-y-4 text-[var(--text-primary)]"
          >
            <div className="flex items-center justify-between border-b border-[var(--border-default)] pb-2.5">
              <h3 className="text-sm font-semibold text-[var(--text-primary)]">
                Establish New Vision & Goal
              </h3>
              <button
                type="button"
                onClick={() => setIsAddingGoal(false)}
                className="active-press p-1 rounded-lg text-[var(--text-tertiary)] hover:text-[var(--text-primary)] cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <div>
                <label className="block text-[var(--text-secondary)] font-medium mb-1">Goal Title</label>
                <input
                  type="text"
                  placeholder="e.g. Master Machine Learning Foundations"
                  value={newGoalTitle}
                  onChange={(e) => setNewGoalTitle(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-[var(--bg-surface-input)] border border-[var(--border-default)] text-[var(--text-primary)] placeholder-[var(--text-tertiary)] focus:outline-hidden font-medium"
                  autoFocus
                />
              </div>

              <div>
                <label className="block text-[var(--text-secondary)] font-medium mb-1">Underlying Vision</label>
                <textarea
                  placeholder="Why does this matter? What does success feel like?"
                  value={newGoalVision}
                  onChange={(e) => setNewGoalVision(e.target.value)}
                  rows={2}
                  className="w-full px-3 py-2 rounded-xl bg-[var(--bg-surface-input)] border border-[var(--border-default)] text-[var(--text-primary)] placeholder-[var(--text-tertiary)] focus:outline-hidden resize-none"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[var(--text-secondary)] font-medium mb-1">Life Area</label>
                  <select
                    value={newGoalArea}
                    onChange={(e) => setNewGoalArea(e.target.value as any)}
                    className="w-full px-2.5 py-1.5 rounded-xl bg-[var(--bg-surface-input)] border border-[var(--border-default)] text-[var(--text-primary)] focus:outline-hidden"
                  >
                    <option value="Career">Career</option>
                    <option value="Health">Health</option>
                    <option value="Learning">Learning</option>
                    <option value="Finance">Finance</option>
                    <option value="Personal">Personal</option>
                    <option value="Creative">Creative</option>
                  </select>
                </div>

                <div>
                  <label className="block text-[var(--text-secondary)] font-medium mb-1">Target Date</label>
                  <input
                    type="date"
                    value={newGoalTargetDate}
                    onChange={(e) => setNewGoalTargetDate(e.target.value)}
                    className="w-full px-2.5 py-1.5 rounded-xl bg-[var(--bg-surface-input)] border border-[var(--border-default)] text-[var(--text-primary)] focus:outline-hidden"
                  />
                </div>
              </div>

              <div>
                <label className="block text-[var(--text-secondary)] font-medium mb-1">
                  Key Milestones (one per line)
                </label>
                <textarea
                  placeholder="Finish textbook parts 1 & 2&#10;Complete 3 practical labs&#10;Deploy demo project"
                  value={newMilestoneText}
                  onChange={(e) => setNewMilestoneText(e.target.value)}
                  rows={3}
                  className="w-full px-3 py-2 rounded-xl bg-[var(--bg-surface-input)] border border-[var(--border-default)] text-[var(--text-primary)] placeholder-[var(--text-tertiary)] focus:outline-hidden resize-none"
                />
              </div>
            </div>

            <div className="flex items-center justify-end gap-2 pt-3 border-t border-[var(--border-default)]">
              <button
                type="button"
                onClick={() => setIsAddingGoal(false)}
                className="active-press px-3 py-1.5 rounded-xl text-xs font-medium text-[var(--text-secondary)] hover:text-[var(--text-primary)] cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="active-press px-4 py-1.5 rounded-xl text-xs font-semibold bg-[var(--accent)] text-[var(--accent-text)] hover:opacity-90 shadow-xs cursor-pointer"
              >
                Save Goal
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
};
