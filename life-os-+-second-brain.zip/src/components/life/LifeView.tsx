import React, { useState } from 'react';
import {
  FolderGit2,
  Repeat,
  DollarSign,
  Zap,
  Plus,
  Flame,
  CheckCircle2,
  Circle,
  Clock,
  Sparkles,
  TrendingUp,
  AlertTriangle,
  Trash2,
  Smile,
  Moon,
  BatteryCharging,
  ArrowUpRight,
  ArrowDownRight,
  X,
  HelpCircle,
} from 'lucide-react';
import { useLifeOS } from '../../context/LifeOSContext';
import { Project, Habit, FinanceItem, EnergyLog } from '../../types';

export const LifeView: React.FC = () => {
  const {
    lifeSubNav,
    projects,
    habits,
    financeItems,
    energyLogs,
    tasks,
    goals,
    addProject,
    deleteProject,
    addHabit,
    deleteHabit,
    toggleHabitDate,
    addFinanceItem,
    deleteFinanceItem,
    addEnergyLog,
    addTask,
    showToast,
    getAIHeaders,
    openHelpWithContext,
  } = useLifeOS();

  const todayStr = new Date().toISOString().split('T')[0];

  // Project Modals
  const [isAddingProject, setIsAddingProject] = useState(false);
  const [newProjTitle, setNewProjTitle] = useState('');
  const [newProjDesc, setNewProjDesc] = useState('');
  const [newProjDeadline, setNewProjDeadline] = useState('2026-10-15');
  const [newProjGoalId, setNewProjGoalId] = useState('');

  // Habit Modals
  const [isAddingHabit, setIsAddingHabit] = useState(false);
  const [newHabitTitle, setNewHabitTitle] = useState('');
  const [newHabitFreq, setNewHabitFreq] = useState<'daily' | 'weekly'>('daily');
  const [newHabitCategory, setNewHabitCategory] = useState('Health');
  const [newHabitGoalId, setNewHabitGoalId] = useState('');

  // Finance Modals
  const [isAddingFinance, setIsAddingFinance] = useState(false);
  const [newFinTitle, setNewFinTitle] = useState('');
  const [newFinAmount, setNewFinAmount] = useState<number>(50);
  const [newFinType, setNewFinType] = useState<'income' | 'expense'>('expense');
  const [newFinCategory, setNewFinCategory] = useState('Productivity');

  // Energy quick check-in state
  const [selectedEnergyLevel, setSelectedEnergyLevel] = useState<EnergyLog['level']>('high');
  const [selectedEnergyMood, setSelectedEnergyMood] = useState('Clear & Driven');

  // AI Task breakdown for a project
  const handleAIProjectBreakdown = async (project: Project) => {
    try {
      showToast('Analyzing project for missing tasks...', 'info');
      const res = await fetch('/api/ai/chat', {
        method: 'POST',
        headers: getAIHeaders(),
        body: JSON.stringify({
          message: `Given this project: "${project.title}" (${project.description}). List 3 concrete missing tasks required to finish it. Output 3 lines starting with "- ":`,
        }),
      });

      if (res.ok) {
        const data = await res.json();
        const items = data.reply
          .split('\n')
          .filter((l: string) => l.trim().startsWith('-') || /^\d+\./.test(l.trim()))
          .map((l: string) => l.replace(/^[-•\d.]\s*/, '').trim())
          .filter((l: string) => l.length > 0);

        items.slice(0, 3).forEach((title: string) => {
          addTask({
            title,
            status: 'today',
            priority: 'medium',
            projectId: project.id,
            durationMinutes: 45,
            subtasks: [],
            tags: ['ai-breakdown'],
          });
        });
        showToast(`Created ${items.slice(0, 3).length} tasks for "${project.title}"`, 'success');
      }
    } catch (e) {
      showToast('AI project breakdown fallback: task added', 'info');
    }
  };

  const handleCreateProject = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newProjTitle.trim()) return;
    addProject({
      title: newProjTitle.trim(),
      description: newProjDesc.trim(),
      status: 'active',
      deadline: newProjDeadline,
      goalId: newProjGoalId || undefined,
    });
    setNewProjTitle('');
    setNewProjDesc('');
    setIsAddingProject(false);
    showToast('Project initialized', 'success');
  };

  const handleCreateHabit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newHabitTitle.trim()) return;
    addHabit({
      title: newHabitTitle.trim(),
      frequency: newHabitFreq,
      targetDaysPerWeek: 5,
      category: newHabitCategory,
      goalId: newHabitGoalId || undefined,
    });
    setNewHabitTitle('');
    setIsAddingHabit(false);
    showToast('Habit established', 'success');
  };

  const handleCreateFinance = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newFinTitle.trim() || !newFinAmount) return;
    addFinanceItem({
      title: newFinTitle.trim(),
      amount: Number(newFinAmount),
      type: newFinType,
      category: newFinCategory,
      date: todayStr,
      isRecurring: false,
    });
    setNewFinTitle('');
    setNewFinAmount(50);
    setIsAddingFinance(false);
    showToast('Transaction recorded', 'success');
  };

  const handleSaveEnergyCheckin = () => {
    const hour = new Date().getHours();
    const timeOfDay = hour < 12 ? 'morning' : hour < 17 ? 'afternoon' : 'evening';
    addEnergyLog({
      date: todayStr,
      timeOfDay,
      level: selectedEnergyLevel,
      mood: selectedEnergyMood,
      tags: ['Focus', 'Hydrated'],
    });
    showToast('Energy check-in logged', 'success');
  };

  // Money calculations
  const totalIncome = financeItems
    .filter((f) => f.type === 'income')
    .reduce((acc, curr) => acc + curr.amount, 0);
  const totalExpenses = financeItems
    .filter((f) => f.type === 'expense')
    .reduce((acc, curr) => acc + curr.amount, 0);
  const netSavings = totalIncome - totalExpenses;

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 py-6 space-y-6 text-[var(--text-primary)]">
      {/* 1. PROJECTS SUB-VIEW */}
      {lifeSubNav === 'projects' && (
        <div className="space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-[var(--border-default)]">
            <div>
              <h1 className="text-xl sm:text-2xl font-bold tracking-tight text-[var(--text-primary)] flex items-center gap-2">
                <FolderGit2 className="w-5 h-5 text-indigo-500" />
                <span>Projects</span>
              </h1>
              <p className="text-xs sm:text-sm text-[var(--text-secondary)] mt-0.5">
                Multi-step initiatives driving goals and housing tasks.
              </p>
            </div>
            <div className="flex items-center gap-2 self-start sm:self-auto">
              <button
                onClick={() => openHelpWithContext('projects')}
                className="active-press p-1.5 rounded-xl border border-[var(--border-default)] text-[var(--text-secondary)] hover:text-[var(--accent)] hover:bg-[var(--ui-hover)] transition-colors cursor-pointer"
                title="Projects Guide"
                aria-label="Projects Help"
              >
                <HelpCircle className="w-4 h-4" />
              </button>
              <button
                onClick={() => setIsAddingProject(true)}
                className="active-press flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl text-xs font-semibold bg-[var(--accent)] text-[var(--accent-text)] hover:opacity-90 transition-all shadow-xs cursor-pointer"
              >
                <Plus className="w-4 h-4" />
                <span>New Project</span>
              </button>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {projects.map((proj) => {
              const projectTasks = tasks.filter((t) => t.projectId === proj.id);
              const completedCount = projectTasks.filter((t) => t.status === 'completed').length;

              return (
                <div
                  key={proj.id}
                  className="p-5 rounded-2xl bg-[var(--bg-surface-elevated)] border border-[var(--border-default)] space-y-4 shadow-xs"
                >
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <h3 className="text-sm sm:text-base font-semibold text-[var(--text-primary)]">
                        {proj.title}
                      </h3>
                      <p className="text-xs text-[var(--text-secondary)] mt-1 line-clamp-2">
                        {proj.description}
                      </p>
                    </div>

                    <button
                      onClick={() => deleteProject(proj.id)}
                      className="active-press p-1 text-[var(--text-tertiary)] hover:text-rose-500 rounded-lg transition-colors cursor-pointer"
                      aria-label="Delete project"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>

                  {/* Progress bar */}
                  <div className="space-y-1">
                    <div className="flex items-center justify-between text-xs text-[var(--text-secondary)]">
                      <span>Progress</span>
                      <span className="font-mono">{proj.progress}%</span>
                    </div>
                    <div className="w-full h-1.5 rounded-full bg-[var(--bg-surface-subtle)] overflow-hidden border border-[var(--border-default)]">
                      <div
                        className="h-full rounded-full bg-[var(--accent)] transition-all duration-500"
                        style={{ width: `${proj.progress}%` }}
                      />
                    </div>
                  </div>

                  {/* Metadata & Actions */}
                  <div className="flex items-center justify-between pt-2 border-t border-[var(--border-default)] text-xs">
                    <span className="text-[11px] text-[var(--text-tertiary)]">
                      Due: {proj.deadline} • {completedCount}/{projectTasks.length} tasks
                    </span>

                    <button
                      onClick={() => handleAIProjectBreakdown(proj)}
                      className="active-press flex items-center gap-1 text-[11px] font-semibold text-indigo-500 hover:underline cursor-pointer"
                    >
                      <Sparkles className="w-3 h-3" />
                      <span>AI Discover Next Tasks</span>
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* 2. HABITS SUB-VIEW */}
      {lifeSubNav === 'habits' && (
        <div className="space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-[var(--border-default)]">
            <div>
              <h1 className="text-xl sm:text-2xl font-bold tracking-tight text-[var(--text-primary)] flex items-center gap-2">
                <Repeat className="w-5 h-5 text-amber-500" />
                <span>Habits & Rituals</span>
              </h1>
              <p className="text-xs sm:text-sm text-[var(--text-secondary)] mt-0.5">
                Small consistent systems that compound into identity and goal achievement.
              </p>
            </div>
            <div className="flex items-center gap-2 self-start sm:self-auto">
              <button
                onClick={() => openHelpWithContext('habits')}
                className="active-press p-1.5 rounded-xl border border-[var(--border-default)] text-[var(--text-secondary)] hover:text-[var(--accent)] hover:bg-[var(--ui-hover)] transition-colors cursor-pointer"
                title="Habits & Rituals Guide"
                aria-label="Habits Help"
              >
                <HelpCircle className="w-4 h-4" />
              </button>
              <button
                onClick={() => setIsAddingHabit(true)}
                className="active-press flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl text-xs font-semibold bg-[var(--accent)] text-[var(--accent-text)] hover:opacity-90 transition-all shadow-xs cursor-pointer"
              >
                <Plus className="w-4 h-4" />
                <span>New Habit</span>
              </button>
            </div>
          </div>

          {/* Habit Tracker Table */}
          <div className="p-4 sm:p-5 rounded-2xl bg-[var(--bg-surface-elevated)] border border-[var(--border-default)] space-y-4 shadow-xs">
            <div className="space-y-3">
              {habits.map((habit) => {
                const isCompletedToday = habit.completedDates.includes(todayStr);

                const last7Days = Array.from({ length: 7 }, (_, i) => {
                  const d = new Date();
                  d.setDate(d.getDate() - (6 - i));
                  return d.toISOString().split('T')[0];
                });

                return (
                  <div
                    key={habit.id}
                    className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 p-3.5 rounded-2xl border border-[var(--border-default)] hover:bg-[var(--ui-hover)] transition-colors"
                  >
                    <div className="flex items-center gap-3">
                      <button
                        onClick={() => toggleHabitDate(habit.id, todayStr)}
                        className="active-press text-[var(--text-tertiary)] hover:text-[var(--text-primary)] cursor-pointer"
                        aria-label="Toggle habit completion"
                      >
                        {isCompletedToday ? (
                          <CheckCircle2 className="w-5 h-5 text-emerald-500" />
                        ) : (
                          <Circle className="w-5 h-5" />
                        )}
                      </button>

                      <div>
                        <span
                          className={`text-xs sm:text-sm font-semibold ${
                            isCompletedToday
                              ? 'line-through text-[var(--text-tertiary)]'
                              : 'text-[var(--text-primary)]'
                          }`}
                        >
                          {habit.title}
                        </span>
                        <div className="flex items-center gap-2 text-[11px] text-[var(--text-tertiary)]">
                          <span>{habit.category}</span>
                          <span>•</span>
                          <span className="flex items-center gap-0.5 text-amber-500 font-semibold">
                            <Flame className="w-3 h-3" />
                            {habit.streak} day streak
                          </span>
                        </div>
                      </div>
                    </div>

                    {/* 7-Day Mini Dots */}
                    <div className="flex items-center gap-1.5 self-end sm:self-auto">
                      {last7Days.map((dStr) => {
                        const done = habit.completedDates.includes(dStr);
                        const isTodayDot = dStr === todayStr;
                        return (
                          <button
                            key={dStr}
                            onClick={() => toggleHabitDate(habit.id, dStr)}
                            className={`active-press w-7 h-7 rounded-lg text-[10px] font-mono flex items-center justify-center transition-all cursor-pointer ${
                              done
                                ? 'bg-[var(--accent)] text-[var(--accent-text)] shadow-xs'
                                : 'bg-[var(--bg-surface-subtle)] text-[var(--text-tertiary)] border border-[var(--border-default)] hover:bg-[var(--ui-hover)]'
                            } ${isTodayDot ? 'ring-1 ring-[var(--accent)]' : ''}`}
                            title={dStr}
                          >
                            {done ? '✓' : ''}
                          </button>
                        );
                      })}

                      <button
                        onClick={() => deleteHabit(habit.id)}
                        className="active-press p-1.5 text-[var(--text-tertiary)] hover:text-rose-500 rounded-lg transition-colors ml-2 cursor-pointer"
                        aria-label="Delete habit"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* 3. MONEY SUB-VIEW */}
      {lifeSubNav === 'money' && (
        <div className="space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-[var(--border-default)]">
            <div>
              <h1 className="text-xl sm:text-2xl font-bold tracking-tight text-[var(--text-primary)] flex items-center gap-2">
                <DollarSign className="w-5 h-5 text-emerald-500" />
                <span>Financial Clarity</span>
              </h1>
              <p className="text-xs sm:text-sm text-[var(--text-secondary)] mt-0.5">
                Actionable tracking of monthly cashflow, runway, and financial goals.
              </p>
            </div>
            <div className="flex items-center gap-2 self-start sm:self-auto">
              <button
                onClick={() => openHelpWithContext('money')}
                className="active-press p-1.5 rounded-xl border border-[var(--border-default)] text-[var(--text-secondary)] hover:text-[var(--accent)] hover:bg-[var(--ui-hover)] transition-colors cursor-pointer"
                title="Finances Guide"
                aria-label="Finances Help"
              >
                <HelpCircle className="w-4 h-4" />
              </button>
              <button
                onClick={() => setIsAddingFinance(true)}
                className="active-press flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl text-xs font-semibold bg-[var(--accent)] text-[var(--accent-text)] hover:opacity-90 transition-all shadow-xs cursor-pointer"
              >
                <Plus className="w-4 h-4" />
                <span>Record Transaction</span>
              </button>
            </div>
          </div>

          {/* Financial Summary Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="p-4 rounded-2xl bg-[var(--bg-surface-elevated)] border border-[var(--border-default)] space-y-1 shadow-xs">
              <span className="text-[11px] font-semibold text-[var(--text-tertiary)] uppercase tracking-wider">
                Monthly Inflow
              </span>
              <p className="text-xl font-bold text-emerald-500 flex items-center gap-1">
                <ArrowUpRight className="w-4 h-4" />
                ${totalIncome.toLocaleString()}
              </p>
            </div>

            <div className="p-4 rounded-2xl bg-[var(--bg-surface-elevated)] border border-[var(--border-default)] space-y-1 shadow-xs">
              <span className="text-[11px] font-semibold text-[var(--text-tertiary)] uppercase tracking-wider">
                Monthly Expenses
              </span>
              <p className="text-xl font-bold text-[var(--text-primary)] flex items-center gap-1">
                <ArrowDownRight className="w-4 h-4 text-rose-500" />
                ${totalExpenses.toLocaleString()}
              </p>
            </div>

            <div className="p-4 rounded-2xl bg-[var(--bg-surface-elevated)] border border-[var(--border-default)] space-y-1 shadow-xs">
              <span className="text-[11px] font-semibold text-[var(--text-tertiary)] uppercase tracking-wider">
                Net Cashflow
              </span>
              <p className="text-xl font-bold text-indigo-500">
                +${netSavings.toLocaleString()}
              </p>
            </div>
          </div>

          {/* Transactions List */}
          <div className="p-4 sm:p-5 rounded-2xl bg-[var(--bg-surface-elevated)] border border-[var(--border-default)] space-y-3 shadow-xs">
            <h3 className="text-xs font-semibold uppercase tracking-wider text-[var(--text-secondary)]">
              Recent Transactions
            </h3>

            <div className="space-y-2">
              {financeItems.map((item) => (
                <div
                  key={item.id}
                  className="flex items-center justify-between p-3.5 rounded-2xl border border-[var(--border-default)] bg-[var(--bg-surface-subtle)]"
                >
                  <div className="space-y-0.5">
                    <span className="text-xs font-semibold text-[var(--text-primary)]">
                      {item.title}
                    </span>
                    <p className="text-[11px] text-[var(--text-tertiary)]">
                      {item.category} • {item.date} {item.isRecurring ? '(Recurring)' : ''}
                    </p>
                  </div>

                  <div className="flex items-center gap-3">
                    <span
                      className={`text-xs font-semibold font-mono ${
                        item.type === 'income' ? 'text-emerald-500' : 'text-[var(--text-primary)]'
                      }`}
                    >
                      {item.type === 'income' ? '+' : '-'}${item.amount}
                    </span>
                    <button
                      onClick={() => deleteFinanceItem(item.id)}
                      className="active-press p-1 text-[var(--text-tertiary)] hover:text-rose-500 rounded-lg transition-colors cursor-pointer"
                      aria-label="Delete transaction"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* 4. ENERGY SUB-VIEW */}
      {lifeSubNav === 'energy' && (
        <div className="space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-[var(--border-default)]">
            <div>
              <h1 className="text-xl sm:text-2xl font-bold tracking-tight text-[var(--text-primary)] flex items-center gap-2">
                <Zap className="w-5 h-5 text-amber-500" />
                <span>Energy & Well-Being Rhythms</span>
              </h1>
              <p className="text-xs sm:text-sm text-[var(--text-secondary)] mt-0.5">
                Align high-leverage cognitive work with your biological peak hours.
              </p>
            </div>
            <button
              onClick={() => openHelpWithContext('energy')}
              className="active-press p-1.5 rounded-xl border border-[var(--border-default)] text-[var(--text-secondary)] hover:text-[var(--accent)] hover:bg-[var(--ui-hover)] transition-colors cursor-pointer self-start sm:self-auto"
              title="Energy & Circadian Rhythms Guide"
              aria-label="Energy Help"
            >
              <HelpCircle className="w-4 h-4" />
            </button>
          </div>

          {/* Quick Check-in Module */}
          <div className="p-5 rounded-2xl bg-[var(--bg-surface-elevated)] border border-[var(--border-default)] space-y-4 shadow-xs">
            <h3 className="text-xs font-semibold uppercase tracking-wider text-[var(--text-secondary)]">
              Log Real-Time Energy Check-In
            </h3>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
              {(['low', 'medium', 'high', 'peak'] as EnergyLog['level'][]).map((level) => (
                <button
                  key={level}
                  onClick={() => setSelectedEnergyLevel(level)}
                  className={`active-press p-3 rounded-xl border text-center text-xs font-semibold capitalize transition-all cursor-pointer ${
                    selectedEnergyLevel === level
                      ? 'bg-[var(--accent)] text-[var(--accent-text)] border-transparent shadow-xs'
                      : 'bg-[var(--bg-surface-subtle)] border-[var(--border-default)] text-[var(--text-secondary)] hover:text-[var(--text-primary)]'
                  }`}
                >
                  {level} Energy
                </button>
              ))}
            </div>

            <div className="flex items-center gap-2 pt-2">
              <input
                type="text"
                placeholder="Current mood / cognitive state (e.g. Sharp, Refreshed, Slight Fatigue)..."
                value={selectedEnergyMood}
                onChange={(e) => setSelectedEnergyMood(e.target.value)}
                className="flex-1 px-3.5 py-2 rounded-xl bg-[var(--bg-surface-input)] border border-[var(--border-default)] text-[var(--text-primary)] placeholder-[var(--text-tertiary)] text-xs focus:outline-hidden"
              />
              <button
                onClick={handleSaveEnergyCheckin}
                className="active-press px-4 py-2 rounded-xl text-xs font-semibold bg-[var(--accent)] text-[var(--accent-text)] hover:opacity-90 shadow-xs cursor-pointer shrink-0"
              >
                Log Check-In
              </button>
            </div>
          </div>

          {/* Past Energy Logs */}
          <div className="p-5 rounded-2xl bg-[var(--bg-surface-elevated)] border border-[var(--border-default)] space-y-3 shadow-xs">
            <h3 className="text-xs font-semibold uppercase tracking-wider text-[var(--text-secondary)]">
              Recent Energy Check-Ins
            </h3>

            <div className="space-y-2">
              {energyLogs.map((log) => (
                <div
                  key={log.id}
                  className="flex items-center justify-between p-3.5 rounded-2xl border border-[var(--border-default)] bg-[var(--bg-surface-subtle)] text-xs"
                >
                  <div className="space-y-0.5">
                    <div className="flex items-center gap-2">
                      <span className="font-semibold text-[var(--text-primary)] capitalize">
                        {log.level} Energy ({log.timeOfDay})
                      </span>
                      <span className="text-[11px] text-[var(--text-tertiary)]">• {log.date}</span>
                    </div>
                    {log.mood && <p className="text-[var(--text-secondary)]">{log.mood}</p>}
                  </div>

                  <span className="px-2 py-0.5 rounded-lg bg-[var(--bg-surface-elevated)] border border-[var(--border-default)] text-[10px] font-semibold uppercase tracking-wider text-[var(--text-secondary)]">
                    {log.level}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Add Project Modal */}
      {isAddingProject && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto">
          <form
            onSubmit={handleCreateProject}
            className="w-full max-w-md p-5 rounded-2xl bg-[var(--bg-surface-elevated)] border border-[var(--border-default)] shadow-2xl space-y-4 text-[var(--text-primary)]"
          >
            <div className="flex items-center justify-between border-b border-[var(--border-default)] pb-2.5">
              <h3 className="text-sm font-semibold text-[var(--text-primary)]">
                Create New Project
              </h3>
              <button
                type="button"
                onClick={() => setIsAddingProject(false)}
                className="active-press p-1 rounded-lg text-[var(--text-tertiary)] hover:text-[var(--text-primary)] cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <div>
                <label className="block text-[var(--text-secondary)] font-medium mb-1">Project Title</label>
                <input
                  type="text"
                  placeholder="e.g. Launch Alpha Life OS"
                  value={newProjTitle}
                  onChange={(e) => setNewProjTitle(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-[var(--bg-surface-input)] border border-[var(--border-default)] text-[var(--text-primary)] placeholder-[var(--text-tertiary)] font-medium focus:outline-hidden"
                  autoFocus
                />
              </div>

              <div>
                <label className="block text-[var(--text-secondary)] font-medium mb-1">Objectives & Description</label>
                <textarea
                  placeholder="What is the definition of done?"
                  value={newProjDesc}
                  onChange={(e) => setNewProjDesc(e.target.value)}
                  rows={2}
                  className="w-full px-3 py-2 rounded-xl bg-[var(--bg-surface-input)] border border-[var(--border-default)] text-[var(--text-primary)] placeholder-[var(--text-tertiary)] focus:outline-hidden resize-none"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[var(--text-secondary)] font-medium mb-1">Deadline</label>
                  <input
                    type="date"
                    value={newProjDeadline}
                    onChange={(e) => setNewProjDeadline(e.target.value)}
                    className="w-full px-2.5 py-1.5 rounded-xl bg-[var(--bg-surface-input)] border border-[var(--border-default)] text-[var(--text-primary)] focus:outline-hidden"
                  />
                </div>

                <div>
                  <label className="block text-[var(--text-secondary)] font-medium mb-1">Link to Goal</label>
                  <select
                    value={newProjGoalId}
                    onChange={(e) => setNewProjGoalId(e.target.value)}
                    className="w-full px-2.5 py-1.5 rounded-xl bg-[var(--bg-surface-input)] border border-[var(--border-default)] text-[var(--text-primary)] focus:outline-hidden truncate"
                  >
                    <option value="">None</option>
                    {goals.map((g) => (
                      <option key={g.id} value={g.id}>
                        {g.title}
                      </option>
                    ))}
                  </select>
                </div>
              </div>
            </div>

            <div className="flex items-center justify-end gap-2 pt-3 border-t border-[var(--border-default)]">
              <button
                type="button"
                onClick={() => setIsAddingProject(false)}
                className="active-press px-3 py-1.5 rounded-xl text-xs font-medium text-[var(--text-secondary)] hover:text-[var(--text-primary)] cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="active-press px-4 py-1.5 rounded-xl text-xs font-semibold bg-[var(--accent)] text-[var(--accent-text)] hover:opacity-90 shadow-xs cursor-pointer"
              >
                Create Project
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Add Habit Modal */}
      {isAddingHabit && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto">
          <form
            onSubmit={handleCreateHabit}
            className="w-full max-w-md p-5 rounded-2xl bg-[var(--bg-surface-elevated)] border border-[var(--border-default)] shadow-2xl space-y-4 text-[var(--text-primary)]"
          >
            <div className="flex items-center justify-between border-b border-[var(--border-default)] pb-2.5">
              <h3 className="text-sm font-semibold text-[var(--text-primary)]">
                Build a New Habit
              </h3>
              <button
                type="button"
                onClick={() => setIsAddingHabit(false)}
                className="active-press p-1 rounded-lg text-[var(--text-tertiary)] hover:text-[var(--text-primary)] cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <div>
                <label className="block text-[var(--text-secondary)] font-medium mb-1">Habit Title</label>
                <input
                  type="text"
                  placeholder="e.g. 20 min morning reading"
                  value={newHabitTitle}
                  onChange={(e) => setNewHabitTitle(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-[var(--bg-surface-input)] border border-[var(--border-default)] text-[var(--text-primary)] placeholder-[var(--text-tertiary)] font-medium focus:outline-hidden"
                  autoFocus
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[var(--text-secondary)] font-medium mb-1">Category</label>
                  <input
                    type="text"
                    value={newHabitCategory}
                    onChange={(e) => setNewHabitCategory(e.target.value)}
                    className="w-full px-2.5 py-1.5 rounded-xl bg-[var(--bg-surface-input)] border border-[var(--border-default)] text-[var(--text-primary)] focus:outline-hidden"
                  />
                </div>

                <div>
                  <label className="block text-[var(--text-secondary)] font-medium mb-1">Frequency</label>
                  <select
                    value={newHabitFreq}
                    onChange={(e) => setNewHabitFreq(e.target.value as any)}
                    className="w-full px-2.5 py-1.5 rounded-xl bg-[var(--bg-surface-input)] border border-[var(--border-default)] text-[var(--text-primary)] focus:outline-hidden"
                  >
                    <option value="daily">Daily</option>
                    <option value="weekly">Weekly</option>
                  </select>
                </div>
              </div>
            </div>

            <div className="flex items-center justify-end gap-2 pt-3 border-t border-[var(--border-default)]">
              <button
                type="button"
                onClick={() => setIsAddingHabit(false)}
                className="active-press px-3 py-1.5 rounded-xl text-xs font-medium text-[var(--text-secondary)] hover:text-[var(--text-primary)] cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="active-press px-4 py-1.5 rounded-xl text-xs font-semibold bg-[var(--accent)] text-[var(--accent-text)] hover:opacity-90 shadow-xs cursor-pointer"
              >
                Save Habit
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Add Finance Modal */}
      {isAddingFinance && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto">
          <form
            onSubmit={handleCreateFinance}
            className="w-full max-w-md p-5 rounded-2xl bg-[var(--bg-surface-elevated)] border border-[var(--border-default)] shadow-2xl space-y-4 text-[var(--text-primary)]"
          >
            <div className="flex items-center justify-between border-b border-[var(--border-default)] pb-2.5">
              <h3 className="text-sm font-semibold text-[var(--text-primary)]">
                Record Income or Expense
              </h3>
              <button
                type="button"
                onClick={() => setIsAddingFinance(false)}
                className="active-press p-1 rounded-lg text-[var(--text-tertiary)] hover:text-[var(--text-primary)] cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <div>
                <label className="block text-[var(--text-secondary)] font-medium mb-1">Description</label>
                <input
                  type="text"
                  placeholder="e.g. Hosting subscription / Client invoice"
                  value={newFinTitle}
                  onChange={(e) => setNewFinTitle(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-[var(--bg-surface-input)] border border-[var(--border-default)] text-[var(--text-primary)] placeholder-[var(--text-tertiary)] font-medium focus:outline-hidden"
                  autoFocus
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[var(--text-secondary)] font-medium mb-1">Amount ($)</label>
                  <input
                    type="number"
                    value={newFinAmount}
                    onChange={(e) => setNewFinAmount(Number(e.target.value))}
                    className="w-full px-2.5 py-1.5 rounded-xl bg-[var(--bg-surface-input)] border border-[var(--border-default)] text-[var(--text-primary)] focus:outline-hidden"
                  />
                </div>

                <div>
                  <label className="block text-[var(--text-secondary)] font-medium mb-1">Type</label>
                  <select
                    value={newFinType}
                    onChange={(e) => setNewFinType(e.target.value as any)}
                    className="w-full px-2.5 py-1.5 rounded-xl bg-[var(--bg-surface-input)] border border-[var(--border-default)] text-[var(--text-primary)] focus:outline-hidden"
                  >
                    <option value="expense">Expense</option>
                    <option value="income">Income</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-[var(--text-secondary)] font-medium mb-1">Category</label>
                <input
                  type="text"
                  value={newFinCategory}
                  onChange={(e) => setNewFinCategory(e.target.value)}
                  className="w-full px-2.5 py-1.5 rounded-xl bg-[var(--bg-surface-input)] border border-[var(--border-default)] text-[var(--text-primary)] focus:outline-hidden"
                />
              </div>
            </div>

            <div className="flex items-center justify-end gap-2 pt-3 border-t border-[var(--border-default)]">
              <button
                type="button"
                onClick={() => setIsAddingFinance(false)}
                className="active-press px-3 py-1.5 rounded-xl text-xs font-medium text-[var(--text-secondary)] hover:text-[var(--text-primary)] cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="active-press px-4 py-1.5 rounded-xl text-xs font-semibold bg-[var(--accent)] text-[var(--accent-text)] hover:opacity-90 shadow-xs cursor-pointer"
              >
                Save
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
};
