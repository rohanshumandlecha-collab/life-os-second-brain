import React, { useState, useEffect } from 'react';
import {
  Plus,
  Trash2,
  ChevronDown,
  ChevronRight,
  Sparkles,
  Link2,
  CheckSquare,
  Square,
  Code,
  Quote,
  Heading1,
  Heading2,
  Heading3,
  AlignLeft,
  List,
  FolderGit2,
  Target,
  ArrowUp,
  ArrowDown,
  Brain,
} from 'lucide-react';
import { BlockItem, BlockType, Note, LifeObject } from '../../types';
import { useLifeOS } from '../../context/LifeOSContext';

interface BlockNoteEditorProps {
  note: Note;
  onUpdateBlocks: (blocks: BlockItem[]) => void;
  onExtractTasks?: () => void;
  onSummarize?: () => void;
  isSynthesizing?: boolean;
}

export const BlockNoteEditor: React.FC<BlockNoteEditorProps> = ({
  note,
  onUpdateBlocks,
  onExtractTasks,
  onSummarize,
  isSynthesizing = false,
}) => {
  const { lifeObjects, showToast } = useLifeOS();

  // Parse note content into blocks if blocks don't exist yet
  const [blocks, setBlocks] = useState<BlockItem[]>(() => {
    if (note.blocks && note.blocks.length > 0) {
      return note.blocks;
    }
    // Parse markdown string into initial blocks
    const lines = (note.content || '').split('\n').filter((l) => l.trim().length > 0);
    if (lines.length === 0) {
      return [
        { id: 'b-1', type: 'paragraph', content: '' },
      ];
    }
    return lines.map((line, idx) => {
      const trimmed = line.trim();
      if (trimmed.startsWith('# ')) {
        return { id: `b-${idx}`, type: 'heading1', content: trimmed.replace(/^#\s+/, '') };
      }
      if (trimmed.startsWith('## ')) {
        return { id: `b-${idx}`, type: 'heading2', content: trimmed.replace(/^##\s+/, '') };
      }
      if (trimmed.startsWith('### ')) {
        return { id: `b-${idx}`, type: 'heading3', content: trimmed.replace(/^###\s+/, '') };
      }
      if (trimmed.startsWith('- [ ] ') || trimmed.startsWith('- [x] ')) {
        return {
          id: `b-${idx}`,
          type: 'todo',
          checked: trimmed.startsWith('- [x] '),
          content: trimmed.replace(/^- \[[ x]\]\s+/, ''),
        };
      }
      if (trimmed.startsWith('- ') || trimmed.startsWith('• ')) {
        return { id: `b-${idx}`, type: 'bullet', content: trimmed.replace(/^[-•]\s+/, '') };
      }
      if (trimmed.startsWith('> ')) {
        return { id: `b-${idx}`, type: 'quote', content: trimmed.replace(/^>\s+/, '') };
      }
      if (trimmed.startsWith('```')) {
        return { id: `b-${idx}`, type: 'code', content: trimmed.replace(/^```\w*\s*/, '').replace(/```$/, '') };
      }
      return { id: `b-${idx}`, type: 'paragraph', content: trimmed };
    });
  });

  const [activeMenuBlockId, setActiveMenuBlockId] = useState<string | null>(null);
  const [relationPickerBlockId, setRelationPickerBlockId] = useState<string | null>(null);

  // Sync back to parent when blocks change
  const handleBlocksChange = (newBlocks: BlockItem[]) => {
    setBlocks(newBlocks);
    onUpdateBlocks(newBlocks);
  };

  const handleUpdateContent = (id: string, content: string) => {
    const updated = blocks.map((b) => (b.id === id ? { ...b, content } : b));
    handleBlocksChange(updated);
  };

  const handleToggleCheck = (id: string) => {
    const updated = blocks.map((b) =>
      b.id === id ? { ...b, checked: !b.checked } : b
    );
    handleBlocksChange(updated);
  };

  const handleToggleCollapse = (id: string) => {
    const updated = blocks.map((b) =>
      b.id === id ? { ...b, collapsed: !b.collapsed } : b
    );
    handleBlocksChange(updated);
  };

  const handleChangeType = (id: string, newType: BlockType) => {
    const updated = blocks.map((b) =>
      b.id === id ? { ...b, type: newType } : b
    );
    handleBlocksChange(updated);
    setActiveMenuBlockId(null);
  };

  const handleAddBlockBelow = (index: number) => {
    const newBlock: BlockItem = {
      id: 'b-' + Date.now(),
      type: 'paragraph',
      content: '',
    };
    const updated = [...blocks];
    updated.splice(index + 1, 0, newBlock);
    handleBlocksChange(updated);
  };

  const handleDeleteBlock = (id: string) => {
    if (blocks.length <= 1) {
      handleBlocksChange([{ id: 'b-' + Date.now(), type: 'paragraph', content: '' }]);
      return;
    }
    const updated = blocks.filter((b) => b.id !== id);
    handleBlocksChange(updated);
  };

  const handleMoveBlock = (index: number, direction: 'up' | 'down') => {
    if (
      (direction === 'up' && index === 0) ||
      (direction === 'down' && index === blocks.length - 1)
    ) {
      return;
    }
    const targetIdx = direction === 'up' ? index - 1 : index + 1;
    const updated = [...blocks];
    const [moved] = updated.splice(index, 1);
    updated.splice(targetIdx, 0, moved);
    handleBlocksChange(updated);
  };

  const handleAttachRelation = (blockId: string, obj: LifeObject) => {
    const updated = blocks.map((b) =>
      b.id === blockId
        ? {
            ...b,
            type: 'relation_embed' as BlockType,
            relatedObjectId: obj.id,
            content: obj.title,
          }
        : b
    );
    handleBlocksChange(updated);
    setRelationPickerBlockId(null);
    showToast(`Embedded connection: "${obj.title}"`, 'success');
  };

  return (
    <div className="space-y-4">
      {/* Block Editor Toolbar */}
      <div className="flex items-center justify-between gap-2 pb-3 border-b border-[var(--border-subtle)] flex-wrap">
        <div className="flex items-center gap-1.5 text-xs text-[var(--text-tertiary)] font-mono">
          <span className="font-semibold text-[var(--text-secondary)]">{blocks.length} blocks</span>
          <span>•</span>
          <span>Rich relational note</span>
        </div>

        <div className="flex items-center gap-2">
          {onExtractTasks && (
            <button
              onClick={onExtractTasks}
              disabled={isSynthesizing}
              className="active-press flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold bg-[var(--bg-surface-subtle)] hover:bg-[var(--ui-hover)] border border-[var(--border-default)] text-[var(--text-primary)] transition-all cursor-pointer disabled:opacity-50"
            >
              <Sparkles className="w-3.5 h-3.5 text-indigo-500" />
              <span>Extract Tasks</span>
            </button>
          )}

          {onSummarize && (
            <button
              onClick={onSummarize}
              disabled={isSynthesizing}
              className="active-press flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold bg-[var(--bg-surface-subtle)] hover:bg-[var(--ui-hover)] border border-[var(--border-default)] text-[var(--text-primary)] transition-all cursor-pointer disabled:opacity-50"
            >
              <Brain className="w-3.5 h-3.5 text-purple-500" />
              <span>Synthesize</span>
            </button>
          )}

          <button
            onClick={() => handleAddBlockBelow(blocks.length - 1)}
            className="active-press flex items-center gap-1 px-3 py-1.5 rounded-xl text-xs font-semibold bg-[var(--accent)] text-[var(--accent-text)] shadow-xs transition-all cursor-pointer"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Add Block</span>
          </button>
        </div>
      </div>

      {/* Interactive Block Stack */}
      <div className="space-y-2">
        {blocks.map((block, index) => {
          return (
            <div
              key={block.id}
              className="group relative flex items-start gap-2 p-2 rounded-xl hover:bg-[var(--bg-surface-subtle)]/70 transition-colors"
            >
              {/* Left Hover Controls (Move & Change Type) */}
              <div className="flex items-center gap-0.5 opacity-0 group-hover:opacity-100 transition-opacity pt-1 shrink-0">
                <button
                  onClick={() => handleMoveBlock(index, 'up')}
                  disabled={index === 0}
                  className="p-1 rounded text-[var(--text-tertiary)] hover:text-[var(--text-primary)] disabled:opacity-20 cursor-pointer"
                  title="Move Block Up"
                >
                  <ArrowUp className="w-3 h-3" />
                </button>
                <button
                  onClick={() => handleMoveBlock(index, 'down')}
                  disabled={index === blocks.length - 1}
                  className="p-1 rounded text-[var(--text-tertiary)] hover:text-[var(--text-primary)] disabled:opacity-20 cursor-pointer"
                  title="Move Block Down"
                >
                  <ArrowDown className="w-3 h-3" />
                </button>
                <button
                  onClick={() =>
                    setActiveMenuBlockId(activeMenuBlockId === block.id ? null : block.id)
                  }
                  className="p-1 rounded text-[var(--text-tertiary)] hover:text-[var(--accent)] cursor-pointer"
                  title="Change Block Type"
                >
                  <AlignLeft className="w-3.5 h-3.5" />
                </button>
              </div>

              {/* Block Content Canvas */}
              <div className="flex-1 min-w-0">
                {/* Heading 1 */}
                {block.type === 'heading1' && (
                  <input
                    type="text"
                    value={block.content}
                    onChange={(e) => handleUpdateContent(block.id, e.target.value)}
                    placeholder="Heading 1..."
                    className="w-full text-xl sm:text-2xl font-bold text-[var(--text-primary)] bg-transparent border-none focus:outline-hidden"
                  />
                )}

                {/* Heading 2 */}
                {block.type === 'heading2' && (
                  <input
                    type="text"
                    value={block.content}
                    onChange={(e) => handleUpdateContent(block.id, e.target.value)}
                    placeholder="Heading 2..."
                    className="w-full text-lg sm:text-xl font-bold text-[var(--text-primary)] bg-transparent border-none focus:outline-hidden"
                  />
                )}

                {/* Heading 3 */}
                {block.type === 'heading3' && (
                  <input
                    type="text"
                    value={block.content}
                    onChange={(e) => handleUpdateContent(block.id, e.target.value)}
                    placeholder="Heading 3..."
                    className="w-full text-base font-semibold text-[var(--text-primary)] bg-transparent border-none focus:outline-hidden"
                  />
                )}

                {/* Todo Checkbox */}
                {block.type === 'todo' && (
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => handleToggleCheck(block.id)}
                      className="text-[var(--text-tertiary)] hover:text-[var(--accent)] transition-colors cursor-pointer shrink-0"
                    >
                      {block.checked ? (
                        <CheckSquare className="w-4 h-4 text-emerald-500" />
                      ) : (
                        <Square className="w-4 h-4" />
                      )}
                    </button>
                    <input
                      type="text"
                      value={block.content}
                      onChange={(e) => handleUpdateContent(block.id, e.target.value)}
                      placeholder="To-do task item..."
                      className={`w-full text-xs sm:text-sm bg-transparent border-none focus:outline-hidden ${
                        block.checked ? 'line-through text-[var(--text-tertiary)]' : 'text-[var(--text-primary)]'
                      }`}
                    />
                  </div>
                )}

                {/* Bullet */}
                {block.type === 'bullet' && (
                  <div className="flex items-center gap-2">
                    <span className="w-1.5 h-1.5 rounded-full bg-[var(--text-tertiary)] shrink-0" />
                    <input
                      type="text"
                      value={block.content}
                      onChange={(e) => handleUpdateContent(block.id, e.target.value)}
                      placeholder="List item..."
                      className="w-full text-xs sm:text-sm text-[var(--text-primary)] bg-transparent border-none focus:outline-hidden"
                    />
                  </div>
                )}

                {/* Collapsible Toggle Block */}
                {block.type === 'toggle' && (
                  <div className="space-y-1 p-2 rounded-xl bg-[var(--bg-surface-subtle)] border border-[var(--border-subtle)]">
                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => handleToggleCollapse(block.id)}
                        className="p-1 rounded text-[var(--text-tertiary)] hover:text-[var(--text-primary)] cursor-pointer shrink-0"
                      >
                        {block.collapsed ? (
                          <ChevronRight className="w-3.5 h-3.5" />
                        ) : (
                          <ChevronDown className="w-3.5 h-3.5" />
                        )}
                      </button>
                      <input
                        type="text"
                        value={block.content}
                        onChange={(e) => handleUpdateContent(block.id, e.target.value)}
                        placeholder="Toggle header (click arrow to expand)..."
                        className="w-full text-xs sm:text-sm font-semibold text-[var(--text-primary)] bg-transparent border-none focus:outline-hidden"
                      />
                    </div>
                    {!block.collapsed && (
                      <div className="pl-6 pt-1 text-xs text-[var(--text-secondary)] italic">
                        Nested expandable section content...
                      </div>
                    )}
                  </div>
                )}

                {/* Quote */}
                {block.type === 'quote' && (
                  <div className="border-l-2 border-[var(--accent)] pl-3 py-1">
                    <input
                      type="text"
                      value={block.content}
                      onChange={(e) => handleUpdateContent(block.id, e.target.value)}
                      placeholder="Impactful quote or thesis..."
                      className="w-full text-xs sm:text-sm italic text-[var(--text-primary)] bg-transparent border-none focus:outline-hidden"
                    />
                  </div>
                )}

                {/* Callout */}
                {block.type === 'callout' && (
                  <div className="flex items-start gap-2 p-3 rounded-xl bg-amber-500/10 border border-amber-500/20 text-xs">
                    <span className="text-base leading-none">💡</span>
                    <input
                      type="text"
                      value={block.content}
                      onChange={(e) => handleUpdateContent(block.id, e.target.value)}
                      placeholder="Important highlight or takeaway..."
                      className="w-full text-xs text-[var(--text-primary)] bg-transparent border-none focus:outline-hidden"
                    />
                  </div>
                )}

                {/* Code */}
                {block.type === 'code' && (
                  <div className="p-3 rounded-xl bg-neutral-900 text-neutral-100 font-mono text-xs">
                    <textarea
                      value={block.content}
                      onChange={(e) => handleUpdateContent(block.id, e.target.value)}
                      placeholder="// code snippet..."
                      rows={3}
                      className="w-full bg-transparent border-none focus:outline-hidden resize-none font-mono"
                    />
                  </div>
                )}

                {/* Relational Life Object Embed Block */}
                {block.type === 'relation_embed' && (
                  <div className="flex items-center justify-between p-2.5 rounded-xl bg-[var(--bg-surface-elevated)] border border-[var(--border-focus)] shadow-xs">
                    <div className="flex items-center gap-2">
                      <Link2 className="w-4 h-4 text-[var(--accent)]" />
                      <span className="text-xs font-semibold text-[var(--text-primary)]">
                        Connected: {block.content}
                      </span>
                    </div>
                    <button
                      onClick={() => setRelationPickerBlockId(block.id)}
                      className="text-[11px] text-[var(--accent)] font-medium hover:underline cursor-pointer"
                    >
                      Change Link
                    </button>
                  </div>
                )}

                {/* Paragraph (Default) */}
                {block.type === 'paragraph' && (
                  <input
                    type="text"
                    value={block.content}
                    onChange={(e) => handleUpdateContent(block.id, e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') {
                        e.preventDefault();
                        handleAddBlockBelow(index);
                      }
                    }}
                    placeholder="Type text or press Enter for a new block..."
                    className="w-full text-xs sm:text-sm text-[var(--text-primary)] bg-transparent border-none focus:outline-hidden"
                  />
                )}

                {/* Divider */}
                {block.type === 'divider' && (
                  <div className="py-2">
                    <hr className="border-[var(--border-default)]" />
                  </div>
                )}
              </div>

              {/* Right Block Controls (Add / Delete / Connect) */}
              <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity pt-1 shrink-0">
                <button
                  onClick={() => setRelationPickerBlockId(block.id)}
                  className="p-1 rounded text-[var(--text-tertiary)] hover:text-[var(--accent)] cursor-pointer"
                  title="Embed Connected Life Object"
                >
                  <Link2 className="w-3.5 h-3.5" />
                </button>
                <button
                  onClick={() => handleAddBlockBelow(index)}
                  className="p-1 rounded text-[var(--text-tertiary)] hover:text-[var(--text-primary)] cursor-pointer"
                  title="Add Block Below"
                >
                  <Plus className="w-3.5 h-3.5" />
                </button>
                <button
                  onClick={() => handleDeleteBlock(block.id)}
                  className="p-1 rounded text-[var(--text-tertiary)] hover:text-rose-500 cursor-pointer"
                  title="Delete Block"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>

              {/* Change Type Popover */}
              {activeMenuBlockId === block.id && (
                <div className="absolute left-6 top-8 z-30 w-44 rounded-xl bg-[var(--bg-surface-elevated)] border border-[var(--border-default)] shadow-xl p-1.5 space-y-0.5 animate-in fade-in zoom-in-95">
                  <button
                    onClick={() => handleChangeType(block.id, 'paragraph')}
                    className="w-full text-left px-2.5 py-1.5 rounded-lg text-xs hover:bg-[var(--ui-hover)] flex items-center gap-2 cursor-pointer"
                  >
                    <AlignLeft className="w-3.5 h-3.5" /> Paragraph
                  </button>
                  <button
                    onClick={() => handleChangeType(block.id, 'heading1')}
                    className="w-full text-left px-2.5 py-1.5 rounded-lg text-xs hover:bg-[var(--ui-hover)] flex items-center gap-2 cursor-pointer"
                  >
                    <Heading1 className="w-3.5 h-3.5" /> Heading 1
                  </button>
                  <button
                    onClick={() => handleChangeType(block.id, 'heading2')}
                    className="w-full text-left px-2.5 py-1.5 rounded-lg text-xs hover:bg-[var(--ui-hover)] flex items-center gap-2 cursor-pointer"
                  >
                    <Heading2 className="w-3.5 h-3.5" /> Heading 2
                  </button>
                  <button
                    onClick={() => handleChangeType(block.id, 'heading3')}
                    className="w-full text-left px-2.5 py-1.5 rounded-lg text-xs hover:bg-[var(--ui-hover)] flex items-center gap-2 cursor-pointer"
                  >
                    <Heading3 className="w-3.5 h-3.5" /> Heading 3
                  </button>
                  <button
                    onClick={() => handleChangeType(block.id, 'todo')}
                    className="w-full text-left px-2.5 py-1.5 rounded-lg text-xs hover:bg-[var(--ui-hover)] flex items-center gap-2 cursor-pointer"
                  >
                    <CheckSquare className="w-3.5 h-3.5" /> To-do List
                  </button>
                  <button
                    onClick={() => handleChangeType(block.id, 'bullet')}
                    className="w-full text-left px-2.5 py-1.5 rounded-lg text-xs hover:bg-[var(--ui-hover)] flex items-center gap-2 cursor-pointer"
                  >
                    <List className="w-3.5 h-3.5" /> Bullet List
                  </button>
                  <button
                    onClick={() => handleChangeType(block.id, 'toggle')}
                    className="w-full text-left px-2.5 py-1.5 rounded-lg text-xs hover:bg-[var(--ui-hover)] flex items-center gap-2 cursor-pointer"
                  >
                    <ChevronRight className="w-3.5 h-3.5" /> Collapsible Toggle
                  </button>
                  <button
                    onClick={() => handleChangeType(block.id, 'quote')}
                    className="w-full text-left px-2.5 py-1.5 rounded-lg text-xs hover:bg-[var(--ui-hover)] flex items-center gap-2 cursor-pointer"
                  >
                    <Quote className="w-3.5 h-3.5" /> Quote
                  </button>
                  <button
                    onClick={() => handleChangeType(block.id, 'code')}
                    className="w-full text-left px-2.5 py-1.5 rounded-lg text-xs hover:bg-[var(--ui-hover)] flex items-center gap-2 cursor-pointer"
                  >
                    <Code className="w-3.5 h-3.5" /> Code Block
                  </button>
                </div>
              )}

              {/* Relation Embed Picker Popover */}
              {relationPickerBlockId === block.id && (
                <div className="absolute right-6 top-8 z-30 w-64 rounded-xl bg-[var(--bg-surface-elevated)] border border-[var(--border-default)] shadow-xl p-2.5 space-y-2 animate-in fade-in zoom-in-95">
                  <div className="flex items-center justify-between pb-1 border-b border-[var(--border-subtle)]">
                    <span className="text-xs font-bold text-[var(--text-primary)]">
                      Embed Connected Object
                    </span>
                    <button
                      onClick={() => setRelationPickerBlockId(null)}
                      className="text-xs text-[var(--text-tertiary)] hover:text-[var(--text-primary)]"
                    >
                      ✕
                    </button>
                  </div>
                  <div className="max-h-48 overflow-y-auto space-y-1">
                    {lifeObjects.slice(0, 15).map((obj) => (
                      <button
                        key={obj.id}
                        onClick={() => handleAttachRelation(block.id, obj)}
                        className="w-full text-left p-1.5 rounded-lg text-xs hover:bg-[var(--ui-hover)] flex items-center justify-between gap-1 transition-colors cursor-pointer"
                      >
                        <span className="truncate font-medium text-[var(--text-primary)]">
                          {obj.title}
                        </span>
                        <span className="text-[9px] uppercase font-mono px-1 rounded bg-[var(--bg-surface-subtle)] text-[var(--text-tertiary)] shrink-0">
                          {obj.type}
                        </span>
                      </button>
                    ))}
                  </div>
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
};
