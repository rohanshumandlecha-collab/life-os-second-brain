import React, { useState } from 'react';
import {
  FileText,
  Brain,
  Plus,
  Tag,
  Link2,
  Trash2,
  Sparkles,
  ArrowRight,
  FolderGit2,
  Pin,
  CheckCircle2,
  ChevronLeft,
  HelpCircle,
  LayoutList,
  Kanban,
  Table as TableIcon,
  Layers,
  Code2,
  Unlink,
  Target,
  CheckSquare,
  Clock,
  ExternalLink,
  X,
  Search,
} from 'lucide-react';
import { useLifeOS } from '../../context/LifeOSContext';
import { Note, NoteType, LifeObject, RelationType } from '../../types';
import { BlockNoteEditor } from './BlockNoteEditor';

export const NotesView: React.FC = () => {
  const {
    notesSubNav,
    setNotesSubNav,
    notes,
    projects,
    goals,
    tasks,
    lifeObjects,
    addNote,
    updateNote,
    deleteNote,
    addTask,
    updateNoteBlocks,
    linkObjects,
    unlinkObjects,
    saveAsTemplate,
    showToast,
    getAIHeaders,
    openHelpWithContext,
  } = useLifeOS();

  const [selectedNoteId, setSelectedNoteId] = useState<string | null>(
    notes.length > 0 ? notes[0].id : null
  );
  const [filterType, setFilterType] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [isSynthesizing, setIsSynthesizing] = useState(false);
  const [mobileShowEditor, setMobileShowEditor] = useState(false);

  // Multi-view mode: 'list' | 'board' | 'table'
  const [viewMode, setViewMode] = useState<'list' | 'board' | 'table'>('list');

  // Editor mode: 'blocks' | 'markdown'
  const [editorMode, setEditorMode] = useState<'blocks' | 'markdown'>('blocks');

  // Relation linker modal state
  const [showRelationPicker, setShowRelationPicker] = useState(false);
  const [relationTargetType, setRelationTargetType] = useState<'all' | 'project' | 'goal' | 'task' | 'note'>('all');
  const [relationSearch, setRelationSearch] = useState('');

  const activeNote = notes.find((n) => n.id === selectedNoteId) || null;

  const filteredNotes = notes.filter((n) => {
    if (filterType !== 'all' && n.type !== filterType) return false;
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      return (
        n.title.toLowerCase().includes(q) ||
        n.content.toLowerCase().includes(q) ||
        n.tags.some((t) => t.toLowerCase().includes(q))
      );
    }
    return true;
  });

  const handleCreateNewNote = (type: NoteType = 'note') => {
    const defaultType = notesSubNav === 'secondbrain' ? 'knowledge' : type;
    const created = addNote({
      title: 'Untitled Note',
      content: '',
      type: defaultType,
      tags: [],
      backlinks: [],
      linkedProjectIds: [],
    });
    setSelectedNoteId(created.id);
    setMobileShowEditor(true);
    showToast('New note created', 'success');
  };

  // AI Task Extraction from Note
  const handleExtractTasksWithAI = async () => {
    if (!activeNote || !activeNote.content.trim()) return;

    setIsSynthesizing(true);
    try {
      const res = await fetch('/api/ai/chat', {
        method: 'POST',
        headers: getAIHeaders(),
        body: JSON.stringify({
          message: `Extract actionable tasks from this note content. Output exactly one task per line starting with '- ': \n\n${activeNote.content}`,
          context: { noteTitle: activeNote.title },
        }),
      });

      if (res.ok) {
        const data = await res.json();
        const lines = data.reply
          .split('\n')
          .filter((l: string) => l.trim().startsWith('-') || l.trim().startsWith('•') || /^\d+\./.test(l.trim()))
          .map((l: string) => l.replace(/^[-•\d.]\s*/, '').trim())
          .filter((l: string) => l.length > 0);

        if (lines.length > 0) {
          lines.slice(0, 3).forEach((taskTitle: string) => {
            addTask({
              title: taskTitle,
              status: 'inbox',
              priority: 'medium',
              projectId: activeNote.linkedProjectIds?.[0] || undefined,
              subtasks: [],
              tags: ['extracted-note'],
            });
          });
          showToast(`Extracted ${Math.min(lines.length, 3)} task(s) to Inbox`, 'success');
        } else {
          showToast('No concrete tasks detected in note', 'info');
        }
      }
    } catch (e) {
      showToast('Could not reach AI task extractor', 'error');
    } finally {
      setIsSynthesizing(false);
    }
  };

  // AI Summarization
  const handleSummarizeNote = async () => {
    if (!activeNote || !activeNote.content.trim()) return;

    setIsSynthesizing(true);
    try {
      const res = await fetch('/api/ai/chat', {
        method: 'POST',
        headers: getAIHeaders(),
        body: JSON.stringify({
          message: `Summarize the key insights of this note into 3 concise bullet points with actionable takeaways: \n\n${activeNote.content}`,
        }),
      });

      if (res.ok) {
        const data = await res.json();
        const updatedContent = `${activeNote.content}\n\n---\n### AI Key Synthesis\n${data.reply}`;
        updateNote(activeNote.id, { content: updatedContent });
        showToast('Summary appended to note', 'success');
      }
    } catch (e) {
      showToast('Could not reach AI summarizer', 'error');
    } finally {
      setIsSynthesizing(false);
    }
  };

  const handleSaveNoteAsTemplate = () => {
    if (!activeNote) return;
    saveAsTemplate({
      title: activeNote.title,
      description: `Custom Template created from "${activeNote.title}"`,
      category: 'reading',
      icon: 'BookOpen',
    });
  };

  const noteCategories: { type: NoteType; label: string }[] = [
    { type: 'note', label: 'Quick Notes' },
    { type: 'knowledge', label: 'Second Brain & Knowledge' },
    { type: 'idea', label: 'Ideas & Sparks' },
    { type: 'research', label: 'Research' },
    { type: 'book_summary', label: 'Book Summaries' },
    { type: 'review', label: 'Reviews & Logs' },
    { type: 'document', label: 'Documents' },
  ];

  return (
    <div className="max-w-6xl mx-auto px-3.5 sm:px-6 py-5 sm:py-6 space-y-5 text-[var(--text-primary)]">
      {/* Header & View Controls */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-3 border-b border-[var(--border-default)]">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold tracking-tight text-[var(--text-primary)] flex items-center gap-2">
            {notesSubNav === 'secondbrain' ? (
              <>
                <Brain className="w-5 h-5 text-indigo-500" />
                <span>Second Brain & Knowledge Hub</span>
              </>
            ) : (
              <>
                <FileText className="w-5 h-5 text-emerald-500" />
                <span>Block Notes & Scratchpad</span>
              </>
            )}
          </h1>
          <p className="text-xs sm:text-sm text-[var(--text-secondary)] mt-0.5">
            {notesSubNav === 'secondbrain'
              ? 'Block-based, expandable, rich, and relational atomic thinking.'
              : 'Block-based notes, markdown scratchpads, properties, and project relations.'}
          </p>
        </div>

        <div className="flex items-center gap-2 self-start sm:self-auto flex-wrap">
          {/* View Switcher: List, Board, Table */}
          <div className="flex items-center p-1 rounded-xl bg-[var(--bg-surface-subtle)] border border-[var(--border-default)]">
            <button
              onClick={() => setViewMode('list')}
              className={`active-press px-2.5 py-1 rounded-lg text-xs font-semibold flex items-center gap-1 transition-colors cursor-pointer ${
                viewMode === 'list'
                  ? 'bg-[var(--accent)] text-[var(--accent-text)] shadow-xs'
                  : 'text-[var(--text-secondary)] hover:text-[var(--text-primary)]'
              }`}
              title="List & Split Editor View"
            >
              <LayoutList className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Editor</span>
            </button>
            <button
              onClick={() => setViewMode('board')}
              className={`active-press px-2.5 py-1 rounded-lg text-xs font-semibold flex items-center gap-1 transition-colors cursor-pointer ${
                viewMode === 'board'
                  ? 'bg-[var(--accent)] text-[var(--accent-text)] shadow-xs'
                  : 'text-[var(--text-secondary)] hover:text-[var(--text-primary)]'
              }`}
              title="Kanban Board View"
            >
              <Kanban className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Board</span>
            </button>
            <button
              onClick={() => setViewMode('table')}
              className={`active-press px-2.5 py-1 rounded-lg text-xs font-semibold flex items-center gap-1 transition-colors cursor-pointer ${
                viewMode === 'table'
                  ? 'bg-[var(--accent)] text-[var(--accent-text)] shadow-xs'
                  : 'text-[var(--text-secondary)] hover:text-[var(--text-primary)]'
              }`}
              title="Database Table View"
            >
              <TableIcon className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Table</span>
            </button>
          </div>

          <button
            onClick={() =>
              openHelpWithContext(notesSubNav === 'secondbrain' ? 'secondbrain' : 'notes')
            }
            className="active-press p-2 rounded-xl border border-[var(--border-default)] text-[var(--text-secondary)] hover:text-[var(--accent)] hover:bg-[var(--ui-hover)] transition-colors cursor-pointer"
            title="Notes & Second Brain Guide"
            aria-label="Notes Help"
          >
            <HelpCircle className="w-4 h-4" />
          </button>
          <button
            onClick={() => handleCreateNewNote()}
            className="active-press flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl text-xs font-semibold bg-[var(--accent)] text-[var(--accent-text)] hover:opacity-90 transition-all shadow-xs cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>New Note</span>
          </button>
        </div>
      </div>

      {/* ============================================================ */}
      {/* 1. LIST & SPLIT EDITOR VIEW */}
      {/* ============================================================ */}
      {viewMode === 'list' && (
        <div className="grid grid-cols-1 md:grid-cols-12 gap-5 min-h-[580px]">
          {/* Left Sidebar: Notes list */}
          <div className={`md:col-span-4 space-y-3 ${mobileShowEditor ? 'hidden md:block' : 'block'}`}>
            {/* Search & Filter */}
            <div className="space-y-2">
              <input
                type="text"
                placeholder="Search notes by title, tag, content..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full px-3.5 py-2 rounded-xl bg-[var(--bg-surface-input)] border border-[var(--border-default)] text-xs text-[var(--text-primary)] placeholder-[var(--text-tertiary)] focus:outline-hidden"
              />

              <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar pb-1">
                {['all', 'knowledge', 'idea', 'research', 'note'].map((t) => (
                  <button
                    key={t}
                    onClick={() => setFilterType(t)}
                    className={`active-press text-[11px] px-2.5 py-1 rounded-lg capitalize font-medium transition-colors cursor-pointer ${
                      filterType === t
                        ? 'bg-[var(--accent)] text-[var(--accent-text)] shadow-xs'
                        : 'bg-[var(--bg-surface-subtle)] text-[var(--text-secondary)] hover:text-[var(--text-primary)] border border-[var(--border-default)]'
                    }`}
                  >
                    {t}
                  </button>
                ))}
              </div>
            </div>

            {/* Notes Stack */}
            <div className="space-y-2 max-h-[640px] overflow-y-auto pr-1">
              {filteredNotes.length === 0 ? (
                <p className="text-xs text-[var(--text-tertiary)] p-6 text-center border border-dashed border-[var(--border-default)] rounded-2xl bg-[var(--bg-surface-subtle)]">
                  No notes found.
                </p>
              ) : (
                filteredNotes.map((note) => {
                  const isSelected = selectedNoteId === note.id;
                  const relationCount = (note.relations || []).length;
                  return (
                    <div
                      key={note.id}
                      onClick={() => {
                        setSelectedNoteId(note.id);
                        setMobileShowEditor(true);
                      }}
                      className={`active-press p-3.5 rounded-2xl border transition-all cursor-pointer ${
                        isSelected
                          ? 'bg-[var(--bg-surface-subtle)] border-[var(--border-focus)] shadow-xs'
                          : 'bg-[var(--bg-surface-elevated)] border border-[var(--border-default)] hover:border-[var(--border-focus)]'
                      }`}
                    >
                      <div className="flex items-start justify-between gap-1">
                        <h4 className="text-xs font-semibold text-[var(--text-primary)] truncate">
                          {note.title || 'Untitled Note'}
                        </h4>
                        {note.isPinned && <Pin className="w-3 h-3 text-amber-500 shrink-0" />}
                      </div>

                      <p className="text-[11px] text-[var(--text-secondary)] line-clamp-2 mt-1">
                        {note.content || 'Empty note...'}
                      </p>

                      <div className="flex items-center gap-1.5 mt-2 flex-wrap">
                        <span className="text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded-lg bg-[var(--bg-surface-subtle)] text-[var(--text-secondary)] border border-[var(--border-default)]">
                          {note.type}
                        </span>
                        {relationCount > 0 && (
                          <span className="text-[10px] font-mono px-1.5 py-0.5 rounded-md bg-purple-500/10 text-purple-600 dark:text-purple-400 flex items-center gap-0.5">
                            <Link2 className="w-2.5 h-2.5" />
                            {relationCount}
                          </span>
                        )}
                        {note.tags.map((tg) => (
                          <span key={tg} className="text-[10px] text-[var(--text-tertiary)]">
                            #{tg}
                          </span>
                        ))}
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          </div>

          {/* Right Editor Pane */}
          <div
            className={`md:col-span-8 p-4 sm:p-5 rounded-2xl bg-[var(--bg-surface-elevated)] border border-[var(--border-default)] space-y-4 shadow-xs ${
              !mobileShowEditor ? 'hidden md:block' : 'block'
            }`}
          >
            {activeNote ? (
              <>
                {/* Note Top Bar */}
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-[var(--border-default)]">
                  <div className="flex items-center gap-2 flex-1 min-w-0">
                    <button
                      onClick={() => setMobileShowEditor(false)}
                      className="md:hidden active-press p-1.5 rounded-lg text-[var(--text-tertiary)] hover:text-[var(--text-primary)] hover:bg-[var(--ui-hover)]"
                      aria-label="Back to notes list"
                    >
                      <ChevronLeft className="w-4 h-4" />
                    </button>
                    <input
                      type="text"
                      value={activeNote.title}
                      onChange={(e) => updateNote(activeNote.id, { title: e.target.value })}
                      placeholder="Note title..."
                      className="text-base sm:text-lg font-bold text-[var(--text-primary)] bg-transparent border-none focus:outline-hidden w-full"
                    />
                  </div>

                  <div className="flex items-center gap-1.5 flex-wrap">
                    {/* Mode Toggle: Blocks vs Raw Markdown */}
                    <div className="flex items-center p-0.5 rounded-lg bg-[var(--bg-surface-subtle)] border border-[var(--border-default)] text-xs">
                      <button
                        onClick={() => setEditorMode('blocks')}
                        className={`active-press px-2 py-0.5 rounded text-[11px] font-semibold transition-colors cursor-pointer ${
                          editorMode === 'blocks'
                            ? 'bg-[var(--accent)] text-[var(--accent-text)]'
                            : 'text-[var(--text-secondary)]'
                        }`}
                      >
                        Blocks
                      </button>
                      <button
                        onClick={() => setEditorMode('markdown')}
                        className={`active-press px-2 py-0.5 rounded text-[11px] font-semibold transition-colors cursor-pointer ${
                          editorMode === 'markdown'
                            ? 'bg-[var(--accent)] text-[var(--accent-text)]'
                            : 'text-[var(--text-secondary)]'
                        }`}
                      >
                        Markdown
                      </button>
                    </div>

                    <button
                      onClick={handleSaveNoteAsTemplate}
                      className="active-press p-1.5 text-[var(--text-secondary)] hover:text-purple-600 rounded-lg hover:bg-[var(--ui-hover)] transition-colors cursor-pointer"
                      title="Save as reusable Template"
                    >
                      <Layers className="w-3.5 h-3.5" />
                    </button>

                    <button
                      onClick={() => {
                        deleteNote(activeNote.id);
                        setSelectedNoteId(null);
                        setMobileShowEditor(false);
                      }}
                      className="active-press p-1.5 text-[var(--text-tertiary)] hover:text-rose-500 rounded-lg transition-colors cursor-pointer"
                      title="Delete Note"
                      aria-label="Delete Note"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>

                {/* Properties & Relations Bar */}
                <div className="p-3 rounded-xl bg-[var(--bg-surface-subtle)] border border-[var(--border-subtle)] space-y-2.5 text-xs">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                    {/* Note Type */}
                    <div className="flex items-center justify-between gap-2">
                      <span className="font-medium text-[var(--text-tertiary)]">Type:</span>
                      <select
                        value={activeNote.type}
                        onChange={(e) => updateNote(activeNote.id, { type: e.target.value as any })}
                        className="px-2 py-1 rounded-lg bg-[var(--bg-surface-elevated)] border border-[var(--border-default)] text-[var(--text-primary)] font-medium capitalize focus:outline-hidden"
                      >
                        <option value="note">Note</option>
                        <option value="knowledge">Knowledge</option>
                        <option value="idea">Idea</option>
                        <option value="research">Research</option>
                        <option value="book_summary">Book Summary</option>
                        <option value="review">Review</option>
                        <option value="document">Document</option>
                      </select>
                    </div>

                    {/* Linked Project */}
                    <div className="flex items-center justify-between gap-2">
                      <span className="font-medium text-[var(--text-tertiary)] flex items-center gap-1">
                        <FolderGit2 className="w-3 h-3" /> Project:
                      </span>
                      <select
                        value={activeNote.linkedProjectIds?.[0] || ''}
                        onChange={(e) =>
                          updateNote(activeNote.id, {
                            linkedProjectIds: e.target.value ? [e.target.value] : [],
                          })
                        }
                        className="px-2 py-1 rounded-lg bg-[var(--bg-surface-elevated)] border border-[var(--border-default)] text-[var(--text-primary)] font-medium focus:outline-hidden max-w-[160px] truncate"
                      >
                        <option value="">None</option>
                        {projects.map((p) => (
                          <option key={p.id} value={p.id}>
                            {p.title}
                          </option>
                        ))}
                      </select>
                    </div>
                  </div>

                  {/* Connected Relations Chips & Add Connection Button */}
                  <div className="pt-2 border-t border-[var(--border-subtle)] flex items-center justify-between gap-2 flex-wrap">
                    <div className="flex items-center gap-1.5 flex-wrap">
                      <span className="text-[11px] font-semibold text-[var(--text-secondary)] flex items-center gap-1">
                        <Link2 className="w-3 h-3 text-purple-500" />
                        Connections:
                      </span>
                      {(activeNote.relations || []).length === 0 ? (
                        <span className="text-[11px] text-[var(--text-tertiary)] italic">
                          No direct relations
                        </span>
                      ) : (
                        (activeNote.relations || []).map((rel) => (
                          <span
                            key={rel.id}
                            className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-[var(--bg-surface-elevated)] border border-[var(--border-default)] text-[11px] text-[var(--text-secondary)] font-medium"
                          >
                            <span className="text-[10px] text-purple-500 uppercase font-bold">
                              {rel.targetType}
                            </span>
                            <span className="truncate max-w-[120px]">
                              {rel.targetTitle || rel.targetId}
                            </span>
                            <button
                              onClick={() => unlinkObjects(activeNote.id, rel.targetId)}
                              className="text-[var(--text-tertiary)] hover:text-rose-500"
                              title="Unlink"
                            >
                              <X className="w-2.5 h-2.5" />
                            </button>
                          </span>
                        ))
                      )}
                    </div>

                    <button
                      onClick={() => setShowRelationPicker(true)}
                      className="active-press px-2 py-0.5 rounded-md bg-purple-500/10 text-purple-600 dark:text-purple-400 hover:bg-purple-500/20 text-[11px] font-semibold flex items-center gap-1 transition-colors cursor-pointer"
                    >
                      <Plus className="w-3 h-3" /> Connect Object
                    </button>
                  </div>
                </div>

                {/* Editor Surface */}
                {editorMode === 'blocks' ? (
                  <BlockNoteEditor
                    note={activeNote}
                    onUpdateBlocks={(blocks) => updateNoteBlocks(activeNote.id, blocks)}
                    onExtractTasks={handleExtractTasksWithAI}
                    onSummarize={handleSummarizeNote}
                    isSynthesizing={isSynthesizing}
                  />
                ) : (
                  <div className="space-y-2">
                    <div className="flex items-center justify-between text-xs text-[var(--text-tertiary)] font-mono">
                      <span>Raw Markdown Mode</span>
                      <div className="flex items-center gap-2">
                        <button
                          onClick={handleExtractTasksWithAI}
                          disabled={isSynthesizing}
                          className="active-press text-indigo-500 font-semibold flex items-center gap-1"
                        >
                          <Sparkles className="w-3 h-3" /> Extract
                        </button>
                        <button
                          onClick={handleSummarizeNote}
                          disabled={isSynthesizing}
                          className="active-press text-purple-500 font-semibold flex items-center gap-1"
                        >
                          <Brain className="w-3 h-3" /> Synthesize
                        </button>
                      </div>
                    </div>
                    <textarea
                      value={activeNote.content}
                      onChange={(e) => updateNote(activeNote.id, { content: e.target.value })}
                      placeholder="Write your note, thoughts, ideas, or markdown here..."
                      rows={16}
                      className="w-full p-3.5 rounded-2xl bg-[var(--bg-surface-input)] border border-[var(--border-default)] text-xs sm:text-sm text-[var(--text-primary)] font-mono leading-relaxed focus:outline-hidden resize-none"
                    />
                  </div>
                )}
              </>
            ) : (
              <div className="h-full flex items-center justify-center p-12 text-center text-[var(--text-tertiary)] text-sm">
                Select or create a note to begin.
              </div>
            )}
          </div>
        </div>
      )}

      {/* ============================================================ */}
      {/* 2. BOARD / KANBAN VIEW */}
      {/* ============================================================ */}
      {viewMode === 'board' && (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 overflow-x-auto pb-4">
          {['knowledge', 'note', 'idea', 'research'].map((typeKey) => {
            const colNotes = filteredNotes.filter((n) => n.type === typeKey);
            return (
              <div
                key={typeKey}
                className="p-3 rounded-2xl bg-[var(--bg-surface-elevated)] border border-[var(--border-default)] space-y-3 flex flex-col max-h-[700px]"
              >
                <div className="flex items-center justify-between pb-2 border-b border-[var(--border-subtle)]">
                  <div className="flex items-center gap-2">
                    <span className="w-2 h-2 rounded-full bg-[var(--accent)]" />
                    <h3 className="text-xs font-bold uppercase tracking-wider text-[var(--text-primary)]">
                      {typeKey}
                    </h3>
                  </div>
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-[var(--bg-surface-subtle)] text-[var(--text-tertiary)] font-bold">
                    {colNotes.length}
                  </span>
                </div>

                <div className="space-y-2 overflow-y-auto flex-1 pr-1">
                  {colNotes.map((note) => (
                    <div
                      key={note.id}
                      onClick={() => {
                        setSelectedNoteId(note.id);
                        setViewMode('list');
                        setMobileShowEditor(true);
                      }}
                      className="active-press p-3 rounded-xl bg-[var(--bg-surface-subtle)] border border-[var(--border-default)] hover:border-[var(--border-focus)] transition-all cursor-pointer space-y-1.5 shadow-xs"
                    >
                      <h4 className="text-xs font-semibold text-[var(--text-primary)] line-clamp-1">
                        {note.title || 'Untitled'}
                      </h4>
                      <p className="text-[11px] text-[var(--text-secondary)] line-clamp-2">
                        {note.content || 'Empty note...'}
                      </p>
                      <div className="flex items-center justify-between pt-1 text-[10px] text-[var(--text-tertiary)]">
                        <span>{new Date(note.updatedAt).toLocaleDateString()}</span>
                        {(note.relations || []).length > 0 && (
                          <span className="flex items-center gap-0.5 text-purple-600 dark:text-purple-400 font-mono">
                            <Link2 className="w-2.5 h-2.5" />
                            {note.relations?.length}
                          </span>
                        )}
                      </div>
                    </div>
                  ))}

                  <button
                    onClick={() => handleCreateNewNote(typeKey as NoteType)}
                    className="active-press w-full py-2 rounded-xl border border-dashed border-[var(--border-default)] text-xs text-[var(--text-tertiary)] hover:text-[var(--text-primary)] hover:border-[var(--accent)] flex items-center justify-center gap-1 transition-colors cursor-pointer"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>New in {typeKey}</span>
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* ============================================================ */}
      {/* 3. TABLE / DATABASE VIEW */}
      {/* ============================================================ */}
      {viewMode === 'table' && (
        <div className="rounded-2xl bg-[var(--bg-surface-elevated)] border border-[var(--border-default)] overflow-hidden shadow-xs">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-[var(--bg-surface-subtle)] border-b border-[var(--border-default)] text-[var(--text-secondary)] font-semibold uppercase tracking-wider text-[10px]">
                <tr>
                  <th className="py-3 px-4">Title</th>
                  <th className="py-3 px-4">Type</th>
                  <th className="py-3 px-4">Linked Project</th>
                  <th className="py-3 px-4">Tags</th>
                  <th className="py-3 px-4">Relations</th>
                  <th className="py-3 px-4">Updated</th>
                  <th className="py-3 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[var(--border-subtle)]">
                {filteredNotes.map((note) => {
                  const proj = projects.find((p) => p.id === note.linkedProjectIds?.[0]);
                  return (
                    <tr
                      key={note.id}
                      onClick={() => {
                        setSelectedNoteId(note.id);
                        setViewMode('list');
                        setMobileShowEditor(true);
                      }}
                      className="hover:bg-[var(--bg-surface-subtle)] transition-colors cursor-pointer group"
                    >
                      <td className="py-3 px-4 font-semibold text-[var(--text-primary)] max-w-[200px] truncate">
                        {note.title || 'Untitled'}
                      </td>
                      <td className="py-3 px-4">
                        <span className="text-[10px] uppercase font-bold px-2 py-0.5 rounded bg-[var(--bg-surface-input)] text-[var(--text-secondary)] border border-[var(--border-default)]">
                          {note.type}
                        </span>
                      </td>
                      <td className="py-3 px-4 text-[var(--text-secondary)] max-w-[150px] truncate">
                        {proj ? proj.title : '—'}
                      </td>
                      <td className="py-3 px-4">
                        <div className="flex items-center gap-1 flex-wrap max-w-[150px]">
                          {note.tags.length > 0 ? (
                            note.tags.map((t) => (
                              <span key={t} className="text-[10px] text-[var(--text-tertiary)]">
                                #{t}
                              </span>
                            ))
                          ) : (
                            <span className="text-[var(--text-tertiary)]">—</span>
                          )}
                        </div>
                      </td>
                      <td className="py-3 px-4">
                        <span className="font-mono text-purple-600 dark:text-purple-400 font-semibold">
                          {(note.relations || []).length}
                        </span>
                      </td>
                      <td className="py-3 px-4 text-[var(--text-tertiary)] whitespace-nowrap">
                        {new Date(note.updatedAt).toLocaleDateString()}
                      </td>
                      <td className="py-3 px-4 text-right">
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            setSelectedNoteId(note.id);
                            setViewMode('list');
                            setMobileShowEditor(true);
                          }}
                          className="active-press text-xs font-semibold text-[var(--accent)] hover:underline"
                        >
                          Open
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* ============================================================ */}
      {/* RELATION PICKER MODAL */}
      {/* ============================================================ */}
      {showRelationPicker && activeNote && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-md flex items-center justify-center p-4">
          <div className="w-full max-w-lg rounded-3xl bg-[var(--bg-surface-elevated)] border border-[var(--border-default)] shadow-2xl p-5 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-[var(--border-default)]">
              <div className="flex items-center gap-2">
                <div className="w-7 h-7 rounded-xl bg-purple-500/10 text-purple-600 dark:text-purple-400 flex items-center justify-center">
                  <Link2 className="w-4 h-4" />
                </div>
                <h3 className="text-sm font-bold text-[var(--text-primary)]">
                  Connect Life Object to Note
                </h3>
              </div>
              <button
                onClick={() => setShowRelationPicker(false)}
                className="text-[var(--text-tertiary)] hover:text-[var(--text-primary)]"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Target type filter */}
            <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar pb-1">
              {['all', 'project', 'goal', 'task', 'note'].map((tp) => (
                <button
                  key={tp}
                  onClick={() => setRelationTargetType(tp as any)}
                  className={`active-press px-2.5 py-1 rounded-lg text-xs font-medium capitalize transition-colors ${
                    relationTargetType === tp
                      ? 'bg-[var(--accent)] text-[var(--accent-text)]'
                      : 'bg-[var(--bg-surface-subtle)] text-[var(--text-secondary)] border border-[var(--border-default)]'
                  }`}
                >
                  {tp}
                </button>
              ))}
            </div>

            <div className="relative">
              <Search className="w-3.5 h-3.5 absolute left-3 top-3 text-[var(--text-tertiary)]" />
              <input
                type="text"
                value={relationSearch}
                onChange={(e) => setRelationSearch(e.target.value)}
                placeholder="Search object to link..."
                className="w-full pl-9 pr-3 py-2 rounded-xl bg-[var(--bg-surface-input)] border border-[var(--border-default)] text-xs text-[var(--text-primary)] focus:outline-hidden"
              />
            </div>

            <div className="space-y-1.5 max-h-[300px] overflow-y-auto">
              {lifeObjects
                .filter((obj) => obj.id !== activeNote.id)
                .filter((obj) => relationTargetType === 'all' || obj.type === relationTargetType)
                .filter((obj) =>
                  relationSearch.trim()
                    ? obj.title.toLowerCase().includes(relationSearch.toLowerCase())
                    : true
                )
                .slice(0, 10)
                .map((obj) => {
                  const alreadyLinked = (activeNote.relations || []).some(
                    (r) => r.targetId === obj.id
                  );
                  return (
                    <div
                      key={obj.id}
                      className="p-2.5 rounded-xl border border-[var(--border-default)] bg-[var(--bg-surface-subtle)] flex items-center justify-between gap-2"
                    >
                      <div className="min-w-0">
                        <span className="text-[10px] uppercase font-bold text-purple-600 dark:text-purple-400 block">
                          {obj.type}
                        </span>
                        <h4 className="text-xs font-semibold text-[var(--text-primary)] truncate">
                          {obj.title}
                        </h4>
                      </div>

                      {alreadyLinked ? (
                        <button
                          onClick={() => unlinkObjects(activeNote.id, obj.id)}
                          className="active-press px-2.5 py-1 rounded-lg text-xs font-semibold text-rose-500 bg-rose-500/10 hover:bg-rose-500/20"
                        >
                          Unlink
                        </button>
                      ) : (
                        <button
                          onClick={() => {
                            linkObjects(activeNote.id, 'note', obj.id, obj.type, 'linked');
                            setShowRelationPicker(false);
                          }}
                          className="active-press px-2.5 py-1 rounded-lg text-xs font-semibold bg-[var(--accent)] text-[var(--accent-text)]"
                        >
                          Connect
                        </button>
                      )}
                    </div>
                  );
                })}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
