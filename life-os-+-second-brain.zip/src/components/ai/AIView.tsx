import React, { useState, useRef, useEffect, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Sparkles,
  Send,
  Bot,
  User,
  Zap,
  CheckCircle2,
  AlertTriangle,
  RotateCcw,
  Sliders,
  Trash2,
  Plus,
  ArrowRight,
  ShieldCheck,
  Brain,
  Layers,
  Cpu,
  Search,
  MessageSquare,
  Clock,
  Edit2,
  Check,
  X,
  ChevronRight,
  ListFilter,
  History,
  Info,
} from 'lucide-react';
import { useLifeOS } from '../../context/LifeOSContext';
import {
  AIMemoryItem,
  AutomationRule,
  AppActionProposal,
  AIConversation,
  AIMessage,
  PipelineStage,
} from '../../types';

export const AIView: React.FC = () => {
  const {
    tasks,
    projects,
    goals,
    calendarEvents,
    habits,
    notes,
    energyLogs,
    financeItems,
    automations,
    toggleAutomation,
    addAutomation,
    aiMemories,
    addAIMemory,
    deleteAIMemory,
    toggleAIMemory,
    resetAIMemories,
    showToast,
    settings,
    toasts,
    homeWidgets,
    getAIHeaders,
    undoStack,
    executeAppAction,
    undoAction,
    aiConversations,
    activeConversationId,
    setActiveConversationId,
    createConversation,
    deleteConversation,
    renameConversation,
    addMessageToConversation,
    clearConversationMessages,
  } = useLifeOS();

  const [activeTab, setActiveTab] = useState<'chat' | 'automations' | 'memory' | 'architecture' | 'undo'>('chat');
  const [inputText, setInputText] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [pipelineStage, setPipelineStage] = useState<PipelineStage | null>(null);
  const [searchConvoQuery, setSearchConvoQuery] = useState('');
  const [editingConvoId, setEditingConvoId] = useState<string | null>(null);
  const [editingTitle, setEditingTitle] = useState('');
  const [showConvoDrawer, setShowConvoDrawer] = useState(false);
  const [executingActionId, setExecutingActionId] = useState<string | null>(null);

  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Active conversation
  const currentConversation = useMemo(() => {
    return (
      aiConversations.find((c) => c.id === activeConversationId) ||
      aiConversations[0] || {
        id: 'convo-fallback',
        title: 'Strategy Session',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
        messages: [],
      }
    );
  }, [aiConversations, activeConversationId]);

  // Filter conversations
  const filteredConversations = useMemo(() => {
    if (!searchConvoQuery.trim()) return aiConversations;
    const q = searchConvoQuery.toLowerCase();
    return aiConversations.filter(
      (c) =>
        c.title.toLowerCase().includes(q) ||
        c.messages.some((m) => m.text.toLowerCase().includes(q))
    );
  }, [aiConversations, searchConvoQuery]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [currentConversation.messages, isTyping, pipelineStage]);

  // Send Message with 8-Step Pipeline: Understand → Context → Plan → Validate → Confirm → Execute → Verify → Save
  const handleSendMessage = async (customPrompt?: string) => {
    const promptToSend = customPrompt || inputText;
    if (!promptToSend.trim() || isTyping) return;

    const userMsg: AIMessage = {
      id: 'msg-' + Date.now(),
      sender: 'user',
      text: promptToSend.trim(),
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    addMessageToConversation(currentConversation.id, userMsg);
    setInputText('');
    setIsTyping(true);

    // 1. Understand & Context stages
    setPipelineStage('understand');
    await new Promise((r) => setTimeout(r, 200));
    setPipelineStage('context');

    try {
      const todayStr = new Date().toISOString().split('T')[0];
      const tomorrowStr = new Date(Date.now() + 86400000).toISOString().split('T')[0];
      const liveContext = {
        userName: settings.userName,
        currentTime: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        todayStr,
        tomorrowStr,
        todayTasksCount: tasks.filter((t) => t.status === 'today').length,
        homeWidgets: homeWidgets.map((w) => ({ id: w.id, enabled: w.enabled, title: w.title })),
        tasks: tasks.map((t) => ({
          id: t.id,
          title: t.title,
          status: t.status,
          priority: t.priority,
          dueDate: t.dueDate,
          durationMinutes: t.durationMinutes,
          description: t.description,
        })),
        calendar: calendarEvents.map((e) => ({
          id: e.id,
          title: e.title,
          date: e.date,
          startTime: e.startTime,
          endTime: e.endTime,
          taskId: e.taskId,
        })),
        habits: habits.map((h) => ({ id: h.id, title: h.title, streak: h.streak })),
        activeProjects: projects.filter((p) => p.status === 'active').map((p) => ({ id: p.id, title: p.title, deadline: p.deadline })),
        activeGoals: goals.filter((g) => g.status === 'active').map((g) => ({ id: g.id, title: g.title, progress: g.progress })),
        memories: aiMemories.filter((m) => m.active).map((m) => `${m.category || 'rule'}: ${m.fact || m.content}`),
        recentEnergy: energyLogs[0]?.level || 'medium',
        settings: { theme: settings.theme, userName: settings.userName },
      };

      setPipelineStage('plan');

      const res = await fetch('/api/ai/chat', {
        method: 'POST',
        headers: getAIHeaders(),
        body: JSON.stringify({
          message: promptToSend,
          context: liveContext,
          messages: currentConversation.messages.map((m) => ({
            role: m.sender === 'user' ? 'user' : 'assistant',
            content: m.text,
          })),
        }),
      });

      let replyText = '';
      let proposedActions: AppActionProposal[] = [];

      if (res.ok) {
        const data = await res.json();
        replyText = data.reply || 'Understood.';

        if (Array.isArray(data.proposedActions) && data.proposedActions.length > 0) {
          proposedActions = data.proposedActions.map((act: any) => ({
            id: act.id || 'act-' + Math.random().toString(36).substring(2, 8),
            actionType: act.actionType || 'create_task',
            title: act.title || 'Execute Plan Item',
            description: act.details || 'Generated via AI Control Layer',
            requiresConfirmation: Boolean(act.requiresConfirmation),
            autoExecute: act.autoExecute ?? true,
            undoable: true,
            payload: act.payload || {},
            status: 'planned',
          }));
        }
      } else {
        throw new Error('AI gateway unavailable');
      }

      setPipelineStage('validate');

      // Auto-execute actions when appropriate (direct execution flow)
      if (proposedActions.length > 0) {
        for (const action of proposedActions) {
          if (action.autoExecute && !action.requiresConfirmation) {
            setPipelineStage('execute');
            const result = await executeAppAction(action);
            setPipelineStage('verify');
            action.status = result.ok ? 'verified' : 'failed';
            action.verificationMessage = result.message;
            await new Promise((r) => setTimeout(r, 150));
          }
        }
      }

      setPipelineStage('save');

      const aiMsg: AIMessage = {
        id: 'ai-' + Date.now(),
        sender: 'ai',
        text: replyText,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        type: proposedActions.length > 0 ? 'action_plan' : 'suggestion',
        proposedActions,
        pipelineStage: 'save',
      };

      addMessageToConversation(currentConversation.id, aiMsg);
    } catch (e: any) {
      console.warn('AI Chat fallback triggered:', e.message);
      // Local Heuristic Fallback with direct typed action execution
      const queryLower = promptToSend.toLowerCase();
      let fallbackReply = '';
      const proposed: AppActionProposal[] = [];

      if (queryLower.includes('how do i use') || queryLower.includes('how to use') || queryLower === 'help') {
        fallbackReply =
          `Here is how to use Life OS step-by-step:\n\n` +
          `1. **Quick Capture**: Press 'C' anywhere to instantly capture tasks, notes, or ideas.\n` +
          `2. **Home Dashboard**: Your 5-second morning overview with live clock, top 3 priorities, and schedule.\n` +
          `3. **Tasks**: GTD pipeline with Inbox, Today, Upcoming, and Someday views.\n` +
          `4. **Plan**: Time-block your calendar and track milestone progress on quarterly Goals.\n` +
          `5. **Life**: Build recurring daily Habits, monitor Project deadlines, and track Energy rhythm.\n` +
          `6. **Notes**: Your linked Second Brain for markdown documents and reference notes.\n` +
          `7. **AI Executive Partner**: Natural language commands to control the app with instant verification and 1-tap Undo.`;
      } else if (queryLower.includes('clock')) {
        fallbackReply = "I've added the Live Clock widget to your Home dashboard.";
        proposed.push({
          id: 'act-clock-' + Date.now(),
          actionType: 'add_home_widget',
          title: 'Add Live Clock to Home',
          description: 'Enables real-time clock widget on Home',
          requiresConfirmation: false,
          autoExecute: true,
          undoable: true,
          status: 'planned',
          payload: { widgetId: 'clock' },
        });
      } else if (queryLower.includes('move') && (queryLower.includes('5') || queryLower.includes('task'))) {
        const tomorrowStr = new Date(Date.now() + 86400000).toISOString().split('T')[0];
        fallbackReply = `I've moved your 5 PM task to tomorrow (${tomorrowStr}).`;
        proposed.push({
          id: 'act-move-' + Date.now(),
          actionType: 'update_task',
          title: 'Move 5 PM task to tomorrow',
          description: `Rescheduled to ${tomorrowStr}`,
          requiresConfirmation: false,
          autoExecute: true,
          undoable: true,
          status: 'planned',
          payload: {
            query: '5 PM',
            updates: { dueDate: tomorrowStr, status: 'upcoming' },
          },
        });
      } else if (queryLower.startsWith('create task') || queryLower.startsWith('add task')) {
        const title = promptToSend.replace(/^(create task|add task)\s*(for|to|:)?\s*/i, '').trim() || 'New Task';
        fallbackReply = `I've created the task: "${title}".`;
        proposed.push({
          id: 'act-task-' + Date.now(),
          actionType: 'create_task',
          title: `Create task "${title}"`,
          description: 'Added to your today queue',
          requiresConfirmation: false,
          autoExecute: true,
          undoable: true,
          status: 'planned',
          payload: {
            title,
            status: 'today',
            priority: 'medium',
          },
        });
      } else {
        fallbackReply = `I've inspected your current state: you have ${tasks.filter((t) => t.status === 'today').length} tasks today and ${calendarEvents.length} calendar events. What would you like me to do?`;
      }

      // Auto-execute fallback proposed actions
      if (proposed.length > 0) {
        for (const action of proposed) {
          if (action.autoExecute) {
            const res = await executeAppAction(action);
            action.status = res.ok ? 'verified' : 'failed';
            action.verificationMessage = res.message;
          }
        }
      }

      const aiMsg: AIMessage = {
        id: 'ai-' + Date.now(),
        sender: 'ai',
        text: fallbackReply,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        type: proposed.length > 0 ? 'action_plan' : 'suggestion',
        proposedActions: proposed,
      };

      addMessageToConversation(currentConversation.id, aiMsg);
    } finally {
      setIsTyping(false);
      setPipelineStage(null);
    }
  };

  // Execute an AI Proposed Action safely through App Action API
  const handleExecuteProposal = async (proposal: AppActionProposal) => {
    setExecutingActionId(proposal.id);
    setPipelineStage('execute');

    try {
      const result = await executeAppAction(proposal);
      setPipelineStage('verify');
      await new Promise((r) => setTimeout(r, 200));
      setPipelineStage('save');

      // Update proposal status in message
      proposal.status = result.ok ? 'verified' : 'failed';
      proposal.verificationMessage = result.message;
    } finally {
      setExecutingActionId(null);
      setTimeout(() => setPipelineStage(null), 1200);
    }
  };

  const handleStartRename = (convo: AIConversation) => {
    setEditingConvoId(convo.id);
    setEditingTitle(convo.title);
  };

  const handleSaveRename = (id: string) => {
    if (editingTitle.trim()) {
      renameConversation(id, editingTitle);
    }
    setEditingConvoId(null);
  };

  return (
    <div className="flex-1 flex flex-col h-full max-w-7xl mx-auto w-full px-2.5 sm:px-6 py-3 sm:py-5 overflow-hidden">
      {/* Top Header & Navigation Tabs */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-[var(--border-default)] shrink-0">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-xl bg-purple-500/15 text-purple-600 dark:text-purple-400 flex items-center justify-center shadow-xs">
            <Sparkles className="w-4 h-4 stroke-[2.3]" />
          </div>
          <div>
            <h1 className="text-base sm:text-lg font-bold tracking-tight text-[var(--text-primary)]">
              AI Executive Partner
            </h1>
            <p className="text-xs text-[var(--text-secondary)] hidden sm:block">
              8-Stage Control Pipeline: Understand → Plan → Validate → Execute → Verify → Undo
            </p>
          </div>
        </div>

        {/* View Tabs */}
        <div className="flex items-center gap-1 overflow-x-auto no-scrollbar pb-1 sm:pb-0">
          {[
            { id: 'chat', label: 'Partner Chat', icon: Bot },
            { id: 'automations', label: 'Automations', icon: Zap },
            { id: 'memory', label: 'Memory & Rules', icon: Brain },
            { id: 'architecture', label: 'Pipeline Architecture', icon: Layers },
            {
              id: 'undo',
              label: `Undo Stack (${undoStack.length})`,
              icon: RotateCcw,
              badge: undoStack.length > 0 ? undoStack.length : null,
            },
          ].map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`active-press flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-all cursor-pointer ${
                  isActive
                    ? 'bg-[var(--accent)] text-[var(--accent-text)] shadow-xs'
                    : 'bg-[var(--bg-surface-subtle)] text-[var(--text-secondary)] hover:text-[var(--text-primary)] border border-[var(--border-default)]'
                }`}
              >
                <Icon className="w-3.5 h-3.5" />
                <span>{tab.label}</span>
                {tab.badge && (
                  <span className="w-4 h-4 rounded-full bg-amber-500 text-white text-[10px] flex items-center justify-center font-bold">
                    {tab.badge}
                  </span>
                )}
              </button>
            );
          })}
        </div>
      </div>

      {/* Main Content Area */}
      <div className="flex-1 min-h-0 pt-3 flex overflow-hidden">
        {/* TAB 1: CHAT & CONVERSATION HISTORY */}
        {activeTab === 'chat' && (
          <div className="flex-1 flex flex-col md:flex-row gap-4 h-full overflow-hidden">
            {/* Conversations Sidebar (Desktop & collapsible on mobile) */}
            <div
              className={`${
                showConvoDrawer ? 'flex' : 'hidden md:flex'
              } flex-col w-full md:w-64 bg-[var(--bg-surface-elevated)] border border-[var(--border-default)] rounded-2xl p-3 shrink-0 h-full overflow-hidden shadow-xs`}
            >
              <div className="flex items-center justify-between pb-2.5 border-b border-[var(--border-default)]">
                <span className="text-xs font-bold text-[var(--text-primary)] flex items-center gap-1.5">
                  <History className="w-3.5 h-3.5 text-indigo-500" />
                  Chat History
                </span>
                <button
                  onClick={() => {
                    const id = createConversation();
                    setShowConvoDrawer(false);
                  }}
                  className="active-press flex items-center gap-1 px-2.5 py-1 rounded-lg text-xs font-semibold bg-[var(--accent)] text-[var(--accent-text)] shadow-xs cursor-pointer"
                >
                  <Plus className="w-3 h-3" />
                  <span>New</span>
                </button>
              </div>

              {/* Search conversations */}
              <div className="relative my-2">
                <Search className="w-3 h-3 absolute left-2.5 top-1/2 -translate-y-1/2 text-[var(--text-tertiary)]" />
                <input
                  type="text"
                  placeholder="Search chats..."
                  value={searchConvoQuery}
                  onChange={(e) => setSearchConvoQuery(e.target.value)}
                  className="w-full pl-7 pr-2.5 py-1.5 rounded-lg text-xs bg-[var(--bg-surface-subtle)] border border-[var(--border-default)] text-[var(--text-primary)] placeholder-[var(--text-tertiary)] focus:outline-hidden"
                />
              </div>

              {/* Convo List */}
              <div className="flex-1 overflow-y-auto space-y-1 no-scrollbar pt-1">
                {filteredConversations.map((convo) => {
                  const isActive = convo.id === currentConversation.id;
                  return (
                    <div
                      key={convo.id}
                      className={`group relative flex items-center justify-between p-2 rounded-xl text-xs font-medium cursor-pointer transition-colors ${
                        isActive
                          ? 'bg-[var(--accent)] text-[var(--accent-text)] font-semibold shadow-xs'
                          : 'text-[var(--text-secondary)] hover:bg-[var(--ui-hover)] hover:text-[var(--text-primary)]'
                      }`}
                      onClick={() => {
                        setActiveConversationId(convo.id);
                        setShowConvoDrawer(false);
                      }}
                    >
                      {editingConvoId === convo.id ? (
                        <div
                          className="flex items-center gap-1 w-full"
                          onClick={(e) => e.stopPropagation()}
                        >
                          <input
                            type="text"
                            value={editingTitle}
                            onChange={(e) => setEditingTitle(e.target.value)}
                            onKeyDown={(e) => e.key === 'Enter' && handleSaveRename(convo.id)}
                            className="flex-1 px-1.5 py-0.5 rounded text-xs bg-black/20 text-white border border-white/30 focus:outline-hidden"
                            autoFocus
                          />
                          <button
                            onClick={() => handleSaveRename(convo.id)}
                            className="p-1 hover:text-white"
                          >
                            <Check className="w-3 h-3" />
                          </button>
                        </div>
                      ) : (
                        <>
                          <div className="flex items-center gap-2 overflow-hidden pr-2">
                            <MessageSquare className="w-3.5 h-3.5 shrink-0" />
                            <span className="truncate">{convo.title}</span>
                          </div>
                          <div className="hidden group-hover:flex items-center gap-1 shrink-0">
                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                handleStartRename(convo);
                              }}
                              className="p-1 hover:opacity-80 transition-opacity"
                              title="Rename chat"
                            >
                              <Edit2 className="w-3 h-3" />
                            </button>
                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                deleteConversation(convo.id);
                              }}
                              className="p-1 hover:text-rose-400 transition-colors"
                              title="Delete chat"
                            >
                              <Trash2 className="w-3 h-3" />
                            </button>
                          </div>
                        </>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Main Chat Interface */}
            <div className="flex-1 flex flex-col h-full bg-[var(--bg-surface-elevated)] border border-[var(--border-default)] rounded-2xl overflow-hidden shadow-xs">
              {/* Active Convo Bar */}
              <div className="flex items-center justify-between px-3 sm:px-4 py-2.5 border-b border-[var(--border-default)] bg-[var(--bg-surface-subtle)]">
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => setShowConvoDrawer(!showConvoDrawer)}
                    className="md:hidden active-press p-1.5 rounded-lg bg-[var(--bg-surface-elevated)] border border-[var(--border-default)] text-xs text-[var(--text-secondary)]"
                    title="Toggle conversations drawer"
                  >
                    <History className="w-3.5 h-3.5" />
                  </button>
                  <span className="text-xs font-bold text-[var(--text-primary)] truncate">
                    {currentConversation.title}
                  </span>
                </div>

                <div className="flex items-center gap-1.5 text-xs text-[var(--text-tertiary)]">
                  <span className="hidden sm:inline">Provider:</span>
                  <span className="px-2 py-0.5 rounded-md bg-[var(--bg-surface-elevated)] border border-[var(--border-default)] font-mono text-[10px] text-indigo-500 font-semibold">
                    {settings.preferredAIProvider === 'openai' ? 'OpenAI' : 'Gemini'}
                  </span>
                  <button
                    onClick={() => clearConversationMessages(currentConversation.id)}
                    className="active-press p-1.5 rounded-lg hover:text-[var(--text-primary)] hover:bg-[var(--ui-hover)] transition-colors ml-1"
                    title="Clear messages in this chat"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>

              {/* Pipeline Live Stepper (when actively processing) */}
              <AnimatePresence>
                {pipelineStage && (
                  <motion.div
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: 'auto' }}
                    exit={{ opacity: 0, height: 0 }}
                    className="bg-indigo-500/10 border-b border-indigo-500/20 px-3 py-2 flex items-center justify-between text-xs"
                  >
                    <div className="flex items-center gap-2">
                      <span className="w-2 h-2 rounded-full bg-indigo-500 animate-ping" />
                      <span className="font-semibold text-indigo-600 dark:text-indigo-400 capitalize">
                        Pipeline: {pipelineStage}...
                      </span>
                    </div>
                    <div className="flex items-center gap-1 text-[10px] font-mono text-[var(--text-tertiary)] hidden sm:flex">
                      {['understand', 'context', 'plan', 'validate', 'execute', 'verify', 'save'].map(
                        (stg, i) => (
                          <span
                            key={stg}
                            className={`px-1 rounded ${
                              pipelineStage === stg
                                ? 'bg-indigo-500 text-white font-bold'
                                : 'opacity-40'
                            }`}
                          >
                            {stg[0].toUpperCase()}
                          </span>
                        )
                      )}
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>

              {/* Chat Message Stream */}
              <div className="flex-1 overflow-y-auto p-3 sm:p-4 space-y-4 no-scrollbar">
                {currentConversation.messages.map((msg) => {
                  const isUser = msg.sender === 'user';
                  return (
                    <motion.div
                      key={msg.id}
                      initial={{ opacity: 0, y: 8 }}
                      animate={{ opacity: 1, y: 0 }}
                      className={`flex gap-2.5 ${isUser ? 'justify-end' : 'justify-start'}`}
                    >
                      {!isUser && (
                        <div className="w-7 h-7 rounded-xl bg-purple-500/15 text-purple-600 dark:text-purple-400 flex items-center justify-center shrink-0 mt-0.5">
                          <Bot className="w-4 h-4" />
                        </div>
                      )}

                      <div
                        className={`max-w-[85%] sm:max-w-xl space-y-2.5 ${
                          isUser
                            ? 'bg-[var(--accent)] text-[var(--accent-text)] rounded-2xl rounded-tr-xs px-3.5 py-2.5 shadow-xs'
                            : 'bg-[var(--bg-surface-subtle)] border border-[var(--border-default)] text-[var(--text-primary)] rounded-2xl rounded-tl-xs p-3.5 shadow-xs'
                        }`}
                      >
                        <p className="text-xs sm:text-sm leading-relaxed whitespace-pre-wrap">
                          {msg.text}
                        </p>

                        {/* Proposed Action Cards */}
                        {msg.proposedActions && msg.proposedActions.length > 0 && (
                          <div className="space-y-2 pt-2 border-t border-[var(--border-default)]">
                            <div className="flex items-center gap-1.5 text-[10px] font-bold uppercase tracking-wider text-[var(--text-tertiary)]">
                              <ShieldCheck className="w-3.5 h-3.5 text-emerald-500" />
                              <span>Verified Action Proposal</span>
                            </div>

                            {msg.proposedActions.map((action) => {
                              const isExecuting = executingActionId === action.id;
                              const isVerified = action.status === 'verified';
                              return (
                                <div
                                  key={action.id}
                                  className="p-2.5 rounded-xl bg-[var(--bg-surface-elevated)] border border-[var(--border-default)] space-y-2"
                                >
                                  <div className="flex items-start justify-between gap-2">
                                    <div>
                                      <h4 className="text-xs font-bold text-[var(--text-primary)]">
                                        {action.title}
                                      </h4>
                                      <p className="text-[11px] text-[var(--text-secondary)] mt-0.5">
                                        {action.description}
                                      </p>
                                    </div>
                                    <span className="text-[10px] px-1.5 py-0.5 rounded font-mono uppercase bg-[var(--bg-surface-subtle)] text-[var(--text-tertiary)] shrink-0">
                                      {action.actionType.replace('_', ' ')}
                                    </span>
                                  </div>

                                  <div className="flex items-center justify-between pt-1 border-t border-[var(--border-subtle)]">
                                    {isVerified ? (
                                      <div className="flex items-center gap-1.5 text-xs text-emerald-600 dark:text-emerald-400 font-semibold">
                                        <CheckCircle2 className="w-3.5 h-3.5" />
                                        <span>Verified & Saved</span>
                                      </div>
                                    ) : (
                                      <button
                                        onClick={() => handleExecuteProposal(action)}
                                        disabled={isExecuting}
                                        className="active-press flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold bg-emerald-600 text-white hover:bg-emerald-700 transition-colors shadow-xs cursor-pointer disabled:opacity-50"
                                      >
                                        <Zap className="w-3.5 h-3.5" />
                                        <span>{isExecuting ? 'Executing...' : 'Confirm & Execute'}</span>
                                      </button>
                                    )}

                                    {action.undoable && (
                                      <button
                                        onClick={() => undoAction()}
                                        className="active-press flex items-center gap-1 text-xs text-amber-600 dark:text-amber-400 hover:underline cursor-pointer"
                                        title="Undo this action"
                                      >
                                        <RotateCcw className="w-3 h-3" />
                                        <span>Undo</span>
                                      </button>
                                    )}
                                  </div>
                                </div>
                              );
                            })}
                          </div>
                        )}

                        <div
                          className={`text-[10px] ${
                            isUser ? 'text-white/70 text-right' : 'text-[var(--text-tertiary)]'
                          }`}
                        >
                          {msg.timestamp}
                        </div>
                      </div>

                      {isUser && (
                        <div className="w-7 h-7 rounded-xl bg-[var(--accent)] text-[var(--accent-text)] flex items-center justify-center shrink-0 mt-0.5">
                          <User className="w-4 h-4" />
                        </div>
                      )}
                    </motion.div>
                  );
                })}

                {isTyping && (
                  <div className="flex items-center gap-2 text-xs text-[var(--text-tertiary)]">
                    <Bot className="w-4 h-4 animate-bounce" />
                    <span>Executive Partner reasoning with real state...</span>
                  </div>
                )}
                <div ref={messagesEndRef} />
              </div>

              {/* Chat Input Bar */}
              <div className="p-2.5 sm:p-3 border-t border-[var(--border-default)] bg-[var(--bg-surface-subtle)] space-y-2">
                {/* Quick Workflow Prompts */}
                <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar">
                  {[
                    'Plan today schedule based on my energy',
                    'Review stale or neglected goals',
                    'Extract actionable tasks from backlog',
                    'Schedule 60m deep work block tomorrow',
                  ].map((chip) => (
                    <button
                      key={chip}
                      onClick={() => handleSendMessage(chip)}
                      className="active-press px-2.5 py-1 rounded-lg text-[11px] bg-[var(--bg-surface-elevated)] border border-[var(--border-default)] text-[var(--text-secondary)] hover:text-[var(--text-primary)] whitespace-nowrap cursor-pointer transition-colors"
                    >
                      {chip}
                    </button>
                  ))}
                </div>

                {/* Input form */}
                <form
                  onSubmit={(e) => {
                    e.preventDefault();
                    handleSendMessage();
                  }}
                  className="flex items-center gap-2"
                >
                  <input
                    type="text"
                    value={inputText}
                    onChange={(e) => setInputText(e.target.value)}
                    placeholder="Message your Executive Partner (e.g. Schedule 45m deep work on Project X)..."
                    className="flex-1 px-3.5 py-2.5 rounded-xl text-xs sm:text-sm bg-[var(--bg-surface-elevated)] border border-[var(--border-default)] text-[var(--text-primary)] placeholder-[var(--text-tertiary)] focus:outline-hidden"
                  />
                  <button
                    type="submit"
                    disabled={!inputText.trim() || isTyping}
                    className="active-press px-4 py-2.5 rounded-xl text-xs sm:text-sm font-semibold bg-[var(--accent)] text-[var(--accent-text)] hover:opacity-90 disabled:opacity-40 transition-all shadow-xs cursor-pointer flex items-center gap-1.5 shrink-0"
                  >
                    <Send className="w-3.5 h-3.5" />
                    <span className="hidden sm:inline">Send</span>
                  </button>
                </form>
              </div>
            </div>
          </div>
        )}

        {/* TAB 2: AUTOMATIONS */}
        {activeTab === 'automations' && (
          <div className="flex-1 overflow-y-auto space-y-3 no-scrollbar p-1">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-sm font-bold text-[var(--text-primary)]">
                  Event-Driven Automations
                </h2>
                <p className="text-xs text-[var(--text-secondary)]">
                  Reactive rules connecting your tasks, habits, and focus schedules.
                </p>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {automations.map((rule) => (
                <div
                  key={rule.id}
                  className="p-3.5 rounded-2xl bg-[var(--bg-surface-elevated)] border border-[var(--border-default)] space-y-2 shadow-xs"
                >
                  <div className="flex items-center justify-between">
                    <h3 className="text-xs font-bold text-[var(--text-primary)]">
                      {rule.title}
                    </h3>
                    <button
                      onClick={() => toggleAutomation(rule.id)}
                      className={`active-press px-2 py-0.5 rounded-md text-[10px] font-bold uppercase transition-colors cursor-pointer ${
                        rule.enabled
                          ? 'bg-emerald-500/15 text-emerald-600 dark:text-emerald-400 border border-emerald-500/30'
                          : 'bg-[var(--bg-surface-subtle)] text-[var(--text-tertiary)] border border-[var(--border-default)]'
                      }`}
                    >
                      {rule.enabled ? 'Enabled' : 'Disabled'}
                    </button>
                  </div>
                  <p className="text-xs text-[var(--text-secondary)] leading-relaxed">
                    {rule.description}
                  </p>
                  <div className="text-[10px] font-mono text-[var(--text-tertiary)] pt-1 border-t border-[var(--border-subtle)]">
                    Trigger: {rule.trigger} → Action: {rule.action}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* TAB 3: AI MEMORY & RULES */}
        {activeTab === 'memory' && (
          <div className="flex-1 overflow-y-auto space-y-3 no-scrollbar p-1">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-sm font-bold text-[var(--text-primary)]">
                  AI Memory & Working Rules
                </h2>
                <p className="text-xs text-[var(--text-secondary)]">
                  Explicit user rules and preferences that guide AI recommendations.
                </p>
              </div>
              <button
                onClick={resetAIMemories}
                className="active-press text-xs text-rose-500 hover:underline cursor-pointer"
              >
                Reset All
              </button>
            </div>

            <div className="space-y-2">
              {aiMemories.map((mem) => (
                <div
                  key={mem.id}
                  className="flex items-center justify-between p-3 rounded-xl bg-[var(--bg-surface-elevated)] border border-[var(--border-default)] shadow-xs text-xs"
                >
                  <div className="flex items-center gap-2">
                    <span className="w-2 h-2 rounded-full bg-indigo-500" />
                    <div>
                      <span className="font-semibold text-[var(--text-primary)]">
                        {mem.fact || mem.content}
                      </span>
                      <span className="text-[10px] text-[var(--text-tertiary)] block">
                        Category: {mem.category || 'General'}
                      </span>
                    </div>
                  </div>
                  <button
                    onClick={() => deleteAIMemory(mem.id)}
                    className="active-press p-1.5 rounded-lg text-[var(--text-tertiary)] hover:text-rose-500 cursor-pointer"
                    title="Delete rule"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* TAB 4: PIPELINE ARCHITECTURE VISUALIZATION */}
        {activeTab === 'architecture' && (
          <div className="flex-1 overflow-y-auto space-y-4 no-scrollbar p-1">
            <div className="p-4 rounded-2xl bg-[var(--bg-surface-elevated)] border border-[var(--border-default)] space-y-3 shadow-xs">
              <h2 className="text-sm font-bold text-[var(--text-primary)] flex items-center gap-2">
                <Layers className="w-4 h-4 text-indigo-500" />
                8-Stage Verified Action Pipeline
              </h2>
              <p className="text-xs text-[var(--text-secondary)] leading-relaxed">
                Life OS does not execute arbitrary model-generated scripts. Every request passes through this strict deterministic pipeline with state verification and full rollback capability.
              </p>

              <div className="space-y-2 pt-2">
                {[
                  {
                    stage: '1. Understand',
                    desc: 'Strict natural language understanding and entity extraction (task, habit, project, calendar, note).',
                  },
                  {
                    stage: '2. Context',
                    desc: 'Injects live database graph snapshot (active projects, goals, daily rhythm, energy, and user preferences).',
                  },
                  {
                    stage: '3. Plan',
                    desc: 'Generates structured AppActionProposal with typed payloads and expected outcome.',
                  },
                  {
                    stage: '4. Validate',
                    desc: 'Validates input fields, format constraints, permissions, and non-destructive integrity.',
                  },
                  {
                    stage: '5. Confirm',
                    desc: 'Explicit user confirmation step for bulk, project-level, or destructive changes.',
                  },
                  {
                    stage: '6. Execute',
                    desc: 'Calls the strictly typed App Action API handlers in the state engine.',
                  },
                  {
                    stage: '7. Verify',
                    desc: 'Queries internal state to confirm the entity actually exists and reflects the requested change.',
                  },
                  {
                    stage: '8. Save & Undo',
                    desc: 'Commits state to persistent storage and pushes snapshot to the multi-action Undo stack.',
                  },
                ].map((item, idx) => (
                  <div
                    key={idx}
                    className="p-2.5 rounded-xl bg-[var(--bg-surface-subtle)] border border-[var(--border-default)] text-xs flex items-start gap-2.5"
                  >
                    <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0 mt-0.5" />
                    <div>
                      <span className="font-bold text-[var(--text-primary)]">{item.stage}</span>
                      <p className="text-[11px] text-[var(--text-secondary)] mt-0.5">{item.desc}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* TAB 5: UNDO STACK */}
        {activeTab === 'undo' && (
          <div className="flex-1 overflow-y-auto space-y-3 no-scrollbar p-1">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-sm font-bold text-[var(--text-primary)]">
                  Action Undo Stack
                </h2>
                <p className="text-xs text-[var(--text-secondary)]">
                  Recent actions executed via the App Action API. Tap Undo to restore exact state.
                </p>
              </div>
              {undoStack.length > 0 && (
                <button
                  onClick={() => undoAction()}
                  className="active-press flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold bg-amber-500/10 text-amber-600 dark:text-amber-400 border border-amber-500/30 cursor-pointer hover:bg-amber-500/20"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  <span>Undo Top Action</span>
                </button>
              )}
            </div>

            {undoStack.length === 0 ? (
              <div className="p-8 rounded-2xl bg-[var(--bg-surface-elevated)] border border-[var(--border-default)] text-center text-xs text-[var(--text-secondary)]">
                No recent actions in the undo stack. Reversible AI actions will appear here.
              </div>
            ) : (
              <div className="space-y-2">
                {undoStack.map((item) => (
                  <div
                    key={item.id}
                    className="flex items-center justify-between p-3.5 rounded-2xl bg-[var(--bg-surface-elevated)] border border-[var(--border-default)] shadow-xs text-xs"
                  >
                    <div>
                      <h4 className="font-bold text-[var(--text-primary)]">{item.title}</h4>
                      <p className="text-[11px] text-[var(--text-tertiary)]">
                        Executed at {item.timestamp} • Type: {item.actionType}
                      </p>
                    </div>
                    <button
                      onClick={() => undoAction(item.id)}
                      className="active-press flex items-center gap-1 px-2.5 py-1.5 rounded-xl text-xs font-semibold bg-[var(--bg-surface-subtle)] border border-[var(--border-default)] text-amber-600 dark:text-amber-400 hover:bg-[var(--ui-hover)] transition-colors cursor-pointer"
                    >
                      <RotateCcw className="w-3.5 h-3.5" />
                      <span>Undo</span>
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};
