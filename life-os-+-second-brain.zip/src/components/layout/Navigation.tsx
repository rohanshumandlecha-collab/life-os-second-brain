import React from 'react';
import { motion } from 'motion/react';
import {
  Home,
  CheckSquare,
  Calendar,
  BookOpen,
  Compass,
  Sparkles,
  Clock,
  Target,
  FileText,
  Brain,
  FolderGit2,
  Repeat,
  DollarSign,
  Zap,
  Layers,
  Star,
  TrendingUp,
  Plus,
} from 'lucide-react';
import { useLifeOS } from '../../context/LifeOSContext';
import { MainNav, PlanSubNav, NotesSubNav, LifeSubNav, TemplatesSubNav } from '../../types';

export const Navigation: React.FC = () => {
  const {
    activeNav,
    setActiveNav,
    planSubNav,
    setPlanSubNav,
    notesSubNav,
    setNotesSubNav,
    lifeSubNav,
    setLifeSubNav,
    templatesSubNav,
    setTemplatesSubNav,
    tasks,
  } = useLifeOS();

  const todayPendingTasks = tasks.filter((t) => t.status === 'today').length;

  const mainTabs: { id: MainNav; label: string; icon: any; badge?: number }[] = [
    { id: 'home', label: 'Home', icon: Home },
    { id: 'tasks', label: 'Tasks', icon: CheckSquare, badge: todayPendingTasks > 0 ? todayPendingTasks : undefined },
    { id: 'plan', label: 'Plan', icon: Calendar },
    { id: 'notes', label: 'Notes', icon: BookOpen },
    { id: 'life', label: 'Life', icon: Compass },
    { id: 'templates', label: 'Templates', icon: Layers },
    { id: 'ai', label: 'Assistant', icon: Sparkles },
  ];

  return (
    <>
      {/* ============================================================ */}
      {/* 1. DESKTOP TOP NAVIGATION BAR (hidden on mobile)            */}
      {/* ============================================================ */}
      <nav
        id="desktop-main-navigation"
        className="hidden sm:block w-full ios-glass border-b border-[var(--border-default)] transition-colors select-none"
      >
        <div className="max-w-5xl mx-auto px-4 sm:px-6">
          {/* Main Segmented Tab Row */}
          <div className="flex items-center space-x-1 sm:space-x-2 py-2 overflow-x-auto no-scrollbar">
            {mainTabs.map((tab) => {
              const Icon = tab.icon;
              const isActive = activeNav === tab.id;
              return (
                <button
                  key={tab.id}
                  id={`nav-tab-${tab.id}`}
                  onClick={() => setActiveNav(tab.id)}
                  className={`active-press relative flex items-center gap-2 px-3.5 py-1.5 rounded-xl text-xs sm:text-sm font-medium transition-colors whitespace-nowrap cursor-pointer ${
                    isActive
                      ? 'text-[var(--accent)] font-semibold'
                      : 'text-[var(--text-secondary)] hover:text-[var(--text-primary)] hover:bg-[var(--ui-hover)]'
                  }`}
                >
                  {isActive && (
                    <motion.div
                      layoutId="desktopNavBackground"
                      transition={{ type: 'spring', stiffness: 450, damping: 32 }}
                      className="absolute inset-0 bg-[var(--ui-selected)] rounded-xl border border-[var(--border-subtle)] shadow-xs"
                    />
                  )}
                  <span className="relative z-10 flex items-center gap-1.5">
                    <Icon className="w-4 h-4" />
                    <span>{tab.label}</span>
                    {tab.badge !== undefined && (
                      <span
                        className={`px-1.5 py-0.2 text-[10px] rounded-full font-bold tabular-nums ${
                          isActive
                            ? 'bg-[var(--accent)] text-[var(--accent-text)]'
                            : 'bg-[var(--bg-surface-input)] text-[var(--text-secondary)]'
                        }`}
                      >
                        {tab.badge}
                      </span>
                    )}
                  </span>
                </button>
              );
            })}
          </div>

          {/* Contextual Sub-Navigation */}
          {activeNav === 'plan' && (
            <motion.div
              initial={{ opacity: 0, y: -4 }}
              animate={{ opacity: 1, y: 0 }}
              className="flex items-center gap-1.5 py-1.5 border-t border-[var(--border-subtle)] overflow-x-auto no-scrollbar"
            >
              {(
                [
                  { id: 'calendar', label: 'Calendar', icon: Calendar },
                  { id: 'timeblocking', label: 'Time Blocking', icon: Clock },
                  { id: 'goals', label: 'Goals', icon: Target },
                ] as { id: PlanSubNav; label: string; icon: any }[]
              ).map((sub) => {
                const SubIcon = sub.icon;
                const isSubActive = planSubNav === sub.id;
                return (
                  <button
                    key={sub.id}
                    id={`plan-sub-${sub.id}`}
                    onClick={() => setPlanSubNav(sub.id)}
                    className={`active-press flex items-center gap-1.5 px-3 py-1 rounded-lg text-xs font-medium transition-colors cursor-pointer ${
                      isSubActive
                        ? 'bg-[var(--bg-surface-elevated)] text-[var(--text-primary)] font-semibold shadow-xs border border-[var(--border-default)]'
                        : 'text-[var(--text-secondary)] hover:text-[var(--text-primary)]'
                    }`}
                  >
                    <SubIcon className="w-3.5 h-3.5" />
                    <span>{sub.label}</span>
                  </button>
                );
              })}
            </motion.div>
          )}

          {activeNav === 'notes' && (
            <motion.div
              initial={{ opacity: 0, y: -4 }}
              animate={{ opacity: 1, y: 0 }}
              className="flex items-center gap-1.5 py-1.5 border-t border-[var(--border-subtle)] overflow-x-auto no-scrollbar"
            >
              {(
                [
                  { id: 'notes', label: 'Notes', icon: FileText },
                  { id: 'secondbrain', label: 'Second Brain', icon: Brain },
                ] as { id: NotesSubNav; label: string; icon: any }[]
              ).map((sub) => {
                const SubIcon = sub.icon;
                const isSubActive = notesSubNav === sub.id;
                return (
                  <button
                    key={sub.id}
                    id={`notes-sub-${sub.id}`}
                    onClick={() => setNotesSubNav(sub.id)}
                    className={`active-press flex items-center gap-1.5 px-3 py-1 rounded-lg text-xs font-medium transition-colors cursor-pointer ${
                      isSubActive
                        ? 'bg-[var(--bg-surface-elevated)] text-[var(--text-primary)] font-semibold shadow-xs border border-[var(--border-default)]'
                        : 'text-[var(--text-secondary)] hover:text-[var(--text-primary)]'
                    }`}
                  >
                    <SubIcon className="w-3.5 h-3.5" />
                    <span>{sub.label}</span>
                  </button>
                );
              })}
            </motion.div>
          )}

          {activeNav === 'life' && (
            <motion.div
              initial={{ opacity: 0, y: -4 }}
              animate={{ opacity: 1, y: 0 }}
              className="flex items-center gap-1.5 py-1.5 border-t border-[var(--border-subtle)] overflow-x-auto no-scrollbar"
            >
              {(
                [
                  { id: 'projects', label: 'Projects', icon: FolderGit2 },
                  { id: 'habits', label: 'Habits', icon: Repeat },
                  { id: 'money', label: 'Money', icon: DollarSign },
                  { id: 'energy', label: 'Energy & Rhythms', icon: Zap },
                ] as { id: LifeSubNav; label: string; icon: any }[]
              ).map((sub) => {
                const SubIcon = sub.icon;
                const isSubActive = lifeSubNav === sub.id;
                return (
                  <button
                    key={sub.id}
                    id={`life-sub-${sub.id}`}
                    onClick={() => setLifeSubNav(sub.id)}
                    className={`active-press flex items-center gap-1.5 px-3 py-1 rounded-lg text-xs font-medium transition-colors cursor-pointer ${
                      isSubActive
                        ? 'bg-[var(--bg-surface-elevated)] text-[var(--text-primary)] font-semibold shadow-xs border border-[var(--border-default)]'
                        : 'text-[var(--text-secondary)] hover:text-[var(--text-primary)]'
                    }`}
                  >
                    <SubIcon className="w-3.5 h-3.5" />
                    <span>{sub.label}</span>
                  </button>
                );
              })}
            </motion.div>
          )}

          {activeNav === 'templates' && (
            <motion.div
              initial={{ opacity: 0, y: -4 }}
              animate={{ opacity: 1, y: 0 }}
              className="flex items-center gap-1.5 py-1.5 border-t border-[var(--border-subtle)] overflow-x-auto no-scrollbar"
            >
              {(
                [
                  { id: 'featured', label: 'Featured', icon: Star },
                  { id: 'popular', label: 'Popular', icon: TrendingUp },
                  { id: 'new', label: 'New', icon: Sparkles },
                  { id: 'recommended', label: 'Recommended', icon: Target },
                  { id: 'categories', label: 'Categories', icon: Layers },
                  { id: 'my-templates', label: 'My Templates', icon: BookOpen },
                  { id: 'create', label: 'Create Template', icon: Plus },
                ] as { id: TemplatesSubNav; label: string; icon: any }[]
              ).map((sub) => {
                const SubIcon = sub.icon;
                const isSubActive = templatesSubNav === sub.id;
                return (
                  <button
                    key={sub.id}
                    id={`templates-sub-${sub.id}`}
                    onClick={() => setTemplatesSubNav(sub.id)}
                    className={`active-press flex items-center gap-1.5 px-3 py-1 rounded-lg text-xs font-medium transition-colors cursor-pointer ${
                      isSubActive
                        ? 'bg-[var(--bg-surface-elevated)] text-[var(--text-primary)] font-semibold shadow-xs border border-[var(--border-default)]'
                        : 'text-[var(--text-secondary)] hover:text-[var(--text-primary)]'
                    }`}
                  >
                    <SubIcon className="w-3.5 h-3.5" />
                    <span>{sub.label}</span>
                  </button>
                );
              })}
            </motion.div>
          )}
        </div>
      </nav>

      {/* ============================================================ */}
      {/* 2. MOBILE SUB-NAVIGATION BAR (Sticky under header on mobile) */}
      {/* ============================================================ */}
      {(activeNav === 'plan' || activeNav === 'notes' || activeNav === 'life' || activeNav === 'templates') && (
        <div className="sm:hidden w-full ios-glass border-b border-[var(--border-default)] px-3 py-1.5 overflow-x-auto no-scrollbar select-none z-20">
          <div className="flex items-center gap-1 bg-[var(--bg-surface-subtle)] p-0.5 rounded-xl min-w-max">
            {activeNav === 'plan' &&
              (
                [
                  { id: 'calendar', label: 'Calendar' },
                  { id: 'timeblocking', label: 'Blocks' },
                  { id: 'goals', label: 'Goals' },
                ] as { id: PlanSubNav; label: string }[]
              ).map((sub) => (
                <button
                  key={sub.id}
                  onClick={() => setPlanSubNav(sub.id)}
                  className={`active-press flex-1 text-center py-1 px-2.5 rounded-lg text-xs font-medium transition-all ${
                    planSubNav === sub.id
                      ? 'bg-[var(--bg-surface-elevated)] text-[var(--text-primary)] font-semibold shadow-xs'
                      : 'text-[var(--text-secondary)]'
                  }`}
                >
                  {sub.label}
                </button>
              ))}

            {activeNav === 'notes' &&
              (
                [
                  { id: 'notes', label: 'Notes' },
                  { id: 'secondbrain', label: 'Brain' },
                ] as { id: NotesSubNav; label: string }[]
              ).map((sub) => (
                <button
                  key={sub.id}
                  onClick={() => setNotesSubNav(sub.id)}
                  className={`active-press flex-1 text-center py-1 px-2.5 rounded-lg text-xs font-medium transition-all ${
                    notesSubNav === sub.id
                      ? 'bg-[var(--bg-surface-elevated)] text-[var(--text-primary)] font-semibold shadow-xs'
                      : 'text-[var(--text-secondary)]'
                  }`}
                >
                  {sub.label}
                </button>
              ))}

            {activeNav === 'life' &&
              (
                [
                  { id: 'projects', label: 'Projects' },
                  { id: 'habits', label: 'Habits' },
                  { id: 'money', label: 'Money' },
                  { id: 'energy', label: 'Energy' },
                ] as { id: LifeSubNav; label: string }[]
              ).map((sub) => (
                <button
                  key={sub.id}
                  onClick={() => setLifeSubNav(sub.id)}
                  className={`active-press flex-1 text-center py-1 px-2.5 rounded-lg text-xs font-medium transition-all ${
                    lifeSubNav === sub.id
                      ? 'bg-[var(--bg-surface-elevated)] text-[var(--text-primary)] font-semibold shadow-xs'
                      : 'text-[var(--text-secondary)]'
                  }`}
                >
                  {sub.label}
                </button>
              ))}

            {activeNav === 'templates' &&
              (
                [
                  { id: 'featured', label: 'Featured' },
                  { id: 'popular', label: 'Popular' },
                  { id: 'new', label: 'New' },
                  { id: 'recommended', label: 'For You' },
                  { id: 'categories', label: 'Categories' },
                  { id: 'my-templates', label: 'My Templates' },
                  { id: 'create', label: '+ Create' },
                ] as { id: TemplatesSubNav; label: string }[]
              ).map((sub) => (
                <button
                  key={sub.id}
                  onClick={() => setTemplatesSubNav(sub.id)}
                  className={`active-press flex-1 text-center py-1 px-2.5 rounded-lg text-xs font-medium whitespace-nowrap transition-all ${
                    templatesSubNav === sub.id
                      ? 'bg-[var(--bg-surface-elevated)] text-[var(--text-primary)] font-semibold shadow-xs'
                      : 'text-[var(--text-secondary)]'
                  }`}
                >
                  {sub.label}
                </button>
              ))}
          </div>
        </div>
      )}

      {/* ============================================================ */}
      {/* 3. iOS MOBILE BOTTOM TAB BAR (fixed at bottom on mobile)     */}
      {/* ============================================================ */}
      <nav
        id="mobile-bottom-navigation"
        className="sm:hidden fixed bottom-0 left-0 right-0 z-40 ios-glass border-t border-[var(--border-default)] pb-safe transition-all select-none"
      >
        <div className="grid grid-cols-7 items-center h-14 px-0.5">
          {mainTabs.map((tab) => {
            const Icon = tab.icon;
            const isActive = activeNav === tab.id;
            return (
              <button
                key={tab.id}
                id={`mobile-tab-${tab.id}`}
                onClick={() => setActiveNav(tab.id)}
                className="active-press flex flex-col items-center justify-center h-full relative cursor-pointer group"
                aria-label={tab.label}
              >
                <div className="relative">
                  <Icon
                    className={`w-5 h-5 transition-all duration-150 ${
                      isActive
                        ? 'text-[var(--accent)] scale-105 stroke-[2.2]'
                        : 'text-[var(--text-tertiary)] group-hover:text-[var(--text-secondary)] stroke-[1.8]'
                    }`}
                  />
                  {tab.badge !== undefined && (
                    <span className="absolute -top-1 -right-2 min-w-[15px] h-[15px] px-1 bg-[var(--error)] text-white text-[9px] font-bold rounded-full flex items-center justify-center shadow-xs">
                      {tab.badge}
                    </span>
                  )}
                </div>
                <span
                  className={`text-[9px] sm:text-[10px] font-medium tracking-tight mt-0.5 truncate max-w-full px-0.5 transition-colors ${
                    isActive
                      ? 'text-[var(--accent)] font-semibold'
                      : 'text-[var(--text-tertiary)]'
                  }`}
                >
                  {tab.label}
                </span>
              </button>
            );
          })}
        </div>
      </nav>
    </>
  );
};
