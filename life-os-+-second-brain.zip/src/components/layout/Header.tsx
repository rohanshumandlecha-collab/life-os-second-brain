import React from 'react';
import { motion } from 'motion/react';
import {
  Sparkles,
  Search,
  Plus,
  Clock,
  Settings as SettingsIcon,
  BookOpen,
  HelpCircle,
  Sun,
  Moon,
  Laptop,
  Volume2,
  VolumeX,
  Layers,
} from 'lucide-react';
import { useLifeOS } from '../../context/LifeOSContext';
import { soundscapes } from '../../utils/audioSynth';

export const Header: React.FC = () => {
  const {
    activeNav,
    setActiveNav,
    settings,
    updateSettings,
    setIsCaptureOpen,
    setIsSearchOpen,
    setIsFocusOpen,
    setIsSettingsOpen,
    setIsHelpOpen,
    setIsTemplateModalOpen,
  } = useLifeOS();

  const cycleTheme = () => {
    const current = settings.theme || 'system';
    const next = current === 'system' ? 'dark' : current === 'dark' ? 'light' : 'system';
    updateSettings({ theme: next });
  };

  const isAmbientPlaying = soundscapes.getCurrentType() !== 'none';

  const toggleSound = () => {
    if (isAmbientPlaying) {
      soundscapes.stop();
      updateSettings({ ambientSound: 'none' });
    } else {
      soundscapes.play('rain', 0.25);
      updateSettings({ ambientSound: 'rain' });
    }
  };

  const today = new Date();
  const dateFormatted = today.toLocaleDateString('en-US', {
    weekday: 'short',
    month: 'short',
    day: 'numeric',
  });

  return (
    <header
      id="main-header"
      className="sticky top-0 z-30 flex items-center justify-between px-3.5 sm:px-6 h-14 pt-safe ios-glass border-b border-[var(--border-default)] transition-colors select-none"
    >
      {/* Brand & Date */}
      <div className="flex items-center gap-2.5 shrink-0">
        <div className="flex items-center gap-2">
          <motion.div
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.94 }}
            transition={{ type: 'spring', stiffness: 450, damping: 25 }}
            className="w-7 h-7 rounded-lg bg-[var(--accent)] flex items-center justify-center text-[var(--accent-text)] shadow-xs"
          >
            <Sparkles className="w-4 h-4 stroke-[2.2]" />
          </motion.div>
          <span className="font-semibold text-sm tracking-tight text-[var(--text-primary)]">
            Life OS
          </span>
        </div>
        <span className="text-[var(--text-tertiary)] hidden sm:inline text-xs">•</span>
        <span className="text-xs font-medium text-[var(--text-secondary)] hidden sm:inline">
          {dateFormatted}
        </span>
      </div>

      {/* Global Action Tools */}
      <div className="flex items-center gap-1 sm:gap-1.5">
        {/* Universal Search trigger */}
        <button
          id="btn-global-search"
          onClick={() => setIsSearchOpen(true)}
          className="active-press flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl text-xs font-medium text-[var(--text-secondary)] hover:text-[var(--text-primary)] hover:bg-[var(--ui-hover)] transition-colors cursor-pointer border border-[var(--border-default)] min-h-[36px]"
          title="Search anything (Cmd+K)"
          aria-label="Search"
        >
          <Search className="w-3.5 h-3.5 shrink-0" />
          <span className="hidden md:inline">Search</span>
          <kbd className="hidden lg:inline px-1 py-0.5 text-[10px] rounded bg-[var(--bg-surface-subtle)] border border-[var(--border-default)] text-[var(--text-tertiary)]">
            ⌘K
          </kbd>
        </button>

        {/* Universal Quick Capture trigger */}
        <button
          id="btn-global-capture"
          onClick={() => setIsCaptureOpen(true)}
          className="active-press flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-medium bg-[var(--accent)] text-[var(--accent-text)] hover:opacity-90 transition-all shadow-xs cursor-pointer min-h-[36px]"
          title="Universal Quick Capture (Press C)"
          aria-label="Universal Quick Capture"
        >
          <Plus className="w-3.5 h-3.5 shrink-0 stroke-[2.5]" />
          <span className="hidden xs:inline">Capture</span>
          <kbd className="hidden md:inline px-1 py-0.5 text-[10px] rounded bg-white/20 text-white">
            C
          </kbd>
        </button>

        {/* Templates System launcher button */}
        <button
          id="btn-global-templates"
          onClick={() => setActiveNav('templates')}
          className={`active-press hidden sm:flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl text-xs font-medium transition-all shadow-xs cursor-pointer min-h-[36px] ${
            activeNav === 'templates'
              ? 'text-purple-600 dark:text-purple-300 bg-purple-500/20 border border-purple-500/40 ring-1 ring-purple-500/30'
              : 'text-purple-600 dark:text-purple-400 bg-purple-500/10 hover:bg-purple-500/20 border border-purple-500/20'
          }`}
          title="Template Library & AI Generator"
          aria-label="Templates"
        >
          <Layers className="w-3.5 h-3.5 shrink-0" />
          <span className="hidden md:inline">Templates</span>
        </button>

        {/* Ambient Sound toggle - hidden on small mobile */}
        <button
          id="btn-toggle-sound"
          onClick={toggleSound}
          className={`active-press hidden sm:flex items-center justify-center p-2 rounded-xl text-xs transition-colors cursor-pointer min-w-[36px] min-h-[36px] ${
            isAmbientPlaying
              ? 'text-emerald-500 bg-emerald-500/10'
              : 'text-[var(--text-secondary)] hover:bg-[var(--ui-hover)] hover:text-[var(--text-primary)]'
          }`}
          title={isAmbientPlaying ? 'Mute ambient sound' : 'Play ambient sound (Rain)'}
          aria-label="Ambient Sound"
        >
          {isAmbientPlaying ? <Volume2 className="w-4 h-4 animate-pulse" /> : <VolumeX className="w-4 h-4" />}
        </button>

        {/* Focus Mode trigger - hidden on mobile */}
        <button
          id="btn-open-focus"
          onClick={() => setIsFocusOpen(true)}
          className="active-press hidden md:flex items-center justify-center p-2 rounded-xl text-xs font-medium text-[var(--text-secondary)] hover:text-[var(--text-primary)] hover:bg-[var(--ui-hover)] transition-colors cursor-pointer min-w-[36px] min-h-[36px]"
          title="Focus Mode & Timer"
          aria-label="Focus Mode"
        >
          <Clock className="w-4 h-4" />
        </button>

        {/* PROMINENT "HOW TO USE" / AI GUIDE BUTTON - ALWAYS VISIBLE ON TOP */}
        <button
          id="btn-open-help"
          onClick={() => setIsHelpOpen(true)}
          className="active-press flex items-center gap-1.5 px-2.5 sm:px-3 py-1.5 rounded-xl text-xs font-semibold bg-indigo-500/10 text-indigo-600 dark:text-indigo-400 hover:bg-indigo-500/20 border border-indigo-500/25 transition-all cursor-pointer min-h-[36px] shadow-xs"
          title="How to Use Life OS & AI Tutor Guide"
          aria-label="How to Use & Guide"
        >
          <BookOpen className="w-3.5 h-3.5 shrink-0 stroke-[2.4]" />
          <span className="hidden xs:inline sm:hidden">Guide</span>
          <span className="hidden sm:inline">How to Use</span>
        </button>

        {/* 3-State Theme toggle */}
        <button
          id="btn-toggle-theme"
          onClick={cycleTheme}
          className="active-press flex items-center justify-center p-2 rounded-xl text-[var(--text-secondary)] hover:text-[var(--text-primary)] hover:bg-[var(--ui-hover)] transition-colors cursor-pointer min-w-[36px] min-h-[36px]"
          title={`Theme: ${settings.theme || 'system'} (Click to cycle)`}
          aria-label="Toggle theme"
        >
          {settings.theme === 'light' ? (
            <Sun className="w-4 h-4 text-amber-500" />
          ) : settings.theme === 'dark' ? (
            <Moon className="w-4 h-4 text-indigo-400" />
          ) : (
            <Laptop className="w-4 h-4 text-[var(--text-secondary)]" />
          )}
        </button>

        {/* DEDICATED SETTINGS ICON ON TOP - ALWAYS VISIBLE */}
        <button
          id="btn-header-settings-icon"
          onClick={() => setIsSettingsOpen(true)}
          className="active-press flex items-center justify-center p-2 rounded-xl text-[var(--text-secondary)] hover:text-[var(--text-primary)] hover:bg-[var(--ui-hover)] border border-[var(--border-default)] transition-colors cursor-pointer min-w-[36px] min-h-[36px]"
          title="Settings & AI Backbone (Gemini, OpenAI, Keys, Data)"
          aria-label="Settings"
        >
          <SettingsIcon className="w-4 h-4" />
        </button>

        {/* User Profile Avatar */}
        <button
          id="btn-open-profile-avatar"
          onClick={() => setIsSettingsOpen(true)}
          className="active-press p-0.5 rounded-full border border-[var(--border-default)] hover:border-[var(--accent)] transition-colors cursor-pointer flex items-center justify-center shrink-0 min-w-[32px] min-h-[32px]"
          title={`Profile & Account: ${settings.userName || 'User'}`}
          aria-label="User Profile"
        >
          {settings.userAvatar ? (
            <img
              src={settings.userAvatar}
              alt={settings.userName}
              className="w-6 h-6 rounded-full object-cover"
            />
          ) : (
            <div className="w-6 h-6 rounded-full bg-[var(--accent)] text-[var(--accent-text)] flex items-center justify-center font-semibold text-[11px]">
              {settings.userName?.slice(0, 1).toUpperCase() || 'U'}
            </div>
          )}
        </button>
      </div>
    </header>
  );
};
