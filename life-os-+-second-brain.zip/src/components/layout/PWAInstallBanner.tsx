import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Download, Share, X, Smartphone, CheckCircle2, HelpCircle } from 'lucide-react';
import { usePWAInstall } from '../../hooks/usePWAInstall';
import { PWAInstallModal } from '../modals/PWAInstallModal';

export const PWAInstallBanner: React.FC = () => {
  const {
    isInstallable,
    isInstalled,
    isIOS,
    isAndroid,
    promptInstall,
    isBannerDismissed,
    dismissBanner,
  } = usePWAInstall();

  const [isModalOpen, setIsModalOpen] = useState(false);

  // If already installed in standalone mode or user dismissed, don't show the floating banner
  if (isInstalled || isBannerDismissed) {
    return null;
  }

  const handleInstallClick = async () => {
    if (isInstallable) {
      const outcome = await promptInstall();
      if (outcome === 'fallback') {
        setIsModalOpen(true);
      }
    } else {
      setIsModalOpen(true);
    }
  };

  return (
    <>
      <AnimatePresence>
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: 50 }}
          className="fixed bottom-18 sm:bottom-6 left-3 right-3 sm:left-auto sm:right-6 sm:max-w-md z-40 bg-[var(--bg-surface-elevated)] border border-[var(--border-default)] p-3.5 sm:p-4 rounded-3xl shadow-2xl backdrop-blur-xl flex flex-col gap-2.5"
        >
          <div className="flex items-start justify-between gap-3">
            <div className="flex items-center gap-3 min-w-0">
              <div className="w-9 h-9 rounded-2xl bg-[var(--accent)] text-[var(--accent-text)] flex items-center justify-center shrink-0 shadow-xs">
                <Download className="w-4 h-4 stroke-[2.5]" />
              </div>
              <div className="min-w-0">
                <h4 className="text-xs sm:text-sm font-bold text-[var(--text-primary)] leading-tight truncate">
                  Install Life OS
                </h4>
                <p className="text-[11px] text-[var(--text-secondary)] mt-0.5 truncate">
                  {isInstallable
                    ? 'Native Android Chrome install ready'
                    : 'Add to Home Screen for offline access'}
                </p>
              </div>
            </div>

            <button
              onClick={dismissBanner}
              className="text-[var(--text-tertiary)] hover:text-[var(--text-primary)] p-1.5 rounded-xl hover:bg-[var(--bg-surface-subtle)] transition-colors cursor-pointer shrink-0"
              aria-label="Dismiss install banner"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          <div className="flex items-center justify-between pt-2 border-t border-[var(--border-subtle)]">
            <button
              onClick={() => setIsModalOpen(true)}
              className="flex items-center gap-1 text-[11px] text-[var(--text-secondary)] hover:text-[var(--text-primary)] transition-colors cursor-pointer"
            >
              <HelpCircle className="w-3.5 h-3.5" />
              <span>Instructions</span>
            </button>

            <div className="flex items-center gap-2">
              <button
                onClick={dismissBanner}
                className="px-2.5 py-1.5 rounded-xl text-xs font-medium text-[var(--text-secondary)] hover:text-[var(--text-primary)] cursor-pointer transition-colors"
              >
                Later
              </button>
              <button
                onClick={handleInstallClick}
                className="active-press flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl text-xs font-bold bg-[var(--accent)] text-[var(--accent-text)] hover:opacity-95 shadow-xs cursor-pointer"
              >
                {isIOS ? (
                  <Share className="w-3.5 h-3.5" />
                ) : (
                  <Download className="w-3.5 h-3.5" />
                )}
                <span>{isInstallable ? 'Install Now' : 'Install Life OS'}</span>
              </button>
            </div>
          </div>
        </motion.div>
      </AnimatePresence>

      <PWAInstallModal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} />
    </>
  );
};
