import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  CheckCircle2,
  Circle,
  Plus,
  Clock,
  ChevronDown,
  ChevronRight,
  Trash2,
  Calendar,
  Zap,
  Repeat,
  Tag,
  Check,
  X,
  SlidersHorizontal,
  HelpCircle,
  LayoutList,
  Kanban,
  Table as TableIcon,
  CalendarDays,
  FolderGit2,
  Target,
  ArrowRight,
} from 'lucide-react';
import { useLifeOS } from '../../context/LifeOSContext';
import { Task, TaskStatus, Priority, EnergyLevel } from '../../types';

export const TasksView: React.FC = () => {
  const {
    tasks,
    projects,
    goals,
    addTask,
    updateTask,
    deleteTask,
    toggleTaskComplete,
    toggleSubtask,
    openHelpWithContext,
  } = useLifeOS();

  // Multi-View state: 'list' | 'board' | 'table' | 'timeline'
  const [viewMode, setViewMode] = useState<'list' | 'board' | 'table' | 'timeline'>('list');

  const [activeTab, setActiveTab] = useState<TaskStatus | 'all'>('today');
  const [priorityFilter, setPriorityFilter] = useState<string>('all');
  const [projectFilter, setProjectFilter] = useState<string>('all');
  const [expandedTaskId, setExpandedTaskId] = useState<string | null>(null);
  const [isAddingTask, setIsAddingTask] = useState(false);
  const [showAdvanced, setShowAdvanced] = useState(false);
  const [quickInlineTitle, setQuickInlineTitle] = useState('');

  // New task form state
  const [newTitle, setNewTitle] = useState('');
  const [newDesc, setNewDesc] = useState('');
  const [newStatus, setNewStatus] = useState<TaskStatus>('today');
  const [newPriority, setNewPriority] = useState<Priority>('medium');
  const [newDueDate, setNewDueDate] = useState(new Date().toISOString().split('T')[0]);
  const [newDuration, setNewDuration] = useState<number>(30);
  const [newEnergy, setNewEnergy] = useState<EnergyLevel>('medium');
  const [newProjectId, setNewProjectId] = useState<string>('');
  const [newGoalId, setNewGoalId] = useState<string>('');
  const [newRecurring, setNewRecurring] = useState<'none' | 'daily' | 'weekly' | 'monthly'>('none');
  const [newSubtaskTitle, setNewSubtaskTitle] = useState('');

  // Filter tasks
  const filteredTasks = tasks.filter((t) => {
    if (viewMode === 'list' && activeTab !== 'all' && t.status !== activeTab) return false;
    if (priorityFilter !== 'all' && t.priority !== priorityFilter) return false;
    if (projectFilter !== 'all' && t.projectId !== projectFilter) return false;
    return true;
  });

  const handleCreateTask = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim()) return;

    addTask({
      title: newTitle.trim(),
      description: newDesc.trim() || undefined,
      status: newStatus,
      priority: newPriority,
      dueDate: newDueDate || undefined,
      durationMinutes: newDuration || 30,
      energyRequired: newEnergy,
      projectId: newProjectId || undefined,
      goalId: newGoalId || undefined,
      recurring: newRecurring,
      subtasks: [],
      tags: [],
    });

    setNewTitle('');
    setNewDesc('');
    setIsAddingTask(false);
    setShowAdvanced(false);
  };

  const handleQuickInlineAdd = (e: React.FormEvent) => {
    e.preventDefault();
    if (!quickInlineTitle.trim()) return;

    addTask({
      title: quickInlineTitle.trim(),
      status: activeTab === 'all' ? 'today' : activeTab,
      priority: 'medium',
      dueDate: new Date().toISOString().split('T')[0],
      durationMinutes: 30,
      energyRequired: 'medium',
      subtasks: [],
      tags: [],
    });

    setQuickInlineTitle('');
  };

  const handleAddSubtaskToTask = (taskId: string) => {
    if (!newSubtaskTitle.trim()) return;
    const task = tasks.find((t) => t.id === taskId);
    if (!task) return;

    const newSub = {
      id: 'sub-' + Date.now(),
      title: newSubtaskTitle.trim(),
      completed: false,
    };
    updateTask(taskId, { subtasks: [...task.subtasks, newSub] });
    setNewSubtaskTitle('');
  };

  const statusTabs: { id: TaskStatus | 'all'; label: string; count: number }[] = [
    { id: 'today', label: 'Today', count: tasks.filter((t) => t.status === 'today').length },
    { id: 'inbox', label: 'Inbox', count: tasks.filter((t) => t.status === 'inbox').length },
    { id: 'upcoming', label: 'Upcoming', count: tasks.filter((t) => t.status === 'upcoming').length },
    { id: 'completed', label: 'Completed', count: tasks.filter((t) => t.status === 'completed').length },
    { id: 'all', label: 'All', count: tasks.length },
  ];

  const kanbanColumns: { status: TaskStatus; label: string; color: string }[] = [
    { status: 'inbox', label: 'Inbox', color: 'bg-zinc-500' },
    { status: 'today', label: 'Today', color: 'bg-purple-500' },
    { status: 'upcoming', label: 'Upcoming', color: 'bg-blue-500' },
    { status: 'completed', label: 'Completed', color: 'bg-emerald-500' },
  ];

  return (
    <div className="max-w-5xl mx-auto px-3.5 sm:px-6 py-5 sm:py-6 space-y-5 text-[var(--text-primary)]">
      {/* Header & View Switcher */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-2 border-b border-[var(--border-subtle)]">
        <div>
          <span className="text-[11px] font-semibold uppercase tracking-wider text-[var(--text-tertiary)] block">
            Organization & Action
          </span>
          <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-[var(--text-primary)]">
            Tasks
          </h1>
        </div>

        <div className="flex items-center gap-2 flex-wrap">
          {/* Multi-View Switcher */}
          <div className="flex items-center p-1 rounded-xl bg-[var(--bg-surface-subtle)] border border-[var(--border-default)]">
            <button
              onClick={() => setViewMode('list')}
              className={`active-press px-2.5 py-1 rounded-lg text-xs font-semibold flex items-center gap-1 transition-colors cursor-pointer ${
                viewMode === 'list'
                  ? 'bg-[var(--accent)] text-[var(--accent-text)] shadow-xs'
                  : 'text-[var(--text-secondary)] hover:text-[var(--text-primary)]'
              }`}
              title="List View"
            >
              <LayoutList className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">List</span>
            </button>
            <button
              onClick={() => setViewMode('board')}
              className={`active-press px-2.5 py-1 rounded-lg text-xs font-semibold flex items-center gap-1 transition-colors cursor-pointer ${
                viewMode === 'board'
                  ? 'bg-[var(--accent)] text-[var(--accent-text)] shadow-xs'
                  : 'text-[var(--text-secondary)] hover:text-[var(--text-primary)]'
              }`}
              title="Kanban Board View"
            >
              <Kanban className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Board</span>
            </button>
            <button
              onClick={() => setViewMode('table')}
              className={`active-press px-2.5 py-1 rounded-lg text-xs font-semibold flex items-center gap-1 transition-colors cursor-pointer ${
                viewMode === 'table'
                  ? 'bg-[var(--accent)] text-[var(--accent-text)] shadow-xs'
                  : 'text-[var(--text-secondary)] hover:text-[var(--text-primary)]'
              }`}
              title="Database Table View"
            >
              <TableIcon className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Table</span>
            </button>
            <button
              onClick={() => setViewMode('timeline')}
              className={`active-press px-2.5 py-1 rounded-lg text-xs font-semibold flex items-center gap-1 transition-colors cursor-pointer ${
                viewMode === 'timeline'
                  ? 'bg-[var(--accent)] text-[var(--accent-text)] shadow-xs'
                  : 'text-[var(--text-secondary)] hover:text-[var(--text-primary)]'
              }`}
              title="Timeline View"
            >
              <Clock className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Timeline</span>
            </button>
          </div>

          <button
            onClick={() => openHelpWithContext('tasks')}
            className="active-press p-2 rounded-xl border border-[var(--border-default)] text-[var(--text-secondary)] hover:text-[var(--accent)] hover:bg-[var(--ui-hover)] transition-colors cursor-pointer"
            title="Tasks Guide & AI Help"
            aria-label="Tasks Help"
          >
            <HelpCircle className="w-4 h-4" />
          </button>
          <button
            onClick={() => setIsAddingTask(true)}
            className="active-press flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl text-xs font-semibold bg-[var(--accent)] text-[var(--accent-text)] shadow-xs transition-all cursor-pointer"
          >
            <Plus className="w-4 h-4 stroke-[2.5]" />
            <span>New Task</span>
          </button>
        </div>
      </div>

      {/* Status Tabs for List View */}
      {viewMode === 'list' && (
        <div className="p-1 rounded-2xl bg-[var(--bg-surface-subtle)] border border-[var(--border-default)] flex items-center overflow-x-auto no-scrollbar">
          {statusTabs.map((tab) => {
            const isSelected = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`active-press relative flex-1 min-w-[72px] text-center py-1.5 px-2 rounded-xl text-xs font-medium transition-all cursor-pointer select-none whitespace-nowrap flex items-center justify-center gap-1.5 ${
                  isSelected
                    ? 'text-[var(--text-primary)] font-semibold shadow-xs'
                    : 'text-[var(--text-secondary)] hover:text-[var(--text-primary)]'
                }`}
              >
                {isSelected && (
                  <motion.div
                    layoutId="taskStatusTabIndicator"
                    transition={{ type: 'spring', stiffness: 450, damping: 32 }}
                    className="absolute inset-0 bg-[var(--bg-surface-elevated)] rounded-xl border border-[var(--border-default)]"
                  />
                )}
                <span className="relative z-10">{tab.label}</span>
                <span
                  className={`relative z-10 text-[10px] px-1.5 py-0.2 rounded-full tabular-nums font-bold ${
                    isSelected
                      ? 'bg-[var(--accent)] text-[var(--accent-text)]'
                      : 'bg-[var(--bg-surface-input)] text-[var(--text-secondary)]'
                  }`}
                >
                  {tab.count}
                </span>
              </button>
            );
          })}
        </div>
      )}

      {/* Secondary Quick Filters */}
      <div className="flex items-center justify-between gap-3 text-xs">
        <div className="flex items-center gap-2 flex-wrap">
          <div className="flex items-center gap-1 bg-[var(--bg-surface-elevated)] border border-[var(--border-default)] rounded-xl px-2.5 py-1 text-xs">
            <SlidersHorizontal className="w-3 h-3 text-[var(--text-tertiary)]" />
            <select
              value={priorityFilter}
              onChange={(e) => setPriorityFilter(e.target.value)}
              className="bg-transparent text-[var(--text-secondary)] focus:outline-hidden cursor-pointer"
            >
              <option value="all">All Priorities</option>
              <option value="urgent">Urgent</option>
              <option value="high">High</option>
              <option value="medium">Medium</option>
              <option value="low">Low</option>
            </select>
          </div>

          <div className="flex items-center gap-1 bg-[var(--bg-surface-elevated)] border border-[var(--border-default)] rounded-xl px-2.5 py-1 text-xs">
            <Tag className="w-3 h-3 text-[var(--text-tertiary)]" />
            <select
              value={projectFilter}
              onChange={(e) => setProjectFilter(e.target.value)}
              className="bg-transparent text-[var(--text-secondary)] focus:outline-hidden max-w-[130px] truncate cursor-pointer"
            >
              <option value="all">All Projects</option>
              {projects.map((p) => (
                <option key={p.id} value={p.id}>
                  {p.title}
                </option>
              ))}
            </select>
          </div>
        </div>

        <span className="text-[11px] text-[var(--text-tertiary)] tabular-nums hidden sm:inline">
          {filteredTasks.length} task{filteredTasks.length !== 1 ? 's' : ''}
        </span>
      </div>

      {/* New Task Drawer / Form */}
      {isAddingTask && (
        <motion.form
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -10 }}
          onSubmit={handleCreateTask}
          className="p-4 sm:p-5 rounded-2xl bg-[var(--bg-surface-elevated)] border border-[var(--border-default)] shadow-lg space-y-4 text-xs"
        >
          <div className="flex items-center justify-between border-b border-[var(--border-subtle)] pb-2.5">
            <h3 className="font-semibold text-sm text-[var(--text-primary)]">
              Create New Task
            </h3>
            <button
              type="button"
              onClick={() => setIsAddingTask(false)}
              className="active-press text-[var(--text-tertiary)] hover:text-[var(--text-primary)]"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          <input
            type="text"
            placeholder="Task title (e.g., Review weekly sprint plan)..."
            value={newTitle}
            onChange={(e) => setNewTitle(e.target.value)}
            className="w-full px-3.5 py-2.5 rounded-xl bg-[var(--bg-surface-input)] border border-[var(--border-default)] text-[var(--text-primary)] placeholder-[var(--text-tertiary)] text-sm focus:outline-hidden focus:border-[var(--accent)] font-medium"
            autoFocus
          />

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <label className="block text-[11px] font-medium text-[var(--text-secondary)] mb-1">Due Date</label>
              <input
                type="date"
                value={newDueDate}
                onChange={(e) => setNewDueDate(e.target.value)}
                className="w-full px-3 py-1.5 rounded-xl bg-[var(--bg-surface-input)] border border-[var(--border-default)] text-[var(--text-primary)] focus:outline-hidden"
              />
            </div>

            <div>
              <label className="block text-[11px] font-medium text-[var(--text-secondary)] mb-1">Status</label>
              <select
                value={newStatus}
                onChange={(e) => setNewStatus(e.target.value as TaskStatus)}
                className="w-full px-3 py-1.5 rounded-xl bg-[var(--bg-surface-input)] border border-[var(--border-default)] text-[var(--text-primary)] focus:outline-hidden cursor-pointer"
              >
                <option value="today">Today</option>
                <option value="inbox">Inbox</option>
                <option value="upcoming">Upcoming</option>
                <option value="someday">Someday</option>
              </select>
            </div>

            <div>
              <label className="block text-[11px] font-medium text-[var(--text-secondary)] mb-1">Priority</label>
              <select
                value={newPriority}
                onChange={(e) => setNewPriority(e.target.value as Priority)}
                className="w-full px-3 py-1.5 rounded-xl bg-[var(--bg-surface-input)] border border-[var(--border-default)] text-[var(--text-primary)] focus:outline-hidden cursor-pointer"
              >
                <option value="low">Low</option>
                <option value="medium">Medium</option>
                <option value="high">High</option>
                <option value="urgent">Urgent</option>
              </select>
            </div>
          </div>

          <div>
            <button
              type="button"
              onClick={() => setShowAdvanced(!showAdvanced)}
              className="text-xs font-semibold text-[var(--accent)] hover:underline cursor-pointer"
            >
              {showAdvanced ? '- Fewer options' : '+ Project, Goal, Duration, Notes'}
            </button>
          </div>

          {showAdvanced && (
            <div className="p-3.5 rounded-xl bg-[var(--bg-surface-subtle)] border border-[var(--border-subtle)] space-y-3">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-[11px] font-medium text-[var(--text-secondary)] mb-1">Linked Project</label>
                  <select
                    value={newProjectId}
                    onChange={(e) => setNewProjectId(e.target.value)}
                    className="w-full px-3 py-1.5 rounded-xl bg-[var(--bg-surface-input)] border border-[var(--border-default)] text-[var(--text-primary)] focus:outline-hidden"
                  >
                    <option value="">None</option>
                    {projects.map((p) => (
                      <option key={p.id} value={p.id}>
                        {p.title}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-[11px] font-medium text-[var(--text-secondary)] mb-1">Linked Goal</label>
                  <select
                    value={newGoalId}
                    onChange={(e) => setNewGoalId(e.target.value)}
                    className="w-full px-3 py-1.5 rounded-xl bg-[var(--bg-surface-input)] border border-[var(--border-default)] text-[var(--text-primary)] focus:outline-hidden"
                  >
                    <option value="">None</option>
                    {goals.map((g) => (
                      <option key={g.id} value={g.id}>
                        {g.title}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-[11px] font-medium text-[var(--text-secondary)] mb-1">Duration (minutes)</label>
                  <input
                    type="number"
                    min={5}
                    step={5}
                    value={newDuration}
                    onChange={(e) => setNewDuration(Number(e.target.value))}
                    className="w-full px-3 py-1.5 rounded-xl bg-[var(--bg-surface-input)] border border-[var(--border-default)] text-[var(--text-primary)] focus:outline-hidden"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-medium text-[var(--text-secondary)] mb-1">Energy Required</label>
                  <select
                    value={newEnergy}
                    onChange={(e) => setNewEnergy(e.target.value as EnergyLevel)}
                    className="w-full px-3 py-1.5 rounded-xl bg-[var(--bg-surface-input)] border border-[var(--border-default)] text-[var(--text-primary)] focus:outline-hidden"
                  >
                    <option value="low">Low Energy (Routine)</option>
                    <option value="medium">Medium Energy (Standard)</option>
                    <option value="high">High Energy (Deep Focus)</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-[11px] font-medium text-[var(--text-secondary)] mb-1">Notes / Description</label>
                <textarea
                  value={newDesc}
                  onChange={(e) => setNewDesc(e.target.value)}
                  placeholder="Additional context, sub-items, or constraints..."
                  rows={2}
                  className="w-full px-3 py-1.5 rounded-xl bg-[var(--bg-surface-input)] border border-[var(--border-default)] text-[var(--text-primary)] focus:outline-hidden"
                />
              </div>
            </div>
          )}

          <div className="flex items-center justify-end gap-2 pt-2 border-t border-[var(--border-subtle)]">
            <button
              type="button"
              onClick={() => setIsAddingTask(false)}
              className="active-press px-3 py-1.5 rounded-xl text-xs font-medium text-[var(--text-secondary)] hover:bg-[var(--ui-hover)] transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="active-press px-4 py-1.5 rounded-xl text-xs font-semibold bg-[var(--accent)] text-[var(--accent-text)] shadow-xs"
            >
              Add Task
            </button>
          </div>
        </motion.form>
      )}

      {/* ============================================================ */}
      {/* 1. LIST VIEW */}
      {/* ============================================================ */}
      {viewMode === 'list' && (
        <div className="ios-grouped-list">
          {/* Fast Inline Reminder Add Row */}
          <form
            onSubmit={handleQuickInlineAdd}
            className="ios-list-row bg-[var(--bg-surface-elevated)]"
          >
            <div className="flex items-center gap-3 w-full">
              <Plus className="w-5 h-5 text-[var(--accent)] shrink-0 stroke-[2.4]" />
              <input
                type="text"
                value={quickInlineTitle}
                onChange={(e) => setQuickInlineTitle(e.target.value)}
                placeholder="Add a new task... (Press Enter to save)"
                className="w-full bg-transparent text-xs sm:text-sm text-[var(--text-primary)] placeholder-[var(--text-tertiary)] focus:outline-hidden"
              />
            </div>
          </form>

          {filteredTasks.length === 0 ? (
            <div className="p-10 text-center space-y-2">
              <CheckCircle2 className="w-8 h-8 mx-auto text-[var(--text-tertiary)] opacity-40" />
              <p className="text-xs text-[var(--text-secondary)] font-medium">
                No tasks in this view.
              </p>
            </div>
          ) : (
            filteredTasks.map((task) => {
              const isDone = task.status === 'completed';
              const isExpanded = expandedTaskId === task.id;
              const completedSubtasks = task.subtasks.filter((s) => s.completed).length;

              return (
                <div key={task.id} className="transition-colors">
                  <div
                    className="ios-list-row gap-3 cursor-pointer"
                    onClick={() => setExpandedTaskId(isExpanded ? null : task.id)}
                  >
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        toggleTaskComplete(task.id);
                      }}
                      className="active-press text-[var(--text-tertiary)] hover:text-[var(--accent)] transition-colors cursor-pointer shrink-0"
                      aria-label="Toggle task status"
                    >
                      {isDone ? (
                        <CheckCircle2 className="w-5 h-5 text-emerald-500" />
                      ) : (
                        <Circle className="w-5 h-5" />
                      )}
                    </button>

                    <div className="flex-1 min-w-0">
                      <span
                        className={`text-xs sm:text-sm font-medium leading-snug block truncate ${
                          isDone
                            ? 'line-through text-[var(--text-tertiary)]'
                            : 'text-[var(--text-primary)]'
                        }`}
                      >
                        {task.title}
                      </span>

                      <div className="flex items-center gap-2 mt-0.5 text-[11px] text-[var(--text-tertiary)] flex-wrap">
                        {task.priority === 'urgent' && (
                          <span className="text-rose-500 font-semibold">Urgent</span>
                        )}
                        {task.priority === 'high' && (
                          <span className="text-amber-500 font-semibold">High</span>
                        )}
                        {task.dueDate && (
                          <span className="flex items-center gap-1">
                            <Calendar className="w-3 h-3" />
                            {task.dueDate}
                          </span>
                        )}
                        {task.subtasks.length > 0 && (
                          <span>
                            {completedSubtasks}/{task.subtasks.length}
                          </span>
                        )}
                        {task.projectId && (
                          <span className="truncate max-w-[120px]">
                            {projects.find((p) => p.id === task.projectId)?.title}
                          </span>
                        )}
                      </div>
                    </div>

                    <div className="flex items-center gap-1 shrink-0" onClick={(e) => e.stopPropagation()}>
                      <button
                        onClick={() => deleteTask(task.id)}
                        className="active-press p-1.5 text-[var(--text-tertiary)] hover:text-rose-500 rounded-lg transition-colors cursor-pointer"
                        title="Delete task"
                        aria-label="Delete task"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => setExpandedTaskId(isExpanded ? null : task.id)}
                        className="active-press p-1.5 text-[var(--text-tertiary)] hover:text-[var(--text-primary)] rounded-lg transition-colors cursor-pointer"
                        aria-label="Expand task details"
                      >
                        {isExpanded ? (
                          <ChevronDown className="w-4 h-4" />
                        ) : (
                          <ChevronRight className="w-4 h-4" />
                        )}
                      </button>
                    </div>
                  </div>

                  {/* Expanded Subtasks Pane */}
                  <AnimatePresence>
                    {isExpanded && (
                      <motion.div
                        initial={{ opacity: 0, height: 0 }}
                        animate={{ opacity: 1, height: 'auto' }}
                        exit={{ opacity: 0, height: 0 }}
                        className="px-4 py-3 bg-[var(--bg-surface-subtle)] border-t border-[var(--border-subtle)] space-y-3 text-xs overflow-hidden"
                      >
                        {task.description && (
                          <p className="text-[var(--text-secondary)] leading-relaxed">
                            {task.description}
                          </p>
                        )}

                        <div className="space-y-1.5">
                          <span className="text-[10px] font-semibold text-[var(--text-tertiary)] uppercase tracking-wider block">
                            Subtasks
                          </span>
                          {task.subtasks.map((sub) => (
                            <div
                              key={sub.id}
                              className="flex items-center gap-2 text-xs text-[var(--text-secondary)]"
                            >
                              <button
                                onClick={() => toggleSubtask(task.id, sub.id)}
                                className="text-[var(--text-tertiary)] hover:text-[var(--accent)] cursor-pointer"
                              >
                                {sub.completed ? (
                                  <CheckCircle2 className="w-4 h-4 text-emerald-500" />
                                ) : (
                                  <Circle className="w-4 h-4" />
                                )}
                              </button>
                              <span className={sub.completed ? 'line-through text-[var(--text-tertiary)]' : ''}>
                                {sub.title}
                              </span>
                            </div>
                          ))}

                          <div className="flex items-center gap-2 pt-1">
                            <input
                              type="text"
                              placeholder="Add item..."
                              value={newSubtaskTitle}
                              onChange={(e) => setNewSubtaskTitle(e.target.value)}
                              onKeyDown={(e) => {
                                if (e.key === 'Enter') {
                                  e.preventDefault();
                                  handleAddSubtaskToTask(task.id);
                                }
                              }}
                              className="flex-1 px-2.5 py-1 rounded-lg bg-[var(--bg-surface-input)] border border-[var(--border-default)] text-xs text-[var(--text-primary)] focus:outline-hidden"
                            />
                            <button
                              type="button"
                              onClick={() => handleAddSubtaskToTask(task.id)}
                              className="active-press px-2.5 py-1 rounded-lg bg-[var(--accent)] text-[var(--accent-text)] text-xs font-semibold"
                            >
                              Add
                            </button>
                          </div>
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>
              );
            })
          )}
        </div>
      )}

      {/* ============================================================ */}
      {/* 2. BOARD / KANBAN VIEW */}
      {/* ============================================================ */}
      {viewMode === 'board' && (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 overflow-x-auto pb-4">
          {kanbanColumns.map((col) => {
            const colTasks = tasks.filter((t) => t.status === col.status);
            return (
              <div
                key={col.status}
                className="p-3 rounded-2xl bg-[var(--bg-surface-elevated)] border border-[var(--border-default)] space-y-3 flex flex-col max-h-[700px]"
              >
                <div className="flex items-center justify-between pb-2 border-b border-[var(--border-subtle)]">
                  <div className="flex items-center gap-2">
                    <span className={`w-2 h-2 rounded-full ${col.color}`} />
                    <h3 className="text-xs font-bold uppercase tracking-wider text-[var(--text-primary)]">
                      {col.label}
                    </h3>
                  </div>
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-[var(--bg-surface-subtle)] text-[var(--text-tertiary)] font-bold">
                    {colTasks.length}
                  </span>
                </div>

                <div className="space-y-2 overflow-y-auto flex-1 pr-1">
                  {colTasks.map((task) => {
                    const isDone = task.status === 'completed';
                    const nextStatus: TaskStatus =
                      task.status === 'inbox'
                        ? 'today'
                        : task.status === 'today'
                        ? 'completed'
                        : task.status === 'upcoming'
                        ? 'today'
                        : 'inbox';

                    return (
                      <div
                        key={task.id}
                        className="p-3 rounded-xl bg-[var(--bg-surface-subtle)] border border-[var(--border-default)] hover:border-[var(--border-focus)] transition-all space-y-2 shadow-xs group"
                      >
                        <div className="flex items-start justify-between gap-1">
                          <span
                            className={`text-xs font-semibold leading-snug line-clamp-2 ${
                              isDone ? 'line-through text-[var(--text-tertiary)]' : 'text-[var(--text-primary)]'
                            }`}
                          >
                            {task.title}
                          </span>
                          <button
                            onClick={() => toggleTaskComplete(task.id)}
                            className="text-[var(--text-tertiary)] hover:text-[var(--accent)] shrink-0"
                          >
                            {isDone ? (
                              <CheckCircle2 className="w-4 h-4 text-emerald-500" />
                            ) : (
                              <Circle className="w-4 h-4" />
                            )}
                          </button>
                        </div>

                        <div className="flex items-center justify-between text-[10px] text-[var(--text-tertiary)] pt-1">
                          <span
                            className={`font-semibold capitalize ${
                              task.priority === 'urgent'
                                ? 'text-rose-500'
                                : task.priority === 'high'
                                ? 'text-amber-500'
                                : ''
                            }`}
                          >
                            {task.priority}
                          </span>

                          <button
                            onClick={() => updateTask(task.id, { status: nextStatus })}
                            className="active-press px-2 py-0.5 rounded-md bg-[var(--bg-surface-elevated)] border border-[var(--border-default)] hover:bg-[var(--accent)] hover:text-white font-semibold flex items-center gap-0.5 transition-colors cursor-pointer"
                            title={`Move to ${nextStatus}`}
                          >
                            <span>→ {nextStatus}</span>
                          </button>
                        </div>
                      </div>
                    );
                  })}

                  <button
                    onClick={() => {
                      setNewStatus(col.status);
                      setIsAddingTask(true);
                    }}
                    className="active-press w-full py-2 rounded-xl border border-dashed border-[var(--border-default)] text-xs text-[var(--text-tertiary)] hover:text-[var(--text-primary)] hover:border-[var(--accent)] flex items-center justify-center gap-1 transition-colors cursor-pointer"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>Add to {col.label}</span>
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* ============================================================ */}
      {/* 3. TABLE / DATABASE VIEW */}
      {/* ============================================================ */}
      {viewMode === 'table' && (
        <div className="rounded-2xl bg-[var(--bg-surface-elevated)] border border-[var(--border-default)] overflow-hidden shadow-xs">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-[var(--bg-surface-subtle)] border-b border-[var(--border-default)] text-[var(--text-secondary)] font-semibold uppercase tracking-wider text-[10px]">
                <tr>
                  <th className="py-3 px-4 w-10">Done</th>
                  <th className="py-3 px-4">Task Title</th>
                  <th className="py-3 px-4">Status</th>
                  <th className="py-3 px-4">Priority</th>
                  <th className="py-3 px-4">Due Date</th>
                  <th className="py-3 px-4">Project</th>
                  <th className="py-3 px-4">Duration</th>
                  <th className="py-3 px-4 text-right">Delete</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[var(--border-subtle)]">
                {filteredTasks.map((task) => {
                  const isDone = task.status === 'completed';
                  const proj = projects.find((p) => p.id === task.projectId);
                  return (
                    <tr key={task.id} className="hover:bg-[var(--bg-surface-subtle)] transition-colors">
                      <td className="py-3 px-4">
                        <button
                          onClick={() => toggleTaskComplete(task.id)}
                          className="text-[var(--text-tertiary)] hover:text-[var(--accent)]"
                        >
                          {isDone ? (
                            <CheckCircle2 className="w-4 h-4 text-emerald-500" />
                          ) : (
                            <Circle className="w-4 h-4" />
                          )}
                        </button>
                      </td>
                      <td className="py-3 px-4 font-semibold text-[var(--text-primary)] max-w-[220px] truncate">
                        <span className={isDone ? 'line-through text-[var(--text-tertiary)]' : ''}>
                          {task.title}
                        </span>
                      </td>
                      <td className="py-3 px-4">
                        <span className="text-[10px] uppercase font-bold px-2 py-0.5 rounded bg-[var(--bg-surface-input)] text-[var(--text-secondary)] border border-[var(--border-default)]">
                          {task.status}
                        </span>
                      </td>
                      <td className="py-3 px-4">
                        <span
                          className={`font-semibold capitalize ${
                            task.priority === 'urgent'
                              ? 'text-rose-500'
                              : task.priority === 'high'
                              ? 'text-amber-500'
                              : 'text-[var(--text-secondary)]'
                          }`}
                        >
                          {task.priority}
                        </span>
                      </td>
                      <td className="py-3 px-4 text-[var(--text-secondary)] whitespace-nowrap">
                        {task.dueDate || '—'}
                      </td>
                      <td className="py-3 px-4 text-[var(--text-secondary)] max-w-[140px] truncate">
                        {proj ? proj.title : '—'}
                      </td>
                      <td className="py-3 px-4 text-[var(--text-tertiary)] font-mono">
                        {task.durationMinutes ? `${task.durationMinutes}m` : '—'}
                      </td>
                      <td className="py-3 px-4 text-right">
                        <button
                          onClick={() => deleteTask(task.id)}
                          className="text-[var(--text-tertiary)] hover:text-rose-500"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* ============================================================ */}
      {/* 4. TIMELINE VIEW */}
      {/* ============================================================ */}
      {viewMode === 'timeline' && (
        <div className="space-y-4">
          <div className="p-4 rounded-2xl bg-[var(--bg-surface-elevated)] border border-[var(--border-default)] space-y-3">
            <h3 className="text-xs font-bold uppercase tracking-wider text-[var(--text-secondary)] flex items-center gap-1.5">
              <Clock className="w-3.5 h-3.5 text-purple-500" />
              <span>Chronological Due-Date Timeline</span>
            </h3>

            <div className="space-y-3 pl-4 border-l-2 border-purple-500/30">
              {filteredTasks
                .slice()
                .sort((a, b) => (a.dueDate || '9999').localeCompare(b.dueDate || '9999'))
                .map((task) => {
                  const proj = projects.find((p) => p.id === task.projectId);
                  return (
                    <div
                      key={task.id}
                      className="relative p-3 rounded-xl bg-[var(--bg-surface-subtle)] border border-[var(--border-default)] space-y-1"
                    >
                      <span className="absolute -left-[23px] top-3.5 w-3 h-3 rounded-full bg-purple-500 border-2 border-[var(--bg-surface-elevated)]" />
                      <div className="flex items-center justify-between gap-2">
                        <span className="font-mono text-[11px] font-bold text-purple-600 dark:text-purple-400">
                          {task.dueDate || 'No Due Date'}
                        </span>
                        <span className="text-[10px] uppercase font-bold text-[var(--text-tertiary)]">
                          {task.priority}
                        </span>
                      </div>
                      <h4 className="text-xs font-semibold text-[var(--text-primary)]">
                        {task.title}
                      </h4>
                      {proj && (
                        <p className="text-[11px] text-[var(--text-secondary)]">
                          Project: {proj.title}
                        </p>
                      )}
                    </div>
                  );
                })}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
