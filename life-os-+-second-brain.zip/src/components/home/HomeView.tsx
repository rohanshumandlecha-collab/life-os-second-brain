import React, { useState, useEffect } from 'react';
import {
  CheckCircle2,
  Circle,
  Clock,
  Flame,
  ArrowRight,
  Sparkles,
  Target,
  FolderGit2,
  Zap,
  ShieldCheck,
  Send,
  ChevronRight,
  HelpCircle,
  X,
  LayoutGrid,
  Check,
  Layers,
  Play,
  Rocket,
  GraduationCap,
  BookOpen,
} from 'lucide-react';
import { useLifeOS } from '../../context/LifeOSContext';

const LiveClockWidget: React.FC<{ onRemove?: () => void; onFocus?: () => void }> = ({
  onRemove,
  onFocus,
}) => {
  const [time, setTime] = useState(new Date());

  useEffect(() => {
    const timer = setInterval(() => setTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  const timeStr = time.toLocaleTimeString([], {
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
    hour12: true,
  });
  const dateStr = time.toLocaleDateString([], {
    weekday: 'long',
    month: 'long',
    day: 'numeric',
    year: 'numeric',
  });
  const timeZone = Intl.DateTimeFormat().resolvedOptions().timeZone || 'Local Time';
  const tzOffset = -time.getTimezoneOffset() / 60;
  const tzOffsetStr = `UTC${tzOffset >= 0 ? '+' : ''}${tzOffset}`;

  return (
    <div className="relative overflow-hidden p-5 sm:p-6 rounded-3xl bg-[var(--bg-surface-elevated)] border border-[var(--border-default)] shadow-xs transition-all">
      {/* Ambient background glow */}
      <div className="absolute -right-10 -top-10 w-44 h-44 bg-purple-500/10 rounded-full blur-2xl pointer-events-none" />
      <div className="absolute -left-10 -bottom-10 w-44 h-44 bg-indigo-500/10 rounded-full blur-2xl pointer-events-none" />

      <div className="relative flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider bg-purple-500/15 text-purple-600 dark:text-purple-400">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
              Live Clock & Timezone
            </span>
            <span className="text-[11px] text-[var(--text-tertiary)]">
              {timeZone} ({tzOffsetStr})
            </span>
          </div>

          <div className="text-3xl sm:text-4xl md:text-5xl font-black tracking-tight text-[var(--text-primary)] font-mono">
            {timeStr}
          </div>

          <p className="text-xs sm:text-sm font-medium text-[var(--text-secondary)]">
            {dateStr}
          </p>
        </div>

        <div className="flex items-center gap-2">
          {onFocus && (
            <button
              onClick={onFocus}
              className="active-press flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold bg-[var(--accent)] text-[var(--accent-text)] shadow-xs transition-all cursor-pointer"
            >
              <Clock className="w-3.5 h-3.5" />
              <span>Start Timer</span>
            </button>
          )}
          {onRemove && (
            <button
              onClick={onRemove}
              title="Hide Clock Widget"
              className="active-press p-2 rounded-xl text-[var(--text-tertiary)] hover:text-[var(--text-secondary)] hover:bg-[var(--bg-surface-subtle)] border border-[var(--border-subtle)] transition-colors cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>
      </div>
    </div>
  );
};

export const HomeView: React.FC = () => {
  const {
    tasks,
    projects,
    goals,
    calendarEvents,
    habits,
    toggleTaskComplete,
    toggleHabitDate,
    setActiveNav,
    setPlanSubNav,
    setLifeSubNav,
    setIsFocusOpen,
    processCapture,
    showToast,
    settings,
    homeWidgets,
    addHomeWidget,
    removeHomeWidget,
    toggleHomeWidget,
    templates,
    automations,
    setIsTemplateModalOpen,
    setActiveTemplateForLaunch,
    triggerAutomation,
  } = useLifeOS();

  const [quickInput, setQuickInput] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [showWidgetManager, setShowWidgetManager] = useState(false);

  // Widget visibility flags
  const isClockEnabled = homeWidgets?.find((w) => w.id === 'clock')?.enabled ?? false;
  const isPrioritiesEnabled = homeWidgets?.find((w) => w.id === 'priorities')?.enabled ?? true;
  const isScheduleEnabled = homeWidgets?.find((w) => w.id === 'schedule')?.enabled ?? true;
  const isHabitsEnabled = homeWidgets?.find((w) => w.id === 'habits')?.enabled ?? true;
  const isGoalsEnabled = homeWidgets?.find((w) => w.id === 'goals')?.enabled ?? true;
  const isProjectsEnabled = homeWidgets?.find((w) => w.id === 'projects')?.enabled ?? true;
  const isQuickCaptureEnabled = homeWidgets?.find((w) => w.id === 'quick_capture')?.enabled ?? true;
  const isTemplatesEnabled = homeWidgets?.find((w) => w.id === 'templates')?.enabled ?? true;
  const isAutomationsEnabled = homeWidgets?.find((w) => w.id === 'automations')?.enabled ?? false;

  const todayStr = new Date().toISOString().split('T')[0];

  // Today's priorities
  const todayTasks = tasks.filter((t) => t.status === 'today');
  const highPriorityTasks = todayTasks
    .filter((t) => t.priority === 'urgent' || t.priority === 'high')
    .slice(0, 3);
  const remainingTodayTasks = todayTasks
    .filter((t) => t.priority !== 'urgent' && t.priority !== 'high')
    .slice(0, 3);

  // Today's schedule & current/next block
  const todayEvents = calendarEvents
    .filter((e) => e.date === todayStr)
    .sort((a, b) => a.startTime.localeCompare(b.startTime));

  const currentOrNextEvent = todayEvents[0] || null;

  // Active Goals & Projects
  const activeGoals = goals.filter((g) => g.status === 'active').slice(0, 2);
  const activeProjects = projects.filter((p) => p.status === 'active').slice(0, 2);

  const handleQuickCapture = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!quickInput.trim() || isProcessing) return;

    setIsProcessing(true);
    try {
      const res = await processCapture({ rawContent: quickInput.trim(), source: 'text' });
      showToast(`Captured as ${res.entityType}: "${res.item.title}"`, 'success');
      setQuickInput('');
    } catch (err) {
      showToast('Error capturing thought', 'error');
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <div className="max-w-5xl mx-auto px-3.5 sm:px-6 py-5 sm:py-6 space-y-6 text-[var(--text-primary)]">
      {/* 5-Second Overview Header with iOS large title feel */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-[var(--border-subtle)]">
        <div>
          <span className="text-[11px] font-semibold uppercase tracking-wider text-[var(--text-tertiary)] block">
            Today
          </span>
          <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-[var(--text-primary)]">
            Welcome back, {settings.userName || 'User'}
          </h1>
          <p className="text-xs sm:text-sm text-[var(--text-secondary)] mt-0.5">
            {todayTasks.length === 0
              ? 'All caught up for today. No urgent obligations pending.'
              : `${todayTasks.length} task${todayTasks.length > 1 ? 's' : ''} queued for today. Focus on high-impact items.`}
          </p>
        </div>

        {/* Action Controls */}
        <div className="flex items-center gap-2 flex-wrap">
          <button
            onClick={() => setShowWidgetManager(!showWidgetManager)}
            className={`active-press flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-medium border shadow-xs transition-colors cursor-pointer ${
              showWidgetManager
                ? 'bg-[var(--accent)] text-[var(--accent-text)] border-[var(--accent)]'
                : 'bg-[var(--bg-surface-elevated)] text-[var(--text-primary)] border-[var(--border-default)]'
            }`}
          >
            <LayoutGrid className="w-3.5 h-3.5" />
            <span>Widgets</span>
          </button>
          <button
            onClick={() => {
              setActiveNav('life');
              setLifeSubNav('energy');
            }}
            className="active-press flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-medium bg-[var(--bg-surface-elevated)] text-[var(--text-primary)] border border-[var(--border-default)] shadow-xs transition-colors cursor-pointer"
          >
            <Zap className="w-3.5 h-3.5 text-amber-500" />
            <span>Energy Rhythm</span>
          </button>
          <button
            onClick={() => setIsFocusOpen(true)}
            className="active-press flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl text-xs font-semibold bg-[var(--accent)] text-[var(--accent-text)] shadow-xs transition-all cursor-pointer"
          >
            <Clock className="w-3.5 h-3.5" />
            <span>Focus Mode</span>
          </button>
        </div>
      </div>

      {/* Widget Customization Tray */}
      {showWidgetManager && (
        <div className="p-4 rounded-2xl bg-[var(--bg-surface-elevated)] border border-[var(--border-default)] shadow-xs space-y-3 animate-in fade-in slide-in-from-top-2 duration-150">
          <div className="flex items-center justify-between pb-2 border-b border-[var(--border-subtle)]">
            <div className="flex items-center gap-2">
              <LayoutGrid className="w-4 h-4 text-[var(--accent)]" />
              <span className="text-xs font-bold text-[var(--text-primary)]">
                Home Dashboard Widgets
              </span>
            </div>
            <button
              onClick={() => setShowWidgetManager(false)}
              className="text-xs text-[var(--text-tertiary)] hover:text-[var(--text-primary)] cursor-pointer"
            >
              Done
            </button>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
            {homeWidgets.map((w) => (
              <button
                key={w.id}
                onClick={() => toggleHomeWidget(w.id)}
                className={`active-press flex items-center justify-between p-2.5 rounded-xl border text-left text-xs transition-all cursor-pointer ${
                  w.enabled
                    ? 'bg-purple-500/10 border-purple-500/30 text-[var(--text-primary)] font-medium'
                    : 'bg-[var(--bg-surface-subtle)] border-[var(--border-subtle)] text-[var(--text-tertiary)]'
                }`}
              >
                <span>{w.title}</span>
                {w.enabled && <Check className="w-3.5 h-3.5 text-purple-600 dark:text-purple-400" />}
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Live Clock Widget (Customizable / controllable by AI) */}
      {isClockEnabled && (
        <LiveClockWidget
          onRemove={() => removeHomeWidget('clock')}
          onFocus={() => setIsFocusOpen(true)}
        />
      )}

      {/* Proactive AI Briefing Banner */}
      <div className="flex items-start gap-3.5 p-4 rounded-2xl bg-[var(--bg-surface-elevated)] border border-[var(--border-default)] shadow-xs">
        <div className="w-8 h-8 rounded-xl bg-[var(--accent)] text-[var(--accent-text)] flex items-center justify-center shrink-0 shadow-xs">
          <Sparkles className="w-4 h-4 stroke-[2.2]" />
        </div>
        <div className="flex-1 text-xs text-[var(--text-secondary)] space-y-1">
          <p className="font-semibold text-sm text-[var(--text-primary)]">
            Daily Intelligence Briefing
          </p>
          <p className="leading-relaxed">
            {currentOrNextEvent
              ? `Next scheduled block is "${currentOrNextEvent.title}" at ${currentOrNextEvent.startTime}. You have protected focus time reserved.`
              : 'Your schedule has open space today. Prime window for deep uninterrupted focus.'}
          </p>
        </div>
        <button
          onClick={() => setActiveNav('ai')}
          className="active-press text-xs font-semibold text-[var(--accent)] flex items-center gap-1 shrink-0 pt-0.5 cursor-pointer"
        >
          Ask AI <ArrowRight className="w-3 h-3" />
        </button>
      </div>

      {/* iOS Style Quick Input Box */}
      {isQuickCaptureEnabled && (
        <form onSubmit={handleQuickCapture} className="relative">
          <input
            type="text"
            value={quickInput}
            onChange={(e) => setQuickInput(e.target.value)}
            placeholder="Quick capture a task, thought, or note... (Press Enter)"
            disabled={isProcessing}
            className="w-full px-4 py-3 pr-10 rounded-2xl text-xs sm:text-sm bg-[var(--bg-surface-elevated)] border border-[var(--border-default)] text-[var(--text-primary)] placeholder-[var(--text-tertiary)] focus:outline-hidden focus:border-[var(--accent)] shadow-xs transition-colors"
          />
          <button
            type="submit"
            disabled={!quickInput.trim() || isProcessing}
            className="active-press absolute right-2.5 top-1/2 -translate-y-1/2 p-1.5 rounded-lg text-[var(--text-secondary)] hover:text-[var(--accent)] disabled:opacity-40 transition-colors cursor-pointer"
          >
            <Send className="w-4 h-4" />
          </button>
        </form>
      )}

      {/* 2-Column iOS Layout */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Left 2 Cols: Inset Grouped Lists for Today's Priorities & Schedule */}
        <div className="md:col-span-2 space-y-6">
          {/* Today's Priorities - Clean Inset Grouped List */}
          {isPrioritiesEnabled && (
            <div className="space-y-2">
              <div className="flex items-center justify-between px-1">
                <h2 className="text-xs font-semibold uppercase tracking-wider text-[var(--text-secondary)] flex items-center gap-2">
                  <span>Today's Priorities</span>
                  <span className="text-[10px] px-1.5 py-0.2 rounded-full bg-[var(--bg-surface-input)] text-[var(--text-secondary)] font-bold">
                    {todayTasks.length}
                  </span>
                </h2>
                <button
                  onClick={() => setActiveNav('tasks')}
                  className="active-press text-xs font-medium text-[var(--accent)] flex items-center gap-0.5 cursor-pointer"
                >
                  All tasks <ChevronRight className="w-3.5 h-3.5" />
                </button>
              </div>

            {todayTasks.length === 0 ? (
              <div className="p-8 rounded-2xl border border-dashed border-[var(--border-default)] bg-[var(--bg-surface-elevated)] text-center">
                <CheckCircle2 className="w-7 h-7 mx-auto text-emerald-500 mb-2" />
                <p className="text-xs font-medium text-[var(--text-secondary)]">
                  All caught up! No urgent tasks pending for today.
                </p>
              </div>
            ) : (
              <div className="ios-grouped-list">
                {[...highPriorityTasks, ...remainingTodayTasks].map((task) => {
                  const isDone = task.status === 'completed';
                  return (
                    <div
                      key={task.id}
                      className="ios-list-row gap-3"
                    >
                      <button
                        onClick={() => toggleTaskComplete(task.id)}
                        className="active-press text-[var(--text-tertiary)] hover:text-[var(--accent)] transition-colors cursor-pointer"
                        aria-label="Toggle task completion"
                      >
                        {isDone ? (
                          <CheckCircle2 className="w-5 h-5 text-emerald-500" />
                        ) : (
                          <Circle className="w-5 h-5" />
                        )}
                      </button>

                      <div className="flex-1 min-w-0">
                        <span
                          className={`text-xs sm:text-sm font-medium leading-snug block truncate ${
                            isDone
                              ? 'line-through text-[var(--text-tertiary)]'
                              : 'text-[var(--text-primary)]'
                          }`}
                        >
                          {task.title}
                        </span>

                        <div className="flex items-center gap-2 mt-0.5 text-[11px] text-[var(--text-tertiary)]">
                          {task.priority === 'urgent' && (
                            <span className="text-rose-500 font-semibold">Urgent</span>
                          )}
                          {task.priority === 'high' && (
                            <span className="text-amber-500 font-semibold">High</span>
                          )}
                          {task.durationMinutes && (
                            <span className="flex items-center gap-1">
                              <Clock className="w-3 h-3" />
                              {task.durationMinutes}m
                            </span>
                          )}
                          {task.projectId && (
                            <span className="truncate max-w-[120px]">
                              {projects.find((p) => p.id === task.projectId)?.title}
                            </span>
                          )}
                        </div>
                      </div>

                      <ChevronRight className="w-4 h-4 text-[var(--text-tertiary)] shrink-0" />
                    </div>
                  );
                })}
              </div>
            )}
          </div>
          )}

          {/* Today's Schedule & Time Blocks - Clean Inset Grouped List */}
          {isScheduleEnabled && (
            <div className="space-y-2">
              <div className="flex items-center justify-between px-1">
                <h2 className="text-xs font-semibold uppercase tracking-wider text-[var(--text-secondary)]">
                  Today's Schedule
                </h2>
                <button
                  onClick={() => {
                    setActiveNav('plan');
                    setPlanSubNav('calendar');
                  }}
                  className="active-press text-xs font-medium text-[var(--accent)] flex items-center gap-0.5 cursor-pointer"
                >
                  Calendar <ChevronRight className="w-3.5 h-3.5" />
                </button>
              </div>

              {todayEvents.length === 0 ? (
                <div className="p-6 rounded-2xl bg-[var(--bg-surface-elevated)] border border-[var(--border-default)] text-center text-xs text-[var(--text-tertiary)]">
                  No calendar events scheduled for today.
                </div>
              ) : (
                <div className="ios-grouped-list">
                  {todayEvents.map((ev) => (
                    <div
                      key={ev.id}
                      className="ios-list-row gap-3"
                    >
                      <div className="flex items-center gap-3 min-w-0 flex-1">
                        <span className="font-mono text-xs text-[var(--accent)] font-semibold shrink-0">
                          {ev.startTime}
                        </span>
                        <div className="truncate min-w-0">
                          <p className="font-medium text-xs sm:text-sm text-[var(--text-primary)] truncate">
                            {ev.title}
                          </p>
                          {ev.notes && (
                            <p className="text-[11px] text-[var(--text-secondary)] truncate">
                              {ev.notes}
                            </p>
                          )}
                        </div>
                      </div>
                      <span className="text-[10px] text-[var(--text-tertiary)] font-mono uppercase bg-[var(--bg-surface-input)] px-2 py-0.5 rounded-md shrink-0">
                        {ev.type}
                      </span>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* Templates Quick Launch - Ready-made & AI Systems */}
          {isTemplatesEnabled && (
            <div className="space-y-2.5">
              <div className="flex items-center justify-between px-1">
                <h2 className="text-xs font-semibold uppercase tracking-wider text-[var(--text-secondary)] flex items-center gap-2">
                  <Layers className="w-3.5 h-3.5 text-purple-500" />
                  <span>Ready-Made Templates</span>
                </h2>
                <button
                  onClick={() => setIsTemplateModalOpen(true)}
                  className="active-press text-xs font-medium text-[var(--accent)] flex items-center gap-0.5 cursor-pointer"
                >
                  Template Hub <ChevronRight className="w-3.5 h-3.5" />
                </button>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {templates.slice(0, 4).map((tpl) => (
                  <div
                    key={tpl.id}
                    onClick={() => {
                      setActiveTemplateForLaunch(tpl);
                      setIsTemplateModalOpen(true);
                    }}
                    className="active-press p-3.5 rounded-2xl bg-[var(--bg-surface-elevated)] border border-[var(--border-default)] hover:border-[var(--border-focus)] transition-all cursor-pointer group flex flex-col justify-between gap-2 shadow-xs"
                  >
                    <div className="flex items-start justify-between gap-2">
                      <div className="flex items-center gap-2 min-w-0">
                        <div className="w-7 h-7 rounded-xl bg-purple-500/10 text-purple-600 dark:text-purple-400 flex items-center justify-center shrink-0">
                          <Layers className="w-3.5 h-3.5" />
                        </div>
                        <h4 className="text-xs font-bold text-[var(--text-primary)] group-hover:text-[var(--accent)] transition-colors truncate">
                          {tpl.title}
                        </h4>
                      </div>
                      <span className="text-[10px] px-2 py-0.5 rounded-full font-mono uppercase bg-[var(--bg-surface-subtle)] text-[var(--text-tertiary)] shrink-0">
                        {tpl.category}
                      </span>
                    </div>

                    <p className="text-[11px] text-[var(--text-secondary)] line-clamp-2">
                      {tpl.description}
                    </p>

                    <div className="flex items-center justify-between pt-1 border-t border-[var(--border-subtle)] text-[10px] text-[var(--text-tertiary)]">
                      <span>Creates connected objects</span>
                      <span className="flex items-center gap-1 font-semibold text-purple-600 dark:text-purple-400 group-hover:translate-x-0.5 transition-transform">
                        Launch <Play className="w-2.5 h-2.5 fill-current" />
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Active Automations Widget */}
          {isAutomationsEnabled && (
            <div className="space-y-2">
              <div className="flex items-center justify-between px-1">
                <h2 className="text-xs font-semibold uppercase tracking-wider text-[var(--text-secondary)] flex items-center gap-2">
                  <Zap className="w-3.5 h-3.5 text-amber-500" />
                  <span>When → If → Then Automations</span>
                </h2>
                <button
                  onClick={() => {
                    setActiveNav('life');
                    setLifeSubNav('automations');
                  }}
                  className="active-press text-xs font-medium text-[var(--accent)] flex items-center gap-0.5 cursor-pointer"
                >
                  Manage <ChevronRight className="w-3.5 h-3.5" />
                </button>
              </div>

              <div className="ios-grouped-list">
                {automations.slice(0, 3).map((auto) => (
                  <div key={auto.id} className="ios-list-row gap-3">
                    <div className="w-7 h-7 rounded-xl bg-amber-500/10 text-amber-600 dark:text-amber-400 flex items-center justify-center shrink-0">
                      <Zap className="w-3.5 h-3.5" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-bold text-[var(--text-primary)] truncate">
                          {auto.title}
                        </span>
                        <span
                          className={`text-[10px] px-1.5 py-0.2 rounded-full font-medium ${
                            auto.enabled
                              ? 'bg-emerald-500/10 text-emerald-600 dark:text-emerald-400'
                              : 'bg-zinc-500/10 text-zinc-500'
                          }`}
                        >
                          {auto.enabled ? 'Active' : 'Paused'}
                        </span>
                      </div>
                      <p className="text-[11px] text-[var(--text-tertiary)] truncate">
                        {auto.description || `${auto.trigger} → ${auto.action}`}
                      </p>
                    </div>
                    <button
                      onClick={() =>
                        triggerAutomation({
                          trigger: 'task_completed',
                          payload: { id: auto.id, title: auto.title },
                        })
                      }
                      className="active-press px-2.5 py-1 rounded-lg text-[10px] font-semibold bg-[var(--bg-surface-subtle)] hover:bg-[var(--accent)] hover:text-white text-[var(--text-secondary)] border border-[var(--border-default)] transition-colors shrink-0 cursor-pointer"
                    >
                      Run
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Right Col: Habits, Goals, Projects */}
        <div className="space-y-6">
          {/* Today's Habits - Inset Grouped List */}
          {isHabitsEnabled && (
            <div className="space-y-2">
              <div className="flex items-center justify-between px-1">
                <h3 className="text-xs font-semibold uppercase tracking-wider text-[var(--text-secondary)] flex items-center gap-1.5">
                  <Flame className="w-3.5 h-3.5 text-amber-500" />
                  <span>Habits</span>
                </h3>
                <button
                  onClick={() => {
                    setActiveNav('life');
                    setLifeSubNav('habits');
                  }}
                  className="active-press text-xs font-medium text-[var(--accent)] flex items-center gap-0.5 cursor-pointer"
                >
                  All <ChevronRight className="w-3.5 h-3.5" />
                </button>
              </div>

              <div className="ios-grouped-list">
                {habits.map((habit) => {
                  const isCompletedToday = habit.completedDates.includes(todayStr);
                  return (
                    <div
                      key={habit.id}
                      onClick={() => toggleHabitDate(habit.id, todayStr)}
                      className="ios-list-row gap-2.5"
                    >
                      <div className="flex items-center gap-2.5 truncate flex-1">
                        <button className="text-[var(--text-tertiary)] hover:text-[var(--accent)] transition-colors">
                          {isCompletedToday ? (
                            <CheckCircle2 className="w-5 h-5 text-emerald-500" />
                          ) : (
                            <Circle className="w-5 h-5" />
                          )}
                        </button>
                        <span
                          className={`text-xs font-medium truncate ${
                            isCompletedToday
                              ? 'line-through text-[var(--text-tertiary)]'
                              : 'text-[var(--text-primary)]'
                          }`}
                        >
                          {habit.title}
                        </span>
                      </div>
                      <span className="text-[11px] font-semibold text-amber-500 flex items-center gap-0.5 shrink-0">
                        <Flame className="w-3 h-3" />
                        {habit.streak}d
                      </span>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* Active Goals - Grouped List */}
          {isGoalsEnabled && (
            <div className="space-y-2">
              <div className="flex items-center justify-between px-1">
                <h3 className="text-xs font-semibold uppercase tracking-wider text-[var(--text-secondary)] flex items-center gap-1.5">
                  <Target className="w-3.5 h-3.5 text-blue-500" />
                  <span>Active Goals</span>
                </h3>
                <button
                  onClick={() => {
                    setActiveNav('plan');
                    setPlanSubNav('goals');
                  }}
                  className="active-press text-xs font-medium text-[var(--accent)] flex items-center gap-0.5 cursor-pointer"
                >
                  All <ChevronRight className="w-3.5 h-3.5" />
                </button>
              </div>

              <div className="ios-grouped-list p-3.5 space-y-3">
                {activeGoals.map((goal) => (
                  <div key={goal.id} className="space-y-1.5">
                    <div className="flex items-center justify-between text-xs">
                      <span className="font-medium text-[var(--text-primary)] truncate max-w-[170px]">
                        {goal.title}
                      </span>
                      <span className="text-[11px] font-mono font-semibold text-[var(--accent)]">
                        {goal.progress}%
                      </span>
                    </div>
                    <div className="w-full h-1.5 rounded-full bg-[var(--bg-surface-input)] overflow-hidden">
                      <div
                        className="h-full rounded-full bg-[var(--accent)] transition-all duration-500"
                        style={{ width: `${goal.progress}%` }}
                      />
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Active Projects - Grouped List */}
          {isProjectsEnabled && (
            <div className="space-y-2">
              <div className="flex items-center justify-between px-1">
                <h3 className="text-xs font-semibold uppercase tracking-wider text-[var(--text-secondary)] flex items-center gap-1.5">
                  <FolderGit2 className="w-3.5 h-3.5 text-indigo-500" />
                  <span>Projects</span>
                </h3>
                <button
                  onClick={() => {
                    setActiveNav('life');
                    setLifeSubNav('projects');
                  }}
                  className="active-press text-xs font-medium text-[var(--accent)] flex items-center gap-0.5 cursor-pointer"
                >
                  All <ChevronRight className="w-3.5 h-3.5" />
                </button>
              </div>

              <div className="ios-grouped-list p-3.5 space-y-3">
                {activeProjects.map((proj) => (
                  <div key={proj.id} className="space-y-1">
                    <div className="flex items-center justify-between text-xs">
                      <span className="font-medium text-[var(--text-primary)] truncate max-w-[170px]">
                        {proj.title}
                      </span>
                      <span className="text-[11px] text-[var(--text-secondary)] font-mono font-semibold">
                        {proj.progress}%
                      </span>
                    </div>
                    <p className="text-[11px] text-[var(--text-tertiary)] truncate">
                      Due {proj.deadline}
                    </p>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Privacy & Trust Badge */}
          <div className="flex items-center gap-2.5 p-3 rounded-2xl bg-[var(--bg-surface-elevated)] border border-[var(--border-default)] text-[var(--text-secondary)] text-[11px] shadow-xs">
            <ShieldCheck className="w-4 h-4 text-emerald-500 shrink-0" />
            <span>Private & secure. Fully responsive and offline resilient.</span>
          </div>
        </div>
      </div>
    </div>
  );
};
