import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { useLifeOS } from '../../context/LifeOSContext';
import {
  Brain,
  Sparkles,
  ArrowRight,
  Check,
  CheckCircle2,
  Lock,
  Sun,
  Moon,
  Laptop,
  CheckSquare,
  Calendar,
  Compass,
  AlertCircle,
  Loader2,
  ShieldCheck,
} from 'lucide-react';
import { signInWithGoogle } from '../../lib/firebase';

export const OnboardingScreen: React.FC = () => {
  const { settings, updateSettings, completeOnboarding, showToast } = useLifeOS();
  const [nameInput, setNameInput] = useState('');
  const [selectedFocus, setSelectedFocus] = useState<string[]>([
    'Tasks & Timeblocking',
    'Second Brain Notes',
  ]);
  const [isGoogleLoading, setIsGoogleLoading] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);
  const [welcomeName, setWelcomeName] = useState('');
  const [authError, setAuthError] = useState<string | null>(null);

  const focusOptions = [
    { id: 'Tasks & Timeblocking', icon: CheckSquare, label: 'Tasks & Daily Planner' },
    { id: 'Second Brain Notes', icon: Brain, label: 'Second Brain & Knowledge' },
    { id: 'Calendar & Routines', icon: Calendar, label: 'Calendar & Routines' },
    { id: 'Life Vision & Goals', icon: Compass, label: 'Life Vision & Projects' },
  ];

  const toggleFocus = (id: string) => {
    setSelectedFocus((prev) =>
      prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id]
    );
  };

  // Real Firebase Google Sign In
  const handleGoogleSignIn = async () => {
    setIsGoogleLoading(true);
    setAuthError(null);
    try {
      const user = await signInWithGoogle();
      const derivedName = user.displayName || user.email?.split('@')[0] || 'Life OS Member';
      setIsSuccess(true);
      setWelcomeName(derivedName);

      setTimeout(() => {
        completeOnboarding(derivedName, {
          userEmail: user.email || undefined,
          userAvatar: user.photoURL || undefined,
          authProvider: 'google',
          primaryAreas: selectedFocus,
        });
      }, 750);
    } catch (err: any) {
      console.error('Firebase Google Sign-In error:', err);
      let errorMsg = 'Google authentication encountered an issue.';
      if (err.code === 'auth/popup-closed-by-user') {
        errorMsg = 'Sign-in window closed before completing. Please try again or enter your name below.';
      } else if (err.code === 'auth/popup-blocked') {
        errorMsg = 'Sign-in popup was blocked by browser. Please allow popups or enter your name below.';
      } else if (err.message) {
        errorMsg = err.message;
      }
      setAuthError(errorMsg);
      showToast(errorMsg, 'error');
    } finally {
      setIsGoogleLoading(false);
    }
  };

  const handleNameSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const finalName = nameInput.trim() || 'Rohan';
    setIsSuccess(true);
    setWelcomeName(finalName);

    setTimeout(() => {
      completeOnboarding(finalName, {
        primaryAreas: selectedFocus,
        authProvider: 'guest',
      });
    }, 500);
  };

  const cycleTheme = () => {
    const modes: Array<'system' | 'light' | 'dark'> = ['system', 'light', 'dark'];
    const next = modes[(modes.indexOf(settings.theme) + 1) % modes.length];
    updateSettings({ theme: next });
  };

  return (
    <div
      id="onboarding-screen"
      className="min-h-screen w-full flex flex-col justify-between bg-[var(--bg-app)] text-[var(--text-primary)] px-4 py-8 sm:py-12 transition-colors relative overflow-hidden"
    >
      {/* Background ambient decorative shapes */}
      <div className="absolute top-[-10%] right-[-5%] w-[400px] h-[400px] bg-indigo-500/5 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-[-10%] left-[-5%] w-[400px] h-[400px] bg-emerald-500/5 rounded-full blur-3xl pointer-events-none" />

      {/* Top Bar with Brand & Theme Switcher */}
      <motion.header
        initial={{ opacity: 0, y: -10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3 }}
        className="w-full max-w-4xl mx-auto flex items-center justify-between relative z-10"
      >
        <div className="flex items-center gap-2.5">
          <div className="w-9 h-9 rounded-xl bg-[var(--accent)] text-[var(--accent-text)] flex items-center justify-center shadow-xs">
            <Brain className="w-5 h-5" />
          </div>
          <div>
            <span className="font-bold text-sm sm:text-base tracking-tight text-[var(--text-primary)]">
              Life OS
            </span>
            <span className="ml-1.5 text-xs text-[var(--text-tertiary)] font-normal hidden sm:inline">
              Personal Operating System
            </span>
          </div>
        </div>

        <motion.button
          whileHover={{ scale: 1.03 }}
          whileTap={{ scale: 0.97 }}
          onClick={cycleTheme}
          className="active-press flex items-center gap-1.5 px-3 py-1.5 rounded-xl border border-[var(--border-default)] bg-[var(--bg-surface)] text-xs text-[var(--text-secondary)] hover:text-[var(--text-primary)] hover:bg-[var(--ui-hover)] transition-colors cursor-pointer shadow-xs"
          title={`Theme: ${settings.theme} (click to toggle)`}
        >
          {settings.theme === 'dark' ? (
            <Moon className="w-3.5 h-3.5 text-indigo-400" />
          ) : settings.theme === 'light' ? (
            <Sun className="w-3.5 h-3.5 text-amber-500" />
          ) : (
            <Laptop className="w-3.5 h-3.5 text-[var(--text-secondary)]" />
          )}
          <span className="capitalize">{settings.theme}</span>
        </motion.button>
      </motion.header>

      {/* Main Center Onboarding Card */}
      <main className="w-full max-w-md mx-auto my-auto py-6 relative z-10">
        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: 15 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          transition={{ duration: 0.35, ease: [0.16, 1, 0.3, 1] }}
          className="bg-[var(--bg-surface)] border border-[var(--border-default)] rounded-3xl p-6 sm:p-8 shadow-[var(--ui-shadow-elevated)] space-y-6"
        >
          {/* Header Typography */}
          <div className="text-center space-y-2">
            <motion.div
              initial={{ scale: 0.8, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              transition={{ delay: 0.1, duration: 0.3 }}
              className="inline-flex items-center justify-center w-12 h-12 rounded-2xl bg-[var(--bg-surface-subtle)] border border-[var(--border-subtle)] text-[var(--accent)] mx-auto mb-1"
            >
              <Sparkles className="w-6 h-6 text-amber-500" />
            </motion.div>
            <h1 className="text-xl sm:text-2xl font-bold tracking-tight text-[var(--text-primary)]">
              Welcome to Life OS
            </h1>
            <p className="text-xs sm:text-sm text-[var(--text-secondary)] leading-relaxed">
              Your personal operating system for daily tasks, deep work rhythms, and continuous growth.
            </p>
          </div>

          {/* Success Animated State */}
          <AnimatePresence mode="wait">
            {isSuccess ? (
              <motion.div
                key="success"
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.9 }}
                className="py-8 text-center space-y-3"
              >
                <motion.div
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  transition={{ type: 'spring', stiffness: 300, damping: 20 }}
                  className="w-14 h-14 rounded-full bg-emerald-500/15 text-emerald-600 dark:text-emerald-400 flex items-center justify-center mx-auto"
                >
                  <CheckCircle2 className="w-8 h-8" />
                </motion.div>
                <h2 className="text-lg font-semibold text-[var(--text-primary)]">
                  Welcome aboard, {welcomeName}!
                </h2>
                <p className="text-xs text-[var(--text-secondary)]">
                  Synchronizing your AI backbone and personal second brain...
                </p>
                <div className="flex justify-center pt-2">
                  <div className="w-6 h-6 border-2 border-[var(--accent)] border-t-transparent rounded-full animate-spin" />
                </div>
              </motion.div>
            ) : (
              <motion.div key="form" className="space-y-5">
                {/* Option 1: Real Firebase "Sign in with Google" button */}
                <div className="space-y-2">
                  <motion.button
                    id="google-signin-btn"
                    type="button"
                    whileHover={{ scale: 1.01 }}
                    whileTap={{ scale: 0.98 }}
                    onClick={handleGoogleSignIn}
                    disabled={isGoogleLoading}
                    className="active-press w-full flex items-center justify-center gap-3 py-3 px-4 rounded-xl border border-[var(--border-default)] bg-[var(--bg-surface-elevated)] hover:bg-[var(--ui-hover)] text-sm font-semibold text-[var(--text-primary)] shadow-xs transition-all cursor-pointer disabled:opacity-70 disabled:cursor-not-allowed"
                  >
                    {isGoogleLoading ? (
                      <div className="flex items-center gap-2">
                        <Loader2 className="w-4 h-4 animate-spin text-[var(--accent)]" />
                        <span className="text-xs font-medium">Connecting Google Account...</span>
                      </div>
                    ) : (
                      <>
                        <svg className="w-4 h-4 shrink-0" viewBox="0 0 24 24">
                          <path
                            fill="#4285F4"
                            d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                          />
                          <path
                            fill="#34A853"
                            d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                          />
                          <path
                            fill="#FBBC05"
                            d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"
                          />
                          <path
                            fill="#EA4335"
                            d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"
                          />
                        </svg>
                        <span>Sign in with Google</span>
                      </>
                    )}
                  </motion.button>

                  <div className="flex items-center justify-center gap-1.5 text-[11px] text-[var(--text-tertiary)]">
                    <ShieldCheck className="w-3.5 h-3.5 text-emerald-500" />
                    <span>Real Firebase Google Authentication</span>
                  </div>

                  {authError && (
                    <motion.div
                      initial={{ opacity: 0, y: -4 }}
                      animate={{ opacity: 1, y: 0 }}
                      className="p-2.5 rounded-xl bg-rose-500/10 border border-rose-500/20 text-rose-600 dark:text-rose-400 text-xs flex items-center gap-2"
                    >
                      <AlertCircle className="w-4 h-4 shrink-0" />
                      <span>{authError}</span>
                    </motion.div>
                  )}
                </div>

                {/* Minimal Divider */}
                <div className="relative flex items-center justify-center">
                  <div className="w-full border-t border-[var(--border-subtle)]" />
                  <span className="absolute bg-[var(--bg-surface)] px-3 text-[11px] font-medium text-[var(--text-tertiary)] uppercase tracking-wider">
                    or continue with name
                  </span>
                </div>

                {/* Option 2: Name Input Field */}
                <form onSubmit={handleNameSubmit} className="space-y-3">
                  <div className="space-y-1.5 text-left">
                    <label
                      htmlFor="user-name-input"
                      className="block text-xs font-semibold text-[var(--text-secondary)]"
                    >
                      What should we call you?
                    </label>
                    <input
                      id="user-name-input"
                      type="text"
                      value={nameInput}
                      onChange={(e) => setNameInput(e.target.value)}
                      placeholder="e.g. Rohan"
                      autoFocus
                      className="w-full px-3.5 py-2.5 rounded-xl bg-[var(--bg-surface-input)] border border-[var(--border-default)] text-[var(--text-primary)] placeholder-[var(--text-tertiary)] text-sm font-medium focus:outline-hidden focus:border-[var(--border-focus)] transition-colors"
                    />
                  </div>

                  {/* Primary Areas of Focus Customization */}
                  <div className="space-y-2 pt-1 text-left">
                    <span className="block text-[11px] font-medium text-[var(--text-tertiary)]">
                      Pick your starting priorities (optional):
                    </span>
                    <div className="grid grid-cols-2 gap-1.5">
                      {focusOptions.map((opt) => {
                        const Icon = opt.icon;
                        const isSelected = selectedFocus.includes(opt.id);
                        return (
                          <motion.button
                            key={opt.id}
                            type="button"
                            whileHover={{ scale: 1.02 }}
                            whileTap={{ scale: 0.98 }}
                            onClick={() => toggleFocus(opt.id)}
                            className={`active-press flex items-center gap-1.5 px-2.5 py-2 rounded-lg border text-[11px] font-medium transition-colors cursor-pointer text-left truncate ${
                              isSelected
                                ? 'bg-[var(--accent)] text-[var(--accent-text)] border-[var(--accent)] shadow-xs'
                                : 'bg-[var(--bg-surface-subtle)] border-[var(--border-subtle)] text-[var(--text-secondary)] hover:bg-[var(--ui-hover)]'
                            }`}
                          >
                            <Icon className="w-3.5 h-3.5 shrink-0" />
                            <span className="truncate">{opt.label}</span>
                          </motion.button>
                        );
                      })}
                    </div>
                  </div>

                  <motion.button
                    id="get-started-btn"
                    type="submit"
                    whileHover={{ scale: 1.01 }}
                    whileTap={{ scale: 0.98 }}
                    className="active-press w-full flex items-center justify-center gap-2 py-2.5 px-4 rounded-xl bg-[var(--accent)] text-[var(--accent-text)] text-sm font-semibold hover:opacity-90 shadow-xs transition-all cursor-pointer mt-2"
                  >
                    <span>Get Started</span>
                    <ArrowRight className="w-4 h-4" />
                  </motion.button>
                </form>
              </motion.div>
            )}
          </AnimatePresence>

          {/* Privacy & Offline Guarantee */}
          <div className="pt-2 border-t border-[var(--border-subtle)] flex items-center justify-center gap-1.5 text-[11px] text-[var(--text-tertiary)]">
            <Lock className="w-3 h-3" />
            <span>Private & offline-first. Your data remains in your control.</span>
          </div>
        </motion.div>
      </main>

      {/* Footer Features Pillars */}
      <motion.footer
        initial={{ opacity: 0, y: 15 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2, duration: 0.35 }}
        className="w-full max-w-2xl mx-auto grid grid-cols-1 sm:grid-cols-3 gap-3 text-center pt-4 relative z-10"
      >
        <motion.div
          whileHover={{ y: -2 }}
          className="p-3 rounded-2xl bg-[var(--bg-surface-subtle)] border border-[var(--border-subtle)] text-xs text-[var(--text-secondary)] transition-all"
        >
          <span className="font-semibold block text-[var(--text-primary)] mb-0.5">
            ⚡ Quick Capture
          </span>
          Inbox for fleeting thoughts & voice memos
        </motion.div>
        <motion.div
          whileHover={{ y: -2 }}
          className="p-3 rounded-2xl bg-[var(--bg-surface-subtle)] border border-[var(--border-subtle)] text-xs text-[var(--text-secondary)] transition-all"
        >
          <span className="font-semibold block text-[var(--text-primary)] mb-0.5">
            🎯 Timeblocking
          </span>
          Seamless daily scheduling & focus sessions
        </motion.div>
        <motion.div
          whileHover={{ y: -2 }}
          className="p-3 rounded-2xl bg-[var(--bg-surface-subtle)] border border-[var(--border-subtle)] text-xs text-[var(--text-secondary)] transition-all"
        >
          <span className="font-semibold block text-[var(--text-primary)] mb-0.5">
            🧠 Second Brain
          </span>
          Linked notes, projects, and life review
        </motion.div>
      </motion.footer>
    </div>
  );
};
