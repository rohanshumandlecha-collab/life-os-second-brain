import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  X,
  Sparkles,
  Mic,
  MicOff,
  Link,
  Send,
  HelpCircle,
  Layers,
  CheckCircle2,
  FileText,
  Target,
  FolderGit2,
  Flame,
  Calendar,
} from 'lucide-react';
import { useLifeOS } from '../../context/LifeOSContext';

export const UniversalCaptureModal: React.FC = () => {
  const {
    isCaptureOpen,
    setIsCaptureOpen,
    processCapture,
    showToast,
    setIsTemplateModalOpen,
  } = useLifeOS();
  const [content, setContent] = useState('');
  const [captureSource, setCaptureSource] = useState<'text' | 'voice' | 'link'>('text');
  const [isProcessing, setIsProcessing] = useState(false);
  const [analysisResult, setAnalysisResult] = useState<any | null>(null);
  const [clarificationAnswer, setClarificationAnswer] = useState('');
  const [selectedEntityHint, setSelectedEntityHint] = useState<string | null>(null);

  // Speech recognition setup
  const [isListening, setIsListening] = useState(false);
  const recognitionRef = useRef<any>(null);

  useEffect(() => {
    if (!isCaptureOpen) {
      setContent('');
      setAnalysisResult(null);
      setIsProcessing(false);
      setSelectedEntityHint(null);
      if (isListening) stopListening();
    }
  }, [isCaptureOpen]);

  const startListening = () => {
    const SpeechRecognition =
      (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SpeechRecognition) {
      showToast('Speech recognition is not supported in this browser.', 'warning');
      return;
    }

    try {
      const recognition = new SpeechRecognition();
      recognition.continuous = true;
      recognition.interimResults = true;
      recognition.lang = 'en-US';

      recognition.onstart = () => {
        setIsListening(true);
        setCaptureSource('voice');
      };

      recognition.onresult = (event: any) => {
        let transcript = '';
        for (let i = event.resultIndex; i < event.results.length; ++i) {
          transcript += event.results[i][0].transcript;
        }
        setContent(transcript);
      };

      recognition.onerror = (event: any) => {
        console.warn('Speech recognition error:', event.error);
        setIsListening(false);
      };

      recognition.onend = () => {
        setIsListening(false);
      };

      recognition.start();
      recognitionRef.current = recognition;
    } catch (e) {
      console.warn('Speech recognition failed to initialize:', e);
      setIsListening(false);
    }
  };

  const stopListening = () => {
    if (recognitionRef.current) {
      recognitionRef.current.stop();
      setIsListening(false);
    }
  };

  const handleCaptureSubmit = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();

    // Check if user is invoking templates
    if (content.trim().startsWith('/template') || content.trim().toLowerCase() === 'template') {
      setIsCaptureOpen(false);
      setIsTemplateModalOpen(true);
      return;
    }

    let textToProcess = content.trim();
    if (selectedEntityHint) {
      textToProcess = `[Type: ${selectedEntityHint}] ${textToProcess}`;
    }
    if (clarificationAnswer) {
      textToProcess = `${textToProcess} (Clarification: ${clarificationAnswer})`;
    }

    if (!textToProcess || isProcessing) return;

    setIsProcessing(true);
    try {
      const result = await processCapture({
        rawContent: textToProcess,
        source: captureSource,
      });

      if (result.analysis?.clarificationNeeded && !clarificationAnswer) {
        setAnalysisResult(result);
        setIsProcessing(false);
        return;
      }

      showToast(`Captured as ${result.entityType}: "${result.item.title}"`, 'success');
      setIsCaptureOpen(false);
    } catch (err) {
      showToast('Saved to Inbox', 'info');
      setIsCaptureOpen(false);
    } finally {
      setIsProcessing(false);
    }
  };

  if (!isCaptureOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-md flex items-end sm:items-center justify-center p-0 sm:p-4 overflow-y-auto">
      <motion.div
        initial={{ opacity: 0, y: 40 }}
        animate={{ opacity: 1, y: 0 }}
        exit={{ opacity: 0, y: 40 }}
        transition={{ type: 'spring', stiffness: 450, damping: 32 }}
        className="w-full max-w-lg rounded-t-[28px] sm:rounded-3xl bg-[var(--bg-surface-elevated)] border border-[var(--border-default)] shadow-2xl p-5 space-y-4 text-[var(--text-primary)] pb-safe"
      >
        {/* iOS Drag Handle */}
        <div className="w-10 h-1.5 rounded-full bg-[var(--text-tertiary)]/40 mx-auto -mt-2 mb-2 sm:hidden" />

        {/* Modal Header */}
        <div className="flex items-center justify-between border-b border-[var(--border-default)] pb-3">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-[var(--accent)] text-[var(--accent-text)] flex items-center justify-center shadow-xs">
              <Sparkles className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-sm font-semibold text-[var(--text-primary)]">
                Universal Quick Capture
              </h2>
              <p className="text-[11px] text-[var(--text-tertiary)]">
                Enter once → AI understands, organizes, connects, and acts.
              </p>
            </div>
          </div>
          <button
            onClick={() => setIsCaptureOpen(false)}
            className="active-press p-1.5 rounded-lg text-[var(--text-tertiary)] hover:text-[var(--text-primary)] hover:bg-[var(--ui-hover)] transition-colors cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Optional Intent Chips */}
        <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar pb-1">
          <button
            onClick={() => {
              setIsCaptureOpen(false);
              setIsTemplateModalOpen(true);
            }}
            className="active-press px-2.5 py-1 rounded-lg text-xs font-semibold bg-purple-500/10 text-purple-600 dark:text-purple-400 border border-purple-500/20 hover:bg-purple-500/20 flex items-center gap-1 shrink-0 cursor-pointer"
          >
            <Layers className="w-3.5 h-3.5" />
            <span>Templates</span>
          </button>

          {[
            { id: 'task', label: 'Task', icon: CheckCircle2 },
            { id: 'note', label: 'Note', icon: FileText },
            { id: 'project', label: 'Project', icon: FolderGit2 },
            { id: 'goal', label: 'Goal', icon: Target },
            { id: 'habit', label: 'Habit', icon: Flame },
            { id: 'event', label: 'Event', icon: Calendar },
          ].map((chip) => {
            const Icon = chip.icon;
            const isSelected = selectedEntityHint === chip.id;
            return (
              <button
                key={chip.id}
                onClick={() => setSelectedEntityHint(isSelected ? null : chip.id)}
                className={`active-press px-2.5 py-1 rounded-lg text-xs font-medium border flex items-center gap-1 shrink-0 transition-colors cursor-pointer ${
                  isSelected
                    ? 'bg-[var(--accent)] text-[var(--accent-text)] border-[var(--accent)] font-semibold'
                    : 'bg-[var(--bg-surface-subtle)] border-[var(--border-subtle)] text-[var(--text-secondary)] hover:text-[var(--text-primary)]'
                }`}
              >
                <Icon className="w-3 h-3" />
                <span>{chip.label}</span>
              </button>
            );
          })}
        </div>

        {/* Input area */}
        <div className="space-y-3">
          <textarea
            value={content}
            onChange={(e) => setContent(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter' && (e.metaKey || e.ctrlKey)) {
                e.preventDefault();
                handleCaptureSubmit();
              }
            }}
            placeholder="What's on your mind? (e.g., 'Prep for finals next month', 'Buy organic coffee', 'Read 20 mins daily', or '/template')..."
            rows={4}
            className="w-full p-3.5 rounded-xl bg-[var(--bg-surface-input)] border border-[var(--border-default)] text-xs sm:text-sm text-[var(--text-primary)] placeholder-[var(--text-tertiary)] focus:outline-hidden focus:border-[var(--border-focus)] resize-none font-sans leading-relaxed"
            autoFocus
          />

          {/* Clarification prompt from AI if needed */}
          {analysisResult?.analysis?.clarificationNeeded && (
            <div className="p-3 rounded-xl bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800 text-xs text-amber-900 dark:text-amber-200 space-y-2">
              <div className="flex items-center gap-1.5 font-semibold">
                <HelpCircle className="w-3.5 h-3.5 text-amber-600" />
                <span>AI Clarification</span>
              </div>
              <p>{analysisResult.analysis.clarificationNeeded}</p>
              <input
                type="text"
                value={clarificationAnswer}
                onChange={(e) => setClarificationAnswer(e.target.value)}
                placeholder="Clarify details (optional)..."
                className="w-full px-2.5 py-1.5 rounded-lg bg-[var(--bg-surface)] border border-amber-200 dark:border-amber-800 text-xs text-[var(--text-primary)] focus:outline-hidden"
              />
            </div>
          )}

          {/* Capture controls & Source Selector */}
          <div className="flex items-center justify-between pt-1">
            <div className="flex items-center gap-1.5">
              <button
                type="button"
                onClick={() => (isListening ? stopListening() : startListening())}
                className={`active-press px-2.5 py-1.5 rounded-lg text-xs font-medium flex items-center gap-1.5 transition-colors cursor-pointer border ${
                  isListening
                    ? 'bg-rose-500/15 text-rose-600 dark:text-rose-400 border-rose-500/30 animate-pulse'
                    : 'bg-[var(--bg-surface-subtle)] border-[var(--border-default)] text-[var(--text-secondary)] hover:text-[var(--text-primary)] hover:bg-[var(--ui-hover)]'
                }`}
                title="Voice dictation (speech-to-text)"
              >
                {isListening ? <MicOff className="w-3.5 h-3.5" /> : <Mic className="w-3.5 h-3.5" />}
                <span>{isListening ? 'Listening...' : 'Voice'}</span>
              </button>

              <button
                type="button"
                onClick={() => setCaptureSource('link')}
                className={`active-press px-2.5 py-1.5 rounded-lg text-xs font-medium flex items-center gap-1.5 transition-colors cursor-pointer border ${
                  captureSource === 'link'
                    ? 'bg-[var(--accent)] text-[var(--accent-text)] border-[var(--accent)]'
                    : 'bg-[var(--bg-surface-subtle)] border-[var(--border-default)] text-[var(--text-secondary)] hover:text-[var(--text-primary)] hover:bg-[var(--ui-hover)]'
                }`}
              >
                <Link className="w-3.5 h-3.5" />
                <span>Link</span>
              </button>
            </div>

            <div className="flex items-center gap-2">
              <span className="text-[11px] text-[var(--text-tertiary)] hidden sm:inline">⌘ + Enter</span>
              <button
                onClick={() => handleCaptureSubmit()}
                disabled={!content.trim() || isProcessing}
                className="active-press flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-semibold bg-[var(--accent)] text-[var(--accent-text)] hover:opacity-90 disabled:opacity-40 transition-colors shadow-xs cursor-pointer"
              >
                <Send className="w-3.5 h-3.5" />
                <span>{isProcessing ? 'Understanding...' : 'Capture'}</span>
              </button>
            </div>
          </div>
        </div>
      </motion.div>
    </div>
  );
};

