import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import {
  X,
  Play,
  Pause,
  RotateCcw,
  Volume2,
  CheckCircle2,
} from 'lucide-react';
import { useLifeOS } from '../../context/LifeOSContext';
import { soundscapes, AmbientType } from '../../utils/audioSynth';

export const FocusModal: React.FC = () => {
  const {
    isFocusOpen,
    setIsFocusOpen,
    tasks,
    logFocusSession,
    showToast,
    toggleTaskComplete,
  } = useLifeOS();

  const [durationMinutes, setDurationMinutes] = useState(25);
  const [secondsRemaining, setSecondsRemaining] = useState(25 * 60);
  const [isRunning, setIsRunning] = useState(false);
  const [selectedTaskId, setSelectedTaskId] = useState('');
  const [ambientSound, setAmbientSound] = useState<AmbientType>('none');
  const [ambientVolume, setAmbientVolume] = useState(0.25);
  const [isCompleted, setIsCompleted] = useState(false);
  const [reflectionNote, setReflectionNote] = useState('');

  // Timer interval
  useEffect(() => {
    let interval: any = null;
    if (isRunning && secondsRemaining > 0) {
      interval = setInterval(() => {
        setSecondsRemaining((prev) => prev - 1);
      }, 1000);
    } else if (isRunning && secondsRemaining === 0) {
      setIsRunning(false);
      setIsCompleted(true);
      soundscapes.stop();
      setAmbientSound('none');
    }
    return () => clearInterval(interval);
  }, [isRunning, secondsRemaining]);

  const handleStartPause = () => {
    if (!isRunning && ambientSound !== 'none') {
      soundscapes.play(ambientSound, ambientVolume);
    } else if (isRunning) {
      soundscapes.stop();
    }
    setIsRunning(!isRunning);
  };

  const handleReset = () => {
    setIsRunning(false);
    setSecondsRemaining(durationMinutes * 60);
    soundscapes.stop();
  };

  const handleSoundChange = (type: AmbientType) => {
    setAmbientSound(type);
    if (isRunning) {
      soundscapes.play(type, ambientVolume);
    }
  };

  const handleVolumeChange = (vol: number) => {
    setAmbientVolume(vol);
    soundscapes.setVolume(vol);
  };

  const handleFinishSession = () => {
    logFocusSession({
      durationMinutes,
      taskId: selectedTaskId || undefined,
      reflection: reflectionNote.trim() || undefined,
      distractionsCount: 0,
    });

    if (selectedTaskId) {
      toggleTaskComplete(selectedTaskId);
    }

    showToast(`Focus session saved (${durationMinutes}m)`, 'success');
    setIsFocusOpen(false);
    setIsCompleted(false);
    setReflectionNote('');
    setSecondsRemaining(durationMinutes * 60);
  };

  if (!isFocusOpen) return null;

  const mins = Math.floor(secondsRemaining / 60);
  const secs = secondsRemaining % 60;
  const timeStr = `${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-3 sm:p-4 overflow-y-auto">
      <motion.div
        initial={{ opacity: 0, scale: 0.95, y: 12 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.95, y: 12 }}
        transition={{ duration: 0.2, ease: [0.16, 1, 0.3, 1] }}
        className="w-full max-w-lg rounded-3xl bg-neutral-900 border border-neutral-800 p-5 sm:p-8 shadow-2xl relative space-y-6 text-neutral-100"
      >
        {/* Close */}
        <button
          onClick={() => {
            soundscapes.stop();
            setIsFocusOpen(false);
          }}
          className="active-press absolute right-5 top-5 p-1.5 rounded-lg text-neutral-500 hover:text-neutral-200 transition-colors cursor-pointer"
          aria-label="Close Focus Mode"
        >
          <X className="w-5 h-5" />
        </button>

        {!isCompleted ? (
          <>
            {/* Header & Task Selector */}
            <div className="text-center space-y-2">
              <span className="text-[11px] font-semibold uppercase tracking-widest text-neutral-400">
                Deep Work Chamber
              </span>
              <div className="pt-1">
                <select
                  value={selectedTaskId}
                  onChange={(e) => setSelectedTaskId(e.target.value)}
                  className="px-3 py-1.5 rounded-lg bg-neutral-800 border border-neutral-700 text-xs text-neutral-200 max-w-xs focus:outline-hidden font-medium"
                >
                  <option value="">Independent Deep Work Block</option>
                  {tasks
                    .filter((t) => t.status !== 'completed')
                    .map((t) => (
                      <option key={t.id} value={t.id}>
                        {t.title}
                      </option>
                    ))}
                </select>
              </div>
            </div>

            {/* Giant Minimalist Timer Display */}
            <div className="text-center py-3 sm:py-5 select-none">
              <div className="text-6xl sm:text-7xl font-light tracking-tighter font-mono text-white">
                {timeStr}
              </div>
            </div>

            {/* Timer preset selection when paused */}
            {!isRunning && (
              <div className="flex justify-center gap-2 flex-wrap">
                {[15, 25, 50, 90].map((m) => (
                  <button
                    key={m}
                    onClick={() => {
                      setDurationMinutes(m);
                      setSecondsRemaining(m * 60);
                    }}
                    className={`active-press px-3.5 py-1.5 rounded-lg text-xs font-medium transition-colors cursor-pointer ${
                      durationMinutes === m
                        ? 'bg-neutral-100 text-neutral-900 shadow-sm'
                        : 'bg-neutral-800 text-neutral-400 hover:text-white'
                    }`}
                  >
                    {m}m
                  </button>
                ))}
              </div>
            )}

            {/* Play / Pause / Reset Controls */}
            <div className="flex items-center justify-center gap-4 pt-2">
              <button
                onClick={handleReset}
                className="active-press p-3 rounded-full bg-neutral-800 text-neutral-400 hover:text-white transition-colors cursor-pointer"
                title="Reset timer"
              >
                <RotateCcw className="w-4 h-4" />
              </button>

              <button
                onClick={handleStartPause}
                className="active-press px-8 py-3.5 rounded-full bg-white text-neutral-900 font-semibold text-sm hover:bg-neutral-200 transition-colors shadow-lg flex items-center gap-2 cursor-pointer"
              >
                {isRunning ? (
                  <>
                    <Pause className="w-4 h-4" />
                    <span>Pause Flow</span>
                  </>
                ) : (
                  <>
                    <Play className="w-4 h-4" />
                    <span>Begin Flow</span>
                  </>
                )}
              </button>
            </div>

            {/* Ambient Soundscapes Selector */}
            <div className="p-4 rounded-2xl bg-neutral-800/60 border border-neutral-800 space-y-3">
              <div className="flex items-center justify-between text-xs text-neutral-400">
                <span className="font-semibold uppercase tracking-wider text-[10px] flex items-center gap-1.5">
                  <Volume2 className="w-3.5 h-3.5" />
                  Ambient Soundscape
                </span>
                <span className="capitalize">{ambientSound === 'none' ? 'Muted' : ambientSound}</span>
              </div>

              <div className="grid grid-cols-5 gap-1.5 text-xs">
                {(['none', 'rain', 'whitenoise', 'cafe', 'waves'] as AmbientType[]).map((type) => (
                  <button
                    key={type}
                    onClick={() => handleSoundChange(type)}
                    className={`active-press py-1.5 rounded-lg capitalize font-medium transition-all text-center cursor-pointer text-[11px] sm:text-xs ${
                      ambientSound === type
                        ? 'bg-neutral-100 text-neutral-900 shadow-xs'
                        : 'bg-neutral-800 text-neutral-400 hover:text-white'
                    }`}
                  >
                    {type === 'whitenoise' ? 'White' : type}
                  </button>
                ))}
              </div>

              {ambientSound !== 'none' && (
                <div className="flex items-center gap-3 pt-1">
                  <span className="text-[11px] text-neutral-400">Volume</span>
                  <input
                    type="range"
                    min="0"
                    max="1"
                    step="0.05"
                    value={ambientVolume}
                    onChange={(e) => handleVolumeChange(parseFloat(e.target.value))}
                    className="flex-1 accent-white cursor-pointer"
                  />
                </div>
              )}
            </div>
          </>
        ) : (
          /* Completion Reflection View */
          <div className="text-center space-y-4 py-4">
            <CheckCircle2 className="w-12 h-12 text-emerald-400 mx-auto" />
            <div>
              <h3 className="text-lg font-semibold text-white">Flow Session Complete</h3>
              <p className="text-xs text-neutral-400 mt-1">
                You maintained focused attention for {durationMinutes} minutes.
              </p>
            </div>

            <textarea
              placeholder="Session reflection / notes on progress..."
              value={reflectionNote}
              onChange={(e) => setReflectionNote(e.target.value)}
              rows={3}
              className="w-full p-3 rounded-xl bg-neutral-800 border border-neutral-700 text-xs text-white placeholder-neutral-500 focus:outline-hidden resize-none"
            />

            <button
              onClick={handleFinishSession}
              className="active-press w-full py-2.5 rounded-xl bg-white text-neutral-900 font-semibold text-xs hover:bg-neutral-200 transition-colors cursor-pointer"
            >
              Log & Return to Life OS
            </button>
          </div>
        )}
      </motion.div>
    </div>
  );
};
