import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  X,
  Settings,
  Download,
  Upload,
  RotateCcw,
  Trash2,
  Moon,
  Sun,
  Laptop,
  Check,
  Shield,
  Key,
  Cpu,
  Eye,
  EyeOff,
  CheckCircle2,
  AlertCircle,
  Loader2,
  Sparkles,
  User as UserIcon,
  LogOut,
  LogIn,
  ExternalLink,
  HelpCircle,
  Smartphone,
} from 'lucide-react';
import { useLifeOS } from '../../context/LifeOSContext';
import { signInWithGoogle } from '../../lib/firebase';
import { usePWAInstall } from '../../hooks/usePWAInstall';
import { PWAInstallModal } from './PWAInstallModal';

export const SettingsModal: React.FC = () => {
  const {
    isSettingsOpen,
    setIsSettingsOpen,
    settings,
    updateSettings,
    currentUser,
    signOutUser,
    testAIConnection,
    exportDataAsJSON,
    importDataFromJSON,
    resetToDefaultData,
    clearAllData,
    restartOnboarding,
    showToast,
    openHelpWithContext,
  } = useLifeOS();

  // Local state for API keys input
  const [geminiKeyInput, setGeminiKeyInput] = useState(settings.geminiApiKey || '');
  const [openaiKeyInput, setOpenaiKeyInput] = useState(settings.openaiApiKey || '');
  const [showGeminiKey, setShowGeminiKey] = useState(false);
  const [showOpenaiKey, setShowOpenaiKey] = useState(false);

  // Testing status
  const [isTestingGemini, setIsTestingGemini] = useState(false);
  const [geminiTestStatus, setGeminiTestStatus] = useState<{
    ok: boolean;
    message: string;
    latencyMs?: number;
  } | null>(null);

  const [isTestingOpenAI, setIsTestingOpenAI] = useState(false);
  const [openaiTestStatus, setOpenaiTestStatus] = useState<{
    ok: boolean;
    message: string;
    latencyMs?: number;
  } | null>(null);

  // Google sign in loading in settings
  const [isGoogleSigningIn, setIsGoogleSigningIn] = useState(false);

  // PWA Install State
  const { isInstallable, isInstalled, promptInstall } = usePWAInstall();
  const [showPwaInstallModal, setShowPwaInstallModal] = useState(false);

  // Backup & Restore
  const [importJsonText, setImportJsonText] = useState('');
  const [showImportArea, setShowImportArea] = useState(false);

  if (!isSettingsOpen) return null;

  // Save Gemini Key to Settings & Local Storage
  const handleSaveGeminiKey = (value: string) => {
    setGeminiKeyInput(value);
    updateSettings({ geminiApiKey: value.trim() });
    setGeminiTestStatus(null);
  };

  // Save OpenAI Key to Settings & Local Storage
  const handleSaveOpenaiKey = (value: string) => {
    setOpenaiKeyInput(value);
    updateSettings({ openaiApiKey: value.trim() });
    setOpenaiTestStatus(null);
  };

  // Test Gemini Key
  const handleTestGeminiKey = async () => {
    const key = geminiKeyInput.trim() || settings.geminiApiKey;
    if (!key) {
      setGeminiTestStatus({ ok: false, message: 'Please enter a Gemini API key first' });
      return;
    }
    setIsTestingGemini(true);
    setGeminiTestStatus(null);
    try {
      const res = await testAIConnection('gemini', key, settings.geminiModel);
      setGeminiTestStatus(res);
      if (res.ok) {
        showToast(res.message, 'success');
      } else {
        showToast(res.message, 'error');
      }
    } catch (e: any) {
      setGeminiTestStatus({ ok: false, message: e.message || 'Verification failed' });
    } finally {
      setIsTestingGemini(false);
    }
  };

  // Test OpenAI Key
  const handleTestOpenaiKey = async () => {
    const key = openaiKeyInput.trim() || settings.openaiApiKey;
    if (!key) {
      setOpenaiTestStatus({ ok: false, message: 'Please enter an OpenAI API key first' });
      return;
    }
    setIsTestingOpenAI(true);
    setOpenaiTestStatus(null);
    try {
      const res = await testAIConnection('openai', key, settings.openaiModel);
      setOpenaiTestStatus(res);
      if (res.ok) {
        showToast(res.message, 'success');
      } else {
        showToast(res.message, 'error');
      }
    } catch (e: any) {
      setOpenaiTestStatus({ ok: false, message: e.message || 'Verification failed' });
    } finally {
      setIsTestingOpenAI(false);
    }
  };

  // Google Sign In from Settings
  const handleSettingsGoogleSignIn = async () => {
    setIsGoogleSigningIn(true);
    try {
      const user = await signInWithGoogle();
      updateSettings({
        userName: user.displayName || settings.userName,
        userEmail: user.email || undefined,
        userAvatar: user.photoURL || undefined,
        authProvider: 'google',
      });
      showToast(`Signed in as ${user.displayName || user.email}!`, 'success');
    } catch (err: any) {
      showToast(err.message || 'Google sign in failed', 'error');
    } finally {
      setIsGoogleSigningIn(false);
    }
  };

  const handleDownloadBackup = () => {
    const jsonStr = exportDataAsJSON();
    const blob = new Blob([jsonStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `life_os_backup_${new Date().toISOString().split('T')[0]}.json`;
    a.click();
    URL.revokeObjectURL(url);
    showToast('Life OS backup file downloaded', 'success');
  };

  const handleApplyImport = () => {
    if (!importJsonText.trim()) return;
    const ok = importDataFromJSON(importJsonText.trim());
    if (ok) {
      setShowImportArea(false);
      setImportJsonText('');
      setIsSettingsOpen(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-md flex items-end sm:items-center justify-center p-0 sm:p-4 overflow-y-auto">
      <motion.div
        initial={{ opacity: 0, y: 40 }}
        animate={{ opacity: 1, y: 0 }}
        exit={{ opacity: 0, y: 40 }}
        transition={{ type: 'spring', stiffness: 450, damping: 32 }}
        className="w-full max-w-xl rounded-t-[28px] sm:rounded-3xl bg-[var(--bg-surface-elevated)] border border-[var(--border-default)] shadow-2xl p-5 sm:p-6 space-y-6 max-h-[92vh] overflow-y-auto text-[var(--text-primary)] pb-safe"
      >
        {/* iOS Drag Handle */}
        <div className="w-10 h-1.5 rounded-full bg-[var(--text-tertiary)]/40 mx-auto -mt-2 mb-2 sm:hidden" />

        {/* Header */}
        <div className="flex items-center justify-between border-b border-[var(--border-default)] pb-3">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-[var(--accent)] text-[var(--accent-text)] flex items-center justify-center shadow-xs">
              <Settings className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-sm font-semibold text-[var(--text-primary)]">
                Life OS Settings
              </h2>
              <p className="text-[11px] text-[var(--text-tertiary)]">
                AI Backbone, Cloud Identity, and Local Preferences
              </p>
            </div>
          </div>
          <div className="flex items-center gap-1.5">
            <button
              onClick={() => {
                setIsSettingsOpen(false);
                openHelpWithContext('settings');
              }}
              className="active-press p-1.5 rounded-lg text-[var(--text-tertiary)] hover:text-[var(--accent)] hover:bg-[var(--ui-hover)] transition-colors cursor-pointer"
              title="Settings & Privacy Help"
              aria-label="Settings Help"
            >
              <HelpCircle className="w-4 h-4" />
            </button>
            <button
              onClick={() => setIsSettingsOpen(false)}
              className="active-press p-1.5 rounded-lg text-[var(--text-tertiary)] hover:text-[var(--text-primary)] hover:bg-[var(--ui-hover)] transition-colors cursor-pointer"
              title="Close Settings"
              aria-label="Close Settings"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Section 1: User Account & Firebase Google Auth */}
        <section className="space-y-3 p-3.5 rounded-xl bg-[var(--bg-surface-subtle)] border border-[var(--border-default)]">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <UserIcon className="w-4 h-4 text-[var(--accent)]" />
              <h3 className="text-xs font-semibold text-[var(--text-primary)]">
                User Identity & Google Authentication
              </h3>
            </div>
            {settings.authProvider === 'google' && (
              <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-medium bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border border-emerald-500/20">
                <CheckCircle2 className="w-3 h-3" />
                Firebase Verified
              </span>
            )}
          </div>

          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pt-1">
            <div className="flex items-center gap-3">
              {settings.userAvatar ? (
                <img
                  src={settings.userAvatar}
                  alt={settings.userName}
                  className="w-10 h-10 rounded-full border border-[var(--border-default)] object-cover"
                />
              ) : (
                <div className="w-10 h-10 rounded-full bg-[var(--accent)] text-[var(--accent-text)] flex items-center justify-center font-bold text-sm shadow-xs">
                  {settings.userName?.slice(0, 1).toUpperCase() || 'U'}
                </div>
              )}
              <div>
                <p className="text-xs font-semibold text-[var(--text-primary)]">
                  {settings.userName || 'Guest User'}
                </p>
                <p className="text-[11px] text-[var(--text-secondary)]">
                  {settings.userEmail || 'Local guest mode (no account linked)'}
                </p>
              </div>
            </div>

            {settings.authProvider === 'google' || currentUser ? (
              <button
                type="button"
                onClick={signOutUser}
                className="active-press inline-flex items-center justify-center gap-1.5 px-3 py-1.5 rounded-lg border border-[var(--border-default)] bg-[var(--bg-surface)] hover:bg-[var(--ui-hover)] text-xs font-medium text-[var(--text-secondary)] hover:text-rose-500 transition-colors cursor-pointer"
              >
                <LogOut className="w-3.5 h-3.5" />
                <span>Sign Out</span>
              </button>
            ) : (
              <button
                type="button"
                onClick={handleSettingsGoogleSignIn}
                disabled={isGoogleSigningIn}
                className="active-press inline-flex items-center justify-center gap-2 px-3 py-1.5 rounded-lg border border-[var(--border-default)] bg-[var(--bg-surface-elevated)] hover:bg-[var(--ui-hover)] text-xs font-semibold text-[var(--text-primary)] shadow-xs transition-colors cursor-pointer disabled:opacity-50"
              >
                {isGoogleSigningIn ? (
                  <Loader2 className="w-3.5 h-3.5 animate-spin" />
                ) : (
                  <svg className="w-3.5 h-3.5" viewBox="0 0 24 24">
                    <path
                      fill="#4285F4"
                      d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                    />
                    <path
                      fill="#34A853"
                      d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                    />
                    <path
                      fill="#FBBC05"
                      d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"
                    />
                    <path
                      fill="#EA4335"
                      d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"
                    />
                  </svg>
                )}
                <span>Sign in with Google</span>
              </button>
            )}
          </div>
        </section>

        {/* Section 2: AI Backbone Configuration (Gemini & OpenAI) */}
        <section className="space-y-4 p-4 rounded-xl bg-[var(--bg-surface-subtle)] border border-[var(--border-default)]">
          <div className="flex items-center justify-between border-b border-[var(--border-subtle)] pb-2.5">
            <div className="flex items-center gap-2">
              <Cpu className="w-4 h-4 text-indigo-500" />
              <div>
                <h3 className="text-xs font-semibold text-[var(--text-primary)]">
                  AI Backbone & Model Provider
                </h3>
                <p className="text-[11px] text-[var(--text-tertiary)]">
                  Configure Gemini and OpenAI keys, models, and fallback routing
                </p>
              </div>
            </div>
            <div className="flex items-center gap-1 text-[11px] text-emerald-600 dark:text-emerald-400 font-medium">
              <Shield className="w-3.5 h-3.5" />
              <span>Local Storage Protected</span>
            </div>
          </div>

          {/* Primary AI Provider Selector */}
          <div className="space-y-2">
            <label className="block text-xs font-semibold text-[var(--text-secondary)]">
              Preferred Primary AI Provider
            </label>
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => updateSettings({ preferredAIProvider: 'gemini' })}
                className={`active-press flex items-center justify-between p-3 rounded-xl border text-left transition-all cursor-pointer ${
                  settings.preferredAIProvider === 'gemini'
                    ? 'border-indigo-500 bg-indigo-500/10 text-[var(--text-primary)] shadow-xs'
                    : 'border-[var(--border-default)] bg-[var(--bg-surface)] text-[var(--text-secondary)] hover:bg-[var(--ui-hover)]'
                }`}
              >
                <div>
                  <span className="text-xs font-semibold block text-[var(--text-primary)]">
                    Google Gemini
                  </span>
                  <span className="text-[10px] text-[var(--text-tertiary)]">
                    Fast reasoning, captures & multi-modal
                  </span>
                </div>
                {settings.preferredAIProvider === 'gemini' && (
                  <Check className="w-4 h-4 text-indigo-500 shrink-0" />
                )}
              </button>

              <button
                type="button"
                onClick={() => updateSettings({ preferredAIProvider: 'openai' })}
                className={`active-press flex items-center justify-between p-3 rounded-xl border text-left transition-all cursor-pointer ${
                  settings.preferredAIProvider === 'openai'
                    ? 'border-emerald-500 bg-emerald-500/10 text-[var(--text-primary)] shadow-xs'
                    : 'border-[var(--border-default)] bg-[var(--bg-surface)] text-[var(--text-secondary)] hover:bg-[var(--ui-hover)]'
                }`}
              >
                <div>
                  <span className="text-xs font-semibold block text-[var(--text-primary)]">
                    OpenAI
                  </span>
                  <span className="text-[10px] text-[var(--text-tertiary)]">
                    GPT-4o & mini intelligence
                  </span>
                </div>
                {settings.preferredAIProvider === 'openai' && (
                  <Check className="w-4 h-4 text-emerald-500 shrink-0" />
                )}
              </button>
            </div>
          </div>

          {/* Gemini API Key Input */}
          <div className="space-y-2 p-3 rounded-xl bg-[var(--bg-surface)] border border-[var(--border-default)]">
            <div className="flex items-center justify-between">
              <label className="text-xs font-semibold text-[var(--text-primary)] flex items-center gap-1.5">
                <Key className="w-3.5 h-3.5 text-indigo-500" />
                <span>Google Gemini API Key</span>
              </label>
              <div className="flex items-center gap-1.5">
                {settings.geminiApiKey ? (
                  <span className="text-[10px] font-medium text-emerald-600 dark:text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded-md">
                    Stored in localStorage
                  </span>
                ) : (
                  <span className="text-[10px] font-medium text-neutral-400">
                    Optional (uses env if unset)
                  </span>
                )}
              </div>
            </div>

            <div className="relative flex items-center">
              <input
                type={showGeminiKey ? 'text' : 'password'}
                value={geminiKeyInput}
                onChange={(e) => handleSaveGeminiKey(e.target.value)}
                placeholder="AIzaSy..."
                className="w-full pl-3 pr-18 py-2 rounded-lg bg-[var(--bg-surface-input)] border border-[var(--border-default)] text-xs font-mono text-[var(--text-primary)] focus:outline-hidden focus:border-indigo-500 transition-colors"
              />
              <div className="absolute right-2 flex items-center gap-1">
                <button
                  type="button"
                  onClick={() => setShowGeminiKey(!showGeminiKey)}
                  className="p-1 rounded text-[var(--text-tertiary)] hover:text-[var(--text-primary)] transition-colors"
                  title={showGeminiKey ? 'Hide key' : 'Show key'}
                >
                  {showGeminiKey ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                </button>
              </div>
            </div>

            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pt-1">
              <div className="flex items-center gap-2">
                <span className="text-[11px] text-[var(--text-tertiary)]">Model:</span>
                <select
                  value={settings.geminiModel || 'gemini-3.6-flash'}
                  onChange={(e) => updateSettings({ geminiModel: e.target.value })}
                  className="px-2 py-1 rounded bg-[var(--bg-surface-input)] border border-[var(--border-default)] text-[11px] text-[var(--text-secondary)] focus:outline-hidden"
                >
                  <option value="gemini-3.6-flash">gemini-3.6-flash (Recommended)</option>
                  <option value="gemini-2.5-flash">gemini-2.5-flash</option>
                  <option value="gemini-2.5-pro">gemini-2.5-pro</option>
                  <option value="gemini-flash-latest">gemini-flash-latest</option>
                </select>
              </div>

              <button
                type="button"
                onClick={handleTestGeminiKey}
                disabled={isTestingGemini || (!geminiKeyInput && !settings.geminiApiKey)}
                className="active-press inline-flex items-center justify-center gap-1.5 px-3 py-1 rounded-lg border border-indigo-200 dark:border-indigo-800 bg-indigo-50 dark:bg-indigo-950/40 text-indigo-600 dark:text-indigo-400 text-xs font-medium hover:bg-indigo-100 transition-colors cursor-pointer disabled:opacity-40"
              >
                {isTestingGemini ? (
                  <Loader2 className="w-3 h-3 animate-spin" />
                ) : (
                  <Sparkles className="w-3 h-3" />
                )}
                <span>Test Connection</span>
              </button>
            </div>

            {geminiTestStatus && (
              <motion.div
                initial={{ opacity: 0, y: -4 }}
                animate={{ opacity: 1, y: 0 }}
                className={`p-2 rounded-lg text-[11px] flex items-center gap-2 ${
                  geminiTestStatus.ok
                    ? 'bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border border-emerald-500/20'
                    : 'bg-rose-500/10 text-rose-600 dark:text-rose-400 border border-rose-500/20'
                }`}
              >
                {geminiTestStatus.ok ? (
                  <CheckCircle2 className="w-3.5 h-3.5 shrink-0" />
                ) : (
                  <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                )}
                <span className="flex-1">{geminiTestStatus.message}</span>
              </motion.div>
            )}
          </div>

          {/* OpenAI API Key Input */}
          <div className="space-y-2 p-3 rounded-xl bg-[var(--bg-surface)] border border-[var(--border-default)]">
            <div className="flex items-center justify-between">
              <label className="text-xs font-semibold text-[var(--text-primary)] flex items-center gap-1.5">
                <Key className="w-3.5 h-3.5 text-emerald-500" />
                <span>OpenAI API Key</span>
              </label>
              <div className="flex items-center gap-1.5">
                {settings.openaiApiKey ? (
                  <span className="text-[10px] font-medium text-emerald-600 dark:text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded-md">
                    Stored in localStorage
                  </span>
                ) : (
                  <span className="text-[10px] font-medium text-neutral-400">
                    Not configured
                  </span>
                )}
              </div>
            </div>

            <div className="relative flex items-center">
              <input
                type={showOpenaiKey ? 'text' : 'password'}
                value={openaiKeyInput}
                onChange={(e) => handleSaveOpenaiKey(e.target.value)}
                placeholder="sk-proj-..."
                className="w-full pl-3 pr-18 py-2 rounded-lg bg-[var(--bg-surface-input)] border border-[var(--border-default)] text-xs font-mono text-[var(--text-primary)] focus:outline-hidden focus:border-emerald-500 transition-colors"
              />
              <div className="absolute right-2 flex items-center gap-1">
                <button
                  type="button"
                  onClick={() => setShowOpenaiKey(!showOpenaiKey)}
                  className="p-1 rounded text-[var(--text-tertiary)] hover:text-[var(--text-primary)] transition-colors"
                  title={showOpenaiKey ? 'Hide key' : 'Show key'}
                >
                  {showOpenaiKey ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                </button>
              </div>
            </div>

            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pt-1">
              <div className="flex items-center gap-2">
                <span className="text-[11px] text-[var(--text-tertiary)]">Model:</span>
                <select
                  value={settings.openaiModel || 'gpt-4o-mini'}
                  onChange={(e) => updateSettings({ openaiModel: e.target.value })}
                  className="px-2 py-1 rounded bg-[var(--bg-surface-input)] border border-[var(--border-default)] text-[11px] text-[var(--text-secondary)] focus:outline-hidden"
                >
                  <option value="gpt-4o-mini">gpt-4o-mini (Fast & efficient)</option>
                  <option value="gpt-4o">gpt-4o (High capability)</option>
                  <option value="gpt-4-turbo">gpt-4-turbo</option>
                  <option value="gpt-3.5-turbo">gpt-3.5-turbo</option>
                </select>
              </div>

              <button
                type="button"
                onClick={handleTestOpenaiKey}
                disabled={isTestingOpenAI || (!openaiKeyInput && !settings.openaiApiKey)}
                className="active-press inline-flex items-center justify-center gap-1.5 px-3 py-1 rounded-lg border border-emerald-200 dark:border-emerald-800 bg-emerald-50 dark:bg-emerald-950/40 text-emerald-600 dark:text-emerald-400 text-xs font-medium hover:bg-emerald-100 transition-colors cursor-pointer disabled:opacity-40"
              >
                {isTestingOpenAI ? (
                  <Loader2 className="w-3 h-3 animate-spin" />
                ) : (
                  <Sparkles className="w-3 h-3" />
                )}
                <span>Test Connection</span>
              </button>
            </div>

            {openaiTestStatus && (
              <motion.div
                initial={{ opacity: 0, y: -4 }}
                animate={{ opacity: 1, y: 0 }}
                className={`p-2 rounded-lg text-[11px] flex items-center gap-2 ${
                  openaiTestStatus.ok
                    ? 'bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border border-emerald-500/20'
                    : 'bg-rose-500/10 text-rose-600 dark:text-rose-400 border border-rose-500/20'
                }`}
              >
                {openaiTestStatus.ok ? (
                  <CheckCircle2 className="w-3.5 h-3.5 shrink-0" />
                ) : (
                  <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                )}
                <span className="flex-1">{openaiTestStatus.message}</span>
              </motion.div>
            )}
          </div>

          {/* Auto Fallback & Privacy info */}
          <div className="flex items-center justify-between pt-1">
            <div>
              <span className="text-xs font-semibold block text-[var(--text-primary)]">
                Autonomous Fallback
              </span>
              <span className="text-[11px] text-[var(--text-tertiary)]">
                Seamlessly fall back to secondary provider or local heuristics
              </span>
            </div>
            <label className="relative inline-flex items-center cursor-pointer">
              <input
                type="checkbox"
                checked={settings.aiAutoFallback !== false}
                onChange={(e) => updateSettings({ aiAutoFallback: e.target.checked })}
                className="sr-only peer"
              />
              <div className="w-9 h-5 bg-neutral-300 peer-focus:outline-none rounded-full peer dark:bg-neutral-700 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-[var(--accent)]"></div>
            </label>
          </div>
        </section>

        {/* Section 3: Appearance & Themes */}
        <section className="space-y-2 text-xs">
          <label className="block font-semibold text-[var(--text-secondary)]">
            Theme Mode
          </label>
          <div className="grid grid-cols-3 gap-2">
            {[
              { id: 'light', label: 'Light', icon: Sun },
              { id: 'dark', label: 'Dark', icon: Moon },
              { id: 'system', label: 'System', icon: Laptop },
            ].map((th) => {
              const Icon = th.icon;
              const isSelected = settings.theme === th.id;
              return (
                <button
                  key={th.id}
                  onClick={() => updateSettings({ theme: th.id as any })}
                  className={`active-press flex items-center justify-center gap-2 p-2.5 rounded-xl border text-xs font-medium transition-all cursor-pointer ${
                    isSelected
                      ? 'bg-[var(--accent)] text-[var(--accent-text)] border-[var(--accent)] shadow-xs'
                      : 'bg-[var(--bg-surface-subtle)] border-[var(--border-default)] text-[var(--text-secondary)] hover:bg-[var(--ui-hover)] hover:text-[var(--text-primary)]'
                  }`}
                >
                  <Icon className="w-3.5 h-3.5" />
                  <span>{th.label}</span>
                </button>
              );
            })}
          </div>
        </section>

        {/* Section 4: PWA & Mobile Installation */}
        <section className="pt-2 border-t border-[var(--border-default)] space-y-2.5 text-xs">
          <div className="flex items-center justify-between">
            <label className="block font-semibold text-[var(--text-secondary)] uppercase tracking-wider text-[11px]">
              Progressive Web App (PWA)
            </label>
            {isInstalled ? (
              <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-semibold bg-emerald-500/15 text-emerald-600 dark:text-emerald-400">
                <CheckCircle2 className="w-3.5 h-3.5" />
                Installed (Standalone)
              </span>
            ) : isInstallable ? (
              <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider bg-purple-500/15 text-purple-600 dark:text-purple-400">
                <Smartphone className="w-3 h-3" />
                Prompt Ready
              </span>
            ) : (
              <span className="text-[11px] text-[var(--text-tertiary)]">
                Web App
              </span>
            )}
          </div>

          <div className="p-3.5 rounded-2xl bg-[var(--bg-surface-subtle)] border border-[var(--border-default)] space-y-2.5">
            <div className="flex items-start gap-2.5">
              <div className="w-8 h-8 rounded-xl bg-[var(--accent)] text-[var(--accent-text)] flex items-center justify-center shrink-0 shadow-xs">
                <Download className="w-4 h-4" />
              </div>
              <div className="min-w-0">
                <p className="font-semibold text-xs text-[var(--text-primary)]">
                  {isInstalled
                    ? 'Life OS is installed as a standalone application'
                    : 'Install Life OS on Android, iOS, or Desktop'}
                </p>
                <p className="text-[11px] text-[var(--text-secondary)] mt-0.5">
                  {isInstalled
                    ? 'Running with offline caching and native app lifecycle.'
                    : 'Fast home screen launch, full offline capabilities, and zero browser chrome.'}
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2 pt-1 border-t border-[var(--border-subtle)]">
              {isInstalled ? (
                <button
                  onClick={() => setShowPwaInstallModal(true)}
                  className="active-press flex items-center gap-1.5 px-3 py-1.5 rounded-xl border border-[var(--border-default)] text-[var(--text-secondary)] hover:text-[var(--text-primary)] hover:bg-[var(--ui-hover)] text-xs font-medium cursor-pointer transition-colors"
                >
                  <Smartphone className="w-3.5 h-3.5" />
                  <span>PWA Info</span>
                </button>
              ) : (
                <>
                  {isInstallable && (
                    <button
                      onClick={async () => {
                        const res = await promptInstall();
                        if (res === 'fallback') setShowPwaInstallModal(true);
                      }}
                      className="active-press flex-1 flex items-center justify-center gap-1.5 py-2 px-3 rounded-xl bg-[var(--accent)] text-[var(--accent-text)] text-xs font-bold shadow-xs hover:opacity-95 transition-all cursor-pointer"
                    >
                      <Download className="w-3.5 h-3.5" />
                      <span>Install Life OS App</span>
                    </button>
                  )}
                  <button
                    onClick={() => setShowPwaInstallModal(true)}
                    className={`active-press flex items-center justify-center gap-1.5 py-2 px-3 rounded-xl border border-[var(--border-default)] text-[var(--text-primary)] hover:bg-[var(--ui-hover)] text-xs font-medium transition-colors cursor-pointer ${
                      isInstallable ? '' : 'flex-1'
                    }`}
                  >
                    <Smartphone className="w-3.5 h-3.5 text-purple-500" />
                    <span>{isInstallable ? 'Instructions' : 'How to Install'}</span>
                  </button>
                </>
              )}
            </div>
          </div>
        </section>

        {/* Section 5: Data Portability & Backup */}
        <section className="pt-2 border-t border-[var(--border-default)] space-y-3 text-xs">
          <label className="block font-semibold text-[var(--text-secondary)] uppercase tracking-wider text-[11px]">
            Data Backup & Portability
          </label>

          <div className="grid grid-cols-2 gap-2">
            <button
              onClick={handleDownloadBackup}
              className="active-press flex items-center justify-center gap-2 p-2.5 rounded-xl bg-[var(--bg-surface-subtle)] hover:bg-[var(--ui-hover)] border border-[var(--border-default)] text-[var(--text-primary)] font-medium transition-colors cursor-pointer"
            >
              <Download className="w-4 h-4" />
              <span>Export JSON</span>
            </button>

            <button
              onClick={() => setShowImportArea(!showImportArea)}
              className="active-press flex items-center justify-center gap-2 p-2.5 rounded-xl bg-[var(--bg-surface-subtle)] hover:bg-[var(--ui-hover)] border border-[var(--border-default)] text-[var(--text-primary)] font-medium transition-colors cursor-pointer"
            >
              <Upload className="w-4 h-4" />
              <span>Import JSON</span>
            </button>
          </div>

          {showImportArea && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              className="space-y-2 p-3 rounded-xl bg-[var(--bg-surface-subtle)] border border-[var(--border-default)]"
            >
              <textarea
                placeholder="Paste backup JSON string here..."
                value={importJsonText}
                onChange={(e) => setImportJsonText(e.target.value)}
                rows={4}
                className="w-full p-2 rounded bg-[var(--bg-surface-input)] border border-[var(--border-default)] text-xs font-mono text-[var(--text-primary)] focus:outline-hidden"
              />
              <button
                onClick={handleApplyImport}
                className="active-press w-full py-1.5 rounded-lg bg-[var(--accent)] text-[var(--accent-text)] font-semibold transition-colors cursor-pointer"
              >
                Apply Imported State
              </button>
            </motion.div>
          )}
        </section>

        {/* Section 5: Reset / Danger Zone */}
        <section className="pt-2 border-t border-[var(--border-default)] space-y-2 text-xs">
          <label className="block font-semibold text-[var(--text-tertiary)] uppercase tracking-wider text-[10px]">
            Workspace Management
          </label>

          <div className="flex flex-wrap items-center gap-2">
            <button
              onClick={() => {
                restartOnboarding();
                setIsSettingsOpen(false);
              }}
              className="active-press px-3 py-1.5 rounded-lg border border-[var(--border-default)] text-[var(--text-secondary)] hover:bg-[var(--ui-hover)] hover:text-[var(--text-primary)] text-xs flex items-center gap-1.5 cursor-pointer transition-colors"
            >
              <Sparkles className="w-3.5 h-3.5 text-amber-500" />
              <span>Replay Onboarding</span>
            </button>

            <button
              onClick={() => {
                if (confirm('Reset workspace to starter kit state?')) {
                  resetToDefaultData();
                  setIsSettingsOpen(false);
                }
              }}
              className="active-press px-3 py-1.5 rounded-lg border border-[var(--border-default)] text-[var(--text-secondary)] hover:bg-[var(--ui-hover)] hover:text-[var(--text-primary)] text-xs flex items-center gap-1.5 cursor-pointer transition-colors"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Reset to Starter Kit</span>
            </button>

            <button
              onClick={() => {
                if (confirm('Clear all tasks, notes, goals, and projects for a clean slate?')) {
                  clearAllData();
                  setIsSettingsOpen(false);
                }
              }}
              className="active-press px-3 py-1.5 rounded-lg border border-[var(--error-border)] text-[var(--error)] bg-[var(--error-bg)] hover:opacity-90 text-xs flex items-center gap-1.5 cursor-pointer transition-colors"
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span>Clear Everything</span>
            </button>
          </div>
        </section>
      </motion.div>

      <PWAInstallModal
        isOpen={showPwaInstallModal}
        onClose={() => setShowPwaInstallModal(false)}
      />
    </div>
  );
};
