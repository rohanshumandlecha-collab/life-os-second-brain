import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  X,
  Sparkles,
  Search,
  Star,
  Plus,
  Play,
  Copy,
  Clock,
  CheckCircle2,
  FolderGit2,
  Target,
  Flame,
  FileText,
  Calendar,
  Layers,
  ArrowRight,
  BookOpen,
  GraduationCap,
  Rocket,
  Compass,
  Users,
  Wallet,
  Zap,
} from 'lucide-react';
import { useLifeOS } from '../../context/LifeOSContext';
import { TemplateItem, TemplateCategory } from '../../types';

export const TemplateModal: React.FC = () => {
  const {
    isTemplateModalOpen,
    setIsTemplateModalOpen,
    templates,
    applyTemplate,
    generateTemplateWithAI,
    toggleTemplateFavorite,
    deleteTemplate,
    showToast,
    activeTemplateForLaunch,
    setActiveTemplateForLaunch,
  } = useLifeOS();

  const [activeCategory, setActiveCategory] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [onlyFavorites, setOnlyFavorites] = useState(false);

  // AI Generator state
  const [isGeneratingAI, setIsGeneratingAI] = useState(false);
  const [aiPrompt, setAiPrompt] = useState('');
  const [showAIPrompt, setShowAIPrompt] = useState(false);

  // Variable values form state when launching a template
  const [variableValues, setVariableValues] = useState<Record<string, string>>({});
  const [isLaunching, setIsLaunching] = useState(false);

  if (!isTemplateModalOpen) return null;

  // Categories list
  const categories: { id: string; label: string }[] = [
    { id: 'all', label: 'All Templates' },
    { id: 'study', label: 'Study & Exams' },
    { id: 'projects', label: 'Projects & Work' },
    { id: 'goals', label: 'Goals & OKRs' },
    { id: 'reviews', label: 'Reviews & Reflection' },
    { id: 'habits', label: 'Habits & Routine' },
    { id: 'reading', label: 'Reading & Knowledge' },
    { id: 'budgeting', label: 'Budget & Finance' },
    { id: 'meetings', label: 'Meetings' },
    { id: 'planning', label: 'Deep Work' },
  ];

  // Filter templates
  const filteredTemplates = templates.filter((tpl) => {
    if (onlyFavorites && !tpl.isFavorite) return false;
    if (activeCategory !== 'all' && tpl.category !== activeCategory) return false;
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const matchTitle = tpl.title.toLowerCase().includes(q);
      const matchDesc = tpl.description.toLowerCase().includes(q);
      const matchTags = tpl.tags?.some((t) => t.toLowerCase().includes(q));
      if (!matchTitle && !matchDesc && !matchTags) return false;
    }
    return true;
  });

  const getTemplateIcon = (iconName: string) => {
    switch (iconName) {
      case 'GraduationCap':
        return <GraduationCap className="w-5 h-5" />;
      case 'Rocket':
        return <Rocket className="w-5 h-5" />;
      case 'Zap':
        return <Zap className="w-5 h-5" />;
      case 'Compass':
        return <Compass className="w-5 h-5" />;
      case 'Users':
        return <Users className="w-5 h-5" />;
      case 'BookOpen':
        return <BookOpen className="w-5 h-5" />;
      case 'Wallet':
        return <Wallet className="w-5 h-5" />;
      case 'Flame':
        return <Flame className="w-5 h-5" />;
      default:
        return <Layers className="w-5 h-5" />;
    }
  };

  const handleStartLaunch = (tpl: TemplateItem) => {
    const initialVars: Record<string, string> = {};
    tpl.variables.forEach((v) => {
      initialVars[v.key] = v.defaultValue;
    });
    setVariableValues(initialVars);
    setActiveTemplateForLaunch(tpl);
  };

  const handleExecuteLaunch = async () => {
    if (!activeTemplateForLaunch) return;
    setIsLaunching(true);
    try {
      await applyTemplate(activeTemplateForLaunch.id, variableValues);
      setActiveTemplateForLaunch(null);
      setIsTemplateModalOpen(false);
    } catch (err: any) {
      showToast('Error applying template: ' + err.message, 'error');
    } finally {
      setIsLaunching(false);
    }
  };

  const handleGenerateAI = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!aiPrompt.trim() || isGeneratingAI) return;
    setIsGeneratingAI(true);
    try {
      const tpl = await generateTemplateWithAI(aiPrompt.trim());
      setAiPrompt('');
      setShowAIPrompt(false);
      handleStartLaunch(tpl);
    } catch (err) {
      showToast('Could not generate template', 'error');
    } finally {
      setIsGeneratingAI(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-md flex items-center justify-center p-3 sm:p-6 overflow-y-auto">
      <motion.div
        initial={{ opacity: 0, scale: 0.96, y: 16 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.96, y: 16 }}
        transition={{ type: 'spring', stiffness: 450, damping: 32 }}
        className="w-full max-w-4xl max-h-[90vh] rounded-3xl bg-[var(--bg-surface-elevated)] border border-[var(--border-default)] shadow-2xl flex flex-col overflow-hidden text-[var(--text-primary)]"
      >
        {/* Modal Header */}
        <div className="flex items-center justify-between p-4 sm:p-5 border-b border-[var(--border-default)] bg-[var(--bg-surface)]">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-2xl bg-purple-500/15 text-purple-600 dark:text-purple-400 flex items-center justify-center font-bold">
              <Layers className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-bold text-[var(--text-primary)]">
                Life OS Template Ecosystem
              </h2>
              <p className="text-xs text-[var(--text-secondary)]">
                Launch interconnected operational workflows with goals, milestones, tasks, and habits.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setShowAIPrompt(!showAIPrompt)}
              className="active-press flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold bg-purple-500/10 text-purple-600 dark:text-purple-400 border border-purple-500/20 hover:bg-purple-500/20 transition-all cursor-pointer"
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span>AI Architect</span>
            </button>
            <button
              onClick={() => {
                setActiveTemplateForLaunch(null);
                setIsTemplateModalOpen(false);
              }}
              className="active-press p-1.5 rounded-xl text-[var(--text-tertiary)] hover:text-[var(--text-primary)] hover:bg-[var(--ui-hover)] transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* AI Generator Prompt Tray */}
        {showAIPrompt && (
          <form
            onSubmit={handleGenerateAI}
            className="p-4 bg-purple-500/5 border-b border-purple-500/20 space-y-2 animate-in fade-in slide-in-from-top-2"
          >
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-purple-600 dark:text-purple-400 flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5" />
                <span>AI Template Generator</span>
              </span>
              <span className="text-[11px] text-[var(--text-tertiary)]">
                Creates an interconnected multi-object system
              </span>
            </div>
            <div className="flex gap-2">
              <input
                type="text"
                value={aiPrompt}
                onChange={(e) => setAiPrompt(e.target.value)}
                placeholder="e.g., 3-month marathon training, Machine Learning paper sprint, or Startup fundraise..."
                disabled={isGeneratingAI}
                className="flex-1 px-3.5 py-2 rounded-xl text-xs bg-[var(--bg-surface-elevated)] border border-[var(--border-default)] text-[var(--text-primary)] placeholder-[var(--text-tertiary)] focus:outline-hidden focus:border-purple-500"
              />
              <button
                type="submit"
                disabled={!aiPrompt.trim() || isGeneratingAI}
                className="active-press px-4 py-2 rounded-xl text-xs font-semibold bg-purple-600 text-white shadow-xs hover:bg-purple-700 disabled:opacity-50 transition-colors cursor-pointer"
              >
                {isGeneratingAI ? 'Synthesizing...' : 'Generate Blueprint'}
              </button>
            </div>
          </form>
        )}

        {/* Content Canvas */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-5">
          {/* If a template is currently selected for launch, show the Variable Wizard */}
          {activeTemplateForLaunch ? (
            <div className="space-y-5 animate-in fade-in zoom-in-95 duration-150">
              <div className="flex items-center justify-between pb-3 border-b border-[var(--border-default)]">
                <button
                  onClick={() => setActiveTemplateForLaunch(null)}
                  className="active-press text-xs font-medium text-[var(--text-secondary)] hover:text-[var(--text-primary)] cursor-pointer"
                >
                  ← Back to Library
                </button>
                <div className="flex items-center gap-2">
                  <span className="text-xs font-bold text-[var(--text-primary)]">
                    Configure Template Variables
                  </span>
                </div>
              </div>

              {/* Template Blueprint Summary */}
              <div className="p-4 rounded-2xl bg-[var(--bg-surface-subtle)] border border-[var(--border-default)] space-y-2">
                <div className="flex items-center gap-2">
                  <div
                    className="w-8 h-8 rounded-xl flex items-center justify-center text-white"
                    style={{ backgroundColor: activeTemplateForLaunch.color }}
                  >
                    {getTemplateIcon(activeTemplateForLaunch.icon)}
                  </div>
                  <div>
                    <h3 className="text-sm font-bold text-[var(--text-primary)]">
                      {activeTemplateForLaunch.title}
                    </h3>
                    <p className="text-xs text-[var(--text-secondary)]">
                      {activeTemplateForLaunch.description}
                    </p>
                  </div>
                </div>

                {/* Connected Objects Pipeline Breakdown */}
                <div className="pt-2 border-t border-[var(--border-subtle)] grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs">
                  {activeTemplateForLaunch.blueprint.goal && (
                    <div className="p-2 rounded-xl bg-[var(--bg-surface-elevated)] border border-[var(--border-subtle)] flex items-center gap-1.5">
                      <Target className="w-3.5 h-3.5 text-blue-500" />
                      <span className="truncate">1 Connected Goal</span>
                    </div>
                  )}
                  {activeTemplateForLaunch.blueprint.projects && (
                    <div className="p-2 rounded-xl bg-[var(--bg-surface-elevated)] border border-[var(--border-subtle)] flex items-center gap-1.5">
                      <FolderGit2 className="w-3.5 h-3.5 text-purple-500" />
                      <span>{activeTemplateForLaunch.blueprint.projects.length} Projects</span>
                    </div>
                  )}
                  {activeTemplateForLaunch.blueprint.tasks && (
                    <div className="p-2 rounded-xl bg-[var(--bg-surface-elevated)] border border-[var(--border-subtle)] flex items-center gap-1.5">
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500" />
                      <span>{activeTemplateForLaunch.blueprint.tasks.length} Action Tasks</span>
                    </div>
                  )}
                  {activeTemplateForLaunch.blueprint.habits && (
                    <div className="p-2 rounded-xl bg-[var(--bg-surface-elevated)] border border-[var(--border-subtle)] flex items-center gap-1.5">
                      <Flame className="w-3.5 h-3.5 text-amber-500" />
                      <span>{activeTemplateForLaunch.blueprint.habits.length} Daily Habits</span>
                    </div>
                  )}
                </div>
              </div>

              {/* Variables Form */}
              <div className="space-y-3">
                <h4 className="text-xs font-bold uppercase tracking-wider text-[var(--text-secondary)]">
                  Customization Parameters
                </h4>
                <div className="space-y-2.5">
                  {activeTemplateForLaunch.variables.map((variable) => (
                    <div key={variable.key} className="space-y-1">
                      <label className="text-xs font-semibold text-[var(--text-primary)] block">
                        {variable.label}
                      </label>
                      <input
                        type={variable.type === 'number' ? 'number' : variable.type === 'date' ? 'date' : 'text'}
                        value={variableValues[variable.key] || ''}
                        onChange={(e) =>
                          setVariableValues({ ...variableValues, [variable.key]: e.target.value })
                        }
                        placeholder={variable.placeholder}
                        className="w-full px-3.5 py-2 rounded-xl text-xs bg-[var(--bg-surface-elevated)] border border-[var(--border-default)] text-[var(--text-primary)] focus:outline-hidden focus:border-[var(--accent)]"
                      />
                    </div>
                  ))}
                </div>
              </div>

              {/* Action Buttons */}
              <div className="pt-3 border-t border-[var(--border-default)] flex items-center justify-end gap-2">
                <button
                  onClick={() => setActiveTemplateForLaunch(null)}
                  className="active-press px-4 py-2 rounded-xl text-xs font-semibold border border-[var(--border-default)] text-[var(--text-secondary)] hover:text-[var(--text-primary)] cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  onClick={handleExecuteLaunch}
                  disabled={isLaunching}
                  className="active-press flex items-center gap-1.5 px-5 py-2 rounded-xl text-xs font-semibold bg-[var(--accent)] text-[var(--accent-text)] shadow-md hover:opacity-90 transition-all cursor-pointer disabled:opacity-50"
                >
                  <Play className="w-3.5 h-3.5 fill-current" />
                  <span>{isLaunching ? 'Connecting Objects...' : 'Launch & Instantiate Workflow'}</span>
                </button>
              </div>
            </div>
          ) : (
            <>
              {/* Filter and Search Bar */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div className="relative flex-1">
                  <Search className="w-4 h-4 text-[var(--text-tertiary)] absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    placeholder="Search templates by title, keyword, or workflow..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="w-full pl-9 pr-4 py-2 rounded-xl text-xs bg-[var(--bg-surface-subtle)] border border-[var(--border-default)] text-[var(--text-primary)] placeholder-[var(--text-tertiary)] focus:outline-hidden focus:border-[var(--accent)]"
                  />
                </div>

                <button
                  onClick={() => setOnlyFavorites(!onlyFavorites)}
                  className={`active-press flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-medium border transition-colors cursor-pointer shrink-0 ${
                    onlyFavorites
                      ? 'bg-amber-500/10 border-amber-500/30 text-amber-600 dark:text-amber-400 font-semibold'
                      : 'bg-[var(--bg-surface-subtle)] border-[var(--border-default)] text-[var(--text-secondary)]'
                  }`}
                >
                  <Star className={`w-3.5 h-3.5 ${onlyFavorites ? 'fill-current' : ''}`} />
                  <span>Favorites</span>
                </button>
              </div>

              {/* Categories Scroll */}
              <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar pb-1">
                {categories.map((cat) => (
                  <button
                    key={cat.id}
                    onClick={() => setActiveCategory(cat.id)}
                    className={`active-press text-xs px-3 py-1.5 rounded-xl whitespace-nowrap font-medium transition-colors cursor-pointer ${
                      activeCategory === cat.id
                        ? 'bg-[var(--accent)] text-[var(--accent-text)] shadow-xs'
                        : 'bg-[var(--bg-surface-subtle)] text-[var(--text-secondary)] hover:text-[var(--text-primary)] border border-[var(--border-default)]'
                    }`}
                  >
                    {cat.label}
                  </button>
                ))}
              </div>

              {/* Template Grid */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {filteredTemplates.map((template) => (
                  <div
                    key={template.id}
                    className="p-4 rounded-2xl bg-[var(--bg-surface-subtle)] border border-[var(--border-default)] hover:border-[var(--border-focus)] transition-all flex flex-col justify-between space-y-3 group shadow-2xs"
                  >
                    <div className="space-y-2">
                      <div className="flex items-start justify-between gap-2">
                        <div className="flex items-center gap-2.5">
                          <div
                            className="w-8 h-8 rounded-xl flex items-center justify-center text-white shrink-0 shadow-xs"
                            style={{ backgroundColor: template.color }}
                          >
                            {getTemplateIcon(template.icon)}
                          </div>
                          <div>
                            <h3 className="text-xs sm:text-sm font-bold text-[var(--text-primary)] line-clamp-1">
                              {template.title}
                            </h3>
                            <span className="text-[10px] uppercase font-mono tracking-wider text-[var(--text-tertiary)]">
                              {template.category}
                            </span>
                          </div>
                        </div>

                        <button
                          onClick={() => toggleTemplateFavorite(template.id)}
                          className="text-[var(--text-tertiary)] hover:text-amber-500 cursor-pointer p-1"
                          title="Toggle favorite"
                        >
                          <Star
                            className={`w-4 h-4 ${
                              template.isFavorite ? 'text-amber-500 fill-amber-500' : ''
                            }`}
                          />
                        </button>
                      </div>

                      <p className="text-xs text-[var(--text-secondary)] leading-relaxed line-clamp-2">
                        {template.description}
                      </p>

                      {/* Blueprint Highlights */}
                      <div className="flex items-center gap-2 text-[10px] text-[var(--text-tertiary)] flex-wrap pt-1">
                        {template.blueprint.goal && (
                          <span className="flex items-center gap-1">
                            <Target className="w-3 h-3 text-blue-500" /> Goal
                          </span>
                        )}
                        {template.blueprint.projects && (
                          <span className="flex items-center gap-1">
                            <FolderGit2 className="w-3 h-3 text-purple-500" />{' '}
                            {template.blueprint.projects.length} Proj
                          </span>
                        )}
                        {template.blueprint.tasks && (
                          <span className="flex items-center gap-1">
                            <CheckCircle2 className="w-3 h-3 text-emerald-500" />{' '}
                            {template.blueprint.tasks.length} Tasks
                          </span>
                        )}
                        {template.blueprint.habits && (
                          <span className="flex items-center gap-1">
                            <Flame className="w-3 h-3 text-amber-500" /> Habit
                          </span>
                        )}
                        {template.blueprint.notes && (
                          <span className="flex items-center gap-1">
                            <FileText className="w-3 h-3 text-indigo-500" /> Note
                          </span>
                        )}
                      </div>
                    </div>

                    {/* Launch Trigger Button */}
                    <div className="pt-2 border-t border-[var(--border-subtle)] flex items-center justify-between">
                      <span className="text-[10px] text-[var(--text-tertiary)]">
                        {template.variables.length} configurable variable{template.variables.length > 1 ? 's' : ''}
                      </span>
                      <button
                        onClick={() => handleStartLaunch(template)}
                        className="active-press flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold bg-[var(--accent)] text-[var(--accent-text)] shadow-xs hover:opacity-90 transition-all cursor-pointer"
                      >
                        <Play className="w-3 h-3 fill-current" />
                        <span>Use Template</span>
                      </button>
                    </div>
                  </div>
                ))}
              </div>

              {filteredTemplates.length === 0 && (
                <div className="p-8 rounded-2xl border border-dashed border-[var(--border-default)] text-center text-xs text-[var(--text-tertiary)]">
                  No templates match your search criteria. Try the "AI Architect" button to generate one!
                </div>
              )}
            </>
          )}
        </div>
      </motion.div>
    </div>
  );
};
