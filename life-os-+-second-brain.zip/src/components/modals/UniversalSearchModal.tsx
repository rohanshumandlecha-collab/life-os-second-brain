import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import {
  Search,
  X,
  CheckSquare,
  FolderGit2,
  Target,
  FileText,
  Calendar,
  Flame,
  Layers,
  Zap,
  ArrowRight,
  Play,
  Clock,
} from 'lucide-react';
import { useLifeOS } from '../../context/LifeOSContext';

export const UniversalSearchModal: React.FC = () => {
  const {
    isSearchOpen,
    setIsSearchOpen,
    tasks,
    projects,
    goals,
    notes,
    habits,
    calendarEvents,
    templates,
    automations,
    setActiveNav,
    setPlanSubNav,
    setNotesSubNav,
    setLifeSubNav,
    setIsTemplateModalOpen,
    setActiveTemplateForLaunch,
    toggleTaskComplete,
  } = useLifeOS();

  const [query, setQuery] = useState('');
  const [activeCategory, setActiveCategory] = useState<string>('all');

  useEffect(() => {
    if (!isSearchOpen) {
      setQuery('');
      setActiveCategory('all');
    }
  }, [isSearchOpen]);

  if (!isSearchOpen) return null;

  const q = query.toLowerCase().trim();

  // Cross-object semantic keyword filtering with relevance
  const matchedTasks = q
    ? tasks.filter((t) => t.title.toLowerCase().includes(q) || t.description?.toLowerCase().includes(q) || t.tags.some((tag) => tag.toLowerCase().includes(q)))
    : [];

  const matchedProjects = q
    ? projects.filter((p) => p.title.toLowerCase().includes(q) || p.description.toLowerCase().includes(q) || p.tags?.some((tag) => tag.toLowerCase().includes(q)))
    : [];

  const matchedGoals = q
    ? goals.filter((g) => g.title.toLowerCase().includes(q) || g.vision.toLowerCase().includes(q) || g.area.toLowerCase().includes(q))
    : [];

  const matchedNotes = q
    ? notes.filter((n) => n.title.toLowerCase().includes(q) || n.content.toLowerCase().includes(q) || n.tags.some((tag) => tag.toLowerCase().includes(q)))
    : [];

  const matchedHabits = q
    ? habits.filter((h) => h.title.toLowerCase().includes(q) || h.category.toLowerCase().includes(q))
    : [];

  const matchedEvents = q
    ? calendarEvents.filter((e) => e.title.toLowerCase().includes(q) || e.notes?.toLowerCase().includes(q))
    : [];

  const matchedTemplates = q
    ? templates.filter((tpl) => tpl.title.toLowerCase().includes(q) || tpl.description.toLowerCase().includes(q) || tpl.category.toLowerCase().includes(q) || tpl.tags?.some((tag) => tag.toLowerCase().includes(q)))
    : [];

  const matchedAutomations = q
    ? automations.filter((a) => a.title.toLowerCase().includes(q) || a.description.toLowerCase().includes(q) || a.trigger.toLowerCase().includes(q))
    : [];

  const totalResults =
    matchedTasks.length +
    matchedProjects.length +
    matchedGoals.length +
    matchedNotes.length +
    matchedHabits.length +
    matchedEvents.length +
    matchedTemplates.length +
    matchedAutomations.length;

  const handleLaunchTemplate = (tpl: any) => {
    setIsSearchOpen(false);
    setActiveTemplateForLaunch(tpl);
    setIsTemplateModalOpen(true);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-md flex items-start justify-center pt-8 sm:pt-16 p-3 sm:p-4 overflow-y-auto">
      <motion.div
        initial={{ opacity: 0, scale: 0.96, y: -12 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.96, y: -12 }}
        transition={{ type: 'spring', stiffness: 450, damping: 32 }}
        className="w-full max-w-2xl rounded-3xl bg-[var(--bg-surface-elevated)] border border-[var(--border-default)] shadow-2xl overflow-hidden flex flex-col max-h-[85vh] text-[var(--text-primary)]"
      >
        {/* Search input header */}
        <div className="flex items-center gap-3 px-4 py-3.5 border-b border-[var(--border-default)] bg-[var(--bg-surface)]">
          <Search className="w-4 h-4 text-[var(--accent)] shrink-0" />
          <input
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Universal search tasks, block notes, projects, goals, habits, templates..."
            className="flex-1 bg-transparent text-sm text-[var(--text-primary)] placeholder-[var(--text-tertiary)] focus:outline-hidden"
            autoFocus
          />
          {query && (
            <button
              onClick={() => setQuery('')}
              className="text-xs text-[var(--text-tertiary)] hover:text-[var(--text-primary)]"
            >
              Clear
            </button>
          )}
          <button
            onClick={() => setIsSearchOpen(false)}
            className="active-press p-1.5 rounded-lg text-[var(--text-tertiary)] hover:text-[var(--text-primary)] hover:bg-[var(--ui-hover)] transition-colors cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Filter Pills */}
        {q && (
          <div className="flex items-center gap-1.5 px-4 py-2 border-b border-[var(--border-subtle)] bg-[var(--bg-surface-subtle)] overflow-x-auto no-scrollbar text-xs">
            {[
              { id: 'all', label: `All (${totalResults})` },
              { id: 'tasks', label: `Tasks (${matchedTasks.length})` },
              { id: 'notes', label: `Notes (${matchedNotes.length})` },
              { id: 'templates', label: `Templates (${matchedTemplates.length})` },
              { id: 'projects', label: `Projects (${matchedProjects.length})` },
              { id: 'goals', label: `Goals (${matchedGoals.length})` },
              { id: 'habits', label: `Habits (${matchedHabits.length})` },
            ].map((cat) => (
              <button
                key={cat.id}
                onClick={() => setActiveCategory(cat.id)}
                className={`active-press px-2.5 py-1 rounded-lg transition-colors cursor-pointer whitespace-nowrap ${
                  activeCategory === cat.id
                    ? 'bg-[var(--accent)] text-[var(--accent-text)] font-semibold'
                    : 'text-[var(--text-secondary)] hover:text-[var(--text-primary)]'
                }`}
              >
                {cat.label}
              </button>
            ))}
          </div>
        )}

        {/* Results Body */}
        <div className="flex-1 overflow-y-auto p-3 sm:p-4 space-y-4">
          {!q && (
            <div className="py-12 text-center space-y-3">
              <Search className="w-10 h-10 text-[var(--text-tertiary)] mx-auto opacity-40" />
              <div>
                <p className="text-xs font-semibold text-[var(--text-primary)]">
                  Fast Universal Semantic Search
                </p>
                <p className="text-[11px] text-[var(--text-secondary)] mt-0.5">
                  Search across entire Second Brain, Tasks, Workflows, Goals, Calendar & Templates.
                </p>
              </div>
            </div>
          )}

          {q && totalResults === 0 && (
            <div className="py-12 text-center space-y-2">
              <p className="text-xs text-[var(--text-tertiary)]">
                No Life Objects found matching "{query}".
              </p>
            </div>
          )}

          {/* Templates */}
          {(activeCategory === 'all' || activeCategory === 'templates') && matchedTemplates.length > 0 && (
            <div className="space-y-1.5">
              <span className="text-[10px] font-bold text-purple-600 dark:text-purple-400 uppercase tracking-wider block px-1 flex items-center gap-1">
                <Layers className="w-3 h-3" />
                Templates ({matchedTemplates.length})
              </span>
              <div className="space-y-1">
                {matchedTemplates.map((tpl) => (
                  <div
                    key={tpl.id}
                    className="p-3 rounded-xl bg-purple-500/5 hover:bg-purple-500/10 border border-purple-500/20 flex items-center justify-between text-xs transition-colors"
                  >
                    <div className="min-w-0 flex-1 pr-3">
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-[var(--text-primary)]">{tpl.title}</span>
                        <span className="text-[10px] uppercase font-mono px-1.5 py-0.2 rounded bg-purple-500/15 text-purple-600 dark:text-purple-400">
                          {tpl.category}
                        </span>
                      </div>
                      <p className="text-[11px] text-[var(--text-secondary)] truncate mt-0.5">
                        {tpl.description}
                      </p>
                    </div>

                    <button
                      onClick={() => handleLaunchTemplate(tpl)}
                      className="active-press flex items-center gap-1 px-3 py-1 rounded-lg text-xs font-semibold bg-purple-600 text-white shadow-xs hover:opacity-90 shrink-0 cursor-pointer"
                    >
                      <Play className="w-3 h-3 fill-current" />
                      <span>Use</span>
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Tasks */}
          {(activeCategory === 'all' || activeCategory === 'tasks') && matchedTasks.length > 0 && (
            <div className="space-y-1.5">
              <span className="text-[10px] font-bold text-[var(--text-tertiary)] uppercase tracking-wider block px-1">
                Tasks ({matchedTasks.length})
              </span>
              <div className="space-y-1">
                {matchedTasks.map((t) => (
                  <button
                    key={t.id}
                    onClick={() => {
                      setActiveNav('tasks');
                      setIsSearchOpen(false);
                    }}
                    className="active-press w-full text-left p-2.5 rounded-xl bg-[var(--bg-surface-subtle)] hover:bg-[var(--ui-hover)] border border-[var(--border-default)] flex items-center justify-between text-xs transition-colors cursor-pointer"
                  >
                    <div className="flex items-center gap-2 truncate">
                      <CheckSquare className="w-3.5 h-3.5 text-emerald-500 shrink-0" />
                      <span className="font-medium truncate text-[var(--text-primary)]">{t.title}</span>
                      <span className="text-[11px] text-[var(--text-tertiary)] font-mono">
                        ({t.status})
                      </span>
                    </div>
                    <ArrowRight className="w-3.5 h-3.5 text-[var(--text-tertiary)] shrink-0 ml-2" />
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Notes */}
          {(activeCategory === 'all' || activeCategory === 'notes') && matchedNotes.length > 0 && (
            <div className="space-y-1.5">
              <span className="text-[10px] font-bold text-[var(--text-tertiary)] uppercase tracking-wider block px-1">
                Second Brain & Notes ({matchedNotes.length})
              </span>
              <div className="space-y-1">
                {matchedNotes.map((n) => (
                  <button
                    key={n.id}
                    onClick={() => {
                      setActiveNav('notes');
                      setIsSearchOpen(false);
                    }}
                    className="active-press w-full text-left p-2.5 rounded-xl bg-[var(--bg-surface-subtle)] hover:bg-[var(--ui-hover)] border border-[var(--border-default)] flex items-center justify-between text-xs transition-colors cursor-pointer"
                  >
                    <div className="flex items-center gap-2 truncate">
                      <FileText className="w-3.5 h-3.5 text-indigo-500 shrink-0" />
                      <span className="font-medium truncate text-[var(--text-primary)]">{n.title}</span>
                      <span className="text-[10px] text-[var(--text-tertiary)] uppercase font-mono">
                        {n.type}
                      </span>
                    </div>
                    <ArrowRight className="w-3.5 h-3.5 text-[var(--text-tertiary)] shrink-0 ml-2" />
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Projects */}
          {(activeCategory === 'all' || activeCategory === 'projects') && matchedProjects.length > 0 && (
            <div className="space-y-1.5">
              <span className="text-[10px] font-bold text-[var(--text-tertiary)] uppercase tracking-wider block px-1">
                Projects ({matchedProjects.length})
              </span>
              <div className="space-y-1">
                {matchedProjects.map((p) => (
                  <button
                    key={p.id}
                    onClick={() => {
                      setActiveNav('life');
                      setLifeSubNav('projects');
                      setIsSearchOpen(false);
                    }}
                    className="active-press w-full text-left p-2.5 rounded-xl bg-[var(--bg-surface-subtle)] hover:bg-[var(--ui-hover)] border border-[var(--border-default)] flex items-center justify-between text-xs transition-colors cursor-pointer"
                  >
                    <div className="flex items-center gap-2 truncate">
                      <FolderGit2 className="w-3.5 h-3.5 text-purple-500 shrink-0" />
                      <span className="font-medium truncate text-[var(--text-primary)]">{p.title}</span>
                      <span className="text-[11px] text-[var(--text-tertiary)]">({p.status})</span>
                    </div>
                    <ArrowRight className="w-3.5 h-3.5 text-[var(--text-tertiary)] shrink-0 ml-2" />
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Goals */}
          {(activeCategory === 'all' || activeCategory === 'goals') && matchedGoals.length > 0 && (
            <div className="space-y-1.5">
              <span className="text-[10px] font-bold text-[var(--text-tertiary)] uppercase tracking-wider block px-1">
                Goals ({matchedGoals.length})
              </span>
              <div className="space-y-1">
                {matchedGoals.map((g) => (
                  <button
                    key={g.id}
                    onClick={() => {
                      setActiveNav('plan');
                      setPlanSubNav('goals');
                      setIsSearchOpen(false);
                    }}
                    className="active-press w-full text-left p-2.5 rounded-xl bg-[var(--bg-surface-subtle)] hover:bg-[var(--ui-hover)] border border-[var(--border-default)] flex items-center justify-between text-xs transition-colors cursor-pointer"
                  >
                    <div className="flex items-center gap-2 truncate">
                      <Target className="w-3.5 h-3.5 text-blue-500 shrink-0" />
                      <span className="font-medium truncate text-[var(--text-primary)]">{g.title}</span>
                      <span className="text-[11px] font-mono text-[var(--accent)] font-semibold">
                        {g.progress}%
                      </span>
                    </div>
                    <ArrowRight className="w-3.5 h-3.5 text-[var(--text-tertiary)] shrink-0 ml-2" />
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Habits */}
          {(activeCategory === 'all' || activeCategory === 'habits') && matchedHabits.length > 0 && (
            <div className="space-y-1.5">
              <span className="text-[10px] font-bold text-[var(--text-tertiary)] uppercase tracking-wider block px-1">
                Habits ({matchedHabits.length})
              </span>
              <div className="space-y-1">
                {matchedHabits.map((h) => (
                  <button
                    key={h.id}
                    onClick={() => {
                      setActiveNav('life');
                      setLifeSubNav('habits');
                      setIsSearchOpen(false);
                    }}
                    className="active-press w-full text-left p-2.5 rounded-xl bg-[var(--bg-surface-subtle)] hover:bg-[var(--ui-hover)] border border-[var(--border-default)] flex items-center justify-between text-xs transition-colors cursor-pointer"
                  >
                    <div className="flex items-center gap-2 truncate">
                      <Flame className="w-3.5 h-3.5 text-amber-500 shrink-0" />
                      <span className="font-medium truncate text-[var(--text-primary)]">{h.title}</span>
                      <span className="text-[11px] text-amber-500 font-semibold">{h.streak}d streak</span>
                    </div>
                    <ArrowRight className="w-3.5 h-3.5 text-[var(--text-tertiary)] shrink-0 ml-2" />
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>
      </motion.div>
    </div>
  );
};
