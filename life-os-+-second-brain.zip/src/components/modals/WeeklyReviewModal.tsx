import React, { useState } from 'react';
import { motion } from 'motion/react';
import {
  X,
  Sparkles,
  AlertCircle,
  ArrowRight,
  Loader2,
} from 'lucide-react';
import { useLifeOS } from '../../context/LifeOSContext';

export const WeeklyReviewModal: React.FC = () => {
  const {
    isReviewOpen,
    setIsReviewOpen,
    tasks,
    goals,
    habits,
    focusSessions,
    saveWeeklyReview,
    showToast,
    getAIHeaders,
  } = useLifeOS();

  const [step, setStep] = useState<1 | 2 | 3 | 4>(1);
  const [isGenerating, setIsGenerating] = useState(false);

  // Form responses
  const [wins, setWins] = useState('');
  const [misses, setMisses] = useState('');
  const [takeaways, setTakeaways] = useState('');
  const [nextPriorities, setNextPriorities] = useState('');

  if (!isReviewOpen) return null;

  const handleAutoGenerateAIReview = async () => {
    setIsGenerating(true);
    try {
      showToast('Synthesizing weekly review with AI backbone...', 'info');
      const res = await fetch('/api/ai/review', {
        method: 'POST',
        headers: getAIHeaders(),
        body: JSON.stringify({
          tasks,
          habits,
          goals,
          focusSessions,
        }),
      });
      if (res.ok) {
        const data = await res.json();
        const r = data.review;
        if (r.whatHappened?.length) setWins(r.whatHappened.join('\n'));
        if (r.whatNeedsAttention?.length) setMisses(r.whatNeedsAttention.join('\n'));
        if (r.whatMatters) setTakeaways(r.whatMatters);
        if (r.proposedNextActions?.length) {
          setNextPriorities(
            r.proposedNextActions
              .map((a: any) => `${a.targetArea ? `[${a.targetArea}] ` : ''}${a.action}`)
              .join('\n')
          );
        }
        showToast('AI synthesized weekly reflection!', 'success');
      }
    } catch (e) {
      showToast('Review synthesized with local intelligence', 'info');
    } finally {
      setIsGenerating(false);
    }
  };

  const completedThisWeek = tasks.filter((t) => t.status === 'completed').length;
  const totalFocusMinutes = focusSessions.reduce((acc, s) => acc + s.durationMinutes, 0);

  const stagnantGoals = goals.filter((g) => {
    const days = Math.floor(
      (Date.now() - new Date(g.lastActivityAt || g.createdAt).getTime()) / (1000 * 60 * 60 * 24)
    );
    return days > 10;
  });

  const handleFinishReview = () => {
    saveWeeklyReview({
      weekStartDate: new Date().toISOString().split('T')[0],
      wins: wins.split('\n').filter(Boolean),
      misses: misses.split('\n').filter(Boolean),
      insights: takeaways,
      nextWeekFocus: nextPriorities.split('\n').filter(Boolean),
      focusHoursTotal: Math.round((totalFocusMinutes / 60) * 10) / 10,
    });
    showToast('Weekly review recorded and synced to AI memory', 'success');
    setIsReviewOpen(false);
    setStep(1);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 overflow-y-auto">
      <motion.div
        initial={{ opacity: 0, scale: 0.95, y: 12 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.95, y: 12 }}
        transition={{ duration: 0.2, ease: [0.16, 1, 0.3, 1] }}
        className="w-full max-w-xl rounded-2xl bg-[var(--bg-surface-elevated)] border border-[var(--border-default)] shadow-2xl p-4 sm:p-6 space-y-5 text-[var(--text-primary)]"
      >
        {/* Header & Step progress */}
        <div className="flex items-center justify-between border-b border-[var(--border-default)] pb-3">
          <div>
            <span className="text-[10px] font-semibold text-[var(--text-tertiary)] uppercase tracking-wider">
              Life OS • Step {step} of 4
            </span>
            <h2 className="text-sm sm:text-base font-semibold text-[var(--text-primary)]">
              {step === 1 && '1. What happened this week?'}
              {step === 2 && '2. What got missed or needs attention?'}
              {step === 3 && '3. Core Lessons & Synthesis'}
              {step === 4 && '4. Next Week High-Impact Priorities'}
            </h2>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={handleAutoGenerateAIReview}
              disabled={isGenerating}
              className="active-press inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[var(--accent)] text-[var(--accent-text)] text-xs font-medium hover:opacity-90 transition-colors disabled:opacity-50 cursor-pointer shadow-xs"
            >
              {isGenerating ? (
                <Loader2 className="w-3.5 h-3.5 animate-spin" />
              ) : (
                <Sparkles className="w-3.5 h-3.5" />
              )}
              <span className="hidden xs:inline">{isGenerating ? 'Synthesizing...' : 'AI Auto-Draft'}</span>
            </button>
            <button
              onClick={() => setIsReviewOpen(false)}
              className="active-press p-1.5 rounded-lg text-[var(--text-tertiary)] hover:text-[var(--text-primary)] hover:bg-[var(--ui-hover)] transition-colors cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Step 1: Wins & Quantified Data */}
        {step === 1 && (
          <div className="space-y-4 text-xs">
            <div className="grid grid-cols-3 gap-2 sm:gap-3">
              <div className="p-3 rounded-xl bg-[var(--bg-surface-subtle)] border border-[var(--border-default)] text-center">
                <span className="text-[10px] text-[var(--text-tertiary)] uppercase font-semibold block">
                  Tasks Finished
                </span>
                <p className="text-base sm:text-lg font-bold text-emerald-500 mt-0.5">
                  {completedThisWeek}
                </p>
              </div>

              <div className="p-3 rounded-xl bg-[var(--bg-surface-subtle)] border border-[var(--border-default)] text-center">
                <span className="text-[10px] text-[var(--text-tertiary)] uppercase font-semibold block">
                  Focus Logged
                </span>
                <p className="text-base sm:text-lg font-bold text-indigo-500 mt-0.5">
                  {Math.round(totalFocusMinutes / 60)}h {totalFocusMinutes % 60}m
                </p>
              </div>

              <div className="p-3 rounded-xl bg-[var(--bg-surface-subtle)] border border-[var(--border-default)] text-center">
                <span className="text-[10px] text-[var(--text-tertiary)] uppercase font-semibold block">
                  Active Habits
                </span>
                <p className="text-base sm:text-lg font-bold text-amber-500 mt-0.5">{habits.length}</p>
              </div>
            </div>

            <div className="space-y-1.5">
              <label className="font-semibold text-[var(--text-secondary)]">
                Key Wins & Meaningful Accomplishments (one per line):
              </label>
              <textarea
                value={wins}
                onChange={(e) => setWins(e.target.value)}
                placeholder="• Shipped the core system architecture&#10;• Maintained consistent morning deep work"
                rows={3}
                className="w-full p-3 rounded-xl bg-[var(--bg-surface-input)] border border-[var(--border-default)] resize-none text-xs text-[var(--text-primary)] placeholder-[var(--text-tertiary)] focus:outline-hidden"
              />
            </div>
          </div>
        )}

        {/* Step 2: Misses & Stagnant Items */}
        {step === 2 && (
          <div className="space-y-4 text-xs">
            {stagnantGoals.length > 0 && (
              <div className="p-3 rounded-xl bg-rose-500/10 border border-rose-500/20 text-rose-600 dark:text-rose-400 space-y-1">
                <div className="flex items-center gap-1.5 font-semibold">
                  <AlertCircle className="w-3.5 h-3.5" />
                  <span>Stagnant Goals Alert</span>
                </div>
                <p className="text-[11px]">
                  {stagnantGoals.map((g) => g.title).join(', ')} have not received recent activity.
                </p>
              </div>
            )}

            <div className="space-y-1.5">
              <label className="font-semibold text-[var(--text-secondary)]">
                What slipped through the cracks or encountered friction?
              </label>
              <textarea
                value={misses}
                onChange={(e) => setMisses(e.target.value)}
                placeholder="• Delayed the database migration due to unexpected dependencies&#10;• Skipped exercise on Thursday"
                rows={4}
                className="w-full p-3 rounded-xl bg-[var(--bg-surface-input)] border border-[var(--border-default)] resize-none text-xs text-[var(--text-primary)] placeholder-[var(--text-tertiary)] focus:outline-hidden"
              />
            </div>
          </div>
        )}

        {/* Step 3: Key Insights */}
        {step === 3 && (
          <div className="space-y-2 text-xs">
            <label className="font-semibold text-[var(--text-secondary)]">
              What did you learn about your energy, focus, or system this week?
            </label>
            <textarea
              value={takeaways}
              onChange={(e) => setTakeaways(e.target.value)}
              placeholder="Morning 9-11 AM is by far my highest cognitive leverage window. Need to guard it from non-critical communications."
              rows={4}
              className="w-full p-3 rounded-xl bg-[var(--bg-surface-input)] border border-[var(--border-default)] resize-none text-xs text-[var(--text-primary)] placeholder-[var(--text-tertiary)] focus:outline-hidden"
            />
          </div>
        )}

        {/* Step 4: Next Priorities */}
        {step === 4 && (
          <div className="space-y-2 text-xs">
            <label className="font-semibold text-[var(--text-secondary)]">
              High-Impact Priorities for the Coming Week (Max 3):
            </label>
            <textarea
              value={nextPriorities}
              onChange={(e) => setNextPriorities(e.target.value)}
              placeholder="1. Complete Alpha testing cycle&#10;2. Schedule investor update&#10;3. Protect 3 morning focus blocks"
              rows={4}
              className="w-full p-3 rounded-xl bg-[var(--bg-surface-input)] border border-[var(--border-default)] resize-none text-xs text-[var(--text-primary)] placeholder-[var(--text-tertiary)] focus:outline-hidden"
            />
          </div>
        )}

        {/* Navigation buttons */}
        <div className="flex items-center justify-between pt-3 border-t border-[var(--border-default)] text-xs">
          {step > 1 ? (
            <button
              onClick={() => setStep((prev) => (prev - 1) as any)}
              className="active-press px-3 py-1.5 rounded-lg text-[var(--text-secondary)] hover:text-[var(--text-primary)] font-medium cursor-pointer"
            >
              Back
            </button>
          ) : (
            <div />
          )}

          {step < 4 ? (
            <button
              onClick={() => setStep((prev) => (prev + 1) as any)}
              className="active-press flex items-center gap-1.5 px-4 py-2 rounded-xl bg-[var(--accent)] text-[var(--accent-text)] font-semibold hover:opacity-90 shadow-xs cursor-pointer"
            >
              <span>Next</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          ) : (
            <button
              onClick={handleFinishReview}
              className="active-press px-4 py-2 rounded-xl bg-emerald-600 text-white font-semibold hover:bg-emerald-700 shadow-xs cursor-pointer"
            >
              Complete & Sync Review
            </button>
          )}
        </div>
      </motion.div>
    </div>
  );
};
