import React, { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  X,
  BookOpen,
  Sparkles,
  Search,
  ArrowRight,
  Compass,
  Play,
  RotateCcw,
  CheckCircle2,
  Smartphone,
  Command,
  Wrench,
  HelpCircle,
  ChevronRight,
  Layers,
  Zap,
  ShieldCheck,
} from 'lucide-react';
import { useLifeOS } from '../../context/LifeOSContext';
import { LIFE_OS_FEATURE_REGISTRY } from '../../data/featureRegistry';
import { FeatureRegistryItem } from '../../types';

type HelpTab = 'tutor' | 'manual' | 'gestures' | 'troubleshooting';

export const HelpModal: React.FC = () => {
  const {
    isHelpOpen,
    setIsHelpOpen,
    setActiveNav,
    setPlanSubNav,
    setNotesSubNav,
    setLifeSubNav,
    setIsCaptureOpen,
    setIsSettingsOpen,
    executeAppAction,
    undoAction,
    undoStack,
    showToast,
  } = useLifeOS();

  const [activeTab, setActiveTab] = useState<HelpTab>('tutor');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [selectedFeature, setSelectedFeature] = useState<FeatureRegistryItem | null>(null);
  const [tutorQuery, setTutorQuery] = useState('');
  const [tutorAnswer, setTutorAnswer] = useState<{
    text: string;
    feature?: FeatureRegistryItem;
    explanation?: string[];
  } | null>(null);
  const [isExecuting, setIsExecuting] = useState(false);

  // Filter features based on search & category
  const filteredFeatures = useMemo(() => {
    return LIFE_OS_FEATURE_REGISTRY.filter((item) => {
      const matchesCat = selectedCategory === 'all' || item.category === selectedCategory;
      const q = searchQuery.toLowerCase().trim();
      if (!q) return matchesCat;
      const matchesSearch =
        item.name.toLowerCase().includes(q) ||
        item.summary.toLowerCase().includes(q) ||
        item.detailedSteps.some((s) => s.toLowerCase().includes(q)) ||
        item.tips.some((t) => t.toLowerCase().includes(q));
      return matchesCat && matchesSearch;
    });
  }, [searchQuery, selectedCategory]);

  if (!isHelpOpen) return null;

  // Handle Tutor Q&A from Actual Registry
  const handleTutorSubmit = (queryText: string) => {
    const q = queryText.trim().toLowerCase();
    if (!q) return;

    // Search registry for best match
    const matched = LIFE_OS_FEATURE_REGISTRY.find((f) => {
      const nameMatch = f.name.toLowerCase().includes(q) || q.includes(f.name.toLowerCase());
      const catMatch = q.includes(f.category);
      const contentMatch =
        f.summary.toLowerCase().includes(q) ||
        f.detailedSteps.some((s) => s.toLowerCase().includes(q));
      return nameMatch || catMatch || contentMatch;
    }) || LIFE_OS_FEATURE_REGISTRY[0];

    setSelectedFeature(matched);

    let answerText = `Here is how "${matched.name}" works in Life OS: ${matched.summary}`;
    if (q.includes('undo')) {
      answerText = `Every reversible AI action in Life OS generates an instant snapshot saved to the Undo stack. You can tap "Undo" on toasts or in the AI Partner view to safely restore the exact previous state.`;
    } else if (q.includes('gesture') || q.includes('swipe')) {
      answerText = `On mobile, you can swipe horizontally left or right anywhere across the screen to transition fluidly between Home, Tasks, Plan, Notes, Life, and AI views.`;
    } else if (q.includes('offline') || q.includes('install') || q.includes('pwa')) {
      answerText = `Life OS is a Progressive Web App (PWA). All data is cached locally in your browser storage so it operates 100% offline. On iOS Safari, tap Share → "Add to Home Screen". On Android/Chrome, tap "Install".`;
    } else if (q.includes('gemini') || q.includes('key') || q.includes('api')) {
      answerText = `You can enter your Gemini or OpenAI API key in Settings → AI Backbone. Keys are passed via secure proxy headers and never exposed client-side. The app also includes local heuristic intelligence if no key is provided.`;
    }

    setTutorAnswer({
      text: answerText,
      feature: matched,
      explanation: matched.detailedSteps,
    });
  };

  // 1. Guide user to target view
  const handleGuideMe = (feature: FeatureRegistryItem) => {
    if (feature.targetNav) {
      setActiveNav(feature.targetNav);
    }
    if (feature.targetSubNav) {
      if (feature.targetNav === 'plan') setPlanSubNav(feature.targetSubNav as any);
      if (feature.targetNav === 'notes') setNotesSubNav(feature.targetSubNav as any);
      if (feature.targetNav === 'life') setLifeSubNav(feature.targetSubNav as any);
    }
    if (feature.id === 'universal-quick-capture') {
      setIsCaptureOpen(true);
    } else if (feature.id === 'settings-sync-backup') {
      setIsSettingsOpen(true);
    }
    setIsHelpOpen(false);
    showToast(`Guided to ${feature.name}`, 'info');
  };

  // 2. Do it for me (Automated App Action with Verification & Undo)
  const handleDoItForMe = async (feature: FeatureRegistryItem) => {
    if (!feature.sampleAction) {
      handleGuideMe(feature);
      return;
    }

    setIsExecuting(true);
    try {
      const result = await executeAppAction({
        id: 'help-action-' + Date.now(),
        actionType: feature.sampleAction.actionType,
        title: feature.sampleAction.label,
        description: `Triggered via AI Tutor for ${feature.name}`,
        requiresConfirmation: false,
        undoable: true,
        payload: feature.sampleAction.payload,
        status: 'planned',
      });

      if (result.ok) {
        setIsHelpOpen(false);
        if (feature.targetNav) setActiveNav(feature.targetNav);
      }
    } finally {
      setIsExecuting(false);
    }
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="help-modal-title"
      className="fixed inset-0 z-50 bg-black/60 backdrop-blur-md flex items-end sm:items-center justify-center p-0 sm:p-4 overflow-y-auto animate-fadeIn"
      onClick={(e) => {
        if (e.target === e.currentTarget) setIsHelpOpen(false);
      }}
    >
      <motion.div
        initial={{ opacity: 0, y: 30, scale: 0.98 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        exit={{ opacity: 0, y: 30, scale: 0.98 }}
        transition={{ type: 'spring', damping: 28, stiffness: 350 }}
        className="w-full sm:max-w-2xl bg-[var(--bg-surface-elevated)] border-t sm:border border-[var(--border-default)] rounded-t-3xl sm:rounded-3xl shadow-2xl flex flex-col max-h-[94dvh] sm:max-h-[88vh] h-[94dvh] sm:h-auto overflow-hidden text-[var(--text-primary)] pb-safe"
      >
        {/* Mobile Pull/Drag Indicator */}
        <div className="w-12 h-1.5 bg-[var(--border-default)] rounded-full mx-auto mt-2.5 sm:hidden shrink-0" />

        {/* Modal Header */}
        <div className="flex items-center justify-between px-3.5 sm:px-6 py-3 border-b border-[var(--border-default)] shrink-0">
          <div className="flex items-center gap-2.5 min-w-0">
            <div className="w-8 h-8 rounded-xl bg-indigo-500/15 text-indigo-600 dark:text-indigo-400 flex items-center justify-center shadow-xs shrink-0">
              <BookOpen className="w-4 h-4 stroke-[2.4]" />
            </div>
            <div className="min-w-0">
              <h2 id="help-modal-title" className="text-sm sm:text-base font-bold text-[var(--text-primary)] leading-tight truncate">
                How to Use Life OS
              </h2>
              <p className="text-[10px] sm:text-[11px] text-[var(--text-secondary)] truncate">
                AI Tutor, Feature Manual & Interactive Guide
              </p>
            </div>
          </div>

          <button
            onClick={() => setIsHelpOpen(false)}
            className="active-press p-2 rounded-xl text-[var(--text-tertiary)] hover:text-[var(--text-primary)] hover:bg-[var(--ui-hover)] transition-colors cursor-pointer min-w-[36px] min-h-[36px] flex items-center justify-center shrink-0"
            aria-label="Close Guide"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Top Navigation Tabs */}
        <div className="flex items-center gap-1 px-4 sm:px-6 pt-2.5 pb-2 border-b border-[var(--border-default)] bg-[var(--bg-surface-subtle)] overflow-x-auto no-scrollbar shrink-0">
          {[
            { id: 'tutor', label: 'AI Tutor & Assistant', icon: Sparkles },
            { id: 'manual', label: 'Feature Manual', icon: BookOpen },
            { id: 'gestures', label: 'Gestures & Keys', icon: Smartphone },
            { id: 'troubleshooting', label: 'Troubleshooting', icon: Wrench },
          ].map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as HelpTab)}
                className={`active-press flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-all cursor-pointer ${
                  isActive
                    ? 'bg-[var(--bg-surface-elevated)] text-[var(--text-primary)] shadow-xs border border-[var(--border-default)]'
                    : 'text-[var(--text-secondary)] hover:text-[var(--text-primary)]'
                }`}
              >
                <Icon className={`w-3.5 h-3.5 ${isActive ? 'text-indigo-500' : ''}`} />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>

        {/* Modal Scrollable Body */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-5 no-scrollbar">
          {/* 1. AI TUTOR TAB */}
          {activeTab === 'tutor' && (
            <div className="space-y-4">
              {/* Natural language question input */}
              <div className="p-3.5 rounded-2xl bg-[var(--bg-surface-subtle)] border border-[var(--border-default)] space-y-2.5">
                <label htmlFor="tutor-question-input" className="text-xs font-semibold text-[var(--text-primary)] flex items-center gap-1.5">
                  <Sparkles className="w-3.5 h-3.5 text-indigo-500" />
                  Ask AI Tutor anything about using the app
                </label>
                <form
                  onSubmit={(e) => {
                    e.preventDefault();
                    handleTutorSubmit(tutorQuery);
                  }}
                  className="flex items-center gap-2"
                >
                  <input
                    id="tutor-question-input"
                    type="text"
                    value={tutorQuery}
                    onChange={(e) => setTutorQuery(e.target.value)}
                    placeholder="e.g. How does quick capture work? How do I undo?"
                    className="flex-1 px-3 py-2 rounded-xl text-xs bg-[var(--bg-surface-elevated)] border border-[var(--border-default)] text-[var(--text-primary)] placeholder-[var(--text-tertiary)] focus:outline-hidden"
                  />
                  <button
                    type="submit"
                    disabled={!tutorQuery.trim()}
                    className="active-press px-3.5 py-2 rounded-xl text-xs font-semibold bg-[var(--accent)] text-[var(--accent-text)] hover:opacity-90 disabled:opacity-40 transition-colors shadow-xs cursor-pointer"
                  >
                    Ask
                  </button>
                </form>

                {/* Quick Prompts Chips */}
                <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar pt-1">
                  <span className="text-[10px] text-[var(--text-tertiary)] font-semibold shrink-0">
                    Try:
                  </span>
                  {[
                    'How does Quick Capture work?',
                    'How to connect Gemini key?',
                    'How does AI Undo work?',
                    'Mobile gestures guide',
                    'How to install PWA?',
                  ].map((prompt) => (
                    <button
                      key={prompt}
                      onClick={() => {
                        setTutorQuery(prompt);
                        handleTutorSubmit(prompt);
                      }}
                      className="active-press text-[11px] px-2.5 py-1 rounded-lg bg-[var(--bg-surface-elevated)] border border-[var(--border-default)] text-[var(--text-secondary)] hover:text-[var(--text-primary)] whitespace-nowrap cursor-pointer transition-colors"
                    >
                      {prompt}
                    </button>
                  ))}
                </div>
              </div>

              {/* AI Tutor Answer Card */}
              {tutorAnswer && (
                <div className="p-4 rounded-2xl bg-indigo-500/5 border border-indigo-500/20 space-y-3">
                  <div className="flex items-center gap-2">
                    <span className="w-2 h-2 rounded-full bg-indigo-500 animate-pulse" />
                    <h3 className="text-xs font-bold text-indigo-600 dark:text-indigo-400">
                      Tutor Response: {tutorAnswer.feature?.name}
                    </h3>
                  </div>
                  <p className="text-xs text-[var(--text-primary)] leading-relaxed">
                    {tutorAnswer.text}
                  </p>

                  {tutorAnswer.explanation && (
                    <div className="space-y-1.5 pt-1">
                      <h4 className="text-[10px] font-bold uppercase tracking-wider text-[var(--text-tertiary)]">
                        Exact Steps
                      </h4>
                      <div className="space-y-1">
                        {tutorAnswer.explanation.map((step, idx) => (
                          <div key={idx} className="text-xs text-[var(--text-secondary)] flex items-start gap-2">
                            <CheckCircle2 className="w-3.5 h-3.5 text-indigo-500 shrink-0 mt-0.5" />
                            <span>{step}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Explain → Guide → Do it for me Actions */}
                  {tutorAnswer.feature && (
                    <div className="pt-2 border-t border-indigo-500/15 flex flex-wrap items-center gap-2">
                      <button
                        onClick={() => handleGuideMe(tutorAnswer.feature!)}
                        className="active-press flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold bg-[var(--accent)] text-[var(--accent-text)] hover:opacity-90 shadow-xs cursor-pointer"
                      >
                        <Compass className="w-3.5 h-3.5" />
                        <span>Guide Me There</span>
                      </button>

                      {tutorAnswer.feature.sampleAction && (
                        <button
                          onClick={() => handleDoItForMe(tutorAnswer.feature!)}
                          disabled={isExecuting}
                          className="active-press flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold bg-emerald-600 text-white hover:bg-emerald-700 shadow-xs cursor-pointer disabled:opacity-50"
                        >
                          <Play className="w-3.5 h-3.5" />
                          <span>Do it for me: {tutorAnswer.feature.sampleAction.label}</span>
                        </button>
                      )}
                    </div>
                  )}
                </div>
              )}

              {/* The 9-Step Operating Philosophy */}
              <div className="p-4 rounded-2xl bg-[var(--bg-surface-elevated)] border border-[var(--border-default)] space-y-2 shadow-xs">
                <div className="flex items-center gap-2">
                  <div className="w-6 h-6 rounded-lg bg-[var(--accent)] text-[var(--accent-text)] flex items-center justify-center text-xs font-bold">
                    9
                  </div>
                  <h3 className="text-xs font-bold text-[var(--text-primary)]">
                    The 9-Step Operating Philosophy
                  </h3>
                </div>
                <p className="p-2.5 rounded-xl bg-[var(--bg-surface-subtle)] border border-[var(--border-default)] font-mono text-[11px] text-[var(--text-primary)] leading-relaxed">
                  Capture → Understand → Organize → Connect → Prioritize → Plan → Act → Learn → Improve
                </p>
                <p className="text-xs text-[var(--text-secondary)] leading-relaxed">
                  Life OS connects all parts of your life into one continuous, intelligent loop. Everything captured flows seamlessly into planning and execution.
                </p>
              </div>
            </div>
          )}

          {/* 2. COMPLETE FEATURE MANUAL TAB */}
          {activeTab === 'manual' && (
            <div className="space-y-4">
              {/* Search and Category Filters */}
              <div className="space-y-2">
                <div className="relative">
                  <Search className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-[var(--text-tertiary)]" />
                  <input
                    type="text"
                    placeholder="Search all features and workflows..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="w-full pl-9 pr-4 py-2 rounded-xl text-xs bg-[var(--bg-surface-subtle)] border border-[var(--border-default)] text-[var(--text-primary)] placeholder-[var(--text-tertiary)] focus:outline-hidden"
                  />
                </div>

                <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar">
                  {[
                    { id: 'all', label: 'All' },
                    { id: 'core', label: 'Core & Navigation' },
                    { id: 'tasks', label: 'Tasks' },
                    { id: 'plan', label: 'Plan & Goals' },
                    { id: 'notes', label: 'Notes & PARA' },
                    { id: 'life', label: 'Life & Habits' },
                    { id: 'ai', label: 'AI & Pipeline' },
                    { id: 'pwa', label: 'PWA & Offline' },
                  ].map((cat) => (
                    <button
                      key={cat.id}
                      onClick={() => setSelectedCategory(cat.id)}
                      className={`active-press px-2.5 py-1 rounded-lg text-[11px] font-semibold transition-colors whitespace-nowrap cursor-pointer ${
                        selectedCategory === cat.id
                          ? 'bg-[var(--accent)] text-[var(--accent-text)]'
                          : 'bg-[var(--bg-surface-subtle)] text-[var(--text-secondary)] hover:text-[var(--text-primary)] border border-[var(--border-default)]'
                      }`}
                    >
                      {cat.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Feature Cards Grid */}
              <div className="space-y-3">
                {filteredFeatures.map((feat) => (
                  <div
                    key={feat.id}
                    className="p-3.5 sm:p-4 rounded-2xl bg-[var(--bg-surface-elevated)] border border-[var(--border-default)] space-y-2.5 shadow-xs"
                  >
                    <div className="flex items-start justify-between gap-2">
                      <div>
                        <h4 className="text-xs sm:text-sm font-bold text-[var(--text-primary)]">
                          {feat.name}
                        </h4>
                        <p className="text-xs text-[var(--text-secondary)] mt-0.5 leading-relaxed">
                          {feat.summary}
                        </p>
                      </div>
                      <span className="text-[10px] uppercase font-bold px-2 py-0.5 rounded-md bg-[var(--bg-surface-subtle)] text-[var(--text-tertiary)] border border-[var(--border-default)] shrink-0">
                        {feat.category}
                      </span>
                    </div>

                    {/* Step by step */}
                    <div className="space-y-1 pt-1 border-t border-[var(--border-subtle)]">
                      {feat.detailedSteps.map((step, sIdx) => (
                        <p key={sIdx} className="text-xs text-[var(--text-secondary)] pl-2 border-l-2 border-indigo-500/40">
                          {step}
                        </p>
                      ))}
                    </div>

                    {/* Action buttons */}
                    <div className="flex items-center gap-2 pt-1">
                      <button
                        onClick={() => handleGuideMe(feat)}
                        className="active-press flex items-center gap-1 text-xs font-semibold text-[var(--accent)] hover:underline cursor-pointer"
                      >
                        <Compass className="w-3.5 h-3.5" />
                        <span>Go to {feat.name}</span>
                      </button>

                      {feat.sampleAction && (
                        <button
                          onClick={() => handleDoItForMe(feat)}
                          className="active-press ml-auto flex items-center gap-1 text-xs font-semibold text-emerald-600 dark:text-emerald-400 hover:underline cursor-pointer"
                        >
                          <Zap className="w-3.5 h-3.5" />
                          <span>Do it for me</span>
                        </button>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* 3. GESTURES & SHORTCUTS TAB */}
          {activeTab === 'gestures' && (
            <div className="space-y-4">
              <div className="space-y-2">
                <h3 className="text-xs font-bold uppercase tracking-wider text-[var(--text-tertiary)] flex items-center gap-1.5">
                  <Smartphone className="w-3.5 h-3.5 text-indigo-500" />
                  Mobile Touch Gestures
                </h3>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                  <div className="p-3 rounded-xl bg-[var(--bg-surface-subtle)] border border-[var(--border-default)] space-y-1">
                    <span className="font-bold text-[var(--text-primary)]">Swipe Left / Right</span>
                    <p className="text-[11px] text-[var(--text-secondary)]">
                      Swiftly swipe horizontally anywhere to transition between Home, Tasks, Plan, Notes, Life, and AI views.
                    </p>
                  </div>
                  <div className="p-3 rounded-xl bg-[var(--bg-surface-subtle)] border border-[var(--border-default)] space-y-1">
                    <span className="font-bold text-[var(--text-primary)]">Floating Quick Capture</span>
                    <p className="text-[11px] text-[var(--text-secondary)]">
                      Tap the round elevated (+) button at the bottom-right for universal one-tap capture from any view.
                    </p>
                  </div>
                  <div className="p-3 rounded-xl bg-[var(--bg-surface-subtle)] border border-[var(--border-default)] space-y-1">
                    <span className="font-bold text-[var(--text-primary)]">Pull Down to Dismiss</span>
                    <p className="text-[11px] text-[var(--text-secondary)]">
                      Tap backdrop or pull downward on modal sheets to smoothly dismiss.
                    </p>
                  </div>
                  <div className="p-3 rounded-xl bg-[var(--bg-surface-subtle)] border border-[var(--border-default)] space-y-1">
                    <span className="font-bold text-[var(--text-primary)]">Liquid Haptic Feel</span>
                    <p className="text-[11px] text-[var(--text-secondary)]">
                      Every button and card features micro-spring active press physics for tactile response.
                    </p>
                  </div>
                </div>
              </div>

              <div className="space-y-2">
                <h3 className="text-xs font-bold uppercase tracking-wider text-[var(--text-tertiary)] flex items-center gap-1.5">
                  <Command className="w-3.5 h-3.5 text-indigo-500" />
                  Keyboard Shortcuts (Desktop & iPad)
                </h3>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                  <div className="flex items-center justify-between p-2.5 rounded-xl bg-[var(--bg-surface-subtle)] border border-[var(--border-default)]">
                    <span>Universal Search</span>
                    <kbd className="px-1.5 py-0.5 rounded bg-[var(--bg-surface-elevated)] border border-[var(--border-default)] font-mono text-[10px]">
                      ⌘K / Ctrl+K
                    </kbd>
                  </div>
                  <div className="flex items-center justify-between p-2.5 rounded-xl bg-[var(--bg-surface-subtle)] border border-[var(--border-default)]">
                    <span>Quick Capture</span>
                    <kbd className="px-1.5 py-0.5 rounded bg-[var(--bg-surface-elevated)] border border-[var(--border-default)] font-mono text-[10px]">
                      C
                    </kbd>
                  </div>
                  <div className="flex items-center justify-between p-2.5 rounded-xl bg-[var(--bg-surface-subtle)] border border-[var(--border-default)]">
                    <span>Close Modal / Dismiss</span>
                    <kbd className="px-1.5 py-0.5 rounded bg-[var(--bg-surface-elevated)] border border-[var(--border-default)] font-mono text-[10px]">
                      Esc
                    </kbd>
                  </div>
                  <div className="flex items-center justify-between p-2.5 rounded-xl bg-[var(--bg-surface-subtle)] border border-[var(--border-default)]">
                    <span>How to Use Guide</span>
                    <kbd className="px-1.5 py-0.5 rounded bg-[var(--bg-surface-elevated)] border border-[var(--border-default)] font-mono text-[10px]">
                      Top Bar
                    </kbd>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* 4. TROUBLESHOOTING & FAQ TAB */}
          {activeTab === 'troubleshooting' && (
            <div className="space-y-3 text-xs">
              <div className="p-3.5 rounded-2xl bg-[var(--bg-surface-elevated)] border border-[var(--border-default)] space-y-1.5">
                <h4 className="font-bold text-[var(--text-primary)]">
                  Q: How do I install Life OS on iPhone or iPad?
                </h4>
                <p className="text-[var(--text-secondary)] leading-relaxed">
                  Open Life OS in Safari. Tap the <strong>Share</strong> button (square with arrow pointing up) at the bottom toolbar, scroll down and tap <strong>"Add to Home Screen"</strong>. It launches full-screen like a native iOS app.
                </p>
              </div>

              <div className="p-3.5 rounded-2xl bg-[var(--bg-surface-elevated)] border border-[var(--border-default)] space-y-1.5">
                <h4 className="font-bold text-[var(--text-primary)]">
                  Q: Does Life OS work without an internet connection?
                </h4>
                <p className="text-[var(--text-secondary)] leading-relaxed">
                  Yes! All tasks, calendar events, habits, and Second Brain notes are stored locally in your browser's persistent database. You can continue working completely offline.
                </p>
              </div>

              <div className="p-3.5 rounded-2xl bg-[var(--bg-surface-elevated)] border border-[var(--border-default)] space-y-1.5">
                <h4 className="font-bold text-[var(--text-primary)]">
                  Q: How does the AI Control Layer protect against accidental changes?
                </h4>
                <p className="text-[var(--text-secondary)] leading-relaxed">
                  All actions use the strict App Action pipeline: Understand → Context → Plan → Validate → Confirm → Execute → Verify → Save. Any reversible action can be instantly undone using the <strong>Undo</strong> button.
                </p>
              </div>

              <div className="p-3.5 rounded-2xl bg-[var(--bg-surface-elevated)] border border-[var(--border-default)] space-y-1.5">
                <h4 className="font-bold text-[var(--text-primary)]">
                  Q: How do I export my data or backup?
                </h4>
                <p className="text-[var(--text-secondary)] leading-relaxed">
                  Tap Settings (gear icon in the top header) → scroll down to <strong>"Data & Backup"</strong> → tap <strong>"Export JSON Backup"</strong>. You can restore this file on any device at any time.
                </p>
              </div>
            </div>
          )}
        </div>

        {/* Modal Footer with Quick Undo Stack Access */}
        <div className="px-4 sm:px-6 py-3 border-t border-[var(--border-default)] bg-[var(--bg-surface-subtle)] flex items-center justify-between text-xs shrink-0">
          <div className="flex items-center gap-2 text-[var(--text-secondary)]">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-500" />
            <span className="text-[11px]">Active Life OS Verified Architecture</span>
          </div>

          {undoStack.length > 0 && (
            <button
              onClick={() => undoAction()}
              className="active-press flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold bg-[var(--bg-surface-elevated)] border border-[var(--border-default)] hover:bg-[var(--ui-hover)] transition-colors cursor-pointer text-amber-600 dark:text-amber-400"
              title="Undo last action"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Undo Last ({undoStack.length})</span>
            </button>
          )}
        </div>
      </motion.div>
    </div>
  );
};
