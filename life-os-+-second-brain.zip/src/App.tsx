/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { LifeOSProvider, useLifeOS } from './context/LifeOSContext';
import { Header } from './components/layout/Header';
import { Navigation } from './components/layout/Navigation';
import { HomeView } from './components/home/HomeView';
import { TasksView } from './components/tasks/TasksView';
import { PlanView } from './components/plan/PlanView';
import { NotesView } from './components/notes/NotesView';
import { LifeView } from './components/life/LifeView';
import { AIView } from './components/ai/AIView';
import { TemplatesView } from './components/templates/TemplatesView';
import { UniversalCaptureModal } from './components/modals/UniversalCaptureModal';
import { UniversalSearchModal } from './components/modals/UniversalSearchModal';
import { FocusModal } from './components/modals/FocusModal';
import { WeeklyReviewModal } from './components/modals/WeeklyReviewModal';
import { SettingsModal } from './components/modals/SettingsModal';
import { HelpModal } from './components/modals/HelpModal';
import { TemplateModal } from './components/modals/TemplateModal';
import { ToastContainer } from './components/common/ToastContainer';
import { PWAInstallBanner } from './components/layout/PWAInstallBanner';
import { OnboardingScreen } from './components/onboarding/OnboardingScreen';
import { Plus } from 'lucide-react';
import { MainNav } from './types';

const NAV_ORDER: MainNav[] = ['home', 'tasks', 'plan', 'notes', 'life', 'templates', 'ai'];

const MainContent: React.FC = () => {
  const { settings, activeNav, setActiveNav, setIsCaptureOpen } = useLifeOS();

  // Track slide transition direction
  const prevNavRef = useRef<MainNav>(activeNav);
  const prevIndex = NAV_ORDER.indexOf(prevNavRef.current);
  const currentIndex = NAV_ORDER.indexOf(activeNav);
  const slideDirection = currentIndex >= prevIndex ? 1 : -1;
  prevNavRef.current = activeNav;

  // Touch gesture handling without interfering with inputs, sliders, or vertical scroll
  const touchStartRef = useRef<{ x: number; y: number; time: number } | null>(null);

  const handleTouchStart = (e: React.TouchEvent) => {
    const target = e.target as HTMLElement;
    // Don't intercept touches on inputs, textareas, sliders, buttons, or scrollable tables
    if (
      target.closest('input') ||
      target.closest('textarea') ||
      target.closest('button') ||
      target.closest('select') ||
      target.closest('[data-no-swipe]')
    ) {
      touchStartRef.current = null;
      return;
    }

    const touch = e.touches[0];
    touchStartRef.current = {
      x: touch.clientX,
      y: touch.clientY,
      time: Date.now(),
    };
  };

  const handleTouchEnd = (e: React.TouchEvent) => {
    if (!touchStartRef.current) return;
    const touch = e.changedTouches[0];
    const deltaX = touch.clientX - touchStartRef.current.x;
    const deltaY = touch.clientY - touchStartRef.current.y;
    const elapsedTime = Date.now() - touchStartRef.current.time;
    touchStartRef.current = null;

    // Strict conditions: swift swipe (< 400ms), significant distance (> 80px),
    // and distinctly horizontal (deltaX at least 2.2x deltaY)
    if (elapsedTime < 400 && Math.abs(deltaX) > 80 && Math.abs(deltaX) > Math.abs(deltaY) * 2.2) {
      const curIdx = NAV_ORDER.indexOf(activeNav);
      if (deltaX < 0 && curIdx < NAV_ORDER.length - 1) {
        // Swiped Left -> go to next tab
        setActiveNav(NAV_ORDER[curIdx + 1]);
      } else if (deltaX > 0 && curIdx > 0) {
        // Swiped Right -> go to prev tab
        setActiveNav(NAV_ORDER[curIdx - 1]);
      }
    }
  };

  // Enforce First-Time Onboarding Experience: Do not show main app until completed
  if (!settings.onboardingCompleted) {
    return (
      <div className="min-h-screen bg-[var(--bg-app)] text-[var(--text-primary)] transition-colors">
        <OnboardingScreen />
        <ToastContainer />
      </div>
    );
  }

  return (
    <div
      className="min-h-screen flex flex-col bg-[var(--bg-app)] text-[var(--text-primary)] transition-colors overflow-x-hidden"
      onTouchStart={handleTouchStart}
      onTouchEnd={handleTouchEnd}
    >
      {/* Top Bar with Settings Icon */}
      <Header />

      {/* Primary Navigation & Sub-Navigation */}
      <Navigation />

      {/* Dynamic View Canvas with Fluid Hardware-Accelerated Transitions */}
      <main id="main-content" className="flex-1 pb-24 sm:pb-16 relative w-full overflow-x-hidden">
        <AnimatePresence mode="wait" initial={false}>
          <motion.div
            key={activeNav}
            initial={{ opacity: 0, x: slideDirection * 16 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -slideDirection * 16 }}
            transition={{
              type: 'spring',
              stiffness: 400,
              damping: 34,
            }}
            className="w-full h-full"
          >
            {activeNav === 'home' && <HomeView />}
            {activeNav === 'tasks' && <TasksView />}
            {activeNav === 'plan' && <PlanView />}
            {activeNav === 'notes' && <NotesView />}
            {activeNav === 'life' && <LifeView />}
            {activeNav === 'templates' && <TemplatesView />}
            {activeNav === 'ai' && <AIView />}
          </motion.div>
        </AnimatePresence>
      </main>

      {/* Floating Action Quick Capture Button (iOS round elevation) */}
      <motion.button
        id="floating-quick-capture"
        whileHover={{ scale: 1.06 }}
        whileTap={{ scale: 0.92 }}
        transition={{ type: 'spring', stiffness: 500, damping: 28 }}
        onClick={() => setIsCaptureOpen(true)}
        className="active-press fixed bottom-20 sm:bottom-6 right-4 sm:right-6 z-30 w-13 h-13 rounded-full bg-[var(--accent)] text-[var(--accent-text)] shadow-xl border border-white/20 flex items-center justify-center cursor-pointer group"
        title="Universal Quick Capture (Press C)"
        aria-label="Quick Capture"
      >
        <Plus className="w-6 h-6 stroke-[2.4] group-hover:rotate-90 transition-transform duration-200" />
      </motion.button>

      {/* Global Modals & Overlays */}
      <UniversalCaptureModal />
      <UniversalSearchModal />
      <TemplateModal />
      <FocusModal />
      <WeeklyReviewModal />
      <SettingsModal />
      <HelpModal />
      <PWAInstallBanner />
      <ToastContainer />
    </div>
  );
};

export default function App() {
  return (
    <LifeOSProvider>
      <MainContent />
    </LifeOSProvider>
  );
}
